##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:10 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 18431 atoms
Valist_getStatistics:  Max atom coordinate:  (72.41, 59.598, 163.546)
Valist_getStatistics:  Min atom coordinate:  (-38.903, -46.971, 35.276)
Valist_getStatistics:  Molecule center:  (16.7535, 6.3135, 99.411)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.788089, 0.916056, 0.876406
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.683922, 0.791056, 0.77224
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.867824, 0.863545, 0.881143 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 92.41 79.598 183.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -58.903 -66.971 15.276
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 82.41 69.598 173.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -48.903 -56.971 25.276
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 82.41 69.598 173.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -48.903 -56.971 25.276
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.854224
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.758251e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.237930e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.537960e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.555257e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.133481e-02
Vprtstp: contraction number = 6.133481e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.619763e-03
Vprtstp: contraction number = 1.568402e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.738063e-03
Vprtstp: contraction number = 2.846290e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.012492e-03
Vprtstp: contraction number = 3.697838e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.505878e-04
Vprtstp: contraction number = 5.437950e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.859933e-04
Vprtstp: contraction number = 5.194327e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.862397e-04
Vprtstp: contraction number = 6.512031e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.042743e-04
Vprtstp: contraction number = 5.598929e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.019916e-05
Vprtstp: contraction number = 6.732164e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.990117e-05
Vprtstp: contraction number = 5.683995e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.711965e-05
Vprtstp: contraction number = 6.796705e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.545221e-05
Vprtstp: contraction number = 5.697792e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.054639e-05
Vprtstp: contraction number = 6.825165e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.005968e-06
Vprtstp: contraction number = 5.694810e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.107725e-06
Vprtstp: contraction number = 6.839406e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.336986e-06
Vprtstp: contraction number = 5.689247e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.600387e-06
Vprtstp: contraction number = 6.848081e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 9.097842e-07
Vprtstp: contraction number = 5.684776e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.124110e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.877572e+00
Vpmg_setPart:  lower corner = (-58.903, -66.971, 15.276)
Vpmg_setPart:  upper corner = (92.41, 79.598, 183.546)
Vpmg_setPart:  actual minima = (-58.903, -66.971, 15.276)
Vpmg_setPart:  actual maxima = (92.41, 79.598, 183.546)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -48.903, -56.971, 25.276
VPMG::focusFillBound -- New mesh maxs = 82.41, 69.598, 173.546
VPMG::focusFillBound -- Old mesh mins = -58.903, -66.971, 15.276
VPMG::focusFillBound -- Old mesh maxs = 92.41, 79.598, 183.546
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.851943
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.938155e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.247610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.539820e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.539672e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.206763e-02
Vprtstp: contraction number = 7.206763e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.095376e-02
Vprtstp: contraction number = 1.519928e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.851013e-03
Vprtstp: contraction number = 2.602771e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.012464e-03
Vprtstp: contraction number = 3.551244e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.044984e-04
Vprtstp: contraction number = 4.982876e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.552283e-04
Vprtstp: contraction number = 5.059051e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.591872e-04
Vprtstp: contraction number = 6.237051e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.033563e-05
Vprtstp: contraction number = 5.674805e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.072558e-05
Vprtstp: contraction number = 6.722218e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.593926e-05
Vprtstp: contraction number = 5.918306e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.498089e-05
Vprtstp: contraction number = 6.950863e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.498033e-05
Vprtstp: contraction number = 5.996717e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.059263e-05
Vprtstp: contraction number = 7.071027e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.364602e-06
Vprtstp: contraction number = 6.008518e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.548508e-06
Vprtstp: contraction number = 7.146570e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.729976e-06
Vprtstp: contraction number = 6.001915e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.964794e-06
Vprtstp: contraction number = 7.197112e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.176512e-06
Vprtstp: contraction number = 5.987968e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 8.508453e-07
Vprtstp: contraction number = 7.231928e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.523373e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.280668e+00
Vpmg_setPart:  lower corner = (-48.903, -56.971, 25.276)
Vpmg_setPart:  upper corner = (82.41, 69.598, 173.546)
Vpmg_setPart:  actual minima = (-48.903, -56.971, 25.276)
Vpmg_setPart:  actual maxima = (82.41, 69.598, 173.546)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.338816e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 18431 atoms
Valist_getStatistics:  Max atom coordinate:  (72.41, 59.598, 163.546)
Valist_getStatistics:  Min atom coordinate:  (-38.903, -46.971, 35.276)
Valist_getStatistics:  Molecule center:  (16.7535, 6.3135, 99.411)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.788089, 0.916056, 0.876406
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.683922, 0.791056, 0.77224
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.867824, 0.863545, 0.881143 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 92.41 79.598 183.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -58.903 -66.971 15.276
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 82.41 69.598 173.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -48.903 -56.971 25.276
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 82.41 69.598 173.546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -48.903 -56.971 25.276
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.871621
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.782644e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.254670e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.695600e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.290825e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 21224745.253958
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.638472e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.243763e+06
Vprtstp: contraction number = 1.243763e+06
Vnewton: Attempting damping, relres = 0.062980
Vnewton: Attempting damping, relres = 0.521578
Vnewton: Damping accepted, relres = 0.062980
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.297959e-02
Vprtstp: contraction number = 6.297959e-02
Vnewton: Using errtol_s: 1336725.838441
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.461869e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.649235e+05
Vprtstp: contraction number = 1.649235e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.320637e-03
Vprtstp: contraction number = 1.479946e-01
Vnewton: Using errtol_s: 197828.139768
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.100583e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.968838e+04
Vprtstp: contraction number = 2.968838e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.788075e-03
Vprtstp: contraction number = 1.918404e-01
Vnewton: Using errtol_s: 37951.430300
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.742260e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.854587e+03
Vprtstp: contraction number = 6.854587e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.006633e-04
Vprtstp: contraction number = 2.240753e-01
Vnewton: Using errtol_s: 8503.976767
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.394175e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.887716e+03
Vprtstp: contraction number = 1.887716e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.371735e-05
Vprtstp: contraction number = 2.339055e-01
Vnewton: Using errtol_s: 1989.126909
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.041098e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.171974e+02
Vprtstp: contraction number = 5.171974e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.220170e-05
Vprtstp: contraction number = 2.369006e-01
Vnewton: Using errtol_s: 471.225393
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.693577e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.332546e+02
Vprtstp: contraction number = 1.332546e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.652268e-06
Vprtstp: contraction number = 2.545872e-01
Vnewton: Using errtol_s: 119.967943
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.349606e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.243204e+01
Vprtstp: contraction number = 3.243204e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.375305e-06
Vprtstp: contraction number = 2.433191e-01
Vnewton: Using errtol_s: 29.190489
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.000629e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.735819e+00
Vprtstp: contraction number = 9.735819e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.128376e-07
Vprtstp: contraction number = 3.001790e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.225498e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.689483e+00
Vpmg_setPart:  lower corner = (-58.903, -66.971, 15.276)
Vpmg_setPart:  upper corner = (92.41, 79.598, 183.546)
Vpmg_setPart:  actual minima = (-58.903, -66.971, 15.276)
Vpmg_setPart:  actual maxima = (92.41, 79.598, 183.546)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -48.903, -56.971, 25.276
VPMG::focusFillBound -- New mesh maxs = 82.41, 69.598, 173.546
VPMG::focusFillBound -- Old mesh mins = -58.903, -66.971, 15.276
VPMG::focusFillBound -- Old mesh maxs = 92.41, 79.598, 183.546
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.856765
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.965888e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.264960e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.740110e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.497493e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 23824837.304161
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.532991e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.709386e+06
Vprtstp: contraction number = 1.709386e+06
Vnewton: Attempting damping, relres = 0.073371
Vnewton: Attempting damping, relres = 0.528164
Vnewton: Damping accepted, relres = 0.073371
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.337143e-02
Vprtstp: contraction number = 7.337143e-02
Vnewton: Using errtol_s: 1748062.273440
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.616864e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.279091e+05
Vprtstp: contraction number = 2.279091e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.058231e-02
Vprtstp: contraction number = 1.442293e-01
Vnewton: Using errtol_s: 252121.783343
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.682969e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.866285e+04
Vprtstp: contraction number = 3.866285e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.903681e-03
Vprtstp: contraction number = 1.798928e-01
Vnewton: Using errtol_s: 45354.893600
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.749288e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.200638e+03
Vprtstp: contraction number = 8.200638e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.997465e-04
Vprtstp: contraction number = 2.099860e-01
Vnewton: Using errtol_s: 9523.894457
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.815515e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.185036e+03
Vprtstp: contraction number = 2.185036e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.185661e-05
Vprtstp: contraction number = 2.297872e-01
Vnewton: Using errtol_s: 2188.468811
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.881588e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.946782e+02
Vprtstp: contraction number = 5.946782e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.260776e-05
Vprtstp: contraction number = 2.461201e-01
Vnewton: Using errtol_s: 538.626134
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.947699e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.563938e+02
Vprtstp: contraction number = 1.563938e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.914862e-06
Vprtstp: contraction number = 2.616297e-01
Vnewton: Using errtol_s: 140.920619
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.013784e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.508501e+01
Vprtstp: contraction number = 4.508501e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.703354e-06
Vprtstp: contraction number = 2.879787e-01
Vnewton: Using errtol_s: 40.582141
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.079716e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.463458e+01
Vprtstp: contraction number = 1.463458e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.529273e-07
Vprtstp: contraction number = 3.246108e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.333306e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.802698e+00
Vpmg_setPart:  lower corner = (-48.903, -56.971, 25.276)
Vpmg_setPart:  upper corner = (82.41, 69.598, 173.546)
Vpmg_setPart:  actual minima = (-48.903, -56.971, 25.276)
Vpmg_setPart:  actual maxima = (82.41, 69.598, 173.546)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.271312e+01
