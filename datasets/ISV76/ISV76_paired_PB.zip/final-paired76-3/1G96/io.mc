##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:21 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3430 atoms
Valist_getStatistics:  Max atom coordinate:  (101.375, 32.333, 36.533)
Valist_getStatistics:  Min atom coordinate:  (39.155, -32.333, -4.967)
Valist_getStatistics:  Molecule center:  (70.265, 0, 15.783)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 70.265 0 15.783
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 70.265 0 15.783
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.798594, 0.817703, 0.848958
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.642344, 0.661453, 0.640625
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.804344, 0.808916, 0.754601 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 70.265 0 15.783
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 121.375 52.333 56.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 19.155 -52.333 -24.967
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 111.375 42.333 46.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 29.155 -42.333 -14.967
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 111.375 42.333 46.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 29.155 -42.333 -14.967
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.4518
Vpbe_ctor2:  solute dimensions = 65.194 x 67.088 x 44.543
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (75, 77.446, 54.28)
Vclist_setupGrid:  Grid lower corner = (32.765, -38.723, -11.357)
Vclist_assignAtoms:  Have 4424989 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.405054
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.773480e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.413800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.844900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.313250e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.444975e-02
Vprtstp: contraction number = 6.444975e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.113662e-03
Vprtstp: contraction number = 1.258913e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.238366e-03
Vprtstp: contraction number = 1.526272e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.063000e-04
Vprtstp: contraction number = 1.665905e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.757470e-05
Vprtstp: contraction number = 1.821363e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.314218e-06
Vprtstp: contraction number = 1.946580e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.408320e-06
Vprtstp: contraction number = 1.925455e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.019094e-07
Vprtstp: contraction number = 2.143757e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.370820e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.794680e-01
Vpmg_setPart:  lower corner = (19.155, -52.333, -24.967)
Vpmg_setPart:  upper corner = (121.375, 52.333, 56.533)
Vpmg_setPart:  actual minima = (19.155, -52.333, -24.967)
Vpmg_setPart:  actual maxima = (121.375, 52.333, 56.533)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.4518
Vpbe_ctor2:  solute dimensions = 65.194 x 67.088 x 44.543
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (75, 77.446, 54.28)
Vclist_setupGrid:  Grid lower corner = (32.765, -38.723, -11.357)
Vclist_assignAtoms:  Have 4424989 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 29.155, -42.333, -14.967
VPMG::focusFillBound -- New mesh maxs = 111.375, 42.333, 46.533
VPMG::focusFillBound -- Old mesh mins = 19.155, -52.333, -24.967
VPMG::focusFillBound -- Old mesh maxs = 121.375, 52.333, 56.533
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.400200
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.647380e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.471000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.944900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.281847e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.747106e-02
Vprtstp: contraction number = 8.747106e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.127725e-02
Vprtstp: contraction number = 1.289255e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.715575e-03
Vprtstp: contraction number = 1.521270e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.043872e-04
Vprtstp: contraction number = 1.774258e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.877567e-05
Vprtstp: contraction number = 1.930951e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.365670e-05
Vprtstp: contraction number = 2.323529e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.863508e-06
Vprtstp: contraction number = 2.096779e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.680054e-07
Vprtstp: contraction number = 2.682044e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.494050e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.938290e-01
Vpmg_setPart:  lower corner = (29.155, -42.333, -14.967)
Vpmg_setPart:  upper corner = (111.375, 42.333, 46.533)
Vpmg_setPart:  actual minima = (29.155, -42.333, -14.967)
Vpmg_setPart:  actual maxima = (111.375, 42.333, 46.533)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.175024e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3430 atoms
Valist_getStatistics:  Max atom coordinate:  (101.375, 32.333, 36.533)
Valist_getStatistics:  Min atom coordinate:  (39.155, -32.333, -4.967)
Valist_getStatistics:  Molecule center:  (70.265, 0, 15.783)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 70.265 0 15.783
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 70.265 0 15.783
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.798594, 0.817703, 0.848958
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.642344, 0.661453, 0.640625
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.804344, 0.808916, 0.754601 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 70.265 0 15.783
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 121.375 52.333 56.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 19.155 -52.333 -24.967
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 111.375 42.333 46.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 29.155 -42.333 -14.967
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 111.375 42.333 46.533
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 29.155 -42.333 -14.967
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.4518
Vpbe_ctor2:  solute dimensions = 65.194 x 67.088 x 44.543
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (75, 77.446, 54.28)
Vclist_setupGrid:  Grid lower corner = (32.765, -38.723, -11.357)
Vclist_assignAtoms:  Have 4424989 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.406026
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.795700e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.417400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.978300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.137980e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4162230.006754
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.087070e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.807027e+05
Vprtstp: contraction number = 2.807027e+05
Vnewton: Attempting damping, relres = 0.061124
Vnewton: Attempting damping, relres = 0.525672
Vnewton: Damping accepted, relres = 0.061124
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.112433e-02
Vprtstp: contraction number = 6.112433e-02
Vnewton: Using errtol_s: 254413.505448
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.109393e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.525899e+04
Vprtstp: contraction number = 3.525899e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.625595e-03
Vprtstp: contraction number = 1.247555e-01
Vnewton: Using errtol_s: 31739.479601
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.260988e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.189824e+03
Vprtstp: contraction number = 5.189824e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.122226e-03
Vprtstp: contraction number = 1.471657e-01
Vnewton: Using errtol_s: 4670.964026
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.411715e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.470044e+02
Vprtstp: contraction number = 8.470044e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.831493e-04
Vprtstp: contraction number = 1.632018e-01
Vnewton: Using errtol_s: 762.309614
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.565347e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.489951e+02
Vprtstp: contraction number = 1.489951e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.221730e-05
Vprtstp: contraction number = 1.759073e-01
Vnewton: Using errtol_s: 134.095812
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.716943e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.763990e+01
Vprtstp: contraction number = 2.763990e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.976584e-06
Vprtstp: contraction number = 1.855085e-01
Vnewton: Using errtol_s: 24.875917
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.874420e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.334927e+00
Vprtstp: contraction number = 5.334927e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.153573e-06
Vprtstp: contraction number = 1.930154e-01
Vnewton: Using errtol_s: 4.801435
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.028635e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.067595e+00
Vprtstp: contraction number = 1.067595e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.308463e-07
Vprtstp: contraction number = 2.001142e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.331185e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.453573e+00
Vpmg_setPart:  lower corner = (19.155, -52.333, -24.967)
Vpmg_setPart:  upper corner = (121.375, 52.333, 56.533)
Vpmg_setPart:  actual minima = (19.155, -52.333, -24.967)
Vpmg_setPart:  actual maxima = (121.375, 52.333, 56.533)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.4518
Vpbe_ctor2:  solute dimensions = 65.194 x 67.088 x 44.543
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (75, 77.446, 54.28)
Vclist_setupGrid:  Grid lower corner = (32.765, -38.723, -11.357)
Vclist_assignAtoms:  Have 4424989 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 29.155, -42.333, -14.967
VPMG::focusFillBound -- New mesh maxs = 111.375, 42.333, 46.533
VPMG::focusFillBound -- Old mesh mins = 19.155, -52.333, -24.967
VPMG::focusFillBound -- Old mesh maxs = 121.375, 52.333, 56.533
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.402025
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.747440e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.505600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.372800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.052006e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4955107.764623
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.149341e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.657268e+05
Vprtstp: contraction number = 4.657268e+05
Vnewton: Attempting damping, relres = 0.084899
Vnewton: Attempting damping, relres = 0.539068
Vnewton: Damping accepted, relres = 0.084899
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.489915e-02
Vprtstp: contraction number = 8.489915e-02
Vnewton: Using errtol_s: 420684.454719
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.353915e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.951630e+04
Vprtstp: contraction number = 5.951630e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.081096e-02
Vprtstp: contraction number = 1.273389e-01
Vnewton: Using errtol_s: 53569.494316
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.516070e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.800863e+03
Vprtstp: contraction number = 8.800863e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.598520e-03
Vprtstp: contraction number = 1.478610e-01
Vnewton: Using errtol_s: 7920.837862
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.674848e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.442864e+03
Vprtstp: contraction number = 1.442864e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.620690e-04
Vprtstp: contraction number = 1.639448e-01
Vnewton: Using errtol_s: 1298.580280
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.830176e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.577472e+02
Vprtstp: contraction number = 2.577472e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.681485e-05
Vprtstp: contraction number = 1.786356e-01
Vnewton: Using errtol_s: 231.972622
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.983872e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.935020e+01
Vprtstp: contraction number = 4.935020e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.963515e-06
Vprtstp: contraction number = 1.914673e-01
Vnewton: Using errtol_s: 44.415180
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.143701e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.000351e+01
Vprtstp: contraction number = 1.000351e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.816945e-06
Vprtstp: contraction number = 2.027046e-01
Vnewton: Using errtol_s: 9.003160
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.298934e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.112433e+00
Vprtstp: contraction number = 2.112433e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.836829e-07
Vprtstp: contraction number = 2.111692e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.365913e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.494031e+00
Vpmg_setPart:  lower corner = (29.155, -42.333, -14.967)
Vpmg_setPart:  upper corner = (111.375, 42.333, 46.533)
Vpmg_setPart:  actual minima = (29.155, -42.333, -14.967)
Vpmg_setPart:  actual maxima = (111.375, 42.333, 46.533)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.771002e+00
