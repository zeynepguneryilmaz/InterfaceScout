##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:47 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20632 atoms
Valist_getStatistics:  Max atom coordinate:  (43.286, 37.912, 33.174)
Valist_getStatistics:  Min atom coordinate:  (-43.286, -37.987, -33.091)
Valist_getStatistics:  Molecule center:  (0, -0.0375, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.791075, 0.905461, 0.830195
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.666075, 0.749211, 0.673945
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.841987, 0.827436, 0.811791 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 63.286 57.912 53.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -63.286 -57.987 -53.091
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 53.286 47.912 43.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -53.286 -47.987 -43.091
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 53.286 47.912 43.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -53.286 -47.987 -43.091
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14135393 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.899265
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.568456e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.810200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.659430e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.873273e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.819355e-02
Vprtstp: contraction number = 5.819355e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.301350e-03
Vprtstp: contraction number = 1.598347e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.088536e-03
Vprtstp: contraction number = 3.320524e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.021001e-03
Vprtstp: contraction number = 3.305778e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.222977e-04
Vprtstp: contraction number = 5.115544e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.144737e-04
Vprtstp: contraction number = 4.106348e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.115783e-04
Vprtstp: contraction number = 5.202423e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.980603e-05
Vprtstp: contraction number = 4.463775e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.526366e-05
Vprtstp: contraction number = 5.072410e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.195896e-05
Vprtstp: contraction number = 4.733662e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.940127e-06
Vprtstp: contraction number = 4.967093e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.931173e-06
Vprtstp: contraction number = 4.934528e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.433435e-06
Vprtstp: contraction number = 4.890313e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.273475e-07
Vprtstp: contraction number = 5.074156e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.622882e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.879717e+00
Vpmg_setPart:  lower corner = (-63.286, -57.987, -53.091)
Vpmg_setPart:  upper corner = (63.286, 57.912, 53.174)
Vpmg_setPart:  actual minima = (-63.286, -57.987, -53.091)
Vpmg_setPart:  actual maxima = (63.286, 57.912, 53.174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14135393 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -53.286, -47.987, -43.091
VPMG::focusFillBound -- New mesh maxs = 53.286, 47.912, 43.174
VPMG::focusFillBound -- Old mesh mins = -63.286, -57.987, -53.091
VPMG::focusFillBound -- Old mesh maxs = 63.286, 57.912, 53.174
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.888829
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.784683e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.531400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.651660e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.542227e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.015099e-02
Vprtstp: contraction number = 7.015099e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.905985e-03
Vprtstp: contraction number = 1.412095e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.157797e-03
Vprtstp: contraction number = 2.178276e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.830033e-04
Vprtstp: contraction number = 3.165281e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.927423e-04
Vprtstp: contraction number = 4.286103e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.429829e-04
Vprtstp: contraction number = 4.884259e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.372723e-05
Vprtstp: contraction number = 5.156366e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.951297e-05
Vprtstp: contraction number = 5.359345e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.086402e-05
Vprtstp: contraction number = 5.280298e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.150014e-05
Vprtstp: contraction number = 5.511949e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.083973e-06
Vprtstp: contraction number = 5.290346e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.395347e-06
Vprtstp: contraction number = 5.580805e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.793512e-06
Vprtstp: contraction number = 5.282265e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.006952e-06
Vprtstp: contraction number = 5.614412e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 5.310426e-07
Vprtstp: contraction number = 5.273764e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.733213e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.986531e+00
Vpmg_setPart:  lower corner = (-53.286, -47.987, -43.091)
Vpmg_setPart:  upper corner = (53.286, 47.912, 43.174)
Vpmg_setPart:  actual minima = (-53.286, -47.987, -43.091)
Vpmg_setPart:  actual maxima = (53.286, 47.912, 43.174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.185525e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:02 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20632 atoms
Valist_getStatistics:  Max atom coordinate:  (43.286, 37.912, 33.174)
Valist_getStatistics:  Min atom coordinate:  (-43.286, -37.987, -33.091)
Valist_getStatistics:  Molecule center:  (0, -0.0375, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.791075, 0.905461, 0.830195
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.666075, 0.749211, 0.673945
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.841987, 0.827436, 0.811791 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 63.286 57.912 53.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -63.286 -57.987 -53.091
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 53.286 47.912 43.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -53.286 -47.987 -43.091
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 53.286 47.912 43.174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -53.286 -47.987 -43.091
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14135393 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.897983
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.567964e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.524400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.128790e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.812577e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 23236921.729226
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.975930e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.319115e+06
Vprtstp: contraction number = 1.319115e+06
Vnewton: Attempting damping, relres = 0.992810
Vnewton: Attempting damping, relres = 0.522609
Vnewton: Attempting damping, relres = 0.760085
Vnewton: Damping accepted, relres = 0.522609
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.226086e-01
Vprtstp: contraction number = 5.226086e-01
Vnewton: Using errtol_s: 12143816.185937
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.368498e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.328249e+05
Vprtstp: contraction number = 7.328249e+05
Vnewton: Attempting damping, relres = 0.030060
Vnewton: Attempting damping, relres = 0.273514
Vnewton: Damping accepted, relres = 0.030060
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.005981e-02
Vprtstp: contraction number = 5.751878e-02
Vnewton: Using errtol_s: 698497.451554
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.692775e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.380503e+04
Vprtstp: contraction number = 9.380503e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.798564e-03
Vprtstp: contraction number = 1.263669e-01
Vnewton: Using errtol_s: 88266.933109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.943460e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.463705e+04
Vprtstp: contraction number = 1.463705e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.778854e-04
Vprtstp: contraction number = 1.521326e-01
Vnewton: Using errtol_s: 13428.278288
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.194827e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.649352e+03
Vprtstp: contraction number = 2.649352e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.025801e-04
Vprtstp: contraction number = 1.775094e-01
Vnewton: Using errtol_s: 2383.645010
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.445498e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.404192e+02
Vprtstp: contraction number = 5.404192e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.091943e-05
Vprtstp: contraction number = 2.039327e-01
Vnewton: Using errtol_s: 486.103119
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.697712e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.303592e+02
Vprtstp: contraction number = 1.303592e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.047406e-06
Vprtstp: contraction number = 2.412784e-01
Vnewton: Using errtol_s: 117.286176
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.949446e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.657770e+01
Vprtstp: contraction number = 3.657770e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.416493e-06
Vprtstp: contraction number = 2.806379e-01
Vnewton: Using errtol_s: 32.914948
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.202595e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.141953e+01
Vprtstp: contraction number = 1.141953e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.422651e-07
Vprtstp: contraction number = 3.122253e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.584657e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.780688e+00
Vpmg_setPart:  lower corner = (-63.286, -57.987, -53.091)
Vpmg_setPart:  upper corner = (63.286, 57.912, 53.174)
Vpmg_setPart:  actual minima = (-63.286, -57.987, -53.091)
Vpmg_setPart:  actual maxima = (63.286, 57.912, 53.174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14135393 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -53.286, -47.987, -43.091
VPMG::focusFillBound -- New mesh maxs = 53.286, 47.912, 43.174
VPMG::focusFillBound -- Old mesh mins = -63.286, -57.987, -53.091
VPMG::focusFillBound -- Old mesh maxs = 63.286, 57.912, 53.174
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.886694
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.779653e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.708800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.108830e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.038084e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 26979365.207045
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.054719e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.025975e+06
Vprtstp: contraction number = 2.025975e+06
Vnewton: Attempting damping, relres = 0.822336
Vnewton: Attempting damping, relres = 0.531666
Vnewton: Attempting damping, relres = 0.764750
Vnewton: Damping accepted, relres = 0.531666
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.316657e-01
Vprtstp: contraction number = 5.316657e-01
Vnewton: Using errtol_s: 14344002.784751
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.094403e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.130861e+06
Vprtstp: contraction number = 1.130861e+06
Vnewton: Attempting damping, relres = 0.038823
Vnewton: Attempting damping, relres = 0.283215
Vnewton: Damping accepted, relres = 0.038823
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.882289e-02
Vprtstp: contraction number = 7.302124e-02
Vnewton: Using errtol_s: 1047416.803889
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.127459e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.461636e+05
Vprtstp: contraction number = 1.461636e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.956518e-03
Vprtstp: contraction number = 1.276700e-01
Vnewton: Using errtol_s: 133723.699747
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.152872e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.262946e+04
Vprtstp: contraction number = 2.262946e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.599711e-04
Vprtstp: contraction number = 1.533276e-01
Vnewton: Using errtol_s: 20503.536549
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.178323e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.992362e+03
Vprtstp: contraction number = 3.992362e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.331932e-04
Vprtstp: contraction number = 1.752609e-01
Vnewton: Using errtol_s: 3593.468486
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.203668e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.831942e+02
Vprtstp: contraction number = 7.831942e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.612624e-05
Vprtstp: contraction number = 1.961529e-01
Vnewton: Using errtol_s: 704.869290
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.229018e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.860293e+02
Vprtstp: contraction number = 1.860293e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.205324e-06
Vprtstp: contraction number = 2.375131e-01
Vnewton: Using errtol_s: 167.415715
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.254430e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.357640e+01
Vprtstp: contraction number = 5.357640e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.787163e-06
Vprtstp: contraction number = 2.880048e-01
Vnewton: Using errtol_s: 48.216536
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.279829e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.780774e+01
Vprtstp: contraction number = 1.780774e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.940286e-07
Vprtstp: contraction number = 3.323863e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.610528e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.807412e+00
Vpmg_setPart:  lower corner = (-53.286, -47.987, -43.091)
Vpmg_setPart:  upper corner = (53.286, 47.912, 43.174)
Vpmg_setPart:  actual minima = (-53.286, -47.987, -43.091)
Vpmg_setPart:  actual maxima = (53.286, 47.912, 43.174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.358962e+01
