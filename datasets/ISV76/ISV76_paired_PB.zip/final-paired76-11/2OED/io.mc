##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:20 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 862 atoms
Valist_getStatistics:  Max atom coordinate:  (10.788, 17.71, 14.851)
Valist_getStatistics:  Min atom coordinate:  (-9.347, -16.577, -14.694)
Valist_getStatistics:  Molecule center:  (0.7205, 0.5665, 0.0785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.939609, 0.773823, 1.08664
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.627109, 0.56549, 0.774141
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.667415, 0.730774, 0.712416 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 30.788 37.71 34.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.347 -36.577 -34.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 20.788 27.71 24.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.347 -26.577 -24.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 20.788 27.71 24.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.347 -26.577 -24.694
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.095479
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.671330e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.787000e-03
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 033)
Vbuildops: Galer: (017, 025, 017)
Vbuildops: Galer: (009, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.707000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.036600e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.090856e-02
Vprtstp: contraction number = 7.090856e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.015131e-02
Vprtstp: contraction number = 1.431606e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.808716e-03
Vprtstp: contraction number = 1.781755e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.532207e-04
Vprtstp: contraction number = 1.952881e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.241968e-05
Vprtstp: contraction number = 2.050267e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.530200e-05
Vprtstp: contraction number = 2.112961e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.285069e-06
Vprtstp: contraction number = 2.146824e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.153247e-07
Vprtstp: contraction number = 2.177503e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.049460e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.357920e-01
Vpmg_setPart:  lower corner = (-29.347, -36.577, -34.694)
Vpmg_setPart:  upper corner = (30.788, 37.71, 34.851)
Vpmg_setPart:  actual minima = (-29.347, -36.577, -34.694)
Vpmg_setPart:  actual maxima = (30.788, 37.71, 34.851)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.347, -26.577, -24.694
VPMG::focusFillBound -- New mesh maxs = 20.788, 27.71, 24.851
VPMG::focusFillBound -- Old mesh mins = -29.347, -36.577, -34.694
VPMG::focusFillBound -- Old mesh maxs = 30.788, 37.71, 34.851
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.095402
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.069650e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.410000e-03
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 033)
Vbuildops: Galer: (017, 025, 017)
Vbuildops: Galer: (009, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.678300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.466450e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.062789e-01
Vprtstp: contraction number = 1.062789e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.666475e-02
Vprtstp: contraction number = 1.568020e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.176975e-03
Vprtstp: contraction number = 1.906405e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.638606e-04
Vprtstp: contraction number = 2.089600e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.464758e-04
Vprtstp: contraction number = 2.206424e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.348253e-05
Vprtstp: contraction number = 2.285874e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.884092e-06
Vprtstp: contraction number = 2.354688e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.897661e-06
Vprtstp: contraction number = 2.406949e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.699475e-07
Vprtstp: contraction number = 2.476457e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.186980e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.487720e-01
Vpmg_setPart:  lower corner = (-19.347, -26.577, -24.694)
Vpmg_setPart:  upper corner = (20.788, 27.71, 24.851)
Vpmg_setPart:  actual minima = (-19.347, -26.577, -24.694)
Vpmg_setPart:  actual maxima = (20.788, 27.71, 24.851)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.365180e-01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:21 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 862 atoms
Valist_getStatistics:  Max atom coordinate:  (10.788, 17.71, 14.851)
Valist_getStatistics:  Min atom coordinate:  (-9.347, -16.577, -14.694)
Valist_getStatistics:  Molecule center:  (0.7205, 0.5665, 0.0785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.939609, 0.773823, 1.08664
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.627109, 0.56549, 0.774141
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.667415, 0.730774, 0.712416 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 30.788 37.71 34.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.347 -36.577 -34.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 20.788 27.71 24.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.347 -26.577 -24.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 20.788 27.71 24.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.347 -26.577 -24.694
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.095786
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.698300e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.148000e-03
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 033)
Vbuildops: Galer: (017, 025, 017)
Vbuildops: Galer: (009, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.602300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.042060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 967109.610600
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.244140e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.236500e+04
Vprtstp: contraction number = 7.236500e+04
Vnewton: Attempting damping, relres = 0.068878
Vnewton: Attempting damping, relres = 0.527758
Vnewton: Damping accepted, relres = 0.068878
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.887782e-02
Vprtstp: contraction number = 6.887782e-02
Vnewton: Using errtol_s: 66612.399015
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.626200e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.063776e+04
Vprtstp: contraction number = 1.063776e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.904382e-03
Vprtstp: contraction number = 1.437964e-01
Vnewton: Using errtol_s: 9578.623481
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.914500e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.914659e+03
Vprtstp: contraction number = 1.914659e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.781900e-03
Vprtstp: contraction number = 1.799103e-01
Vnewton: Using errtol_s: 1723.292564
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.204790e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.766776e+02
Vprtstp: contraction number = 3.766776e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.505433e-04
Vprtstp: contraction number = 1.967245e-01
Vnewton: Using errtol_s: 339.013818
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.493470e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.739297e+01
Vprtstp: contraction number = 7.739297e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.202269e-05
Vprtstp: contraction number = 2.054602e-01
Vnewton: Using errtol_s: 69.653834
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.782900e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.632950e+01
Vprtstp: contraction number = 1.632950e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.519637e-05
Vprtstp: contraction number = 2.109943e-01
Vnewton: Using errtol_s: 14.696559
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.074290e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.508560e+00
Vprtstp: contraction number = 3.508560e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.265094e-06
Vprtstp: contraction number = 2.148601e-01
Vnewton: Using errtol_s: 3.157704
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.370680e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.624707e-01
Vprtstp: contraction number = 7.624707e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.095614e-07
Vprtstp: contraction number = 2.173173e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.547430e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.831770e-01
Vpmg_setPart:  lower corner = (-29.347, -36.577, -34.694)
Vpmg_setPart:  upper corner = (30.788, 37.71, 34.851)
Vpmg_setPart:  actual minima = (-29.347, -36.577, -34.694)
Vpmg_setPart:  actual maxima = (30.788, 37.71, 34.851)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.347, -26.577, -24.694
VPMG::focusFillBound -- New mesh maxs = 20.788, 27.71, 24.851
VPMG::focusFillBound -- Old mesh mins = -29.347, -36.577, -34.694
VPMG::focusFillBound -- Old mesh maxs = 30.788, 37.71, 34.851
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.094790
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.063920e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.535000e-03
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 033)
Vbuildops: Galer: (017, 025, 017)
Vbuildops: Galer: (009, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.615800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.953100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1319580.626630
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.164650e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.537340e+05
Vprtstp: contraction number = 1.537340e+05
Vnewton: Attempting damping, relres = 0.105821
Vnewton: Attempting damping, relres = 0.548933
Vnewton: Damping accepted, relres = 0.105821
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.058207e-01
Vprtstp: contraction number = 1.058207e-01
Vnewton: Using errtol_s: 139638.998029
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.555820e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.429576e+04
Vprtstp: contraction number = 2.429576e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.657399e-02
Vprtstp: contraction number = 1.566232e-01
Vnewton: Using errtol_s: 21870.713379
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.851320e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.647847e+03
Vprtstp: contraction number = 4.647847e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.170050e-03
Vprtstp: contraction number = 1.912666e-01
Vnewton: Using errtol_s: 4183.136133
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.146840e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.726403e+02
Vprtstp: contraction number = 9.726403e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.633770e-04
Vprtstp: contraction number = 2.092639e-01
Vnewton: Using errtol_s: 875.379395
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.440380e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.142685e+02
Vprtstp: contraction number = 2.142685e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.461387e-04
Vprtstp: contraction number = 2.202951e-01
Vnewton: Using errtol_s: 192.841803
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.734410e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.885508e+01
Vprtstp: contraction number = 4.885508e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.332087e-05
Vprtstp: contraction number = 2.280086e-01
Vnewton: Using errtol_s: 43.969580
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.027790e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.144500e+01
Vprtstp: contraction number = 1.144500e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.805887e-06
Vprtstp: contraction number = 2.342642e-01
Vnewton: Using errtol_s: 10.300497
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.322800e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.744107e+00
Vprtstp: contraction number = 2.744107e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.871577e-06
Vprtstp: contraction number = 2.397648e-01
Vnewton: Using errtol_s: 2.469696
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.623500e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.728017e-01
Vprtstp: contraction number = 6.728017e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.588742e-07
Vprtstp: contraction number = 2.451806e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.890990e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.180610e-01
Vpmg_setPart:  lower corner = (-19.347, -26.577, -24.694)
Vpmg_setPart:  upper corner = (20.788, 27.71, 24.851)
Vpmg_setPart:  actual minima = (-19.347, -26.577, -24.694)
Vpmg_setPart:  actual maxima = (20.788, 27.71, 24.851)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.054890e+00
