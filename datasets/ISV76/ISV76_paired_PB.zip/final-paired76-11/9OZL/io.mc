##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:24 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5405 atoms
Valist_getStatistics:  Max atom coordinate:  (37.4, 43.251, 66.222)
Valist_getStatistics:  Min atom coordinate:  (-17.645, -16.456, -2.766)
Valist_getStatistics:  Molecule center:  (9.8775, 13.3975, 31.728)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.990052, 0.778961, 0.851469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.781719, 0.622711, 0.695219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.789573, 0.799412, 0.816494 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 57.4 63.251 86.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -37.645 -36.456 -22.766
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 47.4 53.251 76.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.645 -26.456 -12.766
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 47.4 53.251 76.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.645 -26.456 -12.766
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.718200
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.904140e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.387300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.863500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.138584e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.745161e-02
Vprtstp: contraction number = 5.745161e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.682918e-03
Vprtstp: contraction number = 1.337285e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.289168e-03
Vprtstp: contraction number = 1.677967e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.478953e-04
Vprtstp: contraction number = 1.922909e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.043935e-05
Vprtstp: contraction number = 2.034704e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.125970e-05
Vprtstp: contraction number = 2.232324e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.722374e-06
Vprtstp: contraction number = 2.417804e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.914459e-07
Vprtstp: contraction number = 2.539863e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.993170e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.323630e-01
Vpmg_setPart:  lower corner = (-37.645, -36.456, -22.766)
Vpmg_setPart:  upper corner = (57.4, 63.251, 86.222)
Vpmg_setPart:  actual minima = (-37.645, -36.456, -22.766)
Vpmg_setPart:  actual maxima = (57.4, 63.251, 86.222)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.645, -26.456, -12.766
VPMG::focusFillBound -- New mesh maxs = 47.4, 53.251, 76.222
VPMG::focusFillBound -- Old mesh mins = -37.645, -36.456, -22.766
VPMG::focusFillBound -- Old mesh maxs = 57.4, 63.251, 86.222
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.713948
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.071835e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.400300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.121200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.848436e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.585324e-02
Vprtstp: contraction number = 7.585324e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.036578e-02
Vprtstp: contraction number = 1.366558e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.763882e-03
Vprtstp: contraction number = 1.701639e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.444002e-04
Vprtstp: contraction number = 1.952512e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.634638e-05
Vprtstp: contraction number = 2.216793e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.968156e-05
Vprtstp: contraction number = 2.577929e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.803563e-06
Vprtstp: contraction number = 2.948732e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.905160e-06
Vprtstp: contraction number = 3.282741e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.610761e-07
Vprtstp: contraction number = 3.469925e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.687770e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.032200e-01
Vpmg_setPart:  lower corner = (-27.645, -26.456, -12.766)
Vpmg_setPart:  upper corner = (47.4, 53.251, 76.222)
Vpmg_setPart:  actual minima = (-27.645, -26.456, -12.766)
Vpmg_setPart:  actual maxima = (47.4, 53.251, 76.222)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.757793e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:29 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5405 atoms
Valist_getStatistics:  Max atom coordinate:  (37.4, 43.251, 66.222)
Valist_getStatistics:  Min atom coordinate:  (-17.645, -16.456, -2.766)
Valist_getStatistics:  Molecule center:  (9.8775, 13.3975, 31.728)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.990052, 0.778961, 0.851469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.781719, 0.622711, 0.695219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.789573, 0.799412, 0.816494 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 57.4 63.251 86.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -37.645 -36.456 -22.766
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 47.4 53.251 76.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.645 -26.456 -12.766
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 47.4 53.251 76.222
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.645 -26.456 -12.766
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.713306
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.852300e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.628100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.929700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.123769e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6363688.253170
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.220264e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.631429e+05
Vprtstp: contraction number = 3.631429e+05
Vnewton: Attempting damping, relres = 0.054229
Vnewton: Attempting damping, relres = 0.520476
Vnewton: Damping accepted, relres = 0.054229
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.422945e-02
Vprtstp: contraction number = 5.422945e-02
Vnewton: Using errtol_s: 345099.310506
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.403959e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.889714e+04
Vprtstp: contraction number = 4.889714e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.127185e-03
Vprtstp: contraction number = 1.314265e-01
Vnewton: Using errtol_s: 45355.185024
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.543834e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.246502e+03
Vprtstp: contraction number = 8.246502e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.171364e-03
Vprtstp: contraction number = 1.643516e-01
Vnewton: Using errtol_s: 7454.197925
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.682186e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.551512e+03
Vprtstp: contraction number = 1.551512e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.194590e-04
Vprtstp: contraction number = 1.873533e-01
Vnewton: Using errtol_s: 1396.568475
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.824544e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.147561e+02
Vprtstp: contraction number = 3.147561e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.451541e-05
Vprtstp: contraction number = 2.028416e-01
Vnewton: Using errtol_s: 283.282177
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.969456e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.732942e+01
Vprtstp: contraction number = 6.732942e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.522235e-06
Vprtstp: contraction number = 2.139087e-01
Vnewton: Using errtol_s: 60.596533
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.111588e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.503328e+01
Vprtstp: contraction number = 1.503328e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.126118e-06
Vprtstp: contraction number = 2.232793e-01
Vnewton: Using errtol_s: 13.529955
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.253358e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.493739e+00
Vprtstp: contraction number = 3.493739e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.941105e-07
Vprtstp: contraction number = 2.324003e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.237980e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.361112e+00
Vpmg_setPart:  lower corner = (-37.645, -36.456, -22.766)
Vpmg_setPart:  upper corner = (57.4, 63.251, 86.222)
Vpmg_setPart:  actual minima = (-37.645, -36.456, -22.766)
Vpmg_setPart:  actual maxima = (57.4, 63.251, 86.222)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.645, -26.456, -12.766
VPMG::focusFillBound -- New mesh maxs = 47.4, 53.251, 76.222
VPMG::focusFillBound -- Old mesh mins = -37.645, -36.456, -22.766
VPMG::focusFillBound -- Old mesh maxs = 57.4, 63.251, 86.222
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.710506
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.070932e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.470300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.786700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.557279e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7596607.510896
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.653902e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.992911e+05
Vprtstp: contraction number = 5.992911e+05
Vnewton: Attempting damping, relres = 0.073264
Vnewton: Attempting damping, relres = 0.531659
Vnewton: Damping accepted, relres = 0.073264
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.326396e-02
Vprtstp: contraction number = 7.326396e-02
Vnewton: Using errtol_s: 556557.540417
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.841401e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.089449e+04
Vprtstp: contraction number = 8.089449e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.736764e-03
Vprtstp: contraction number = 1.328998e-01
Vnewton: Using errtol_s: 73966.372897
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.982414e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.334200e+04
Vprtstp: contraction number = 1.334200e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.582806e-03
Vprtstp: contraction number = 1.625598e-01
Vnewton: Using errtol_s: 12023.957452
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.123621e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.461267e+03
Vprtstp: contraction number = 2.461267e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.916025e-04
Vprtstp: contraction number = 1.842313e-01
Vnewton: Using errtol_s: 2215.189448
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.266735e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.884250e+02
Vprtstp: contraction number = 4.884250e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.786573e-05
Vprtstp: contraction number = 1.984405e-01
Vnewton: Using errtol_s: 439.583242
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.407820e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.017711e+02
Vprtstp: contraction number = 1.017711e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.205723e-05
Vprtstp: contraction number = 2.083657e-01
Vnewton: Using errtol_s: 91.594057
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.551308e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.187942e+01
Vprtstp: contraction number = 2.187942e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.592142e-06
Vprtstp: contraction number = 2.149865e-01
Vnewton: Using errtol_s: 19.691483
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.695592e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.802945e+00
Vprtstp: contraction number = 4.802945e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.690238e-07
Vprtstp: contraction number = 2.195188e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.247270e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.367401e+00
Vpmg_setPart:  lower corner = (-27.645, -26.456, -12.766)
Vpmg_setPart:  upper corner = (47.4, 53.251, 76.222)
Vpmg_setPart:  actual minima = (-27.645, -26.456, -12.766)
Vpmg_setPart:  actual maxima = (47.4, 53.251, 76.222)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.156499e+00
