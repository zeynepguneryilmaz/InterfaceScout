##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:28:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2201 atoms
Valist_getStatistics:  Max atom coordinate:  (34.909, 53.916, 32.497)
Valist_getStatistics:  Min atom coordinate:  (-10.775, -8.638, -9.997)
Valist_getStatistics:  Molecule center:  (12.067, 22.639, 11.25)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.892542, 0.801203, 0.859313
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.684208, 0.644953, 0.650979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.766584, 0.804981, 0.757558 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.909 73.916 52.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -30.775 -28.638 -29.997
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.909 63.916 42.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -20.775 -18.638 -19.997
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.909 63.916 42.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -20.775 -18.638 -19.997
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.249421
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.418950e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.569500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.856400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.502310e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.596613e-02
Vprtstp: contraction number = 9.596613e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.268907e-02
Vprtstp: contraction number = 1.322245e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.568554e-03
Vprtstp: contraction number = 2.024225e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.346393e-04
Vprtstp: contraction number = 1.692156e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.926521e-05
Vprtstp: contraction number = 2.283852e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.832954e-05
Vprtstp: contraction number = 1.846522e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.366819e-06
Vprtstp: contraction number = 2.382394e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.676922e-07
Vprtstp: contraction number = 1.987012e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.508210e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.503500e-01
Vpmg_setPart:  lower corner = (-30.775, -28.638, -29.997)
Vpmg_setPart:  upper corner = (54.909, 73.916, 52.497)
Vpmg_setPart:  actual minima = (-30.775, -28.638, -29.997)
Vpmg_setPart:  actual maxima = (54.909, 73.916, 52.497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -20.775, -18.638, -19.997
VPMG::focusFillBound -- New mesh maxs = 44.909, 63.916, 42.497
VPMG::focusFillBound -- Old mesh mins = -30.775, -28.638, -29.997
VPMG::focusFillBound -- Old mesh maxs = 54.909, 73.916, 52.497
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.247665
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.127330e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.608800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.133600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.519339e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.138029e-01
Vprtstp: contraction number = 1.138029e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.566499e-02
Vprtstp: contraction number = 1.376501e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.011439e-03
Vprtstp: contraction number = 1.922401e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.478791e-04
Vprtstp: contraction number = 1.819327e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.250990e-04
Vprtstp: contraction number = 2.283331e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.446491e-05
Vprtstp: contraction number = 1.955645e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.928450e-06
Vprtstp: contraction number = 2.423246e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.180501e-06
Vprtstp: contraction number = 1.991247e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.923903e-07
Vprtstp: contraction number = 2.476833e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.010530e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.034030e-01
Vpmg_setPart:  lower corner = (-20.775, -18.638, -19.997)
Vpmg_setPart:  upper corner = (44.909, 63.916, 42.497)
Vpmg_setPart:  actual minima = (-20.775, -18.638, -19.997)
Vpmg_setPart:  actual maxima = (44.909, 63.916, 42.497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.163613e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:28:41 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2201 atoms
Valist_getStatistics:  Max atom coordinate:  (34.909, 53.916, 32.497)
Valist_getStatistics:  Min atom coordinate:  (-10.775, -8.638, -9.997)
Valist_getStatistics:  Molecule center:  (12.067, 22.639, 11.25)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.892542, 0.801203, 0.859313
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.684208, 0.644953, 0.650979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.766584, 0.804981, 0.757558 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.909 73.916 52.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -30.775 -28.638 -29.997
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.909 63.916 42.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -20.775 -18.638 -19.997
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.909 63.916 42.497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -20.775 -18.638 -19.997
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.251409
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.446180e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.488500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.996800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.410770e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2904072.706950
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.075460e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.407446e+05
Vprtstp: contraction number = 2.407446e+05
Vnewton: Attempting damping, relres = 0.105444
Vnewton: Attempting damping, relres = 0.533908
Vnewton: Damping accepted, relres = 0.105444
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.054435e-01
Vprtstp: contraction number = 1.054435e-01
Vnewton: Using errtol_s: 306215.670875
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.339180e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.668823e+04
Vprtstp: contraction number = 3.668823e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.657972e-02
Vprtstp: contraction number = 1.572379e-01
Vnewton: Using errtol_s: 48148.704564
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.294240e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.067534e+03
Vprtstp: contraction number = 7.067534e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.914160e-03
Vprtstp: contraction number = 1.757666e-01
Vnewton: Using errtol_s: 8462.933908
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.255960e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.495686e+03
Vprtstp: contraction number = 1.495686e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.850094e-04
Vprtstp: contraction number = 2.007471e-01
Vnewton: Using errtol_s: 1698.909735
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.021735e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.446533e+02
Vprtstp: contraction number = 3.446533e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.202546e-04
Vprtstp: contraction number = 2.055601e-01
Vnewton: Using errtol_s: 349.228010
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.117235e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.811005e+01
Vprtstp: contraction number = 7.811005e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.453420e-05
Vprtstp: contraction number = 2.040189e-01
Vnewton: Using errtol_s: 71.249105
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.212253e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.698684e+01
Vprtstp: contraction number = 1.698684e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.265747e-06
Vprtstp: contraction number = 2.146288e-01
Vnewton: Using errtol_s: 15.292112
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.308866e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.759330e+00
Vprtstp: contraction number = 3.759330e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.165064e-06
Vprtstp: contraction number = 2.212533e-01
Vnewton: Using errtol_s: 3.383431
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.405966e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.488465e-01
Vprtstp: contraction number = 8.488465e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.630658e-07
Vprtstp: contraction number = 2.257951e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.389440e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.026685e+00
Vpmg_setPart:  lower corner = (-30.775, -28.638, -29.997)
Vpmg_setPart:  upper corner = (54.909, 73.916, 52.497)
Vpmg_setPart:  actual minima = (-30.775, -28.638, -29.997)
Vpmg_setPart:  actual maxima = (54.909, 73.916, 52.497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -20.775, -18.638, -19.997
VPMG::focusFillBound -- New mesh maxs = 44.909, 63.916, 42.497
VPMG::focusFillBound -- Old mesh mins = -30.775, -28.638, -29.997
VPMG::focusFillBound -- Old mesh maxs = 54.909, 73.916, 52.497
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.249272
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.123830e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.600600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.074500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.085260e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3473661.587215
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.153681e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.792192e+05
Vprtstp: contraction number = 3.792192e+05
Vnewton: Attempting damping, relres = 0.119308
Vnewton: Attempting damping, relres = 0.547376
Vnewton: Damping accepted, relres = 0.119308
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.193075e-01
Vprtstp: contraction number = 1.193075e-01
Vnewton: Using errtol_s: 414434.028162
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.281725e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.483905e+04
Vprtstp: contraction number = 5.483905e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.688014e-02
Vprtstp: contraction number = 1.414843e-01
Vnewton: Using errtol_s: 58635.893666
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.379136e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.431131e+03
Vprtstp: contraction number = 9.431131e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.593557e-03
Vprtstp: contraction number = 1.536455e-01
Vnewton: Using errtol_s: 9009.139544
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.476425e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.694608e+03
Vprtstp: contraction number = 1.694608e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.407799e-04
Vprtstp: contraction number = 1.699519e-01
Vnewton: Using errtol_s: 1531.120247
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.574944e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.202366e+02
Vprtstp: contraction number = 3.202366e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.297796e-05
Vprtstp: contraction number = 1.882526e-01
Vnewton: Using errtol_s: 288.237339
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.672650e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.374643e+01
Vprtstp: contraction number = 6.374643e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.651627e-05
Vprtstp: contraction number = 1.990440e-01
Vnewton: Using errtol_s: 57.371921
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.772116e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.308551e+01
Vprtstp: contraction number = 1.308551e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.390361e-06
Vprtstp: contraction number = 2.052740e-01
Vnewton: Using errtol_s: 11.776965
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.870175e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.745286e+00
Vprtstp: contraction number = 2.745286e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.112834e-07
Vprtstp: contraction number = 2.097958e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 8.597000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.494940e-01
Vpmg_setPart:  lower corner = (-20.775, -18.638, -19.997)
Vpmg_setPart:  upper corner = (44.909, 63.916, 42.497)
Vpmg_setPart:  actual minima = (-20.775, -18.638, -19.997)
Vpmg_setPart:  actual maxima = (44.909, 63.916, 42.497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.193353e+00
