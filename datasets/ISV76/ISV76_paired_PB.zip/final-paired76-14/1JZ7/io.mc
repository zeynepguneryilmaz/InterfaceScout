##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 225, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 63370 atoms
Valist_getStatistics:  Max atom coordinate:  (55.811, 65.715, 83.528)
Valist_getStatistics:  Min atom coordinate:  (-55.284, -72.582, -90.009)
Valist_getStatistics:  Molecule center:  (0.2635, -3.4335, -3.2405)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.786953, 0.795969, 0.834129
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.682786, 0.706683, 0.756004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.867633, 0.887828, 0.906339 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.811 85.715 103.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -75.284 -92.582 -110.009
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.811 75.715 93.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -65.284 -82.582 -100.009
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.811 75.715 93.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -65.284 -82.582 -100.009
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -122
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13696871 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 12.339176
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.452536e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.283260e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 129)
Vbuildops: Galer: (049, 057, 065)
Vbuildops: Galer: (025, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.864342e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.689280e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.005358e-02
Vprtstp: contraction number = 6.005358e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.322711e-03
Vprtstp: contraction number = 1.552399e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.901086e-03
Vprtstp: contraction number = 3.111848e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.006718e-03
Vprtstp: contraction number = 3.470143e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.968368e-04
Vprtstp: contraction number = 5.928538e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.548379e-04
Vprtstp: contraction number = 4.269808e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.668151e-04
Vprtstp: contraction number = 6.545930e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.617558e-05
Vprtstp: contraction number = 4.566468e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.089644e-05
Vprtstp: contraction number = 6.681464e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.396218e-05
Vprtstp: contraction number = 4.708026e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.607179e-05
Vprtstp: contraction number = 6.707150e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.678333e-06
Vprtstp: contraction number = 4.777522e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.146606e-06
Vprtstp: contraction number = 6.702765e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.477674e-06
Vprtstp: contraction number = 4.814189e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.658212e-06
Vprtstp: contraction number = 6.692616e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 8.017511e-07
Vprtstp: contraction number = 4.835034e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.039678e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.262412e+01
Vpmg_setPart:  lower corner = (-75.284, -92.582, -110.009)
Vpmg_setPart:  upper corner = (75.811, 85.715, 103.528)
Vpmg_setPart:  actual minima = (-75.284, -92.582, -110.009)
Vpmg_setPart:  actual maxima = (75.811, 85.715, 103.528)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -122
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13696871 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -65.284, -82.582, -100.009
VPMG::focusFillBound -- New mesh maxs = 65.811, 75.715, 93.528
VPMG::focusFillBound -- Old mesh mins = -75.284, -92.582, -110.009
VPMG::focusFillBound -- Old mesh maxs = 75.811, 85.715, 103.528
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 12.278868
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.496992e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.309980e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 129)
Vbuildops: Galer: (049, 057, 065)
Vbuildops: Galer: (025, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.901878e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.458013e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.690813e-02
Vprtstp: contraction number = 6.690813e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.898062e-03
Vprtstp: contraction number = 1.479351e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.031302e-03
Vprtstp: contraction number = 3.062521e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.026980e-03
Vprtstp: contraction number = 3.387916e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.496637e-04
Vprtstp: contraction number = 6.325964e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.771859e-04
Vprtstp: contraction number = 4.266606e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.968796e-04
Vprtstp: contraction number = 7.102800e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.119804e-05
Vprtstp: contraction number = 4.632172e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.660847e-05
Vprtstp: contraction number = 7.303717e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.248677e-05
Vprtstp: contraction number = 4.877273e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.391712e-05
Vprtstp: contraction number = 7.362112e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.204409e-05
Vprtstp: contraction number = 5.035758e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.866134e-06
Vprtstp: contraction number = 7.361400e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 4.553767e-06
Vprtstp: contraction number = 5.136136e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 3.342777e-06
Vprtstp: contraction number = 7.340685e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.738275e-06
Vprtstp: contraction number = 5.200093e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.271802e-06
Vprtstp: contraction number = 7.316458e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 6.666505e-07
Vprtstp: contraction number = 5.241780e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.170702e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.397455e+01
Vpmg_setPart:  lower corner = (-65.284, -82.582, -100.009)
Vpmg_setPart:  upper corner = (65.811, 75.715, 93.528)
Vpmg_setPart:  actual minima = (-65.284, -82.582, -100.009)
Vpmg_setPart:  actual maxima = (65.811, 75.715, 93.528)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.870871e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:23 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 225, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 63370 atoms
Valist_getStatistics:  Max atom coordinate:  (55.811, 65.715, 83.528)
Valist_getStatistics:  Min atom coordinate:  (-55.284, -72.582, -90.009)
Valist_getStatistics:  Molecule center:  (0.2635, -3.4335, -3.2405)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.786953, 0.795969, 0.834129
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.682786, 0.706683, 0.756004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.867633, 0.887828, 0.906339 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.811 85.715 103.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -75.284 -92.582 -110.009
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.811 75.715 93.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -65.284 -82.582 -100.009
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.811 75.715 93.528
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -65.284 -82.582 -100.009
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -122
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13696871 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 12.322971
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.452826e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.298670e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 129)
Vbuildops: Galer: (049, 057, 065)
Vbuildops: Galer: (025, 029, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.710130e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.568612e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 83321097.456921
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.633680e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.899143e+06
Vprtstp: contraction number = 4.899143e+06
Vnewton: Attempting damping, relres = 449.398795
Vnewton: Attempting damping, relres = 0.528745
Vnewton: Attempting damping, relres = 0.760920
Vnewton: Damping accepted, relres = 0.528745
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.287454e-01
Vprtstp: contraction number = 5.287454e-01
Vnewton: Using errtol_s: 44055647.256840
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.815092e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.704791e+06
Vprtstp: contraction number = 2.704791e+06
Vnewton: Attempting damping, relres = 0.032734
Vnewton: Attempting damping, relres = 0.277744
Vnewton: Damping accepted, relres = 0.032734
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.273366e-02
Vprtstp: contraction number = 6.190816e-02
Vnewton: Using errtol_s: 2727404.159042
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.973064e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.189957e+05
Vprtstp: contraction number = 3.189957e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.213983e-03
Vprtstp: contraction number = 1.287355e-01
Vnewton: Using errtol_s: 351113.715813
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.092947e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.781845e+04
Vprtstp: contraction number = 4.781845e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.210844e-04
Vprtstp: contraction number = 1.711171e-01
Vnewton: Using errtol_s: 60081.543565
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.213160e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.607481e+03
Vprtstp: contraction number = 9.607481e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.502301e-04
Vprtstp: contraction number = 2.083391e-01
Vnewton: Using errtol_s: 12517.333345
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.332085e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.641170e+03
Vprtstp: contraction number = 2.641170e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.478174e-05
Vprtstp: contraction number = 2.315231e-01
Vnewton: Using errtol_s: 2898.052344
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.450756e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.488989e+02
Vprtstp: contraction number = 8.488989e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.500385e-06
Vprtstp: contraction number = 2.731429e-01
Vnewton: Using errtol_s: 791.582475
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.569634e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.905652e+02
Vprtstp: contraction number = 2.905652e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.150264e-06
Vprtstp: contraction number = 3.315933e-01
Vnewton: Using errtol_s: 262.483422
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.689358e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.060916e+02
Vprtstp: contraction number = 1.060916e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.147181e-06
Vprtstp: contraction number = 3.641539e-01
Vnewton: Using errtol_s: 95.584373
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.808838e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.045321e+01
Vprtstp: contraction number = 4.045321e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.371410e-07
Vprtstp: contraction number = 3.810567e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.333973e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.435839e+01
Vpmg_setPart:  lower corner = (-75.284, -92.582, -110.009)
Vpmg_setPart:  upper corner = (75.811, 85.715, 103.528)
Vpmg_setPart:  actual minima = (-75.284, -92.582, -110.009)
Vpmg_setPart:  actual maxima = (75.811, 85.715, 103.528)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -122
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13696871 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -65.284, -82.582, -100.009
VPMG::focusFillBound -- New mesh maxs = 65.811, 75.715, 93.528
VPMG::focusFillBound -- Old mesh mins = -75.284, -92.582, -110.009
VPMG::focusFillBound -- Old mesh maxs = 75.811, 85.715, 103.528
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 12.304753
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.501915e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.297070e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 129)
Vbuildops: Galer: (049, 057, 065)
Vbuildops: Galer: (025, 029, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.644550e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.511451e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 86594716.931943
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.577399e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.829717e+06
Vprtstp: contraction number = 5.829717e+06
Vnewton: Attempting damping, relres = 451.972103
Vnewton: Attempting damping, relres = 0.532623
Vnewton: Attempting damping, relres = 0.763025
Vnewton: Damping accepted, relres = 0.532623
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.326225e-01
Vprtstp: contraction number = 5.326225e-01
Vnewton: Using errtol_s: 46122295.961868
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.759935e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.238067e+06
Vprtstp: contraction number = 3.238067e+06
Vnewton: Attempting damping, relres = 0.036171
Vnewton: Attempting damping, relres = 0.282156
Vnewton: Damping accepted, relres = 0.036171
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.617060e-02
Vprtstp: contraction number = 6.791039e-02
Vnewton: Using errtol_s: 3132183.162723
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.916919e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.039260e+05
Vprtstp: contraction number = 4.039260e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.870802e-03
Vprtstp: contraction number = 1.346619e-01
Vnewton: Using errtol_s: 421785.739652
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.037906e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.269745e+04
Vprtstp: contraction number = 6.269745e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.476935e-04
Vprtstp: contraction number = 1.740357e-01
Vnewton: Using errtol_s: 73405.778467
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.159081e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.253233e+04
Vprtstp: contraction number = 1.253233e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.759085e-04
Vprtstp: contraction number = 2.075143e-01
Vnewton: Using errtol_s: 15232.749366
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.280354e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.276614e+03
Vprtstp: contraction number = 3.276614e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.074793e-05
Vprtstp: contraction number = 2.316427e-01
Vnewton: Using errtol_s: 3528.555218
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.401060e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.033969e+03
Vprtstp: contraction number = 1.033969e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.118841e-05
Vprtstp: contraction number = 2.745762e-01
Vnewton: Using errtol_s: 968.857209
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.521590e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.528999e+02
Vprtstp: contraction number = 3.528999e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.687470e-06
Vprtstp: contraction number = 3.295794e-01
Vnewton: Using errtol_s: 319.315413
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.643808e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.273941e+02
Vprtstp: contraction number = 1.273941e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.325859e-06
Vprtstp: contraction number = 3.595578e-01
Vnewton: Using errtol_s: 114.812357
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.765060e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.732471e+01
Vprtstp: contraction number = 4.732471e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.920689e-07
Vprtstp: contraction number = 3.711323e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.348772e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.450408e+01
Vpmg_setPart:  lower corner = (-65.284, -82.582, -100.009)
Vpmg_setPart:  upper corner = (65.811, 75.715, 93.528)
Vpmg_setPart:  actual minima = (-65.284, -82.582, -100.009)
Vpmg_setPart:  actual maxima = (65.811, 75.715, 93.528)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.106865e+01
