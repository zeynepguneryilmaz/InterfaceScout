##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:22 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2455 atoms
Valist_getStatistics:  Max atom coordinate:  (15.184, 42.409, 28.876)
Valist_getStatistics:  Min atom coordinate:  (-24.948, -6.87, -8.361)
Valist_getStatistics:  Molecule center:  (-4.882, 17.7695, 10.2575)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.834708, 0.92999, 0.804552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.626375, 0.721656, 0.596219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.750412, 0.775983, 0.741057 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 35.184 62.409 48.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -44.948 -26.87 -28.361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 25.184 52.409 38.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -34.948 -16.87 -18.361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 25.184 52.409 38.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -34.948 -16.87 -18.361
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.3602
Vpbe_ctor2:  solute dimensions = 43.2022 x 51.547 x 40.0172
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.912, 62.059, 50.017)
Vclist_setupGrid:  Grid lower corner = (-31.338, -13.26, -14.751)
Vclist_assignAtoms:  Have 5423659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.297046
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.835490e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.967600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.293200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.670340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.395780e-02
Vprtstp: contraction number = 6.395780e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.542213e-03
Vprtstp: contraction number = 1.335601e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.423739e-03
Vprtstp: contraction number = 1.666709e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.961375e-04
Vprtstp: contraction number = 2.079999e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.149499e-05
Vprtstp: contraction number = 2.076569e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.517490e-05
Vprtstp: contraction number = 2.467664e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.459855e-06
Vprtstp: contraction number = 2.279986e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.502303e-07
Vprtstp: contraction number = 2.746446e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.559000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.301780e-01
Vpmg_setPart:  lower corner = (-44.948, -26.87, -28.361)
Vpmg_setPart:  upper corner = (35.184, 62.409, 48.876)
Vpmg_setPart:  actual minima = (-44.948, -26.87, -28.361)
Vpmg_setPart:  actual maxima = (35.184, 62.409, 48.876)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.3602
Vpbe_ctor2:  solute dimensions = 43.2022 x 51.547 x 40.0172
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.912, 62.059, 50.017)
Vclist_setupGrid:  Grid lower corner = (-31.338, -13.26, -14.751)
Vclist_assignAtoms:  Have 5423659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -34.948, -16.87, -18.361
VPMG::focusFillBound -- New mesh maxs = 25.184, 52.409, 38.876
VPMG::focusFillBound -- Old mesh mins = -44.948, -26.87, -28.361
VPMG::focusFillBound -- Old mesh maxs = 35.184, 62.409, 48.876
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.305608
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.662220e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.011500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.335200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.466765e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.176319e-02
Vprtstp: contraction number = 9.176319e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.297744e-02
Vprtstp: contraction number = 1.414231e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.290604e-03
Vprtstp: contraction number = 1.765066e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.977356e-04
Vprtstp: contraction number = 2.172945e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.164563e-04
Vprtstp: contraction number = 2.339722e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.202664e-05
Vprtstp: contraction number = 2.750101e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.487889e-06
Vprtstp: contraction number = 2.650259e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.618189e-06
Vprtstp: contraction number = 3.084617e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.468854e-07
Vprtstp: contraction number = 2.852680e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.022180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.775470e-01
Vpmg_setPart:  lower corner = (-34.948, -16.87, -18.361)
Vpmg_setPart:  upper corner = (25.184, 52.409, 38.876)
Vpmg_setPart:  actual minima = (-34.948, -16.87, -18.361)
Vpmg_setPart:  actual maxima = (25.184, 52.409, 38.876)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.959775e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2455 atoms
Valist_getStatistics:  Max atom coordinate:  (15.184, 42.409, 28.876)
Valist_getStatistics:  Min atom coordinate:  (-24.948, -6.87, -8.361)
Valist_getStatistics:  Molecule center:  (-4.882, 17.7695, 10.2575)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.834708, 0.92999, 0.804552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.626375, 0.721656, 0.596219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.750412, 0.775983, 0.741057 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -4.882 17.7695 10.2575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 35.184 62.409 48.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -44.948 -26.87 -28.361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 25.184 52.409 38.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -34.948 -16.87 -18.361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 25.184 52.409 38.876
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -34.948 -16.87 -18.361
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.3602
Vpbe_ctor2:  solute dimensions = 43.2022 x 51.547 x 40.0172
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.912, 62.059, 50.017)
Vclist_setupGrid:  Grid lower corner = (-31.338, -13.26, -14.751)
Vclist_assignAtoms:  Have 5423659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.301066
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.876420e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.884600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.888300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.642780e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2887030.958187
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.175820e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.866176e+05
Vprtstp: contraction number = 1.866176e+05
Vnewton: Attempting damping, relres = 0.072405
Vnewton: Attempting damping, relres = 0.524321
Vnewton: Damping accepted, relres = 0.072405
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.240548e-02
Vprtstp: contraction number = 7.240548e-02
Vnewton: Using errtol_s: 209036.866130
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.174150e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.613901e+04
Vprtstp: contraction number = 2.613901e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.200120e-02
Vprtstp: contraction number = 1.657499e-01
Vnewton: Using errtol_s: 34647.843893
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.942190e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.061293e+03
Vprtstp: contraction number = 5.061293e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.685291e-03
Vprtstp: contraction number = 2.237518e-01
Vnewton: Using errtol_s: 7752.517684
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.706340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.269342e+03
Vprtstp: contraction number = 1.269342e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.493247e-04
Vprtstp: contraction number = 2.418080e-01
Vnewton: Using errtol_s: 1874.620520
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.488200e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.223328e+02
Vprtstp: contraction number = 3.223328e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.304997e-04
Vprtstp: contraction number = 2.009776e-01
Vnewton: Using errtol_s: 376.756683
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.026352e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.960567e+01
Vprtstp: contraction number = 6.960567e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.248675e-05
Vprtstp: contraction number = 1.723127e-01
Vnewton: Using errtol_s: 64.919954
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.102473e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.322830e+01
Vprtstp: contraction number = 1.322830e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.127813e-06
Vprtstp: contraction number = 1.835664e-01
Vnewton: Using errtol_s: 11.917123
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.178873e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.623799e+00
Vprtstp: contraction number = 2.623799e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.179689e-07
Vprtstp: contraction number = 1.981604e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.707900e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.379430e-01
Vpmg_setPart:  lower corner = (-44.948, -26.87, -28.361)
Vpmg_setPart:  upper corner = (35.184, 62.409, 48.876)
Vpmg_setPart:  actual minima = (-44.948, -26.87, -28.361)
Vpmg_setPart:  actual maxima = (35.184, 62.409, 48.876)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.3602
Vpbe_ctor2:  solute dimensions = 43.2022 x 51.547 x 40.0172
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.912, 62.059, 50.017)
Vclist_setupGrid:  Grid lower corner = (-31.338, -13.26, -14.751)
Vclist_assignAtoms:  Have 5423659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -34.948, -16.87, -18.361
VPMG::focusFillBound -- New mesh maxs = 25.184, 52.409, 38.876
VPMG::focusFillBound -- Old mesh mins = -44.948, -26.87, -28.361
VPMG::focusFillBound -- Old mesh maxs = 35.184, 62.409, 48.876
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.298945
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.617410e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.893000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.767300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.865402e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3611417.559513
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.918047e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.547634e+05
Vprtstp: contraction number = 3.547634e+05
Vnewton: Attempting damping, relres = 0.097687
Vnewton: Attempting damping, relres = 0.541193
Vnewton: Damping accepted, relres = 0.097687
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.768699e-02
Vprtstp: contraction number = 9.768699e-02
Vnewton: Using errtol_s: 352788.517610
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.020760e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.066806e+04
Vprtstp: contraction number = 5.066806e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.499129e-02
Vprtstp: contraction number = 1.534625e-01
Vnewton: Using errtol_s: 54139.823579
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.098578e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.872925e+03
Vprtstp: contraction number = 8.872925e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.872043e-03
Vprtstp: contraction number = 1.915807e-01
Vnewton: Using errtol_s: 10372.146579
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.176258e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.786354e+03
Vprtstp: contraction number = 1.786354e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.763433e-04
Vprtstp: contraction number = 2.006736e-01
Vnewton: Using errtol_s: 2081.416417
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.251585e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.828397e+02
Vprtstp: contraction number = 3.828397e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.048414e-04
Vprtstp: contraction number = 1.819079e-01
Vnewton: Using errtol_s: 378.626072
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.328507e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.561367e+01
Vprtstp: contraction number = 7.561367e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.890635e-05
Vprtstp: contraction number = 1.803328e-01
Vnewton: Using errtol_s: 68.278715
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.406519e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.500385e+01
Vprtstp: contraction number = 1.500385e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.739134e-06
Vprtstp: contraction number = 1.977714e-01
Vnewton: Using errtol_s: 13.503575
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.484974e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.963115e+00
Vprtstp: contraction number = 2.963115e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.384372e-07
Vprtstp: contraction number = 1.974888e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.778230e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.440620e-01
Vpmg_setPart:  lower corner = (-34.948, -16.87, -18.361)
Vpmg_setPart:  upper corner = (25.184, 52.409, 38.876)
Vpmg_setPart:  actual minima = (-34.948, -16.87, -18.361)
Vpmg_setPart:  actual maxima = (25.184, 52.409, 38.876)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.736131e+00
