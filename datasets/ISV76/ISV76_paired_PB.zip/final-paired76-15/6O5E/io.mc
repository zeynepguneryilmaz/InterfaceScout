##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:53 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3015 atoms
Valist_getStatistics:  Max atom coordinate:  (37.807, 63.708, 66.754)
Valist_getStatistics:  Min atom coordinate:  (-6.801, 28.577, 17.075)
Valist_getStatistics:  Molecule center:  (15.503, 46.1425, 41.9145)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.881333, 0.782615, 0.934156
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.673, 0.574281, 0.725823
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763616, 0.733798, 0.776982 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 57.807 83.708 86.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -26.801 8.577 -2.925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 47.807 73.708 76.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -16.801 18.577 7.075
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 47.807 73.708 76.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -16.801 18.577 7.075
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = 1.59039e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6381653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.373931
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.740940e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.840400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.012800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.539220e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.083062e-02
Vprtstp: contraction number = 6.083062e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.390014e-03
Vprtstp: contraction number = 1.214851e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.138713e-03
Vprtstp: contraction number = 1.540880e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.110231e-04
Vprtstp: contraction number = 1.853173e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.854427e-05
Vprtstp: contraction number = 2.300424e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.164606e-05
Vprtstp: contraction number = 2.399060e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.260615e-06
Vprtstp: contraction number = 2.799758e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.396946e-07
Vprtstp: contraction number = 2.575264e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.400530e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.091550e-01
Vpmg_setPart:  lower corner = (-26.801, 8.577, -2.925)
Vpmg_setPart:  upper corner = (57.807, 83.708, 86.754)
Vpmg_setPart:  actual minima = (-26.801, 8.577, -2.925)
Vpmg_setPart:  actual maxima = (57.807, 83.708, 86.754)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = 1.59039e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6381653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -16.801, 18.577, 7.075
VPMG::focusFillBound -- New mesh maxs = 47.807, 73.708, 76.754
VPMG::focusFillBound -- Old mesh mins = -26.801, 8.577, -2.925
VPMG::focusFillBound -- Old mesh maxs = 57.807, 83.708, 86.754
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.369483
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.486650e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.868200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.148700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.615957e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.018537e-02
Vprtstp: contraction number = 9.018537e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.232001e-02
Vprtstp: contraction number = 1.366076e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.999780e-03
Vprtstp: contraction number = 1.623197e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.858462e-04
Vprtstp: contraction number = 1.929444e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.542756e-05
Vprtstp: contraction number = 2.473202e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.563701e-05
Vprtstp: contraction number = 2.686542e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.042403e-06
Vprtstp: contraction number = 3.137028e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.468341e-06
Vprtstp: contraction number = 3.069159e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.362188e-07
Vprtstp: contraction number = 3.387777e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.816320e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.526090e-01
Vpmg_setPart:  lower corner = (-16.801, 18.577, 7.075)
Vpmg_setPart:  upper corner = (47.807, 73.708, 76.754)
Vpmg_setPart:  actual minima = (-16.801, 18.577, 7.075)
Vpmg_setPart:  actual maxima = (47.807, 73.708, 76.754)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.081687e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3015 atoms
Valist_getStatistics:  Max atom coordinate:  (37.807, 63.708, 66.754)
Valist_getStatistics:  Min atom coordinate:  (-6.801, 28.577, 17.075)
Valist_getStatistics:  Molecule center:  (15.503, 46.1425, 41.9145)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.881333, 0.782615, 0.934156
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.673, 0.574281, 0.725823
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763616, 0.733798, 0.776982 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 57.807 83.708 86.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -26.801 8.577 -2.925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 47.807 73.708 76.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -16.801 18.577 7.075
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 47.807 73.708 76.754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -16.801 18.577 7.075
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = 1.59039e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6381653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.375398
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.775090e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.879600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.854500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.551060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3391816.642627
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.033830e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.150939e+05
Vprtstp: contraction number = 2.150939e+05
Vnewton: Attempting damping, relres = 0.114758
Vnewton: Attempting damping, relres = 0.524367
Vnewton: Damping accepted, relres = 0.114758
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.147579e-01
Vprtstp: contraction number = 1.147579e-01
Vnewton: Using errtol_s: 389237.761279
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.959820e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.935019e+04
Vprtstp: contraction number = 2.935019e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.768662e-02
Vprtstp: contraction number = 2.412611e-01
Vnewton: Using errtol_s: 93907.933908
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.640990e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.394985e+03
Vprtstp: contraction number = 6.394985e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.569973e-03
Vprtstp: contraction number = 3.095349e-01
Vnewton: Using errtol_s: 29067.778403
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.329060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.409435e+03
Vprtstp: contraction number = 2.409435e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.891227e-03
Vprtstp: contraction number = 3.373671e-01
Vnewton: Using errtol_s: 9806.513427
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.002930e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.109736e+03
Vprtstp: contraction number = 1.109736e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.498899e-04
Vprtstp: contraction number = 3.285421e-01
Vnewton: Using errtol_s: 3221.852357
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.071756e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.606198e+02
Vprtstp: contraction number = 4.606198e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.639410e-04
Vprtstp: contraction number = 2.778648e-01
Vnewton: Using errtol_s: 895.239513
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.140205e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.557793e+02
Vprtstp: contraction number = 1.557793e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.564278e-05
Vprtstp: contraction number = 2.108152e-01
Vnewton: Using errtol_s: 188.730100
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.212209e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.039311e+01
Vprtstp: contraction number = 4.039311e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.106390e-05
Vprtstp: contraction number = 1.988380e-01
Vnewton: Using errtol_s: 37.526723
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.286634e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.103222e+00
Vprtstp: contraction number = 9.103222e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.418609e-06
Vprtstp: contraction number = 2.186036e-01
Vnewton: Using errtol_s: 8.203477
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.359590e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.009755e+00
Vprtstp: contraction number = 2.009755e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.333409e-07
Vprtstp: contraction number = 2.205156e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.601570e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.271030e-01
Vpmg_setPart:  lower corner = (-26.801, 8.577, -2.925)
Vpmg_setPart:  upper corner = (57.807, 83.708, 86.754)
Vpmg_setPart:  actual minima = (-26.801, 8.577, -2.925)
Vpmg_setPart:  actual maxima = (57.807, 83.708, 86.754)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = 1.59039e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6381653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -16.801, 18.577, 7.075
VPMG::focusFillBound -- New mesh maxs = 47.807, 73.708, 76.754
VPMG::focusFillBound -- Old mesh mins = -26.801, 8.577, -2.925
VPMG::focusFillBound -- Old mesh maxs = 57.807, 83.708, 86.754
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.380143
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.669900e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.922300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.737700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.150904e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4256123.341289
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.201863e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.175158e+05
Vprtstp: contraction number = 4.175158e+05
Vnewton: Attempting damping, relres = 0.127773
Vnewton: Attempting damping, relres = 0.541339
Vnewton: Damping accepted, relres = 0.127773
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.277733e-01
Vprtstp: contraction number = 1.277733e-01
Vnewton: Using errtol_s: 543819.128027
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.295836e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.986428e+04
Vprtstp: contraction number = 5.986428e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.615463e-02
Vprtstp: contraction number = 2.046955e-01
Vnewton: Using errtol_s: 111317.344229
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.365132e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.130719e+04
Vprtstp: contraction number = 1.130719e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.027726e-03
Vprtstp: contraction number = 2.686991e-01
Vnewton: Using errtol_s: 29910.868657
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.435717e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.016521e+03
Vprtstp: contraction number = 3.016521e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.144591e-03
Vprtstp: contraction number = 3.051615e-01
Vnewton: Using errtol_s: 9127.645756
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.505901e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.032396e+03
Vprtstp: contraction number = 1.032396e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.426535e-04
Vprtstp: contraction number = 2.996624e-01
Vnewton: Using errtol_s: 2735.212520
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.576012e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.546958e+02
Vprtstp: contraction number = 3.546958e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.581923e-04
Vprtstp: contraction number = 2.461548e-01
Vnewton: Using errtol_s: 673.285735
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.645251e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.025243e+02
Vprtstp: contraction number = 1.025243e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.858395e-05
Vprtstp: contraction number = 1.806912e-01
Vnewton: Using errtol_s: 121.656815
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.714587e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.290965e+01
Vprtstp: contraction number = 2.290965e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.953731e-06
Vprtstp: contraction number = 1.733047e-01
Vnewton: Using errtol_s: 21.083692
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.783946e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.639840e+00
Vprtstp: contraction number = 4.639840e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.813570e-07
Vprtstp: contraction number = 1.981046e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.863770e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.525890e-01
Vpmg_setPart:  lower corner = (-16.801, 18.577, 7.075)
Vpmg_setPart:  upper corner = (47.807, 73.708, 76.754)
Vpmg_setPart:  actual minima = (-16.801, 18.577, 7.075)
Vpmg_setPart:  actual maxima = (47.807, 73.708, 76.754)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.021060e+00
