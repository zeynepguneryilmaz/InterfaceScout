##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:26 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16378 atoms
Valist_getStatistics:  Max atom coordinate:  (59.251, 70.957, 67.909)
Valist_getStatistics:  Min atom coordinate:  (-33.283, -0.428, -32.929)
Valist_getStatistics:  Molecule center:  (12.984, 35.2645, 17.49)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.828337, 0.870195, 0.880238
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.703338, 0.713945, 0.755238
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.849095, 0.820443, 0.857993 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 79.251 90.957 87.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -53.283 -20.428 -52.929
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 69.251 80.957 77.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -43.283 -10.428 -42.929
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 69.251 80.957 77.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -43.283 -10.428 -42.929
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8517262 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.423151
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.053127e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.951800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.125450e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.417339e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.321247e-02
Vprtstp: contraction number = 5.321247e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.510251e-03
Vprtstp: contraction number = 1.223445e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.224730e-03
Vprtstp: contraction number = 1.881233e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.786159e-04
Vprtstp: contraction number = 2.274917e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.959585e-05
Vprtstp: contraction number = 3.215748e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.452050e-05
Vprtstp: contraction number = 2.736790e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.678975e-06
Vprtstp: contraction number = 3.539477e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.581275e-06
Vprtstp: contraction number = 2.974170e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.817010e-07
Vprtstp: contraction number = 3.803163e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.526718e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.851658e+00
Vpmg_setPart:  lower corner = (-53.283, -20.428, -52.929)
Vpmg_setPart:  upper corner = (79.251, 90.957, 87.909)
Vpmg_setPart:  actual minima = (-53.283, -20.428, -52.929)
Vpmg_setPart:  actual maxima = (79.251, 90.957, 87.909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8517262 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -43.283, -10.428, -42.929
VPMG::focusFillBound -- New mesh maxs = 69.251, 80.957, 77.909
VPMG::focusFillBound -- Old mesh mins = -53.283, -20.428, -52.929
VPMG::focusFillBound -- Old mesh maxs = 79.251, 90.957, 87.909
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.419474
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.214081e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.091200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.103880e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.493331e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.586576e-02
Vprtstp: contraction number = 6.586576e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.309417e-03
Vprtstp: contraction number = 1.261569e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.625413e-03
Vprtstp: contraction number = 1.956109e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.749553e-04
Vprtstp: contraction number = 2.306831e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.231304e-04
Vprtstp: contraction number = 3.283870e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.862762e-05
Vprtstp: contraction number = 3.137130e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.619583e-05
Vprtstp: contraction number = 4.192810e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.165215e-06
Vprtstp: contraction number = 3.189226e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.270706e-06
Vprtstp: contraction number = 4.396150e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.568133e-07
Vprtstp: contraction number = 3.332942e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.733291e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.058806e+00
Vpmg_setPart:  lower corner = (-43.283, -10.428, -42.929)
Vpmg_setPart:  upper corner = (69.251, 80.957, 77.909)
Vpmg_setPart:  actual minima = (-43.283, -10.428, -42.929)
Vpmg_setPart:  actual maxima = (69.251, 80.957, 77.909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.095147e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:41 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16378 atoms
Valist_getStatistics:  Max atom coordinate:  (59.251, 70.957, 67.909)
Valist_getStatistics:  Min atom coordinate:  (-33.283, -0.428, -32.929)
Valist_getStatistics:  Molecule center:  (12.984, 35.2645, 17.49)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.828337, 0.870195, 0.880238
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.703338, 0.713945, 0.755238
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.849095, 0.820443, 0.857993 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 79.251 90.957 87.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -53.283 -20.428 -52.929
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 69.251 80.957 77.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -43.283 -10.428 -42.929
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 69.251 80.957 77.909
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -43.283 -10.428 -42.929
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8517262 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.426066
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.057559e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 6.994400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.425960e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.346729e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 18243941.400686
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.561785e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.805671e+05
Vprtstp: contraction number = 9.805671e+05
Vnewton: Attempting damping, relres = 0.049815
Vnewton: Attempting damping, relres = 0.519284
Vnewton: Damping accepted, relres = 0.049815
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.981539e-02
Vprtstp: contraction number = 4.981539e-02
Vnewton: Using errtol_s: 908829.049390
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.001235e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.154962e+05
Vprtstp: contraction number = 1.154962e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.733168e-03
Vprtstp: contraction number = 1.150883e-01
Vnewton: Using errtol_s: 104595.585899
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.344647e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.681251e+04
Vprtstp: contraction number = 1.681251e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.298559e-04
Vprtstp: contraction number = 1.447465e-01
Vnewton: Using errtol_s: 15139.841738
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.688930e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.891116e+03
Vprtstp: contraction number = 2.891116e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.426271e-04
Vprtstp: contraction number = 1.718697e-01
Vnewton: Using errtol_s: 2602.079550
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.023282e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.679592e+02
Vprtstp: contraction number = 5.679592e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.801831e-05
Vprtstp: contraction number = 1.964445e-01
Vnewton: Using errtol_s: 511.164336
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.354594e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.252006e+02
Vprtstp: contraction number = 1.252006e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.176327e-06
Vprtstp: contraction number = 2.204390e-01
Vnewton: Using errtol_s: 112.680545
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.689652e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.052116e+01
Vprtstp: contraction number = 3.052116e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.505653e-06
Vprtstp: contraction number = 2.437781e-01
Vnewton: Using errtol_s: 27.469046
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.024572e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.173708e+00
Vprtstp: contraction number = 8.173708e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.032209e-07
Vprtstp: contraction number = 2.678046e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.937375e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.187344e+00
Vpmg_setPart:  lower corner = (-53.283, -20.428, -52.929)
Vpmg_setPart:  upper corner = (79.251, 90.957, 87.909)
Vpmg_setPart:  actual minima = (-53.283, -20.428, -52.929)
Vpmg_setPart:  actual maxima = (79.251, 90.957, 87.909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8517262 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -43.283, -10.428, -42.929
VPMG::focusFillBound -- New mesh maxs = 69.251, 80.957, 77.909
VPMG::focusFillBound -- Old mesh mins = -53.283, -20.428, -52.929
VPMG::focusFillBound -- Old mesh maxs = 79.251, 90.957, 87.909
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.415474
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.212223e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 7.181700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.403490e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.755929e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 21012660.484499
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.968509e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.435875e+06
Vprtstp: contraction number = 1.435875e+06
Vnewton: Attempting damping, relres = 0.062675
Vnewton: Attempting damping, relres = 0.526812
Vnewton: Damping accepted, relres = 0.062675
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.267499e-02
Vprtstp: contraction number = 6.267499e-02
Vnewton: Using errtol_s: 1316968.225094
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.040489e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.722170e+05
Vprtstp: contraction number = 1.722170e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.402173e-03
Vprtstp: contraction number = 1.181041e-01
Vnewton: Using errtol_s: 155539.338547
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.074159e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.506610e+04
Vprtstp: contraction number = 2.506610e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.073762e-03
Vprtstp: contraction number = 1.450603e-01
Vnewton: Using errtol_s: 22562.588816
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.108037e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.210203e+03
Vprtstp: contraction number = 4.210203e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.803291e-04
Vprtstp: contraction number = 1.679415e-01
Vnewton: Using errtol_s: 3789.194219
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.141610e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.762086e+02
Vprtstp: contraction number = 7.762086e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.324607e-05
Vprtstp: contraction number = 1.843633e-01
Vnewton: Using errtol_s: 698.588375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.175276e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.530217e+02
Vprtstp: contraction number = 1.530217e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.554125e-06
Vprtstp: contraction number = 1.971398e-01
Vnewton: Using errtol_s: 137.719597
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.208727e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.236839e+01
Vprtstp: contraction number = 3.236839e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.386381e-06
Vprtstp: contraction number = 2.115280e-01
Vnewton: Using errtol_s: 29.131550
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.242582e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.482647e+00
Vprtstp: contraction number = 7.482647e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.204917e-07
Vprtstp: contraction number = 2.311714e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.925576e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.175771e+00
Vpmg_setPart:  lower corner = (-43.283, -10.428, -42.929)
Vpmg_setPart:  upper corner = (69.251, 80.957, 77.909)
Vpmg_setPart:  actual minima = (-43.283, -10.428, -42.929)
Vpmg_setPart:  actual maxima = (69.251, 80.957, 77.909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.341517e+01
