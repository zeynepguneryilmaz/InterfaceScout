##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:14 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6518 atoms
Valist_getStatistics:  Max atom coordinate:  (46.765, 59.843, 65.515)
Valist_getStatistics:  Min atom coordinate:  (-11.498, 2.215, 13.555)
Valist_getStatistics:  Molecule center:  (17.6335, 31.029, 39.535)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.76768, 0.762719, 0.957917
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.61143, 0.606469, 0.749583
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.796465, 0.795141, 0.782514 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.765 79.843 85.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -31.498 -17.785 -6.445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.765 69.843 75.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -21.498 -7.785 3.555
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.765 69.843 75.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -21.498 -7.785 3.555
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8261550 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.805925
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.127602e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.415700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.030000e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.303528e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.811230e-02
Vprtstp: contraction number = 5.811230e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.685573e-03
Vprtstp: contraction number = 1.322538e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.481961e-03
Vprtstp: contraction number = 1.928238e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.335239e-04
Vprtstp: contraction number = 2.250557e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.118626e-05
Vprtstp: contraction number = 2.734025e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.864757e-05
Vprtstp: contraction number = 3.141654e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.479574e-06
Vprtstp: contraction number = 3.309032e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.473307e-06
Vprtstp: contraction number = 3.663991e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.189494e-06
Vprtstp: contraction number = 3.424674e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.666603e-07
Vprtstp: contraction number = 3.923182e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.601890e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.178960e-01
Vpmg_setPart:  lower corner = (-31.498, -17.785, -6.445)
Vpmg_setPart:  upper corner = (66.765, 79.843, 85.515)
Vpmg_setPart:  actual minima = (-31.498, -17.785, -6.445)
Vpmg_setPart:  actual maxima = (66.765, 79.843, 85.515)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8261550 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -21.498, -7.785, 3.555
VPMG::focusFillBound -- New mesh maxs = 56.765, 69.843, 75.515
VPMG::focusFillBound -- Old mesh mins = -31.498, -17.785, -6.445
VPMG::focusFillBound -- Old mesh maxs = 66.765, 79.843, 85.515
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.801535
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.234829e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.504700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.866700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.347394e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.746082e-02
Vprtstp: contraction number = 7.746082e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.071642e-02
Vprtstp: contraction number = 1.383464e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.994020e-03
Vprtstp: contraction number = 1.860714e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.501238e-04
Vprtstp: contraction number = 2.257368e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.226805e-04
Vprtstp: contraction number = 2.725484e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.998221e-05
Vprtstp: contraction number = 3.259052e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.393107e-05
Vprtstp: contraction number = 3.484317e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.742774e-06
Vprtstp: contraction number = 4.122278e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.236755e-06
Vprtstp: contraction number = 3.894904e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.007057e-06
Vprtstp: contraction number = 4.502311e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.034194e-07
Vprtstp: contraction number = 4.005925e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.588570e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.034020e-01
Vpmg_setPart:  lower corner = (-21.498, -7.785, 3.555)
Vpmg_setPart:  upper corner = (56.765, 69.843, 75.515)
Vpmg_setPart:  actual minima = (-21.498, -7.785, 3.555)
Vpmg_setPart:  actual maxima = (56.765, 69.843, 75.515)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.452535e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:20 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6518 atoms
Valist_getStatistics:  Max atom coordinate:  (46.765, 59.843, 65.515)
Valist_getStatistics:  Min atom coordinate:  (-11.498, 2.215, 13.555)
Valist_getStatistics:  Molecule center:  (17.6335, 31.029, 39.535)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.76768, 0.762719, 0.957917
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.61143, 0.606469, 0.749583
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.796465, 0.795141, 0.782514 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.765 79.843 85.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -31.498 -17.785 -6.445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.765 69.843 75.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -21.498 -7.785 3.555
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.765 69.843 75.515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -21.498 -7.785 3.555
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8261550 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.802117
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.124373e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.449400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.782200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.263625e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8281259.968615
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.361899e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.817532e+05
Vprtstp: contraction number = 4.817532e+05
Vnewton: Attempting damping, relres = 0.062655
Vnewton: Attempting damping, relres = 0.521347
Vnewton: Damping accepted, relres = 0.062655
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.265503e-02
Vprtstp: contraction number = 6.265503e-02
Vnewton: Using errtol_s: 518862.579066
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.553715e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.881340e+04
Vprtstp: contraction number = 6.881340e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.026682e-02
Vprtstp: contraction number = 1.638627e-01
Vnewton: Using errtol_s: 85022.202375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.697994e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.435179e+04
Vprtstp: contraction number = 1.435179e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.261992e-03
Vprtstp: contraction number = 2.203206e-01
Vnewton: Using errtol_s: 18732.144106
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.840873e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.742580e+03
Vprtstp: contraction number = 3.742580e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.503474e-04
Vprtstp: contraction number = 2.433021e-01
Vnewton: Using errtol_s: 4557.570007
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.983595e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.014933e+03
Vprtstp: contraction number = 1.014933e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.257378e-04
Vprtstp: contraction number = 2.284698e-01
Vnewton: Using errtol_s: 1041.267134
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.125566e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.547896e+02
Vprtstp: contraction number = 2.547896e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.815452e-05
Vprtstp: contraction number = 2.239146e-01
Vnewton: Using errtol_s: 233.154914
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.270053e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.245293e+01
Vprtstp: contraction number = 6.245293e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.788240e-06
Vprtstp: contraction number = 2.411066e-01
Vnewton: Using errtol_s: 56.215184
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.413784e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.584933e+01
Vprtstp: contraction number = 1.584933e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.722504e-06
Vprtstp: contraction number = 2.537482e-01
Vnewton: Using errtol_s: 14.264504
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.557686e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.095259e+00
Vprtstp: contraction number = 4.095259e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.450694e-07
Vprtstp: contraction number = 2.583851e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.402878e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.523492e+00
Vpmg_setPart:  lower corner = (-31.498, -17.785, -6.445)
Vpmg_setPart:  upper corner = (66.765, 79.843, 85.515)
Vpmg_setPart:  actual minima = (-31.498, -17.785, -6.445)
Vpmg_setPart:  actual maxima = (66.765, 79.843, 85.515)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8261550 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -21.498, -7.785, 3.555
VPMG::focusFillBound -- New mesh maxs = 56.765, 69.843, 75.515
VPMG::focusFillBound -- Old mesh mins = -31.498, -17.785, -6.445
VPMG::focusFillBound -- Old mesh maxs = 66.765, 79.843, 85.515
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.798180
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.231783e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.369300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.809500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.022776e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9778482.706643
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.120244e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.061939e+05
Vprtstp: contraction number = 8.061939e+05
Vnewton: Attempting damping, relres = 0.082933
Vnewton: Attempting damping, relres = 0.533531
Vnewton: Damping accepted, relres = 0.082933
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.293338e-02
Vprtstp: contraction number = 8.293338e-02
Vnewton: Using errtol_s: 810962.583081
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.312627e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.139113e+05
Vprtstp: contraction number = 1.139113e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.283272e-02
Vprtstp: contraction number = 1.547353e-01
Vnewton: Using errtol_s: 125484.569456
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.461722e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.159341e+04
Vprtstp: contraction number = 2.159341e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.584584e-03
Vprtstp: contraction number = 2.014057e-01
Vnewton: Using errtol_s: 25273.311481
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.607534e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.929700e+03
Vprtstp: contraction number = 4.929700e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.777894e-04
Vprtstp: contraction number = 2.235522e-01
Vnewton: Using errtol_s: 5649.903208
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.756599e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.206223e+03
Vprtstp: contraction number = 1.206223e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.237312e-04
Vprtstp: contraction number = 2.141459e-01
Vnewton: Using errtol_s: 1209.903862
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.904617e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.774460e+02
Vprtstp: contraction number = 2.774460e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.584058e-05
Vprtstp: contraction number = 2.088444e-01
Vnewton: Using errtol_s: 252.681654
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.053452e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.230114e+01
Vprtstp: contraction number = 6.230114e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.733368e-06
Vprtstp: contraction number = 2.218746e-01
Vnewton: Using errtol_s: 56.063644
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.201979e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.346359e+01
Vprtstp: contraction number = 1.346359e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.239177e-06
Vprtstp: contraction number = 2.161341e-01
Vnewton: Using errtol_s: 12.117267
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.351851e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.970286e+00
Vprtstp: contraction number = 2.970286e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.733816e-07
Vprtstp: contraction number = 2.206155e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.440073e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.560538e+00
Vpmg_setPart:  lower corner = (-21.498, -7.785, 3.555)
Vpmg_setPart:  upper corner = (56.765, 69.843, 75.515)
Vpmg_setPart:  actual minima = (-21.498, -7.785, 3.555)
Vpmg_setPart:  actual maxima = (56.765, 69.843, 75.515)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.812718e+00
