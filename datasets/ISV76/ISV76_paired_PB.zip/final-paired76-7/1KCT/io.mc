##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:06 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5969 atoms
Valist_getStatistics:  Max atom coordinate:  (65.368, 24.495, 51.41)
Valist_getStatistics:  Min atom coordinate:  (-1.991, -23.12, -7.811)
Valist_getStatistics:  Molecule center:  (31.6885, 0.6875, 21.7995)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.838742, 0.912656, 0.775164
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.682492, 0.704323, 0.618914
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.813709, 0.771729, 0.79843 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.368 44.495 71.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -21.991 -43.12 -27.811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.368 34.495 61.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -11.991 -33.12 -17.811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.368 34.495 61.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -11.991 -33.12 -17.811
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107692 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.766869
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.071972e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.335300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.981700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.222644e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.879583e-02
Vprtstp: contraction number = 6.879583e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.039566e-02
Vprtstp: contraction number = 1.511089e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.514611e-03
Vprtstp: contraction number = 2.418905e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.783749e-04
Vprtstp: contraction number = 3.493084e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.348111e-04
Vprtstp: contraction number = 3.811710e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.574213e-04
Vprtstp: contraction number = 4.701795e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.680501e-05
Vprtstp: contraction number = 4.243708e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.338552e-05
Vprtstp: contraction number = 4.997457e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.430423e-05
Vprtstp: contraction number = 4.284562e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.244569e-06
Vprtstp: contraction number = 5.064633e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.101696e-06
Vprtstp: contraction number = 4.281408e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.577839e-06
Vprtstp: contraction number = 5.087020e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.748175e-07
Vprtstp: contraction number = 4.276847e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.290070e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.623630e-01
Vpmg_setPart:  lower corner = (-21.991, -43.12, -27.811)
Vpmg_setPart:  upper corner = (85.368, 44.495, 71.41)
Vpmg_setPart:  actual minima = (-21.991, -43.12, -27.811)
Vpmg_setPart:  actual maxima = (85.368, 44.495, 71.41)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107692 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -11.991, -33.12, -17.811
VPMG::focusFillBound -- New mesh maxs = 75.368, 34.495, 61.41
VPMG::focusFillBound -- Old mesh mins = -21.991, -43.12, -27.811
VPMG::focusFillBound -- Old mesh maxs = 85.368, 44.495, 71.41
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.762839
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.175367e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.427000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.011400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.365134e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.736501e-02
Vprtstp: contraction number = 8.736501e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.234172e-02
Vprtstp: contraction number = 1.412662e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.440028e-03
Vprtstp: contraction number = 1.977056e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.742218e-04
Vprtstp: contraction number = 3.173004e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.963789e-04
Vprtstp: contraction number = 3.828087e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.546240e-04
Vprtstp: contraction number = 5.217108e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.199407e-05
Vprtstp: contraction number = 4.656073e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.086801e-05
Vprtstp: contraction number = 5.676579e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.947828e-05
Vprtstp: contraction number = 4.766144e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.118531e-05
Vprtstp: contraction number = 5.742452e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.356238e-06
Vprtstp: contraction number = 4.788637e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.081748e-06
Vprtstp: contraction number = 5.753568e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.479695e-06
Vprtstp: contraction number = 4.801480e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 8.520765e-07
Vprtstp: contraction number = 5.758460e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.383240e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.072089e+00
Vpmg_setPart:  lower corner = (-11.991, -33.12, -17.811)
Vpmg_setPart:  upper corner = (75.368, 34.495, 61.41)
Vpmg_setPart:  actual minima = (-11.991, -33.12, -17.811)
Vpmg_setPart:  actual maxima = (75.368, 34.495, 61.41)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.638654e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5969 atoms
Valist_getStatistics:  Max atom coordinate:  (65.368, 24.495, 51.41)
Valist_getStatistics:  Min atom coordinate:  (-1.991, -23.12, -7.811)
Valist_getStatistics:  Molecule center:  (31.6885, 0.6875, 21.7995)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.838742, 0.912656, 0.775164
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.682492, 0.704323, 0.618914
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.813709, 0.771729, 0.79843 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.368 44.495 71.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -21.991 -43.12 -27.811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.368 34.495 61.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -11.991 -33.12 -17.811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.368 34.495 61.41
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -11.991 -33.12 -17.811
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107692 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.772087
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.081818e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.328800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.747100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.217340e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6786223.623495
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.317891e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.697127e+05
Vprtstp: contraction number = 4.697127e+05
Vnewton: Attempting damping, relres = 0.066729
Vnewton: Attempting damping, relres = 0.526306
Vnewton: Damping accepted, relres = 0.066729
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.672887e-02
Vprtstp: contraction number = 6.672887e-02
Vnewton: Using errtol_s: 452837.034967
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.514093e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.259782e+04
Vprtstp: contraction number = 6.259782e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.743505e-03
Vprtstp: contraction number = 1.310303e-01
Vnewton: Using errtol_s: 59335.378635
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.668001e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.007378e+04
Vprtstp: contraction number = 1.007378e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.363412e-03
Vprtstp: contraction number = 1.559342e-01
Vnewton: Using errtol_s: 9252.416269
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.819183e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.770054e+03
Vprtstp: contraction number = 1.770054e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.352377e-04
Vprtstp: contraction number = 1.725361e-01
Vnewton: Using errtol_s: 1596.375758
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.973976e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.288416e+02
Vprtstp: contraction number = 3.288416e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.361206e-05
Vprtstp: contraction number = 1.853957e-01
Vnewton: Using errtol_s: 295.961187
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.130952e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.445868e+01
Vprtstp: contraction number = 6.445868e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.548663e-06
Vprtstp: contraction number = 1.960160e-01
Vnewton: Using errtol_s: 58.013136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.280768e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.456266e+01
Vprtstp: contraction number = 1.456266e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.931325e-06
Vprtstp: contraction number = 2.259213e-01
Vnewton: Using errtol_s: 13.106401
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.428995e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.796704e+00
Vprtstp: contraction number = 3.796704e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.035264e-07
Vprtstp: contraction number = 2.607156e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.320020e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.438401e+00
Vpmg_setPart:  lower corner = (-21.991, -43.12, -27.811)
Vpmg_setPart:  upper corner = (85.368, 44.495, 71.41)
Vpmg_setPart:  actual minima = (-21.991, -43.12, -27.811)
Vpmg_setPart:  actual maxima = (85.368, 44.495, 71.41)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107692 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -11.991, -33.12, -17.811
VPMG::focusFillBound -- New mesh maxs = 75.368, 34.495, 61.41
VPMG::focusFillBound -- Old mesh mins = -21.991, -43.12, -27.811
VPMG::focusFillBound -- Old mesh maxs = 85.368, 44.495, 71.41
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.763217
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.176636e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.356600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.832800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.837550e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8074798.237653
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.936046e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.479048e+05
Vprtstp: contraction number = 7.479048e+05
Vnewton: Attempting damping, relres = 0.086659
Vnewton: Attempting damping, relres = 0.538313
Vnewton: Damping accepted, relres = 0.086659
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.665922e-02
Vprtstp: contraction number = 8.665922e-02
Vnewton: Using errtol_s: 699755.689744
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.131905e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.791374e+04
Vprtstp: contraction number = 9.791374e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.117991e-02
Vprtstp: contraction number = 1.290100e-01
Vnewton: Using errtol_s: 90275.504335
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.279449e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.508944e+04
Vprtstp: contraction number = 1.508944e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.688539e-03
Vprtstp: contraction number = 1.510334e-01
Vnewton: Using errtol_s: 13634.614590
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.431485e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.549134e+03
Vprtstp: contraction number = 2.549134e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.841424e-04
Vprtstp: contraction number = 1.682770e-01
Vnewton: Using errtol_s: 2294.392408
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.583701e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.547138e+02
Vprtstp: contraction number = 4.547138e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.068161e-05
Vprtstp: contraction number = 1.783669e-01
Vnewton: Using errtol_s: 409.243738
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.732696e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.083144e+01
Vprtstp: contraction number = 9.083144e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.012463e-05
Vprtstp: contraction number = 1.997693e-01
Vnewton: Using errtol_s: 81.754320
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.880994e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.439220e+01
Vprtstp: contraction number = 2.439220e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.718707e-06
Vprtstp: contraction number = 2.685242e-01
Vnewton: Using errtol_s: 21.953011
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.025752e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.538840e+00
Vprtstp: contraction number = 7.538840e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.403097e-07
Vprtstp: contraction number = 3.090843e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.296406e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.415810e+00
Vpmg_setPart:  lower corner = (-11.991, -33.12, -17.811)
Vpmg_setPart:  upper corner = (75.368, 34.495, 61.41)
Vpmg_setPart:  actual minima = (-11.991, -33.12, -17.811)
Vpmg_setPart:  actual maxima = (75.368, 34.495, 61.41)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.483758e+00
