##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 225, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 81294 atoms
Valist_getStatistics:  Max atom coordinate:  (146.872, 185.854, 168.776)
Valist_getStatistics:  Min atom coordinate:  (-14.542, 39.991, -24.762)
Valist_getStatistics:  Molecule center:  (66.165, 112.923, 72.007)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.786773, 0.829746, 0.912258
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.708648, 0.74046, 0.834133
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.900702, 0.892394, 0.914361 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 166.872 205.854 188.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.542 19.991 -44.762
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 156.872 195.854 178.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -24.542 29.991 -34.762
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 156.872 195.854 178.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -24.542 29.991 -34.762
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -62.0012
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12671661 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.710775
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.002831e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.068190e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 113, 129)
Vbuildops: Galer: (065, 057, 065)
Vbuildops: Galer: (033, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.634555e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.533125e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.090199e-02
Vprtstp: contraction number = 7.090199e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.029632e-02
Vprtstp: contraction number = 1.452191e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.400156e-03
Vprtstp: contraction number = 2.331081e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.407128e-04
Vprtstp: contraction number = 3.086103e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.840050e-04
Vprtstp: contraction number = 3.834211e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.202320e-04
Vprtstp: contraction number = 4.233446e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.118507e-05
Vprtstp: contraction number = 4.257193e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.310845e-05
Vprtstp: contraction number = 4.514686e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.015818e-05
Vprtstp: contraction number = 4.395874e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.651672e-06
Vprtstp: contraction number = 4.579236e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.099825e-06
Vprtstp: contraction number = 4.514129e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 9.637731e-07
Vprtstp: contraction number = 4.589779e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.155053e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.667759e+01
Vpmg_setPart:  lower corner = (-34.542, 19.991, -44.762)
Vpmg_setPart:  upper corner = (166.872, 205.854, 188.776)
Vpmg_setPart:  actual minima = (-34.542, 19.991, -44.762)
Vpmg_setPart:  actual maxima = (166.872, 205.854, 188.776)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -62.0012
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12671661 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -24.542, 29.991, -34.762
VPMG::focusFillBound -- New mesh maxs = 156.872, 195.854, 178.776
VPMG::focusFillBound -- Old mesh mins = -34.542, 19.991, -44.762
VPMG::focusFillBound -- Old mesh maxs = 166.872, 205.854, 188.776
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.653443
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.055418e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.068080e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 113, 129)
Vbuildops: Galer: (065, 057, 065)
Vbuildops: Galer: (033, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.989728e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.299078e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.544301e-02
Vprtstp: contraction number = 7.544301e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.115432e-02
Vprtstp: contraction number = 1.478509e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.585268e-03
Vprtstp: contraction number = 2.317729e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.364661e-04
Vprtstp: contraction number = 3.235511e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.422844e-04
Vprtstp: contraction number = 4.092029e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.620295e-04
Vprtstp: contraction number = 4.733769e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.553580e-05
Vprtstp: contraction number = 4.661855e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.819442e-05
Vprtstp: contraction number = 5.056466e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.843977e-05
Vprtstp: contraction number = 4.827870e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.401285e-06
Vprtstp: contraction number = 5.098374e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.663973e-06
Vprtstp: contraction number = 4.960995e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.365931e-06
Vprtstp: contraction number = 5.072780e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.202047e-06
Vprtstp: contraction number = 5.080650e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.043026e-07
Vprtstp: contraction number = 5.027280e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.370830e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.919039e+01
Vpmg_setPart:  lower corner = (-24.542, 29.991, -34.762)
Vpmg_setPart:  upper corner = (156.872, 195.854, 178.776)
Vpmg_setPart:  actual minima = (-24.542, 29.991, -34.762)
Vpmg_setPart:  actual maxima = (156.872, 195.854, 178.776)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.007413e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:51 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 225, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 81294 atoms
Valist_getStatistics:  Max atom coordinate:  (146.872, 185.854, 168.776)
Valist_getStatistics:  Min atom coordinate:  (-14.542, 39.991, -24.762)
Valist_getStatistics:  Molecule center:  (66.165, 112.923, 72.007)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.786773, 0.829746, 0.912258
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.708648, 0.74046, 0.834133
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.900702, 0.892394, 0.914361 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 166.872 205.854 188.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.542 19.991 -44.762
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 156.872 195.854 178.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -24.542 29.991 -34.762
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 156.872 195.854 178.776
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -24.542 29.991 -34.762
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -62.0012
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12671661 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.721686
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.003906e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (257, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.078670e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 113, 129)
Vbuildops: Galer: (065, 057, 065)
Vbuildops: Galer: (033, 029, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.481770e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.153229e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 103686755.759654
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.248617e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.304368e+06
Vprtstp: contraction number = 7.304368e+06
Vnewton: Attempting damping, relres = 0.148683
Vnewton: Attempting damping, relres = 0.527752
Vnewton: Damping accepted, relres = 0.148683
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.486830e-01
Vprtstp: contraction number = 1.486830e-01
Vnewton: Using errtol_s: 15416455.437635
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.459556e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.793705e+05
Vprtstp: contraction number = 9.793705e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.701558e-02
Vprtstp: contraction number = 2.489564e-01
Vnewton: Using errtol_s: 3838025.632838
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.626130e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.974399e+05
Vprtstp: contraction number = 1.974399e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.061651e-02
Vprtstp: contraction number = 2.868119e-01
Vnewton: Using errtol_s: 1100791.471677
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.794404e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.507403e+04
Vprtstp: contraction number = 5.507403e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.145987e-03
Vprtstp: contraction number = 2.963297e-01
Vnewton: Using errtol_s: 326197.214618
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.965678e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.711239e+04
Vprtstp: contraction number = 1.711239e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.783339e-04
Vprtstp: contraction number = 3.109783e-01
Vnewton: Using errtol_s: 101440.271259
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.133398e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.225943e+03
Vprtstp: contraction number = 6.225943e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.308289e-04
Vprtstp: contraction number = 3.381554e-01
Vnewton: Using errtol_s: 34302.573418
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.304776e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.171162e+03
Vprtstp: contraction number = 3.171162e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.176357e-04
Vprtstp: contraction number = 3.555786e-01
Vnewton: Using errtol_s: 12197.261134
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.476253e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.945183e+03
Vprtstp: contraction number = 1.945183e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.335213e-05
Vprtstp: contraction number = 3.685288e-01
Vnewton: Using errtol_s: 4495.041683
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.647977e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.197848e+03
Vprtstp: contraction number = 1.197848e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.670672e-05
Vprtstp: contraction number = 3.853726e-01
Vnewton: Using errtol_s: 1732.266071
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.817421e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.789670e+02
Vprtstp: contraction number = 6.789670e+02
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.802147e-06
Vprtstp: contraction number = 4.071503e-01
Vnewton: Using errtol_s: 705.292567
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.986599e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.445304e+02
Vprtstp: contraction number = 3.445304e+02
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.053415e-06
Vprtstp: contraction number = 4.488899e-01
Vnewton: Using errtol_s: 316.598700
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.155318e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.653532e+02
Vprtstp: contraction number = 1.653532e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.442293e-06
Vprtstp: contraction number = 4.723540e-01
Vnewton: Using errtol_s: 149.546661
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.323834e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.875588e+01
Vprtstp: contraction number = 7.875588e+01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.851600e-07
Vprtstp: contraction number = 4.750492e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.303172e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.435080e+01
Vpmg_setPart:  lower corner = (-34.542, 19.991, -44.762)
Vpmg_setPart:  upper corner = (166.872, 205.854, 188.776)
Vpmg_setPart:  actual minima = (-34.542, 19.991, -44.762)
Vpmg_setPart:  actual maxima = (166.872, 205.854, 188.776)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -62.0012
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12671661 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -24.542, 29.991, -34.762
VPMG::focusFillBound -- New mesh maxs = 156.872, 195.854, 178.776
VPMG::focusFillBound -- Old mesh mins = -34.542, 19.991, -44.762
VPMG::focusFillBound -- Old mesh maxs = 166.872, 205.854, 188.776
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.630547
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.054926e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (257, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.106230e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 113, 129)
Vbuildops: Galer: (065, 057, 065)
Vbuildops: Galer: (033, 029, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 9.291450e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.658624e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 104186229.034974
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.753473e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.966579e+06
Vprtstp: contraction number = 7.966579e+06
Vnewton: Attempting damping, relres = 0.094525
Vnewton: Attempting damping, relres = 0.530409
Vnewton: Damping accepted, relres = 0.094525
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.452481e-02
Vprtstp: contraction number = 9.452481e-02
Vnewton: Using errtol_s: 9848183.884808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.965591e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.091566e+06
Vprtstp: contraction number = 1.091566e+06
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.781902e-02
Vprtstp: contraction number = 1.885116e-01
Vnewton: Using errtol_s: 1856496.856978
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.133372e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.888062e+05
Vprtstp: contraction number = 1.888062e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.479597e-03
Vprtstp: contraction number = 2.513941e-01
Vnewton: Using errtol_s: 466712.300016
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.301645e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.176512e+04
Vprtstp: contraction number = 4.176512e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.329516e-03
Vprtstp: contraction number = 2.967936e-01
Vnewton: Using errtol_s: 138517.246893
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.471511e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.275028e+04
Vprtstp: contraction number = 1.275028e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.334254e-04
Vprtstp: contraction number = 3.260024e-01
Vnewton: Using errtol_s: 45156.956968
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.643157e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.606385e+03
Vprtstp: contraction number = 5.606385e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.486582e-04
Vprtstp: contraction number = 3.429845e-01
Vnewton: Using errtol_s: 15488.135753
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.812031e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.052036e+03
Vprtstp: contraction number = 3.052036e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.252302e-05
Vprtstp: contraction number = 3.533140e-01
Vnewton: Using errtol_s: 5472.175045
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.979923e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.672098e+03
Vprtstp: contraction number = 1.672098e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.954480e-05
Vprtstp: contraction number = 3.721188e-01
Vnewton: Using errtol_s: 2036.299399
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.148069e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.534450e+02
Vprtstp: contraction number = 8.534450e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.997171e-06
Vprtstp: contraction number = 4.091712e-01
Vnewton: Using errtol_s: 833.195092
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.317084e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.176959e+02
Vprtstp: contraction number = 4.176959e+02
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.656562e-06
Vprtstp: contraction number = 4.572319e-01
Vnewton: Using errtol_s: 380.963404
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.487283e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.063392e+02
Vprtstp: contraction number = 2.063392e+02
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.789495e-06
Vprtstp: contraction number = 4.893928e-01
Vnewton: Using errtol_s: 186.440748
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.658450e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.047518e+02
Vprtstp: contraction number = 1.047518e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 9.067211e-07
Vprtstp: contraction number = 5.066910e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.133368e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.273726e+01
Vpmg_setPart:  lower corner = (-24.542, 29.991, -34.762)
Vpmg_setPart:  upper corner = (156.872, 195.854, 178.776)
Vpmg_setPart:  actual minima = (-24.542, 29.991, -34.762)
Vpmg_setPart:  actual maxima = (156.872, 195.854, 178.776)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.128827e+01
