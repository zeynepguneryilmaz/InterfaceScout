##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:29:44 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8739 atoms
Valist_getStatistics:  Max atom coordinate:  (47.471, 30.722, 43.241)
Valist_getStatistics:  Min atom coordinate:  (-19.459, -25.892, -16.428)
Valist_getStatistics:  Molecule center:  (14.006, 2.415, 13.4065)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.835391, 1.0064, 0.778664
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.679141, 0.798063, 0.622414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.812962, 0.792991, 0.799336 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 67.471 50.722 63.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.459 -45.892 -36.428
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.471 40.722 53.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.459 -35.892 -26.428
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.471 40.722 53.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.459 -35.892 -26.428
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9293468 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.138316
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.514410e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.337900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.103700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.671089e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.692370e-02
Vprtstp: contraction number = 5.692370e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.304452e-03
Vprtstp: contraction number = 1.458874e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.792549e-03
Vprtstp: contraction number = 2.158539e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.049092e-04
Vprtstp: contraction number = 2.258846e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.286000e-04
Vprtstp: contraction number = 3.176020e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.522535e-05
Vprtstp: contraction number = 2.739141e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.371932e-05
Vprtstp: contraction number = 3.894730e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.113593e-06
Vprtstp: contraction number = 2.998394e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.723573e-06
Vprtstp: contraction number = 4.189944e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.362977e-07
Vprtstp: contraction number = 3.111546e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.168280e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.505020e-01
Vpmg_setPart:  lower corner = (-39.459, -45.892, -36.428)
Vpmg_setPart:  upper corner = (67.471, 50.722, 63.241)
Vpmg_setPart:  actual minima = (-39.459, -45.892, -36.428)
Vpmg_setPart:  actual maxima = (67.471, 50.722, 63.241)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9293468 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.459, -35.892, -26.428
VPMG::focusFillBound -- New mesh maxs = 57.471, 40.722, 53.241
VPMG::focusFillBound -- Old mesh mins = -39.459, -45.892, -36.428
VPMG::focusFillBound -- Old mesh maxs = 67.471, 50.722, 63.241
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.132159
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.642614e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.401500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.080800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.070831e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.549681e-02
Vprtstp: contraction number = 7.549681e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.089447e-02
Vprtstp: contraction number = 1.443038e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.908150e-03
Vprtstp: contraction number = 1.751484e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.889138e-04
Vprtstp: contraction number = 2.038173e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.511654e-05
Vprtstp: contraction number = 2.188571e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.142370e-05
Vprtstp: contraction number = 2.516985e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.544742e-06
Vprtstp: contraction number = 2.588134e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.693103e-06
Vprtstp: contraction number = 3.053529e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.021655e-07
Vprtstp: contraction number = 2.965947e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.722170e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.071770e-01
Vpmg_setPart:  lower corner = (-29.459, -35.892, -26.428)
Vpmg_setPart:  upper corner = (57.471, 40.722, 53.241)
Vpmg_setPart:  actual minima = (-29.459, -35.892, -26.428)
Vpmg_setPart:  actual maxima = (57.471, 40.722, 53.241)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.997496e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:29:51 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8739 atoms
Valist_getStatistics:  Max atom coordinate:  (47.471, 30.722, 43.241)
Valist_getStatistics:  Min atom coordinate:  (-19.459, -25.892, -16.428)
Valist_getStatistics:  Molecule center:  (14.006, 2.415, 13.4065)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.835391, 1.0064, 0.778664
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.679141, 0.798063, 0.622414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.812962, 0.792991, 0.799336 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 67.471 50.722 63.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.459 -45.892 -36.428
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.471 40.722 53.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.459 -35.892 -26.428
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.471 40.722 53.241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.459 -35.892 -26.428
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9293468 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.133738
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.511732e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.329000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.773600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.652330e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9545959.667643
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.749574e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.582074e+05
Vprtstp: contraction number = 5.582074e+05
Vnewton: Attempting damping, relres = 0.110113
Vnewton: Attempting damping, relres = 0.522132
Vnewton: Damping accepted, relres = 0.110113
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.101130e-01
Vprtstp: contraction number = 1.101130e-01
Vnewton: Using errtol_s: 1051134.222395
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.934086e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.762343e+04
Vprtstp: contraction number = 9.762343e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.792962e-02
Vprtstp: contraction number = 2.536451e-01
Vnewton: Using errtol_s: 266615.002694
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.074587e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.629985e+04
Vprtstp: contraction number = 2.629985e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.749217e-03
Vprtstp: contraction number = 3.132594e-01
Vnewton: Using errtol_s: 83519.667917
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.214349e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.425925e+03
Vprtstp: contraction number = 8.425925e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.718667e-03
Vprtstp: contraction number = 3.107327e-01
Vnewton: Using errtol_s: 25952.288870
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.354040e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.877307e+03
Vprtstp: contraction number = 2.877307e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.039252e-04
Vprtstp: contraction number = 2.589229e-01
Vnewton: Using errtol_s: 6719.641618
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.494038e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.972651e+02
Vprtstp: contraction number = 8.972651e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.266698e-04
Vprtstp: contraction number = 1.799478e-01
Vnewton: Using errtol_s: 1209.185038
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.634085e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.978161e+02
Vprtstp: contraction number = 1.978161e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.931977e-05
Vprtstp: contraction number = 1.525207e-01
Vnewton: Using errtol_s: 184.425779
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.776099e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.620379e+01
Vprtstp: contraction number = 3.620379e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.415577e-06
Vprtstp: contraction number = 1.767918e-01
Vnewton: Using errtol_s: 32.604964
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.918096e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.072988e+00
Vprtstp: contraction number = 7.072988e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.668549e-07
Vprtstp: contraction number = 1.952393e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.372702e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.490446e+00
Vpmg_setPart:  lower corner = (-39.459, -45.892, -36.428)
Vpmg_setPart:  upper corner = (67.471, 50.722, 63.241)
Vpmg_setPart:  actual minima = (-39.459, -45.892, -36.428)
Vpmg_setPart:  actual maxima = (67.471, 50.722, 63.241)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9293468 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.459, -35.892, -26.428
VPMG::focusFillBound -- New mesh maxs = 57.471, 40.722, 53.241
VPMG::focusFillBound -- Old mesh mins = -39.459, -45.892, -36.428
VPMG::focusFillBound -- Old mesh maxs = 67.471, 50.722, 63.241
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.126757
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.640424e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.389700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.824600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.789002e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 11426027.026613
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.883934e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.377848e+05
Vprtstp: contraction number = 9.377848e+05
Vnewton: Attempting damping, relres = 0.117619
Vnewton: Attempting damping, relres = 0.533783
Vnewton: Damping accepted, relres = 0.117619
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.176192e-01
Vprtstp: contraction number = 1.176192e-01
Vnewton: Using errtol_s: 1343920.409228
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.074680e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.528680e+05
Vprtstp: contraction number = 1.528680e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.610501e-02
Vprtstp: contraction number = 2.219451e-01
Vnewton: Using errtol_s: 298276.550153
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.218922e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.328975e+04
Vprtstp: contraction number = 3.328975e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.384107e-03
Vprtstp: contraction number = 2.828617e-01
Vnewton: Using errtol_s: 84371.004066
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.362729e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.997428e+03
Vprtstp: contraction number = 8.997428e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.121542e-03
Vprtstp: contraction number = 2.873119e-01
Vnewton: Using errtol_s: 24240.796053
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.506852e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.884302e+03
Vprtstp: contraction number = 2.884302e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.066251e-04
Vprtstp: contraction number = 2.388004e-01
Vnewton: Using errtol_s: 5788.712311
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.648996e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.649435e+02
Vprtstp: contraction number = 8.649435e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.662124e-05
Vprtstp: contraction number = 1.709770e-01
Vnewton: Using errtol_s: 989.736594
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.790773e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.848818e+02
Vprtstp: contraction number = 1.848818e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.469772e-05
Vprtstp: contraction number = 1.696780e-01
Vnewton: Using errtol_s: 167.936543
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.934976e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.568676e+01
Vprtstp: contraction number = 3.568676e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.811175e-06
Vprtstp: contraction number = 1.912661e-01
Vnewton: Using errtol_s: 32.120562
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.079311e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.164043e+00
Vprtstp: contraction number = 7.164043e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.642948e-07
Vprtstp: contraction number = 2.007327e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.398373e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.517610e+00
Vpmg_setPart:  lower corner = (-29.459, -35.892, -26.428)
Vpmg_setPart:  upper corner = (57.471, 40.722, 53.241)
Vpmg_setPart:  actual minima = (-29.459, -35.892, -26.428)
Vpmg_setPart:  actual maxima = (57.471, 40.722, 53.241)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.545609e+00
