##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:22 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2226 atoms
Valist_getStatistics:  Max atom coordinate:  (23.969, 45.272, 32.405)
Valist_getStatistics:  Min atom coordinate:  (-15.451, 0.219, -2.639)
Valist_getStatistics:  Molecule center:  (4.259, 22.7455, 14.883)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.827292, 0.885969, 0.781708
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.618958, 0.677635, 0.573375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.748174, 0.764853, 0.73349 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 43.969 65.272 52.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -35.451 -19.781 -22.639
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 33.969 55.272 42.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -25.451 -9.781 -12.639
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 33.969 55.272 42.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -25.451 -9.781 -12.639
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.1265
Vpbe_ctor2:  solute dimensions = 41.733 x 47.052 x 37.334
Vpbe_ctor2:  solute charge = 10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 74 table
Vclist_ctor2:  Using 75 x 75 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.2, 57.833, 47.824)
Vclist_setupGrid:  Grid lower corner = (-21.841, -6.171, -9.029)
Vclist_assignAtoms:  Have 5395302 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.243808
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.025550e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.119600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.842600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.024700e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.707796e-02
Vprtstp: contraction number = 6.707796e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.457449e-03
Vprtstp: contraction number = 1.260839e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.413302e-03
Vprtstp: contraction number = 1.671073e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.844241e-04
Vprtstp: contraction number = 2.012480e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.617565e-05
Vprtstp: contraction number = 1.975067e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.311103e-05
Vprtstp: contraction number = 2.333934e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.707670e-06
Vprtstp: contraction number = 2.065185e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.688710e-07
Vprtstp: contraction number = 2.470282e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.654210e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.555520e-01
Vpmg_setPart:  lower corner = (-35.451, -19.781, -22.639)
Vpmg_setPart:  upper corner = (43.969, 65.272, 52.405)
Vpmg_setPart:  actual minima = (-35.451, -19.781, -22.639)
Vpmg_setPart:  actual maxima = (43.969, 65.272, 52.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.1265
Vpbe_ctor2:  solute dimensions = 41.733 x 47.052 x 37.334
Vpbe_ctor2:  solute charge = 10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 74 table
Vclist_ctor2:  Using 75 x 75 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.2, 57.833, 47.824)
Vclist_setupGrid:  Grid lower corner = (-21.841, -6.171, -9.029)
Vclist_assignAtoms:  Have 5395302 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -25.451, -9.781, -12.639
VPMG::focusFillBound -- New mesh maxs = 33.969, 55.272, 42.405
VPMG::focusFillBound -- Old mesh mins = -35.451, -19.781, -22.639
VPMG::focusFillBound -- Old mesh maxs = 43.969, 65.272, 52.405
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.244511
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.871770e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.051100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.673300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.344738e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.751214e-02
Vprtstp: contraction number = 9.751214e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.341277e-02
Vprtstp: contraction number = 1.375498e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.238940e-03
Vprtstp: contraction number = 1.669259e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.517751e-04
Vprtstp: contraction number = 2.017808e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.377708e-05
Vprtstp: contraction number = 2.075747e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.261336e-05
Vprtstp: contraction number = 2.411395e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.994014e-06
Vprtstp: contraction number = 2.208436e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.291766e-06
Vprtstp: contraction number = 2.586629e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.942816e-07
Vprtstp: contraction number = 2.278134e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.953820e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.829020e-01
Vpmg_setPart:  lower corner = (-25.451, -9.781, -12.639)
Vpmg_setPart:  upper corner = (33.969, 55.272, 42.405)
Vpmg_setPart:  actual minima = (-25.451, -9.781, -12.639)
Vpmg_setPart:  actual maxima = (33.969, 55.272, 42.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.779607e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:24 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2226 atoms
Valist_getStatistics:  Max atom coordinate:  (23.969, 45.272, 32.405)
Valist_getStatistics:  Min atom coordinate:  (-15.451, 0.219, -2.639)
Valist_getStatistics:  Molecule center:  (4.259, 22.7455, 14.883)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.827292, 0.885969, 0.781708
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.618958, 0.677635, 0.573375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.748174, 0.764853, 0.73349 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.259 22.7455 14.883
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 43.969 65.272 52.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -35.451 -19.781 -22.639
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 33.969 55.272 42.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -25.451 -9.781 -12.639
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 33.969 55.272 42.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -25.451 -9.781 -12.639
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.1265
Vpbe_ctor2:  solute dimensions = 41.733 x 47.052 x 37.334
Vpbe_ctor2:  solute charge = 10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 74 table
Vclist_ctor2:  Using 75 x 75 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.2, 57.833, 47.824)
Vclist_setupGrid:  Grid lower corner = (-21.841, -6.171, -9.029)
Vclist_assignAtoms:  Have 5395302 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.244833
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.028070e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.047300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.145700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.934250e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2586350.753097
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.377920e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.770738e+05
Vprtstp: contraction number = 1.770738e+05
Vnewton: Attempting damping, relres = 0.063348
Vnewton: Attempting damping, relres = 0.525564
Vnewton: Damping accepted, relres = 0.063348
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.334811e-02
Vprtstp: contraction number = 6.334811e-02
Vnewton: Using errtol_s: 163840.437708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.200610e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.288457e+04
Vprtstp: contraction number = 2.288457e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.984863e-03
Vprtstp: contraction number = 1.260474e-01
Vnewton: Using errtol_s: 20651.655854
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.858790e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.528037e+03
Vprtstp: contraction number = 3.528037e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.227950e-03
Vprtstp: contraction number = 1.537848e-01
Vnewton: Using errtol_s: 3175.910681
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.543080e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.130425e+02
Vprtstp: contraction number = 6.130425e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.133336e-04
Vprtstp: contraction number = 1.737315e-01
Vnewton: Using errtol_s: 551.755623
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.227590e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.155224e+02
Vprtstp: contraction number = 1.155224e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.019973e-05
Vprtstp: contraction number = 1.884360e-01
Vnewton: Using errtol_s: 103.970596
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.910080e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.314319e+01
Vprtstp: contraction number = 2.314319e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.053386e-06
Vprtstp: contraction number = 2.003343e-01
Vnewton: Using errtol_s: 20.828881
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.599900e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.855960e+00
Vprtstp: contraction number = 4.855960e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.689780e-06
Vprtstp: contraction number = 2.098223e-01
Vnewton: Using errtol_s: 4.370364
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.029082e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.053190e+00
Vprtstp: contraction number = 1.053190e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.664897e-07
Vprtstp: contraction number = 2.168860e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.880660e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.693540e-01
Vpmg_setPart:  lower corner = (-35.451, -19.781, -22.639)
Vpmg_setPart:  upper corner = (43.969, 65.272, 52.405)
Vpmg_setPart:  actual minima = (-35.451, -19.781, -22.639)
Vpmg_setPart:  actual maxima = (43.969, 65.272, 52.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.1265
Vpbe_ctor2:  solute dimensions = 41.733 x 47.052 x 37.334
Vpbe_ctor2:  solute charge = 10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 74 table
Vclist_ctor2:  Using 75 x 75 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (52.2, 57.833, 47.824)
Vclist_setupGrid:  Grid lower corner = (-21.841, -6.171, -9.029)
Vclist_assignAtoms:  Have 5395302 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -25.451, -9.781, -12.639
VPMG::focusFillBound -- New mesh maxs = 33.969, 55.272, 42.405
VPMG::focusFillBound -- Old mesh mins = -35.451, -19.781, -22.639
VPMG::focusFillBound -- Old mesh maxs = 43.969, 65.272, 52.405
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.240010
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.813810e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.044800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.381700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.648397e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3219552.318490
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.693314e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.374511e+05
Vprtstp: contraction number = 3.374511e+05
Vnewton: Attempting damping, relres = 0.095662
Vnewton: Attempting damping, relres = 0.544339
Vnewton: Damping accepted, relres = 0.095662
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.566180e-02
Vprtstp: contraction number = 9.566180e-02
Vnewton: Using errtol_s: 307988.182336
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.778698e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.574621e+04
Vprtstp: contraction number = 4.574621e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.280317e-02
Vprtstp: contraction number = 1.338379e-01
Vnewton: Using errtol_s: 41220.487748
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.847286e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.200634e+03
Vprtstp: contraction number = 7.200634e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.012944e-03
Vprtstp: contraction number = 1.572223e-01
Vnewton: Using errtol_s: 6480.779778
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.915519e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.248510e+03
Vprtstp: contraction number = 1.248510e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.490131e-04
Vprtstp: contraction number = 1.733844e-01
Vnewton: Using errtol_s: 1123.665997
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.984064e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.306248e+02
Vprtstp: contraction number = 2.306248e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.446940e-05
Vprtstp: contraction number = 1.847191e-01
Vnewton: Using errtol_s: 207.562597
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.050410e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.475249e+01
Vprtstp: contraction number = 4.475249e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.251020e-05
Vprtstp: contraction number = 1.940487e-01
Vnewton: Using errtol_s: 40.277253
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.118905e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.033901e+00
Vprtstp: contraction number = 9.033901e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.525355e-06
Vprtstp: contraction number = 2.018636e-01
Vnewton: Using errtol_s: 8.130511
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.187780e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.880963e+00
Vprtstp: contraction number = 1.880963e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.258082e-07
Vprtstp: contraction number = 2.082116e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.924920e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.761170e-01
Vpmg_setPart:  lower corner = (-25.451, -9.781, -12.639)
Vpmg_setPart:  upper corner = (33.969, 55.272, 42.405)
Vpmg_setPart:  actual minima = (-25.451, -9.781, -12.639)
Vpmg_setPart:  actual maxima = (33.969, 55.272, 42.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.385479e+00
