##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:23:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1856 atoms
Valist_getStatistics:  Max atom coordinate:  (49.597, 39.954, 28.944)
Valist_getStatistics:  Min atom coordinate:  (11.11, -6.742, -4.612)
Valist_getStatistics:  Molecule center:  (30.3535, 16.606, 12.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.817573, 0.903083, 0.766208
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.60924, 0.69475, 0.557875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.745181, 0.769309, 0.728098 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 69.597 59.954 48.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -8.89 -26.742 -24.612
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 59.597 49.954 38.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 1.11 -16.742 -14.612
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 59.597 49.954 38.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 1.11 -16.742 -14.612
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.202326
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.484380e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.044100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.658300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.443510e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.856129e-02
Vprtstp: contraction number = 6.856129e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.586315e-03
Vprtstp: contraction number = 1.252356e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.377626e-03
Vprtstp: contraction number = 1.604444e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.402303e-04
Vprtstp: contraction number = 1.743799e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.503021e-05
Vprtstp: contraction number = 1.874460e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.614388e-06
Vprtstp: contraction number = 2.135097e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.944427e-06
Vprtstp: contraction number = 2.022414e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.530933e-07
Vprtstp: contraction number = 2.330215e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.683280e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.556680e-01
Vpmg_setPart:  lower corner = (-8.89, -26.742, -24.612)
Vpmg_setPart:  upper corner = (69.597, 59.954, 48.944)
Vpmg_setPart:  actual minima = (-8.89, -26.742, -24.612)
Vpmg_setPart:  actual maxima = (69.597, 59.954, 48.944)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 1.11, -16.742, -14.612
VPMG::focusFillBound -- New mesh maxs = 59.597, 49.954, 38.944
VPMG::focusFillBound -- Old mesh mins = -8.89, -26.742, -24.612
VPMG::focusFillBound -- Old mesh maxs = 69.597, 59.954, 48.944
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.206000
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.232910e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.996900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.379500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.221836e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.007147e-01
Vprtstp: contraction number = 1.007147e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.405988e-02
Vprtstp: contraction number = 1.396011e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.373822e-03
Vprtstp: contraction number = 1.688366e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.583302e-04
Vprtstp: contraction number = 1.930769e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.270141e-05
Vprtstp: contraction number = 2.022590e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.111578e-05
Vprtstp: contraction number = 2.277827e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.550336e-06
Vprtstp: contraction number = 2.154946e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.121639e-06
Vprtstp: contraction number = 2.464959e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.507311e-07
Vprtstp: contraction number = 2.235399e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.961180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.799040e-01
Vpmg_setPart:  lower corner = (1.11, -16.742, -14.612)
Vpmg_setPart:  upper corner = (59.597, 49.954, 38.944)
Vpmg_setPart:  actual minima = (1.11, -16.742, -14.612)
Vpmg_setPart:  actual maxima = (59.597, 49.954, 38.944)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.657325e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:23:59 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1856 atoms
Valist_getStatistics:  Max atom coordinate:  (49.597, 39.954, 28.944)
Valist_getStatistics:  Min atom coordinate:  (11.11, -6.742, -4.612)
Valist_getStatistics:  Molecule center:  (30.3535, 16.606, 12.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.817573, 0.903083, 0.766208
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.60924, 0.69475, 0.557875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.745181, 0.769309, 0.728098 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 69.597 59.954 48.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -8.89 -26.742 -24.612
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 59.597 49.954 38.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 1.11 -16.742 -14.612
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 59.597 49.954 38.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 1.11 -16.742 -14.612
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.207351
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.538470e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.018400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.254600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.448790e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2308615.754838
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.898840e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.573663e+05
Vprtstp: contraction number = 1.573663e+05
Vnewton: Attempting damping, relres = 0.069200
Vnewton: Attempting damping, relres = 0.526229
Vnewton: Damping accepted, relres = 0.069200
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.920018e-02
Vprtstp: contraction number = 6.920018e-02
Vnewton: Using errtol_s: 159756.626930
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.731810e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.076488e+04
Vprtstp: contraction number = 2.076488e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.644641e-03
Vprtstp: contraction number = 1.393731e-01
Vnewton: Using errtol_s: 22265.769903
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.385310e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.415121e+03
Vprtstp: contraction number = 3.415121e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.629361e-03
Vprtstp: contraction number = 1.689395e-01
Vnewton: Using errtol_s: 3761.568889
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.039670e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.418411e+02
Vprtstp: contraction number = 6.418411e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.760998e-04
Vprtstp: contraction number = 1.694528e-01
Vnewton: Using errtol_s: 637.408337
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.698540e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.195656e+02
Vprtstp: contraction number = 1.195656e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.701085e-05
Vprtstp: contraction number = 1.702676e-01
Vnewton: Using errtol_s: 108.529997
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.360620e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.263903e+01
Vprtstp: contraction number = 2.263903e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.826293e-06
Vprtstp: contraction number = 1.877501e-01
Vnewton: Using errtol_s: 20.376519
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.020710e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.596445e+00
Vprtstp: contraction number = 4.596445e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.791900e-06
Vprtstp: contraction number = 2.030184e-01
Vnewton: Using errtol_s: 4.136808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.687300e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.865919e-01
Vprtstp: contraction number = 9.865919e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.846170e-07
Vprtstp: contraction number = 2.146420e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.761750e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.583720e-01
Vpmg_setPart:  lower corner = (-8.89, -26.742, -24.612)
Vpmg_setPart:  upper corner = (69.597, 59.954, 48.944)
Vpmg_setPart:  actual minima = (-8.89, -26.742, -24.612)
Vpmg_setPart:  actual maxima = (69.597, 59.954, 48.944)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 1.11, -16.742, -14.612
VPMG::focusFillBound -- New mesh maxs = 59.597, 49.954, 38.944
VPMG::focusFillBound -- Old mesh mins = -8.89, -26.742, -24.612
VPMG::focusFillBound -- Old mesh maxs = 69.597, 59.954, 48.944
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.205129
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.285050e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.153900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.453200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.537927e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2845102.398556
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.583630e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.054163e+05
Vprtstp: contraction number = 3.054163e+05
Vnewton: Attempting damping, relres = 0.102477
Vnewton: Attempting damping, relres = 0.545568
Vnewton: Damping accepted, relres = 0.102477
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.024772e-01
Vprtstp: contraction number = 1.024772e-01
Vnewton: Using errtol_s: 291558.088310
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.669475e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.326224e+04
Vprtstp: contraction number = 4.326224e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.480106e-02
Vprtstp: contraction number = 1.444327e-01
Vnewton: Using errtol_s: 42110.529798
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.755767e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.225864e+03
Vprtstp: contraction number = 7.225864e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.482736e-03
Vprtstp: contraction number = 1.677404e-01
Vnewton: Using errtol_s: 7063.637926
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.851393e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.332155e+03
Vprtstp: contraction number = 1.332155e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.337618e-04
Vprtstp: contraction number = 1.747112e-01
Vnewton: Using errtol_s: 1234.096708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.929132e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.527174e+02
Vprtstp: contraction number = 2.527174e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.001134e-05
Vprtstp: contraction number = 1.844592e-01
Vnewton: Using errtol_s: 227.640456
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.055663e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.985209e+01
Vprtstp: contraction number = 4.985209e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.576991e-05
Vprtstp: contraction number = 1.970959e-01
Vnewton: Using errtol_s: 44.867009
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.159060e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.026483e+01
Vprtstp: contraction number = 1.026483e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.247105e-06
Vprtstp: contraction number = 2.059051e-01
Vnewton: Using errtol_s: 9.238347
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.268033e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.178683e+00
Vprtstp: contraction number = 2.178683e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.891896e-07
Vprtstp: contraction number = 2.122474e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.882380e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.745090e-01
Vpmg_setPart:  lower corner = (1.11, -16.742, -14.612)
Vpmg_setPart:  upper corner = (59.597, 49.954, 38.944)
Vpmg_setPart:  actual minima = (1.11, -16.742, -14.612)
Vpmg_setPart:  actual maxima = (59.597, 49.954, 38.944)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.476864e+00
