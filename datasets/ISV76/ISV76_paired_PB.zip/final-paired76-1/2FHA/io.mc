##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:44 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 66528 atoms
Valist_getStatistics:  Max atom coordinate:  (61.573, 61.573, 61.573)
Valist_getStatistics:  Min atom coordinate:  (-61.573, -61.573, -61.573)
Valist_getStatistics:  Molecule center:  (0, 0, 0)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 0 0
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.849719, 0.849719, 0.849719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.745552, 0.745552, 0.745552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.87741, 0.87741, 0.87741 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 81.573 81.573 81.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -81.573 -81.573 -81.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 71.573 71.573 71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -71.573 -71.573 -71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 71.573 71.573 71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -71.573 -71.573 -71.573
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -144
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17716681 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 9.875280
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.158368e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.613350e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.884020e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.234462e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.843782e-02
Vprtstp: contraction number = 4.843782e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.987902e-03
Vprtstp: contraction number = 1.236204e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.363182e-04
Vprtstp: contraction number = 1.563683e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.687716e-04
Vprtstp: contraction number = 1.802502e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.213972e-05
Vprtstp: contraction number = 1.904332e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.607297e-06
Vprtstp: contraction number = 2.055804e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.571922e-06
Vprtstp: contraction number = 2.379069e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.409066e-07
Vprtstp: contraction number = 2.804889e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.400911e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.030273e+00
Vpmg_setPart:  lower corner = (-81.573, -81.573, -81.573)
Vpmg_setPart:  upper corner = (81.573, 81.573, 81.573)
Vpmg_setPart:  actual minima = (-81.573, -81.573, -81.573)
Vpmg_setPart:  actual maxima = (81.573, 81.573, 81.573)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -144
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17716681 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -71.573, -71.573, -71.573
VPMG::focusFillBound -- New mesh maxs = 71.573, 71.573, 71.573
VPMG::focusFillBound -- Old mesh mins = -81.573, -81.573, -81.573
VPMG::focusFillBound -- Old mesh maxs = 81.573, 81.573, 81.573
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.065107
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.220011e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.528330e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.602620e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.754768e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.000231e-02
Vprtstp: contraction number = 6.000231e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.580120e-03
Vprtstp: contraction number = 1.263305e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.202657e-03
Vprtstp: contraction number = 1.586594e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.195643e-04
Vprtstp: contraction number = 1.825659e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.339503e-05
Vprtstp: contraction number = 1.976416e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.000699e-05
Vprtstp: contraction number = 2.306023e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.698723e-06
Vprtstp: contraction number = 2.696837e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.898140e-07
Vprtstp: contraction number = 3.297166e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.191624e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.777960e+00
Vpmg_setPart:  lower corner = (-71.573, -71.573, -71.573)
Vpmg_setPart:  upper corner = (71.573, 71.573, 71.573)
Vpmg_setPart:  actual minima = (-71.573, -71.573, -71.573)
Vpmg_setPart:  actual maxima = (71.573, 71.573, 71.573)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.082402e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:26 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 66528 atoms
Valist_getStatistics:  Max atom coordinate:  (61.573, 61.573, 61.573)
Valist_getStatistics:  Min atom coordinate:  (-61.573, -61.573, -61.573)
Valist_getStatistics:  Molecule center:  (0, 0, 0)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 0 0
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.849719, 0.849719, 0.849719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.745552, 0.745552, 0.745552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.87741, 0.87741, 0.87741 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 81.573 81.573 81.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -81.573 -81.573 -81.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 71.573 71.573 71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -71.573 -71.573 -71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 71.573 71.573 71.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -71.573 -71.573 -71.573
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -144
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17716681 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.177049
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.191324e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.607000e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.743820e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.265457e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 78943335.214139
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.300803e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.246833e+06
Vprtstp: contraction number = 4.246833e+06
Vnewton: Attempting damping, relres = 0.168802
Vnewton: Attempting damping, relres = 0.519946
Vnewton: Damping accepted, relres = 0.168802
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.688020e-01
Vprtstp: contraction number = 1.688020e-01
Vnewton: Using errtol_s: 13325794.892892
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.369413e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.888935e+05
Vprtstp: contraction number = 5.888935e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.888522e-02
Vprtstp: contraction number = 2.896009e-01
Vnewton: Using errtol_s: 3859161.945322
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.423798e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.309554e+05
Vprtstp: contraction number = 1.309554e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.639487e-02
Vprtstp: contraction number = 3.353747e-01
Vnewton: Using errtol_s: 1294265.415142
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.478881e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.399223e+04
Vprtstp: contraction number = 4.399223e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.773505e-03
Vprtstp: contraction number = 3.521532e-01
Vnewton: Using errtol_s: 455779.733888
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.532967e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.158368e+04
Vprtstp: contraction number = 2.158368e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.099667e-03
Vprtstp: contraction number = 3.636728e-01
Vnewton: Using errtol_s: 165754.691365
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.594146e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.383344e+04
Vprtstp: contraction number = 1.383344e+04
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.969521e-04
Vprtstp: contraction number = 3.795612e-01
Vnewton: Using errtol_s: 62914.053568
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.648431e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.383912e+03
Vprtstp: contraction number = 9.383912e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.139007e-04
Vprtstp: contraction number = 3.938765e-01
Vnewton: Using errtol_s: 24780.367701
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.703559e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.692147e+03
Vprtstp: contraction number = 5.692147e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.212025e-04
Vprtstp: contraction number = 3.861174e-01
Vnewton: Using errtol_s: 9568.130592
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.757370e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.793844e+03
Vprtstp: contraction number = 2.793844e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.153981e-05
Vprtstp: contraction number = 3.427306e-01
Vnewton: Using errtol_s: 3279.290949
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.811256e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.083081e+03
Vprtstp: contraction number = 1.083081e+03
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.301806e-05
Vprtstp: contraction number = 3.133876e-01
Vnewton: Using errtol_s: 1027.689073
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.866939e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.595459e+02
Vprtstp: contraction number = 3.595459e+02
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.122680e-06
Vprtstp: contraction number = 3.166893e-01
Vnewton: Using errtol_s: 325.458136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.922009e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.139784e+02
Vprtstp: contraction number = 1.139784e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.300913e-06
Vprtstp: contraction number = 3.155503e-01
Vnewton: Using errtol_s: 102.698420
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.976524e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.610201e+01
Vprtstp: contraction number = 3.610201e+01
Vprtstp: iteration = 13
Vprtstp: relative residual = 4.117099e-07
Vprtstp: contraction number = 3.164777e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.524973e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.134992e+00
Vpmg_setPart:  lower corner = (-81.573, -81.573, -81.573)
Vpmg_setPart:  upper corner = (81.573, 81.573, 81.573)
Vpmg_setPart:  actual minima = (-81.573, -81.573, -81.573)
Vpmg_setPart:  actual maxima = (81.573, 81.573, 81.573)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -144
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17716681 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -71.573, -71.573, -71.573
VPMG::focusFillBound -- New mesh maxs = 71.573, 71.573, 71.573
VPMG::focusFillBound -- Old mesh mins = -81.573, -81.573, -81.573
VPMG::focusFillBound -- Old mesh maxs = 81.573, 81.573, 81.573
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.017412
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.221495e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.600490e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.673220e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.301163e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 88216566.327142
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.335689e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.853851e+06
Vprtstp: contraction number = 5.853851e+06
Vnewton: Attempting damping, relres = 0.533904
Vnewton: Attempting damping, relres = 0.526484
Vnewton: Attempting damping, relres = 0.762615
Vnewton: Damping accepted, relres = 0.526484
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.264836e-01
Vprtstp: contraction number = 5.264836e-01
Vnewton: Using errtol_s: 46444576.626496
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.417939e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.262043e+06
Vprtstp: contraction number = 3.262043e+06
Vnewton: Attempting damping, relres = 0.035076
Vnewton: Attempting damping, relres = 0.278321
Vnewton: Damping accepted, relres = 0.035076
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.507586e-02
Vprtstp: contraction number = 6.662289e-02
Vnewton: Using errtol_s: 3094272.037942
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.487062e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.276984e+05
Vprtstp: contraction number = 4.276984e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.500915e-03
Vprtstp: contraction number = 1.283194e-01
Vnewton: Using errtol_s: 397055.252561
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.542685e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.042826e+04
Vprtstp: contraction number = 7.042826e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.346091e-04
Vprtstp: contraction number = 1.632133e-01
Vnewton: Using errtol_s: 64804.692289
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.597318e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.368720e+04
Vprtstp: contraction number = 1.368720e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.408902e-04
Vprtstp: contraction number = 1.917893e-01
Vnewton: Using errtol_s: 12428.847649
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.652551e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.862665e+03
Vprtstp: contraction number = 2.862665e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.920713e-05
Vprtstp: contraction number = 2.073042e-01
Vnewton: Using errtol_s: 2576.552430
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.707898e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.959364e+02
Vprtstp: contraction number = 5.959364e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.079854e-06
Vprtstp: contraction number = 2.081634e-01
Vnewton: Using errtol_s: 536.343876
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.763782e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.257513e+02
Vprtstp: contraction number = 1.257513e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.282936e-06
Vprtstp: contraction number = 2.110142e-01
Vnewton: Using errtol_s: 113.176199
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.818571e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.788375e+01
Vprtstp: contraction number = 2.788375e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.844746e-07
Vprtstp: contraction number = 2.217372e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.663974e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.265688e+00
Vpmg_setPart:  lower corner = (-71.573, -71.573, -71.573)
Vpmg_setPart:  upper corner = (71.573, 71.573, 71.573)
Vpmg_setPart:  actual minima = (-71.573, -71.573, -71.573)
Vpmg_setPart:  actual maxima = (71.573, 71.573, 71.573)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.981050e+01
