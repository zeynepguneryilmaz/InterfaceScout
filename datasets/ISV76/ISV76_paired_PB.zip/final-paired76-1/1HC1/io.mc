##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:28:15 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 193, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 60463 atoms
Valist_getStatistics:  Max atom coordinate:  (62.66, 90.146, 152.086)
Valist_getStatistics:  Min atom coordinate:  (-67.575, -24.394, 13.491)
Valist_getStatistics:  Molecule center:  (-2.4575, 32.876, 82.7885)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.886641, 0.804896, 0.797299
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.782474, 0.700729, 0.708013
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.882515, 0.870584, 0.888015 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 82.66 110.146 172.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -87.575 -44.394 -6.509
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 72.66 100.146 162.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -77.575 -34.394 3.491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 72.66 100.146 162.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -77.575 -34.394 3.491
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -161
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15204837 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 8.992033
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.066261e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.773330e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 113)
Vbuildops: Galer: (049, 049, 057)
Vbuildops: Galer: (025, 025, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.005798e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.205776e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.430653e-02
Vprtstp: contraction number = 6.430653e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.236521e-02
Vprtstp: contraction number = 1.922854e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.849192e-03
Vprtstp: contraction number = 3.921643e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.252914e-03
Vprtstp: contraction number = 4.645958e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.572441e-03
Vprtstp: contraction number = 6.979585e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.160410e-04
Vprtstp: contraction number = 5.189645e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.063049e-04
Vprtstp: contraction number = 7.429833e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.161222e-04
Vprtstp: contraction number = 5.213915e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.390713e-04
Vprtstp: contraction number = 7.562624e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.243911e-04
Vprtstp: contraction number = 5.203097e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.485004e-05
Vprtstp: contraction number = 7.625144e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.926723e-05
Vprtstp: contraction number = 5.194223e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.771137e-05
Vprtstp: contraction number = 7.654453e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.957587e-05
Vprtstp: contraction number = 5.190973e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.500827e-05
Vprtstp: contraction number = 7.666721e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 7.792811e-06
Vprtstp: contraction number = 5.192344e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 5.977508e-06
Vprtstp: contraction number = 7.670541e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.106313e-06
Vprtstp: contraction number = 5.196669e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.382469e-06
Vprtstp: contraction number = 7.669765e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.239539e-06
Vprtstp: contraction number = 5.202752e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 9.502751e-07
Vprtstp: contraction number = 7.666357e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.873658e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.146320e+00
Vpmg_setPart:  lower corner = (-87.575, -44.394, -6.509)
Vpmg_setPart:  upper corner = (82.66, 110.146, 172.086)
Vpmg_setPart:  actual minima = (-87.575, -44.394, -6.509)
Vpmg_setPart:  actual maxima = (82.66, 110.146, 172.086)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -161
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15204837 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -77.575, -34.394, 3.491
VPMG::focusFillBound -- New mesh maxs = 72.66, 100.146, 162.086
VPMG::focusFillBound -- Old mesh mins = -87.575, -44.394, -6.509
VPMG::focusFillBound -- Old mesh maxs = 82.66, 110.146, 172.086
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 9.081178
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.124301e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.866030e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 113)
Vbuildops: Galer: (049, 049, 057)
Vbuildops: Galer: (025, 025, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.039717e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.151021e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.187122e-02
Vprtstp: contraction number = 7.187122e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.197399e-02
Vprtstp: contraction number = 1.666034e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.135701e-03
Vprtstp: contraction number = 3.453903e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.764354e-03
Vprtstp: contraction number = 4.266156e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.290774e-03
Vprtstp: contraction number = 7.315844e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.571111e-04
Vprtstp: contraction number = 5.090830e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.264796e-04
Vprtstp: contraction number = 8.012034e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.743466e-04
Vprtstp: contraction number = 5.210963e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.238685e-04
Vprtstp: contraction number = 8.160062e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.173692e-04
Vprtstp: contraction number = 5.242776e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.640604e-05
Vprtstp: contraction number = 8.213910e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.067599e-05
Vprtstp: contraction number = 5.256516e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 4.173192e-05
Vprtstp: contraction number = 8.235047e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.197900e-05
Vprtstp: contraction number = 5.266712e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.811163e-05
Vprtstp: contraction number = 8.240427e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 9.557158e-06
Vprtstp: contraction number = 5.276807e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 7.873407e-06
Vprtstp: contraction number = 8.238230e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 4.163078e-06
Vprtstp: contraction number = 5.287518e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 3.427175e-06
Vprtstp: contraction number = 8.232312e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.815954e-06
Vprtstp: contraction number = 5.298690e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.493510e-06
Vprtstp: contraction number = 8.224384e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 7.930736e-07
Vprtstp: contraction number = 5.310132e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.560408e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.878530e+00
Vpmg_setPart:  lower corner = (-77.575, -34.394, 3.491)
Vpmg_setPart:  upper corner = (72.66, 100.146, 162.086)
Vpmg_setPart:  actual minima = (-77.575, -34.394, 3.491)
Vpmg_setPart:  actual maxima = (72.66, 100.146, 162.086)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.035233e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:29:06 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 193, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 60463 atoms
Valist_getStatistics:  Max atom coordinate:  (62.66, 90.146, 152.086)
Valist_getStatistics:  Min atom coordinate:  (-67.575, -24.394, 13.491)
Valist_getStatistics:  Molecule center:  (-2.4575, 32.876, 82.7885)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.886641, 0.804896, 0.797299
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.782474, 0.700729, 0.708013
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.882515, 0.870584, 0.888015 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 82.66 110.146 172.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -87.575 -44.394 -6.509
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 72.66 100.146 162.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -77.575 -34.394 3.491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 72.66 100.146 162.086
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -77.575 -34.394 3.491
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -161
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15204837 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 9.441599
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.117311e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.843810e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 113)
Vbuildops: Galer: (049, 049, 057)
Vbuildops: Galer: (025, 025, 029)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.429420e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.200512e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 73429813.625896
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.240308e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.533373e+06
Vprtstp: contraction number = 4.533373e+06
Vnewton: Attempting damping, relres = 401.668437
Vnewton: Attempting damping, relres = 0.538065
Vnewton: Attempting damping, relres = 0.761633
Vnewton: Damping accepted, relres = 0.538065
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.380646e-01
Vprtstp: contraction number = 5.380646e-01
Vnewton: Using errtol_s: 39509985.258273
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.335252e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.525867e+06
Vprtstp: contraction number = 2.525867e+06
Vnewton: Attempting damping, relres = 0.036137
Vnewton: Attempting damping, relres = 0.283757
Vnewton: Damping accepted, relres = 0.036137
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.613657e-02
Vprtstp: contraction number = 6.716028e-02
Vnewton: Using errtol_s: 2653501.755233
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.415462e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.361139e+05
Vprtstp: contraction number = 3.361139e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.408181e-03
Vprtstp: contraction number = 1.496595e-01
Vnewton: Using errtol_s: 397121.706022
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.485751e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.776838e+04
Vprtstp: contraction number = 5.776838e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.016283e-03
Vprtstp: contraction number = 1.879159e-01
Vnewton: Using errtol_s: 74625.478856
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.550298e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.302511e+04
Vprtstp: contraction number = 1.302511e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.133474e-04
Vprtstp: contraction number = 2.099291e-01
Vnewton: Using errtol_s: 15666.057205
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.614447e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.501698e+03
Vprtstp: contraction number = 3.501698e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.821845e-05
Vprtstp: contraction number = 2.260091e-01
Vnewton: Using errtol_s: 3540.671799
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.679008e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.756240e+02
Vprtstp: contraction number = 9.756240e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.221989e-05
Vprtstp: contraction number = 2.534276e-01
Vnewton: Using errtol_s: 897.303980
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.744824e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.015476e+02
Vprtstp: contraction number = 3.015476e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.702598e-06
Vprtstp: contraction number = 3.029977e-01
Vnewton: Using errtol_s: 271.881062
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.808995e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.042465e+02
Vprtstp: contraction number = 1.042465e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.278020e-06
Vprtstp: contraction number = 3.451686e-01
Vnewton: Using errtol_s: 93.844792
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.873222e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.002968e+01
Vprtstp: contraction number = 4.002968e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.906291e-07
Vprtstp: contraction number = 3.838977e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.223590e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.930910e+00
Vpmg_setPart:  lower corner = (-87.575, -44.394, -6.509)
Vpmg_setPart:  upper corner = (82.66, 110.146, 172.086)
Vpmg_setPart:  actual minima = (-87.575, -44.394, -6.509)
Vpmg_setPart:  actual maxima = (82.66, 110.146, 172.086)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -161
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15204837 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -77.575, -34.394, 3.491
VPMG::focusFillBound -- New mesh maxs = 72.66, 100.146, 162.086
VPMG::focusFillBound -- Old mesh mins = -87.575, -44.394, -6.509
VPMG::focusFillBound -- Old mesh maxs = 82.66, 110.146, 172.086
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 9.278235
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.151444e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.860290e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 113)
Vbuildops: Galer: (049, 049, 057)
Vbuildops: Galer: (025, 025, 029)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.379920e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.146965e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 79945555.158481
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.186962e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.804044e+06
Vprtstp: contraction number = 5.804044e+06
Vnewton: Attempting damping, relres = 175.302169
Vnewton: Attempting damping, relres = 0.541464
Vnewton: Attempting damping, relres = 0.764428
Vnewton: Damping accepted, relres = 0.541464
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.414635e-01
Vprtstp: contraction number = 5.414635e-01
Vnewton: Using errtol_s: 43287603.014281
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.283748e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.243625e+06
Vprtstp: contraction number = 3.243625e+06
Vnewton: Attempting damping, relres = 0.040851
Vnewton: Attempting damping, relres = 0.288406
Vnewton: Damping accepted, relres = 0.040851
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.085086e-02
Vprtstp: contraction number = 7.544526e-02
Vnewton: Using errtol_s: 3265844.579579
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.363420e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.349316e+05
Vprtstp: contraction number = 4.349316e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.933808e-03
Vprtstp: contraction number = 1.452554e-01
Vnewton: Using errtol_s: 474381.566481
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.428052e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.356853e+04
Vprtstp: contraction number = 7.356853e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.052107e-03
Vprtstp: contraction number = 1.773071e-01
Vnewton: Using errtol_s: 84111.238785
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.492042e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.576883e+04
Vprtstp: contraction number = 1.576883e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.065404e-04
Vprtstp: contraction number = 1.963113e-01
Vnewton: Using errtol_s: 16511.988107
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.562361e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.898211e+03
Vprtstp: contraction number = 3.898211e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.505744e-05
Vprtstp: contraction number = 2.181531e-01
Vnewton: Using errtol_s: 3602.141813
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.626732e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.906146e+02
Vprtstp: contraction number = 9.906146e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.118446e-05
Vprtstp: contraction number = 2.482267e-01
Vnewton: Using errtol_s: 894.147622
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.689903e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.730015e+02
Vprtstp: contraction number = 2.730015e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.075316e-06
Vprtstp: contraction number = 2.749634e-01
Vnewton: Using errtol_s: 245.857856
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.753935e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.200405e+01
Vprtstp: contraction number = 8.200405e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.233667e-07
Vprtstp: contraction number = 3.002510e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.567597e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.275738e+00
Vpmg_setPart:  lower corner = (-77.575, -34.394, 3.491)
Vpmg_setPart:  upper corner = (72.66, 100.146, 162.086)
Vpmg_setPart:  actual minima = (-77.575, -34.394, 3.491)
Vpmg_setPart:  actual maxima = (72.66, 100.146, 162.086)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.931691e+01
