##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:05 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10277 atoms
Valist_getStatistics:  Max atom coordinate:  (-19.812, 57.208, 7.965)
Valist_getStatistics:  Min atom coordinate:  (-86.855, -27.454, -62.759)
Valist_getStatistics:  Molecule center:  (-53.3335, 14.877, -27.397)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.836273, 0.779138, 0.865031
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.680023, 0.654138, 0.708781
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.813159, 0.839566, 0.819371 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 0.188 77.208 27.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -106.855 -47.454 -82.759
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -9.812 67.208 17.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -96.855 -37.454 -72.759
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -9.812 67.208 17.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -96.855 -37.454 -72.759
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433416 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.384519
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.876600e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.509800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.649310e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.154839e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.984481e-02
Vprtstp: contraction number = 5.984481e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.816438e-03
Vprtstp: contraction number = 1.306118e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.287445e-03
Vprtstp: contraction number = 1.647100e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.372657e-04
Vprtstp: contraction number = 2.619651e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.022926e-04
Vprtstp: contraction number = 3.032996e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.690107e-05
Vprtstp: contraction number = 4.584992e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.950699e-05
Vprtstp: contraction number = 4.159178e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.066291e-05
Vprtstp: contraction number = 5.466201e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.671239e-06
Vprtstp: contraction number = 4.380829e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.633691e-06
Vprtstp: contraction number = 5.638099e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.163888e-06
Vprtstp: contraction number = 4.419228e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.625033e-07
Vprtstp: contraction number = 5.692156e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.426446e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.678333e+00
Vpmg_setPart:  lower corner = (-106.855, -47.454, -82.759)
Vpmg_setPart:  upper corner = (0.188, 77.208, 27.965)
Vpmg_setPart:  actual minima = (-106.855, -47.454, -82.759)
Vpmg_setPart:  actual maxima = (0.188, 77.208, 27.965)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433416 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -96.855, -37.454, -72.759
VPMG::focusFillBound -- New mesh maxs = -9.812, 67.208, 17.965
VPMG::focusFillBound -- Old mesh mins = -106.855, -47.454, -82.759
VPMG::focusFillBound -- Old mesh maxs = 0.188, 77.208, 27.965
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.379901
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.027094e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.536000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.635960e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.868470e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.687899e-02
Vprtstp: contraction number = 7.687899e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.015024e-02
Vprtstp: contraction number = 1.320288e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.684246e-03
Vprtstp: contraction number = 1.659316e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.042499e-04
Vprtstp: contraction number = 2.400183e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.083057e-04
Vprtstp: contraction number = 2.679178e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.584647e-05
Vprtstp: contraction number = 4.233060e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.742859e-05
Vprtstp: contraction number = 3.801512e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.688930e-06
Vprtstp: contraction number = 5.559216e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.140596e-06
Vprtstp: contraction number = 4.273532e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.467201e-06
Vprtstp: contraction number = 5.958564e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.103546e-06
Vprtstp: contraction number = 4.472868e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.712881e-07
Vprtstp: contraction number = 6.083009e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.447400e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.699122e+00
Vpmg_setPart:  lower corner = (-96.855, -37.454, -72.759)
Vpmg_setPart:  upper corner = (-9.812, 67.208, 17.965)
Vpmg_setPart:  actual minima = (-96.855, -37.454, -72.759)
Vpmg_setPart:  actual maxima = (-9.812, 67.208, 17.965)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.886605e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:15 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10277 atoms
Valist_getStatistics:  Max atom coordinate:  (-19.812, 57.208, 7.965)
Valist_getStatistics:  Min atom coordinate:  (-86.855, -27.454, -62.759)
Valist_getStatistics:  Molecule center:  (-53.3335, 14.877, -27.397)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.836273, 0.779138, 0.865031
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.680023, 0.654138, 0.708781
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.813159, 0.839566, 0.819371 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 0.188 77.208 27.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -106.855 -47.454 -82.759
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -9.812 67.208 17.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -96.855 -37.454 -72.759
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -9.812 67.208 17.965
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -96.855 -37.454 -72.759
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433416 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.383791
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.880532e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.522200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.113270e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.100303e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12136168.172053
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.256494e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.489664e+05
Vprtstp: contraction number = 7.489664e+05
Vnewton: Attempting damping, relres = 0.056574
Vnewton: Attempting damping, relres = 0.522939
Vnewton: Damping accepted, relres = 0.056574
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.657428e-02
Vprtstp: contraction number = 5.657428e-02
Vnewton: Using errtol_s: 686595.022653
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.575536e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.211278e+04
Vprtstp: contraction number = 9.211278e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.880726e-03
Vprtstp: contraction number = 1.216228e-01
Vnewton: Using errtol_s: 83505.641906
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.825259e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.346295e+04
Vprtstp: contraction number = 1.346295e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.992863e-04
Vprtstp: contraction number = 1.452298e-01
Vnewton: Using errtol_s: 12127.507106
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.072041e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.146863e+03
Vprtstp: contraction number = 2.146863e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.592108e-04
Vprtstp: contraction number = 1.593245e-01
Vnewton: Using errtol_s: 1932.209307
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.320166e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.589832e+02
Vprtstp: contraction number = 3.589832e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.662173e-05
Vprtstp: contraction number = 1.672106e-01
Vnewton: Using errtol_s: 323.085807
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.568421e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.242451e+01
Vprtstp: contraction number = 6.242451e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.629336e-06
Vprtstp: contraction number = 1.738931e-01
Vnewton: Using errtol_s: 56.182396
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.818855e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.154654e+01
Vprtstp: contraction number = 1.154654e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.562759e-07
Vprtstp: contraction number = 1.849673e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.905757e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.099747e+00
Vpmg_setPart:  lower corner = (-106.855, -47.454, -82.759)
Vpmg_setPart:  upper corner = (0.188, 77.208, 27.965)
Vpmg_setPart:  actual minima = (-106.855, -47.454, -82.759)
Vpmg_setPart:  actual maxima = (0.188, 77.208, 27.965)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433416 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -96.855, -37.454, -72.759
VPMG::focusFillBound -- New mesh maxs = -9.812, 67.208, 17.965
VPMG::focusFillBound -- Old mesh mins = -106.855, -47.454, -82.759
VPMG::focusFillBound -- Old mesh maxs = 0.188, 77.208, 27.965
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.377327
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.023704e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.539700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.115120e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.231821e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 13991650.464852
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.388682e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.148273e+06
Vprtstp: contraction number = 1.148273e+06
Vnewton: Attempting damping, relres = 0.074675
Vnewton: Attempting damping, relres = 0.533431
Vnewton: Damping accepted, relres = 0.074675
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.467465e-02
Vprtstp: contraction number = 7.467465e-02
Vnewton: Using errtol_s: 1044821.580750
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.716648e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.438022e+05
Vprtstp: contraction number = 1.438022e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.282052e-03
Vprtstp: contraction number = 1.242999e-01
Vnewton: Using errtol_s: 129871.226601
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.962705e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.103421e+04
Vprtstp: contraction number = 2.103421e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.353350e-03
Vprtstp: contraction number = 1.458029e-01
Vnewton: Using errtol_s: 18935.595501
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.209491e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.301660e+03
Vprtstp: contraction number = 3.301660e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.123785e-04
Vprtstp: contraction number = 1.569280e-01
Vnewton: Using errtol_s: 2971.525284
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.459710e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.376539e+02
Vprtstp: contraction number = 5.376539e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.458444e-05
Vprtstp: contraction number = 1.628435e-01
Vnewton: Using errtol_s: 483.893433
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.718451e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.204165e+01
Vprtstp: contraction number = 9.204165e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.920522e-06
Vprtstp: contraction number = 1.711903e-01
Vnewton: Using errtol_s: 82.837878
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.975440e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.744355e+01
Vprtstp: contraction number = 1.744355e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.122042e-06
Vprtstp: contraction number = 1.895174e-01
Vnewton: Using errtol_s: 15.699219
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.225254e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.678948e+00
Vprtstp: contraction number = 3.678948e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.366450e-07
Vprtstp: contraction number = 2.109057e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.180676e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.374994e+00
Vpmg_setPart:  lower corner = (-96.855, -37.454, -72.759)
Vpmg_setPart:  upper corner = (-9.812, 67.208, 17.965)
Vpmg_setPart:  actual minima = (-96.855, -37.454, -72.759)
Vpmg_setPart:  actual maxima = (-9.812, 67.208, 17.965)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.983864e+00
