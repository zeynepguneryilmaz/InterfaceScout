##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:14 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5124 atoms
Valist_getStatistics:  Max atom coordinate:  (77.878, 40.675, 140.763)
Valist_getStatistics:  Min atom coordinate:  (29.157, -1.775, 46.873)
Valist_getStatistics:  Molecule center:  (53.5175, 19.45, 93.818)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.924177, 0.858854, 0.836812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.715844, 0.650521, 0.711812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.774574, 0.757429, 0.850624 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 97.878 60.675 160.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 9.157 -21.775 26.873
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 87.878 50.675 150.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 19.157 -11.775 36.873
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 87.878 50.675 150.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 19.157 -11.775 36.873
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.657347
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.453010e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.454300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 081)
Vbuildops: Galer: (025, 025, 041)
Vbuildops: Galer: (013, 013, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.297900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.086733e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.805650e-02
Vprtstp: contraction number = 6.805650e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.162626e-03
Vprtstp: contraction number = 1.199390e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.287951e-03
Vprtstp: contraction number = 1.577864e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.053439e-04
Vprtstp: contraction number = 1.594345e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.279860e-05
Vprtstp: contraction number = 2.084240e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.432518e-06
Vprtstp: contraction number = 1.970279e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.097616e-06
Vprtstp: contraction number = 2.487532e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.918889e-07
Vprtstp: contraction number = 2.344990e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.807090e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.073720e-01
Vpmg_setPart:  lower corner = (9.157, -21.775, 26.873)
Vpmg_setPart:  upper corner = (97.878, 60.675, 160.763)
Vpmg_setPart:  actual minima = (9.157, -21.775, 26.873)
Vpmg_setPart:  actual maxima = (97.878, 60.675, 160.763)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 19.157, -11.775, 36.873
VPMG::focusFillBound -- New mesh maxs = 87.878, 50.675, 150.763
VPMG::focusFillBound -- Old mesh mins = 9.157, -21.775, 26.873
VPMG::focusFillBound -- Old mesh maxs = 97.878, 60.675, 160.763
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.651835
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.039611e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.237100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 081)
Vbuildops: Galer: (025, 025, 041)
Vbuildops: Galer: (013, 013, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.085300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.732354e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.150971e-02
Vprtstp: contraction number = 8.150971e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.045421e-02
Vprtstp: contraction number = 1.282572e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.705411e-03
Vprtstp: contraction number = 1.631315e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.101073e-04
Vprtstp: contraction number = 1.818372e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.290103e-05
Vprtstp: contraction number = 2.350833e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.753425e-05
Vprtstp: contraction number = 2.405213e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.433188e-06
Vprtstp: contraction number = 3.098614e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.585366e-06
Vprtstp: contraction number = 2.917929e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.772907e-07
Vprtstp: contraction number = 3.641372e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.283170e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.497300e-01
Vpmg_setPart:  lower corner = (19.157, -11.775, 36.873)
Vpmg_setPart:  upper corner = (87.878, 50.675, 150.763)
Vpmg_setPart:  actual minima = (19.157, -11.775, 36.873)
Vpmg_setPart:  actual maxima = (87.878, 50.675, 150.763)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.565178e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:18 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5124 atoms
Valist_getStatistics:  Max atom coordinate:  (77.878, 40.675, 140.763)
Valist_getStatistics:  Min atom coordinate:  (29.157, -1.775, 46.873)
Valist_getStatistics:  Molecule center:  (53.5175, 19.45, 93.818)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.924177, 0.858854, 0.836812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.715844, 0.650521, 0.711812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.774574, 0.757429, 0.850624 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 97.878 60.675 160.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 9.157 -21.775 26.873
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 87.878 50.675 150.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 19.157 -11.775 36.873
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 87.878 50.675 150.763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 19.157 -11.775 36.873
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.657175
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.467590e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.104100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 081)
Vbuildops: Galer: (025, 025, 041)
Vbuildops: Galer: (013, 013, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.329600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.071755e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6685525.430143
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.156273e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.484954e+05
Vprtstp: contraction number = 4.484954e+05
Vnewton: Attempting damping, relres = 0.067599
Vnewton: Attempting damping, relres = 0.525923
Vnewton: Damping accepted, relres = 0.067599
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.759873e-02
Vprtstp: contraction number = 6.759873e-02
Vnewton: Using errtol_s: 451933.019949
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.330091e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.534837e+04
Vprtstp: contraction number = 5.534837e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.263720e-03
Vprtstp: contraction number = 1.222467e-01
Vnewton: Using errtol_s: 55247.310872
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.461528e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.310432e+03
Vprtstp: contraction number = 8.310432e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.178010e-03
Vprtstp: contraction number = 1.425520e-01
Vnewton: Using errtol_s: 7875.612976
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.593023e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.391480e+03
Vprtstp: contraction number = 1.391480e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.899720e-04
Vprtstp: contraction number = 1.612652e-01
Vnewton: Using errtol_s: 1270.062614
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.726455e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.504651e+02
Vprtstp: contraction number = 2.504651e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.373843e-05
Vprtstp: contraction number = 1.775969e-01
Vnewton: Using errtol_s: 225.559164
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.859597e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.753623e+01
Vprtstp: contraction number = 4.753623e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.399341e-06
Vprtstp: contraction number = 1.896751e-01
Vnewton: Using errtol_s: 42.782957
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.994111e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.409439e+00
Vprtstp: contraction number = 9.409439e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.266691e-06
Vprtstp: contraction number = 1.979409e-01
Vnewton: Using errtol_s: 8.468496
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.127513e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.961024e+00
Vprtstp: contraction number = 1.961024e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.639915e-07
Vprtstp: contraction number = 2.084103e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.156632e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.266591e+00
Vpmg_setPart:  lower corner = (9.157, -21.775, 26.873)
Vpmg_setPart:  upper corner = (97.878, 60.675, 160.763)
Vpmg_setPart:  actual minima = (9.157, -21.775, 26.873)
Vpmg_setPart:  actual maxima = (97.878, 60.675, 160.763)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 19.157, -11.775, 36.873
VPMG::focusFillBound -- New mesh maxs = 87.878, 50.675, 150.763
VPMG::focusFillBound -- Old mesh mins = 9.157, -21.775, 26.873
VPMG::focusFillBound -- Old mesh maxs = 97.878, 60.675, 160.763
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.655338
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.042210e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.225400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 081)
Vbuildops: Galer: (025, 025, 041)
Vbuildops: Galer: (013, 013, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.342400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.386628e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7638241.310564
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.471879e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.519594e+05
Vprtstp: contraction number = 6.519594e+05
Vnewton: Attempting damping, relres = 0.082534
Vnewton: Attempting damping, relres = 0.535189
Vnewton: Damping accepted, relres = 0.082534
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.253378e-02
Vprtstp: contraction number = 8.253378e-02
Vnewton: Using errtol_s: 630412.918858
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.643765e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.446610e+04
Vprtstp: contraction number = 8.446610e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.060098e-02
Vprtstp: contraction number = 1.284441e-01
Vnewton: Using errtol_s: 80972.824692
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.773328e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.309822e+04
Vprtstp: contraction number = 1.309822e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.590863e-03
Vprtstp: contraction number = 1.500676e-01
Vnewton: Using errtol_s: 12151.397127
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.901697e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.255870e+03
Vprtstp: contraction number = 2.255870e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.681129e-04
Vprtstp: contraction number = 1.685330e-01
Vnewton: Using errtol_s: 2047.911402
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.037213e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.206614e+02
Vprtstp: contraction number = 4.206614e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.958290e-05
Vprtstp: contraction number = 1.849329e-01
Vnewton: Using errtol_s: 378.726189
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.171116e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.336673e+01
Vprtstp: contraction number = 8.336673e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.822947e-06
Vprtstp: contraction number = 1.981116e-01
Vnewton: Using errtol_s: 75.030036
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.304576e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.697462e+01
Vprtstp: contraction number = 1.697462e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.000089e-06
Vprtstp: contraction number = 2.036139e-01
Vnewton: Using errtol_s: 15.277159
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.436174e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.421894e+00
Vprtstp: contraction number = 3.421894e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.031955e-07
Vprtstp: contraction number = 2.015888e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.148223e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.260302e+00
Vpmg_setPart:  lower corner = (19.157, -11.775, 36.873)
Vpmg_setPart:  upper corner = (87.878, 50.675, 150.763)
Vpmg_setPart:  actual minima = (19.157, -11.775, 36.873)
Vpmg_setPart:  actual maxima = (87.878, 50.675, 150.763)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.845056e+00
