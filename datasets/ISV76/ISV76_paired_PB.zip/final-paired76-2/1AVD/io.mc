##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:58 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7708 atoms
Valist_getStatistics:  Max atom coordinate:  (72.743, 37.919, 53.636)
Valist_getStatistics:  Min atom coordinate:  (7.407, -37.919, 5.056)
Valist_getStatistics:  Molecule center:  (40.075, 0, 29.346)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.822937, 0.904984, 0.922708
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.666687, 0.748734, 0.714375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.810131, 0.827345, 0.774215 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 92.743 57.919 73.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -12.593 -57.919 -14.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 82.743 47.919 63.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -2.593 -47.919 -4.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 82.743 47.919 63.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -2.593 -47.919 -4.944
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.998185
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.335611e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.344000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.661700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.496601e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.789788e-02
Vprtstp: contraction number = 5.789788e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.861809e-03
Vprtstp: contraction number = 1.357875e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.197572e-03
Vprtstp: contraction number = 2.795250e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.819756e-04
Vprtstp: contraction number = 3.103314e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.941206e-04
Vprtstp: contraction number = 4.312772e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.063684e-04
Vprtstp: contraction number = 3.616488e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.001626e-05
Vprtstp: contraction number = 4.702175e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.829957e-05
Vprtstp: contraction number = 3.658724e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.688182e-06
Vprtstp: contraction number = 4.747752e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.177264e-06
Vprtstp: contraction number = 3.656995e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.512860e-06
Vprtstp: contraction number = 4.761518e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.526786e-07
Vprtstp: contraction number = 3.653205e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.655510e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.058120e-01
Vpmg_setPart:  lower corner = (-12.593, -57.919, -14.944)
Vpmg_setPart:  upper corner = (92.743, 57.919, 73.636)
Vpmg_setPart:  actual minima = (-12.593, -57.919, -14.944)
Vpmg_setPart:  actual maxima = (92.743, 57.919, 73.636)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -2.593, -47.919, -4.944
VPMG::focusFillBound -- New mesh maxs = 82.743, 47.919, 63.636
VPMG::focusFillBound -- Old mesh mins = -12.593, -57.919, -14.944
VPMG::focusFillBound -- Old mesh maxs = 92.743, 57.919, 73.636
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.993595
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.442828e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.436600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.691400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.850417e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.214294e-02
Vprtstp: contraction number = 7.214294e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.443684e-03
Vprtstp: contraction number = 1.309024e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.052497e-03
Vprtstp: contraction number = 2.173407e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.494543e-04
Vprtstp: contraction number = 2.677004e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.401041e-04
Vprtstp: contraction number = 4.369865e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.841596e-05
Vprtstp: contraction number = 3.682401e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.651376e-05
Vprtstp: contraction number = 5.260788e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.798709e-05
Vprtstp: contraction number = 3.867047e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.570120e-06
Vprtstp: contraction number = 5.320549e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.736783e-06
Vprtstp: contraction number = 3.904635e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.983447e-06
Vprtstp: contraction number = 5.307900e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.784762e-07
Vprtstp: contraction number = 3.924865e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.749040e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.159820e-01
Vpmg_setPart:  lower corner = (-2.593, -47.919, -4.944)
Vpmg_setPart:  upper corner = (82.743, 47.919, 63.636)
Vpmg_setPart:  actual minima = (-2.593, -47.919, -4.944)
Vpmg_setPart:  actual maxima = (82.743, 47.919, 63.636)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.961160e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:04 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7708 atoms
Valist_getStatistics:  Max atom coordinate:  (72.743, 37.919, 53.636)
Valist_getStatistics:  Min atom coordinate:  (7.407, -37.919, 5.056)
Valist_getStatistics:  Molecule center:  (40.075, 0, 29.346)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.822937, 0.904984, 0.922708
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.666687, 0.748734, 0.714375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.810131, 0.827345, 0.774215 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 92.743 57.919 73.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -12.593 -57.919 -14.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 82.743 47.919 63.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -2.593 -47.919 -4.944
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 82.743 47.919 63.636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -2.593 -47.919 -4.944
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.999362
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.335218e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.472000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.733000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.476087e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8808543.064488
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.569945e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.030655e+05
Vprtstp: contraction number = 5.030655e+05
Vnewton: Attempting damping, relres = 0.055497
Vnewton: Attempting damping, relres = 0.520949
Vnewton: Damping accepted, relres = 0.055497
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.549653e-02
Vprtstp: contraction number = 5.549653e-02
Vnewton: Using errtol_s: 488843.581028
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.755278e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.329483e+04
Vprtstp: contraction number = 6.329483e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.043379e-03
Vprtstp: contraction number = 1.269157e-01
Vnewton: Using errtol_s: 62041.909827
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.893986e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.572753e+03
Vprtstp: contraction number = 9.572753e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.030333e-03
Vprtstp: contraction number = 1.462839e-01
Vnewton: Using errtol_s: 9075.731837
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.032880e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.564172e+03
Vprtstp: contraction number = 1.564172e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.603475e-04
Vprtstp: contraction number = 1.556269e-01
Vnewton: Using errtol_s: 1412.427808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.172283e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.625611e+02
Vprtstp: contraction number = 2.625611e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.683307e-05
Vprtstp: contraction number = 1.673433e-01
Vnewton: Using errtol_s: 236.360292
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.313060e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.582905e+01
Vprtstp: contraction number = 4.582905e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.682798e-06
Vprtstp: contraction number = 1.745159e-01
Vnewton: Using errtol_s: 41.248624
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.456315e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.770559e+00
Vprtstp: contraction number = 8.770559e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.961369e-07
Vprtstp: contraction number = 1.913679e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.085607e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.205753e+00
Vpmg_setPart:  lower corner = (-12.593, -57.919, -14.944)
Vpmg_setPart:  upper corner = (92.743, 57.919, 73.636)
Vpmg_setPart:  actual minima = (-12.593, -57.919, -14.944)
Vpmg_setPart:  actual maxima = (92.743, 57.919, 73.636)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -2.593, -47.919, -4.944
VPMG::focusFillBound -- New mesh maxs = 82.743, 47.919, 63.636
VPMG::focusFillBound -- Old mesh mins = -12.593, -57.919, -14.944
VPMG::focusFillBound -- Old mesh maxs = 92.743, 57.919, 73.636
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.992793
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.439917e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.396200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.020700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.127530e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 10699388.852015
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.220540e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.116290e+05
Vprtstp: contraction number = 8.116290e+05
Vnewton: Attempting damping, relres = 0.071742
Vnewton: Attempting damping, relres = 0.530491
Vnewton: Damping accepted, relres = 0.071742
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.174239e-02
Vprtstp: contraction number = 7.174239e-02
Vnewton: Using errtol_s: 767599.684336
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.406782e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.028722e+05
Vprtstp: contraction number = 1.028722e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.169023e-03
Vprtstp: contraction number = 1.278048e-01
Vnewton: Using errtol_s: 98102.938863
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.548922e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.547413e+04
Vprtstp: contraction number = 1.547413e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.353769e-03
Vprtstp: contraction number = 1.476460e-01
Vnewton: Using errtol_s: 14484.504174
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.691064e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.560355e+03
Vprtstp: contraction number = 2.560355e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.160301e-04
Vprtstp: contraction number = 1.595767e-01
Vnewton: Using errtol_s: 2311.390018
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.832685e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.482187e+02
Vprtstp: contraction number = 4.482187e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.770823e-05
Vprtstp: contraction number = 1.745508e-01
Vnewton: Using errtol_s: 403.455002
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.974366e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.100528e+01
Vprtstp: contraction number = 8.100528e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.813990e-06
Vprtstp: contraction number = 1.807030e-01
Vnewton: Using errtol_s: 72.905524
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.117175e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.666353e+01
Vprtstp: contraction number = 1.666353e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.401719e-06
Vprtstp: contraction number = 2.057119e-01
Vnewton: Using errtol_s: 14.997533
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.258784e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.668235e+00
Vprtstp: contraction number = 3.668235e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.085610e-07
Vprtstp: contraction number = 2.201305e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.238393e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.359890e+00
Vpmg_setPart:  lower corner = (-2.593, -47.919, -4.944)
Vpmg_setPart:  upper corner = (82.743, 47.919, 63.636)
Vpmg_setPart:  actual minima = (-2.593, -47.919, -4.944)
Vpmg_setPart:  actual maxima = (82.743, 47.919, 63.636)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.701134e+00
