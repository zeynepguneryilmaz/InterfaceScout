##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:44 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7465 atoms
Valist_getStatistics:  Max atom coordinate:  (51.081, 33.625, 68.431)
Valist_getStatistics:  Min atom coordinate:  (-13.925, -22.048, 7.855)
Valist_getStatistics:  Molecule center:  (18.578, 5.7885, 38.143)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.820359, 0.996594, 0.78575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.664109, 0.78826, 0.6295
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.809535, 0.790955, 0.801145 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 71.081 53.625 88.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -33.925 -42.048 -12.145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 61.081 43.625 78.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -23.925 -32.048 -2.145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 61.081 43.625 78.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -23.925 -32.048 -2.145
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8117156 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.001551
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.322028e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.465800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.291200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.480703e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.828235e-02
Vprtstp: contraction number = 5.828235e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.078041e-03
Vprtstp: contraction number = 1.557597e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.588570e-03
Vprtstp: contraction number = 2.851464e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.326615e-04
Vprtstp: contraction number = 2.444058e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.396097e-04
Vprtstp: contraction number = 3.787329e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.924797e-05
Vprtstp: contraction number = 2.890032e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.766006e-05
Vprtstp: contraction number = 3.994350e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.680980e-06
Vprtstp: contraction number = 3.138453e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.476167e-06
Vprtstp: contraction number = 4.004348e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.147432e-06
Vprtstp: contraction number = 3.300855e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.609716e-07
Vprtstp: contraction number = 4.017419e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.472430e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.855250e-01
Vpmg_setPart:  lower corner = (-33.925, -42.048, -12.145)
Vpmg_setPart:  upper corner = (71.081, 53.625, 88.431)
Vpmg_setPart:  actual minima = (-33.925, -42.048, -12.145)
Vpmg_setPart:  actual maxima = (71.081, 53.625, 88.431)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8117156 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -23.925, -32.048, -2.145
VPMG::focusFillBound -- New mesh maxs = 61.081, 43.625, 78.431
VPMG::focusFillBound -- Old mesh mins = -33.925, -42.048, -12.145
VPMG::focusFillBound -- Old mesh maxs = 71.081, 53.625, 88.431
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.996818
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.424324e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.584400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.310100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.796274e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.326303e-02
Vprtstp: contraction number = 7.326303e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.111974e-02
Vprtstp: contraction number = 1.517783e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.834262e-03
Vprtstp: contraction number = 2.548857e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.807452e-04
Vprtstp: contraction number = 2.754668e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.145859e-04
Vprtstp: contraction number = 4.029303e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.064658e-04
Vprtstp: contraction number = 3.384317e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.740608e-05
Vprtstp: contraction number = 4.452704e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.706251e-05
Vprtstp: contraction number = 3.599225e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.668073e-06
Vprtstp: contraction number = 4.494105e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.835597e-06
Vprtstp: contraction number = 3.697927e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.273047e-06
Vprtstp: contraction number = 4.489521e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.771136e-07
Vprtstp: contraction number = 3.747807e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.098570e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.495610e-01
Vpmg_setPart:  lower corner = (-23.925, -32.048, -2.145)
Vpmg_setPart:  upper corner = (61.081, 43.625, 78.431)
Vpmg_setPart:  actual minima = (-23.925, -32.048, -2.145)
Vpmg_setPart:  actual maxima = (61.081, 43.625, 78.431)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.954325e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:51 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7465 atoms
Valist_getStatistics:  Max atom coordinate:  (51.081, 33.625, 68.431)
Valist_getStatistics:  Min atom coordinate:  (-13.925, -22.048, 7.855)
Valist_getStatistics:  Molecule center:  (18.578, 5.7885, 38.143)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.820359, 0.996594, 0.78575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.664109, 0.78826, 0.6295
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.809535, 0.790955, 0.801145 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 71.081 53.625 88.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -33.925 -42.048 -12.145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 61.081 43.625 78.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -23.925 -32.048 -2.145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 61.081 43.625 78.431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -23.925 -32.048 -2.145
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8117156 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.000900
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.323729e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.376100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.088000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.467646e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8331089.753745
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.563598e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.492545e+05
Vprtstp: contraction number = 4.492545e+05
Vnewton: Attempting damping, relres = 0.051511
Vnewton: Attempting damping, relres = 0.519219
Vnewton: Damping accepted, relres = 0.051511
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.151107e-02
Vprtstp: contraction number = 5.151107e-02
Vnewton: Using errtol_s: 429143.321179
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.754914e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.967372e+04
Vprtstp: contraction number = 5.967372e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.009527e-03
Vprtstp: contraction number = 1.360781e-01
Vnewton: Using errtol_s: 58396.995427
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.899238e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.052163e+04
Vprtstp: contraction number = 1.052163e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.220467e-03
Vprtstp: contraction number = 1.741155e-01
Vnewton: Using errtol_s: 10167.821860
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.043335e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.166017e+03
Vprtstp: contraction number = 2.166017e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.425733e-04
Vprtstp: contraction number = 1.987545e-01
Vnewton: Using errtol_s: 2020.899944
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.187061e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.956453e+02
Vprtstp: contraction number = 4.956453e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.435765e-05
Vprtstp: contraction number = 2.240875e-01
Vnewton: Using errtol_s: 452.858446
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.334169e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.224602e+02
Vprtstp: contraction number = 1.224602e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.327612e-05
Vprtstp: contraction number = 2.442364e-01
Vnewton: Using errtol_s: 110.604506
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.479002e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.111871e+01
Vprtstp: contraction number = 3.111871e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.363629e-06
Vprtstp: contraction number = 2.533595e-01
Vnewton: Using errtol_s: 28.022697
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.624565e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.996451e+00
Vprtstp: contraction number = 7.996451e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.638398e-07
Vprtstp: contraction number = 2.568178e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.266416e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.390032e+00
Vpmg_setPart:  lower corner = (-33.925, -42.048, -12.145)
Vpmg_setPart:  upper corner = (71.081, 53.625, 88.431)
Vpmg_setPart:  actual minima = (-33.925, -42.048, -12.145)
Vpmg_setPart:  actual maxima = (71.081, 53.625, 88.431)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8117156 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -23.925, -32.048, -2.145
VPMG::focusFillBound -- New mesh maxs = 61.081, 43.625, 78.431
VPMG::focusFillBound -- Old mesh mins = -33.925, -42.048, -12.145
VPMG::focusFillBound -- Old mesh maxs = 71.081, 53.625, 88.431
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.994192
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.422743e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.477000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.965500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.283986e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9942343.561300
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.381480e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.538699e+05
Vprtstp: contraction number = 7.538699e+05
Vnewton: Attempting damping, relres = 0.071207
Vnewton: Attempting damping, relres = 0.530207
Vnewton: Damping accepted, relres = 0.071207
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.120683e-02
Vprtstp: contraction number = 7.120683e-02
Vnewton: Using errtol_s: 707962.763980
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.574443e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.023916e+05
Vprtstp: contraction number = 1.023916e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.879157e-03
Vprtstp: contraction number = 1.387389e-01
Vnewton: Using errtol_s: 98221.976375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.725271e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.769741e+04
Vprtstp: contraction number = 1.769741e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.713330e-03
Vprtstp: contraction number = 1.734288e-01
Vnewton: Using errtol_s: 17034.518153
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.876511e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.585338e+03
Vprtstp: contraction number = 3.585338e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.453596e-04
Vprtstp: contraction number = 2.015721e-01
Vnewton: Using errtol_s: 3433.683717
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.023047e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.422319e+02
Vprtstp: contraction number = 8.422319e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.002438e-05
Vprtstp: contraction number = 2.317132e-01
Vnewton: Using errtol_s: 795.629925
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.170484e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.180042e+02
Vprtstp: contraction number = 2.180042e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.004767e-05
Vprtstp: contraction number = 2.505196e-01
Vnewton: Using errtol_s: 199.320862
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.317843e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.804662e+01
Vprtstp: contraction number = 5.804662e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.250579e-06
Vprtstp: contraction number = 2.619047e-01
Vnewton: Using errtol_s: 52.203065
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.465487e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.542576e+01
Vprtstp: contraction number = 1.542576e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.396354e-06
Vprtstp: contraction number = 2.659427e-01
Vnewton: Using errtol_s: 13.883026
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.611958e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.280894e+00
Vprtstp: contraction number = 4.280894e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.875143e-07
Vprtstp: contraction number = 2.775187e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.438336e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.561248e+00
Vpmg_setPart:  lower corner = (-23.925, -32.048, -2.145)
Vpmg_setPart:  upper corner = (61.081, 43.625, 78.431)
Vpmg_setPart:  actual minima = (-23.925, -32.048, -2.145)
Vpmg_setPart:  actual maxima = (61.081, 43.625, 78.431)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.081424e+00
