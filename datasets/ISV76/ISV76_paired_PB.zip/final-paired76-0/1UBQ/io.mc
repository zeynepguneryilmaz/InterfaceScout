##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1231 atoms
Valist_getStatistics:  Max atom coordinate:  (46.124, 45.268, 36.251)
Valist_getStatistics:  Min atom coordinate:  (15.44, 12.896, -0.366)
Valist_getStatistics:  Molecule center:  (30.782, 29.082, 17.9425)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.10444, 0.753875, 0.798094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.791937, 0.545542, 0.58976
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.717051, 0.72365, 0.738961 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.124 65.268 56.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -4.56 -7.104 -20.366
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.124 55.268 46.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 5.44 2.896 -10.366
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.124 55.268 46.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 5.44 2.896 -10.366
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.150112
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.595750e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.329400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.679400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.140930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.689027e-02
Vprtstp: contraction number = 7.689027e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.227556e-02
Vprtstp: contraction number = 1.596503e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.601373e-03
Vprtstp: contraction number = 2.119149e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.030147e-04
Vprtstp: contraction number = 2.318063e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.504579e-04
Vprtstp: contraction number = 2.495094e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.825842e-05
Vprtstp: contraction number = 2.542800e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.011237e-05
Vprtstp: contraction number = 2.643174e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.718629e-06
Vprtstp: contraction number = 2.688420e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.475692e-07
Vprtstp: contraction number = 2.749802e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.846850e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.325180e-01
Vpmg_setPart:  lower corner = (-4.56, -7.104, -20.366)
Vpmg_setPart:  upper corner = (66.124, 65.268, 56.251)
Vpmg_setPart:  actual minima = (-4.56, -7.104, -20.366)
Vpmg_setPart:  actual maxima = (66.124, 65.268, 56.251)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 5.44, 2.896, -10.366
VPMG::focusFillBound -- New mesh maxs = 56.124, 55.268, 46.251
VPMG::focusFillBound -- Old mesh mins = -4.56, -7.104, -20.366
VPMG::focusFillBound -- Old mesh maxs = 66.124, 65.268, 56.251
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.149390
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.099440e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.313000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.698300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.580930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.129809e-01
Vprtstp: contraction number = 1.129809e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.933701e-02
Vprtstp: contraction number = 1.711530e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.086718e-03
Vprtstp: contraction number = 2.113418e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.368459e-04
Vprtstp: contraction number = 2.292416e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.257561e-04
Vprtstp: contraction number = 2.409747e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.558232e-05
Vprtstp: contraction number = 2.462051e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.405205e-05
Vprtstp: contraction number = 2.528151e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.612801e-06
Vprtstp: contraction number = 2.571014e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.455473e-07
Vprtstp: contraction number = 2.617214e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.863390e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.341500e-01
Vpmg_setPart:  lower corner = (5.44, 2.896, -10.366)
Vpmg_setPart:  upper corner = (56.124, 55.268, 46.251)
Vpmg_setPart:  actual minima = (5.44, 2.896, -10.366)
Vpmg_setPart:  actual maxima = (56.124, 55.268, 46.251)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.167181e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1231 atoms
Valist_getStatistics:  Max atom coordinate:  (46.124, 45.268, 36.251)
Valist_getStatistics:  Min atom coordinate:  (15.44, 12.896, -0.366)
Valist_getStatistics:  Molecule center:  (30.782, 29.082, 17.9425)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.10444, 0.753875, 0.798094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.791937, 0.545542, 0.58976
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.717051, 0.72365, 0.738961 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.124 65.268 56.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -4.56 -7.104 -20.366
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.124 55.268 46.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 5.44 2.896 -10.366
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.124 55.268 46.251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 5.44 2.896 -10.366
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.149302
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.594780e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.355700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.566900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.126970e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1393193.582779
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.473740e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.131308e+05
Vprtstp: contraction number = 1.131308e+05
Vnewton: Attempting damping, relres = 0.073815
Vnewton: Attempting damping, relres = 0.530370
Vnewton: Damping accepted, relres = 0.073815
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.381516e-02
Vprtstp: contraction number = 7.381516e-02
Vnewton: Using errtol_s: 102838.807695
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.112690e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.841744e+04
Vprtstp: contraction number = 1.841744e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.189942e-02
Vprtstp: contraction number = 1.612056e-01
Vnewton: Using errtol_s: 16578.193342
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.594670e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.881138e+03
Vprtstp: contraction number = 3.881138e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.507236e-03
Vprtstp: contraction number = 2.107024e-01
Vnewton: Using errtol_s: 3493.064422
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.090750e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.141467e+02
Vprtstp: contraction number = 9.141467e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.905387e-04
Vprtstp: contraction number = 2.355338e-01
Vnewton: Using errtol_s: 822.734660
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.572780e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.269573e+02
Vprtstp: contraction number = 2.269573e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.466141e-04
Vprtstp: contraction number = 2.482718e-01
Vnewton: Using errtol_s: 204.261789
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.071340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.838096e+01
Vprtstp: contraction number = 5.838096e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.771398e-05
Vprtstp: contraction number = 2.572330e-01
Vnewton: Using errtol_s: 52.542880
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.557470e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.543933e+01
Vprtstp: contraction number = 1.543933e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.973775e-06
Vprtstp: contraction number = 2.644583e-01
Vnewton: Using errtol_s: 13.895399
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.034730e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.175620e+00
Vprtstp: contraction number = 4.175620e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.697441e-06
Vprtstp: contraction number = 2.704534e-01
Vnewton: Using errtol_s: 3.758058
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.531390e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.151034e+00
Vprtstp: contraction number = 1.151034e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.435653e-07
Vprtstp: contraction number = 2.756558e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.769150e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.231020e-01
Vpmg_setPart:  lower corner = (-4.56, -7.104, -20.366)
Vpmg_setPart:  upper corner = (66.124, 65.268, 56.251)
Vpmg_setPart:  actual minima = (-4.56, -7.104, -20.366)
Vpmg_setPart:  actual maxima = (66.124, 65.268, 56.251)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 5.44, 2.896, -10.366
VPMG::focusFillBound -- New mesh maxs = 56.124, 55.268, 46.251
VPMG::focusFillBound -- Old mesh mins = -4.56, -7.104, -20.366
VPMG::focusFillBound -- Old mesh maxs = 66.124, 65.268, 56.251
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.148516
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.085170e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.354800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.647500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.146644e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1790631.603095
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.182455e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.202059e+05
Vprtstp: contraction number = 2.202059e+05
Vnewton: Attempting damping, relres = 0.111189
Vnewton: Attempting damping, relres = 0.551367
Vnewton: Damping accepted, relres = 0.111189
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.111886e-01
Vprtstp: contraction number = 1.111886e-01
Vnewton: Using errtol_s: 199097.847261
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.246666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.763953e+04
Vprtstp: contraction number = 3.763953e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.891971e-02
Vprtstp: contraction number = 1.701587e-01
Vnewton: Using errtol_s: 33878.233601
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.293804e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.941834e+03
Vprtstp: contraction number = 7.941834e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.991714e-03
Vprtstp: contraction number = 2.109817e-01
Vnewton: Using errtol_s: 7147.688492
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.341457e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.831703e+03
Vprtstp: contraction number = 1.831703e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.206442e-04
Vprtstp: contraction number = 2.306388e-01
Vnewton: Using errtol_s: 1648.534651
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.390142e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.414575e+02
Vprtstp: contraction number = 4.414575e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.218836e-04
Vprtstp: contraction number = 2.410091e-01
Vnewton: Using errtol_s: 397.311852
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.440018e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.094588e+02
Vprtstp: contraction number = 1.094588e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.501572e-05
Vprtstp: contraction number = 2.479485e-01
Vnewton: Using errtol_s: 98.512891
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.489367e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.775065e+01
Vprtstp: contraction number = 2.775065e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.394792e-05
Vprtstp: contraction number = 2.535260e-01
Vnewton: Using errtol_s: 24.975582
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.539447e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.165833e+00
Vprtstp: contraction number = 7.165833e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.601662e-06
Vprtstp: contraction number = 2.582222e-01
Vnewton: Using errtol_s: 6.449250
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.590163e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.883003e+00
Vprtstp: contraction number = 1.883003e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.464272e-07
Vprtstp: contraction number = 2.627751e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.815280e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.284780e-01
Vpmg_setPart:  lower corner = (5.44, 2.896, -10.366)
Vpmg_setPart:  upper corner = (56.124, 55.268, 46.251)
Vpmg_setPart:  actual minima = (5.44, 2.896, -10.366)
Vpmg_setPart:  actual maxima = (56.124, 55.268, 46.251)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.751777e+00
