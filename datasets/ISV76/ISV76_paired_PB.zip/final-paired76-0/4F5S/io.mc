##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:08 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9221 atoms
Valist_getStatistics:  Max atom coordinate:  (55.518, 54.313, 140.028)
Valist_getStatistics:  Min atom coordinate:  (-37.618, -8.602, 64.109)
Valist_getStatistics:  Molecule center:  (8.95, 22.8555, 102.069)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.8321, 0.804023, 0.905617
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.7071, 0.647773, 0.749367
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.849778, 0.805665, 0.827466 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.518 74.313 160.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -57.618 -28.602 44.109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.518 64.313 150.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -47.618 -18.602 54.109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.518 64.313 150.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -47.618 -18.602 54.109
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -15.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6234737 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.270217
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.747021e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.600500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.714540e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.031282e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.283716e-02
Vprtstp: contraction number = 7.283716e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.497613e-02
Vprtstp: contraction number = 2.056111e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.968084e-03
Vprtstp: contraction number = 3.317336e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.101779e-03
Vprtstp: contraction number = 4.230562e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.680684e-04
Vprtstp: contraction number = 4.130161e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.331406e-04
Vprtstp: contraction number = 4.989706e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.763454e-04
Vprtstp: contraction number = 4.071321e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.199830e-05
Vprtstp: contraction number = 5.216937e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.662798e-05
Vprtstp: contraction number = 3.981376e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.950630e-05
Vprtstp: contraction number = 5.325520e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.668797e-06
Vprtstp: contraction number = 3.931445e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.129740e-06
Vprtstp: contraction number = 5.385121e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.613205e-06
Vprtstp: contraction number = 3.906313e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 8.737763e-07
Vprtstp: contraction number = 5.416398e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.757743e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.018058e+00
Vpmg_setPart:  lower corner = (-57.618, -28.602, 44.109)
Vpmg_setPart:  upper corner = (75.518, 74.313, 160.028)
Vpmg_setPart:  actual minima = (-57.618, -28.602, 44.109)
Vpmg_setPart:  actual maxima = (75.518, 74.313, 160.028)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -15.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6234737 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -47.618, -18.602, 54.109
VPMG::focusFillBound -- New mesh maxs = 65.518, 64.313, 150.028
VPMG::focusFillBound -- Old mesh mins = -57.618, -28.602, 44.109
VPMG::focusFillBound -- Old mesh maxs = 75.518, 74.313, 160.028
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.269678
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.888791e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.579500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.701050e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.944738e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.611465e-02
Vprtstp: contraction number = 8.611465e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.461110e-02
Vprtstp: contraction number = 1.696703e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.993754e-03
Vprtstp: contraction number = 2.733370e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.594821e-03
Vprtstp: contraction number = 3.993288e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.733077e-04
Vprtstp: contraction number = 4.221838e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.571642e-04
Vprtstp: contraction number = 5.304621e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.564488e-04
Vprtstp: contraction number = 4.380304e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.752064e-05
Vprtstp: contraction number = 5.594204e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.787676e-05
Vprtstp: contraction number = 4.327751e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.161148e-05
Vprtstp: contraction number = 5.705738e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.286380e-06
Vprtstp: contraction number = 4.296965e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.358079e-06
Vprtstp: contraction number = 5.769826e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.297330e-06
Vprtstp: contraction number = 4.287600e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.333812e-06
Vprtstp: contraction number = 5.805923e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 5.723559e-07
Vprtstp: contraction number = 4.291128e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.939522e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.199557e+00
Vpmg_setPart:  lower corner = (-47.618, -18.602, 54.109)
Vpmg_setPart:  upper corner = (65.518, 64.313, 150.028)
Vpmg_setPart:  actual minima = (-47.618, -18.602, 54.109)
Vpmg_setPart:  actual maxima = (65.518, 64.313, 150.028)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.461904e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:19 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9221 atoms
Valist_getStatistics:  Max atom coordinate:  (55.518, 54.313, 140.028)
Valist_getStatistics:  Min atom coordinate:  (-37.618, -8.602, 64.109)
Valist_getStatistics:  Molecule center:  (8.95, 22.8555, 102.069)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.8321, 0.804023, 0.905617
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.7071, 0.647773, 0.749367
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.849778, 0.805665, 0.827466 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.518 74.313 160.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -57.618 -28.602 44.109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.518 64.313 150.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -47.618 -18.602 54.109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.518 64.313 150.028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -47.618 -18.602 54.109
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -15.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6234737 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.281339
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.760447e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.599300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.130820e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.984088e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 10711497.827602
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.154674e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.022545e+05
Vprtstp: contraction number = 7.022545e+05
Vnewton: Attempting damping, relres = 29.580472
Vnewton: Attempting damping, relres = 0.529773
Vnewton: Attempting damping, relres = 0.762017
Vnewton: Damping accepted, relres = 0.529773
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.297726e-01
Vprtstp: contraction number = 5.297726e-01
Vnewton: Using errtol_s: 5674658.210417
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.553348e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.919719e+05
Vprtstp: contraction number = 3.919719e+05
Vnewton: Attempting damping, relres = 0.035397
Vnewton: Attempting damping, relres = 0.279541
Vnewton: Damping accepted, relres = 0.035397
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.539741e-02
Vprtstp: contraction number = 6.681623e-02
Vnewton: Using errtol_s: 379159.271132
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.881285e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.434595e+04
Vprtstp: contraction number = 5.434595e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.833229e-03
Vprtstp: contraction number = 1.365419e-01
Vnewton: Using errtol_s: 51771.120688
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.137780e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.051661e+03
Vprtstp: contraction number = 9.051661e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.773302e-04
Vprtstp: contraction number = 1.608304e-01
Vnewton: Using errtol_s: 8326.371150
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.391887e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.788796e+03
Vprtstp: contraction number = 1.788796e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.506634e-04
Vprtstp: contraction number = 1.938216e-01
Vnewton: Using errtol_s: 1613.830924
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.647821e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.517999e+02
Vprtstp: contraction number = 4.517999e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.801314e-05
Vprtstp: contraction number = 2.523051e-01
Vnewton: Using errtol_s: 407.177703
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.901959e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.523914e+02
Vprtstp: contraction number = 1.523914e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.281729e-05
Vprtstp: contraction number = 3.371804e-01
Vnewton: Using errtol_s: 137.292355
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.157098e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.417362e+01
Vprtstp: contraction number = 6.417362e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.395571e-06
Vprtstp: contraction number = 4.209604e-01
Vnewton: Using errtol_s: 57.794652
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.438299e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.058682e+01
Vprtstp: contraction number = 3.058682e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.570961e-06
Vprtstp: contraction number = 4.764947e-01
Vnewton: Using errtol_s: 27.538847
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.697834e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.540738e+01
Vprtstp: contraction number = 1.540738e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.294838e-06
Vprtstp: contraction number = 5.036397e-01
Vnewton: Using errtol_s: 13.869658
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.955751e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.960561e+00
Vprtstp: contraction number = 7.960561e+00
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.689408e-07
Vprtstp: contraction number = 5.166211e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.167759e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.367420e+00
Vpmg_setPart:  lower corner = (-57.618, -28.602, 44.109)
Vpmg_setPart:  upper corner = (75.518, 74.313, 160.028)
Vpmg_setPart:  actual minima = (-57.618, -28.602, 44.109)
Vpmg_setPart:  actual maxima = (75.518, 74.313, 160.028)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -15.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6234737 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -47.618, -18.602, 54.109
VPMG::focusFillBound -- New mesh maxs = 65.518, 64.313, 150.028
VPMG::focusFillBound -- Old mesh mins = -57.618, -28.602, 44.109
VPMG::focusFillBound -- Old mesh maxs = 75.518, 74.313, 160.028
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.269359
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.892893e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.875700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.149330e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.255703e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12380231.440742
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.425799e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.066228e+06
Vprtstp: contraction number = 1.066228e+06
Vnewton: Attempting damping, relres = 20.122228
Vnewton: Attempting damping, relres = 0.539569
Vnewton: Attempting damping, relres = 0.767245
Vnewton: Damping accepted, relres = 0.539569
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.395692e-01
Vprtstp: contraction number = 5.395692e-01
Vnewton: Using errtol_s: 6679992.010913
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.826592e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.991403e+05
Vprtstp: contraction number = 5.991403e+05
Vnewton: Attempting damping, relres = 0.045718
Vnewton: Attempting damping, relres = 0.290301
Vnewton: Damping accepted, relres = 0.045718
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.571754e-02
Vprtstp: contraction number = 8.472971e-02
Vnewton: Using errtol_s: 565993.787356
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.160588e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.466068e+04
Vprtstp: contraction number = 8.466068e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.390824e-03
Vprtstp: contraction number = 1.397893e-01
Vnewton: Using errtol_s: 79119.885637
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.420025e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.421975e+04
Vprtstp: contraction number = 1.421975e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.048718e-03
Vprtstp: contraction number = 1.640975e-01
Vnewton: Using errtol_s: 12983.373903
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.679102e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.696245e+03
Vprtstp: contraction number = 2.696245e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.964678e-04
Vprtstp: contraction number = 1.873409e-01
Vnewton: Using errtol_s: 2432.316745
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.934743e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.941277e+02
Vprtstp: contraction number = 5.941277e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.321206e-05
Vprtstp: contraction number = 2.199448e-01
Vnewton: Using errtol_s: 534.975315
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.192860e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.658586e+02
Vprtstp: contraction number = 1.658586e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.205998e-05
Vprtstp: contraction number = 2.790883e-01
Vnewton: Using errtol_s: 149.305336
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.459501e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.872372e+01
Vprtstp: contraction number = 5.872372e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.269487e-06
Vprtstp: contraction number = 3.540211e-01
Vnewton: Using errtol_s: 52.857242
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.722862e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.448685e+01
Vprtstp: contraction number = 2.448685e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.780213e-06
Vprtstp: contraction number = 4.169617e-01
Vnewton: Using errtol_s: 22.039443
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.986600e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.118528e+01
Vprtstp: contraction number = 1.118528e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.131553e-07
Vprtstp: contraction number = 4.567743e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.928378e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.131987e+00
Vpmg_setPart:  lower corner = (-47.618, -18.602, 54.109)
Vpmg_setPart:  upper corner = (65.518, 64.313, 150.028)
Vpmg_setPart:  actual minima = (-47.618, -18.602, 54.109)
Vpmg_setPart:  actual maxima = (65.518, 64.313, 150.028)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.076178e+01
