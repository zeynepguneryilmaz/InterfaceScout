##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:59 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1416 atoms
Valist_getStatistics:  Max atom coordinate:  (16.918, 20.221, 12.444)
Valist_getStatistics:  Min atom coordinate:  (-23.639, -20.226, -15.753)
Valist_getStatistics:  Molecule center:  (-3.3605, -0.0025, -1.6545)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.839135, 0.83799, 1.06558
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.630802, 0.629656, 0.753078
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.751729, 0.751389, 0.706732 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.918 40.221 32.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -43.639 -40.226 -35.753
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.918 30.221 22.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -33.639 -30.226 -25.753
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.918 30.221 22.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -33.639 -30.226 -25.753
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.167897
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.856100e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.257000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.935100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.421110e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.265125e-02
Vprtstp: contraction number = 7.265125e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.704121e-03
Vprtstp: contraction number = 1.335713e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.768252e-03
Vprtstp: contraction number = 1.822166e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.777952e-04
Vprtstp: contraction number = 2.136547e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.906802e-05
Vprtstp: contraction number = 2.357574e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.345516e-05
Vprtstp: contraction number = 2.633398e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.318657e-06
Vprtstp: contraction number = 2.693931e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.870056e-06
Vprtstp: contraction number = 2.959578e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.355427e-07
Vprtstp: contraction number = 2.863779e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.793880e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.289730e-01
Vpmg_setPart:  lower corner = (-43.639, -40.226, -35.753)
Vpmg_setPart:  upper corner = (36.918, 40.221, 32.444)
Vpmg_setPart:  actual minima = (-43.639, -40.226, -35.753)
Vpmg_setPart:  actual maxima = (36.918, 40.221, 32.444)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -33.639, -30.226, -25.753
VPMG::focusFillBound -- New mesh maxs = 26.918, 30.221, 22.444
VPMG::focusFillBound -- Old mesh mins = -43.639, -40.226, -35.753
VPMG::focusFillBound -- Old mesh maxs = 36.918, 40.221, 32.444
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.167626
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.351730e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.294500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.908200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.078320e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.505917e-02
Vprtstp: contraction number = 9.505917e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.341648e-02
Vprtstp: contraction number = 1.411382e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.483908e-03
Vprtstp: contraction number = 1.851386e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.289957e-04
Vprtstp: contraction number = 2.532283e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.908672e-04
Vprtstp: contraction number = 3.034475e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.569126e-05
Vprtstp: contraction number = 3.441726e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.346520e-05
Vprtstp: contraction number = 3.572042e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.340597e-06
Vprtstp: contraction number = 3.980618e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.458596e-06
Vprtstp: contraction number = 3.702756e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.429292e-06
Vprtstp: contraction number = 4.132580e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.293367e-07
Vprtstp: contraction number = 3.703488e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.187960e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.683330e-01
Vpmg_setPart:  lower corner = (-33.639, -30.226, -25.753)
Vpmg_setPart:  upper corner = (26.918, 30.221, 22.444)
Vpmg_setPart:  actual minima = (-33.639, -30.226, -25.753)
Vpmg_setPart:  actual maxima = (26.918, 30.221, 22.444)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.245235e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:01 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1416 atoms
Valist_getStatistics:  Max atom coordinate:  (16.918, 20.221, 12.444)
Valist_getStatistics:  Min atom coordinate:  (-23.639, -20.226, -15.753)
Valist_getStatistics:  Molecule center:  (-3.3605, -0.0025, -1.6545)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.839135, 0.83799, 1.06558
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.630802, 0.629656, 0.753078
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.751729, 0.751389, 0.706732 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.918 40.221 32.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -43.639 -40.226 -35.753
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.918 30.221 22.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -33.639 -30.226 -25.753
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.918 30.221 22.444
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -33.639 -30.226 -25.753
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.168104
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.870500e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.317700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.649700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.407220e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1593165.719839
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.759370e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.145015e+05
Vprtstp: contraction number = 1.145015e+05
Vnewton: Attempting damping, relres = 0.068301
Vnewton: Attempting damping, relres = 0.526981
Vnewton: Damping accepted, relres = 0.068301
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.830076e-02
Vprtstp: contraction number = 6.830076e-02
Vnewton: Using errtol_s: 108814.430986
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.379990e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.603749e+04
Vprtstp: contraction number = 1.603749e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.167899e-03
Vprtstp: contraction number = 1.342284e-01
Vnewton: Using errtol_s: 14605.982751
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.823570e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.864469e+03
Vprtstp: contraction number = 2.864469e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.618926e-03
Vprtstp: contraction number = 1.765864e-01
Vnewton: Using errtol_s: 2579.217420
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.281180e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.777279e+02
Vprtstp: contraction number = 5.777279e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.263701e-04
Vprtstp: contraction number = 2.015967e-01
Vnewton: Using errtol_s: 519.961722
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.744590e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.233806e+02
Vprtstp: contraction number = 1.233806e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.969948e-05
Vprtstp: contraction number = 2.135596e-01
Vnewton: Using errtol_s: 111.042828
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.220700e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.723119e+01
Vprtstp: contraction number = 2.723119e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.538326e-05
Vprtstp: contraction number = 2.207084e-01
Vnewton: Using errtol_s: 24.508082
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.704440e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.189791e+00
Vprtstp: contraction number = 6.189791e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.496694e-06
Vprtstp: contraction number = 2.273051e-01
Vnewton: Using errtol_s: 5.570813
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.180980e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.459094e+00
Vprtstp: contraction number = 1.459094e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.242610e-07
Vprtstp: contraction number = 2.357258e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.124850e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.590210e-01
Vpmg_setPart:  lower corner = (-43.639, -40.226, -35.753)
Vpmg_setPart:  upper corner = (36.918, 40.221, 32.444)
Vpmg_setPart:  actual minima = (-43.639, -40.226, -35.753)
Vpmg_setPart:  actual maxima = (36.918, 40.221, 32.444)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -33.639, -30.226, -25.753
VPMG::focusFillBound -- New mesh maxs = 26.918, 30.221, 22.444
VPMG::focusFillBound -- Old mesh mins = -43.639, -40.226, -35.753
VPMG::focusFillBound -- Old mesh maxs = 36.918, 40.221, 32.444
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.168637
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.346460e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.305300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.685900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.136005e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2095146.019189
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.171538e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.123820e+05
Vprtstp: contraction number = 2.123820e+05
Vnewton: Attempting damping, relres = 0.093900
Vnewton: Attempting damping, relres = 0.542264
Vnewton: Damping accepted, relres = 0.093900
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.390028e-02
Vprtstp: contraction number = 9.390028e-02
Vnewton: Using errtol_s: 196734.795371
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.235420e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.962355e+04
Vprtstp: contraction number = 2.962355e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.279056e-02
Vprtstp: contraction number = 1.362142e-01
Vnewton: Using errtol_s: 26798.082531
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.281909e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.978044e+03
Vprtstp: contraction number = 4.978044e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.138688e-03
Vprtstp: contraction number = 1.672083e-01
Vnewton: Using errtol_s: 4480.862882
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.328230e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.279181e+02
Vprtstp: contraction number = 9.279181e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.986020e-04
Vprtstp: contraction number = 1.863769e-01
Vnewton: Using errtol_s: 835.129454
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.375046e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.769078e+02
Vprtstp: contraction number = 1.769078e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.599338e-05
Vprtstp: contraction number = 1.906498e-01
Vnewton: Using errtol_s: 159.217232
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.422082e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.441576e+01
Vprtstp: contraction number = 3.441576e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.478384e-05
Vprtstp: contraction number = 1.945412e-01
Vnewton: Using errtol_s: 30.974307
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.469910e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.124341e+00
Vprtstp: contraction number = 8.124341e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.489931e-06
Vprtstp: contraction number = 2.360639e-01
Vnewton: Using errtol_s: 7.311915
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.516268e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.592673e+00
Vprtstp: contraction number = 2.592673e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.113725e-06
Vprtstp: contraction number = 3.191253e-01
Vnewton: Using errtol_s: 2.333417
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.563892e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.473904e-01
Vprtstp: contraction number = 9.473904e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.069656e-07
Vprtstp: contraction number = 3.654093e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.633340e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.099720e-01
Vpmg_setPart:  lower corner = (-33.639, -30.226, -25.753)
Vpmg_setPart:  upper corner = (26.918, 30.221, 22.444)
Vpmg_setPart:  actual minima = (-33.639, -30.226, -25.753)
Vpmg_setPart:  actual maxima = (26.918, 30.221, 22.444)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.719626e+00
