##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:33 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1397 atoms
Valist_getStatistics:  Max atom coordinate:  (45.852, 73.289, 20.559)
Valist_getStatistics:  Min atom coordinate:  (13.03, 27.999, -2.577)
Valist_getStatistics:  Molecule center:  (29.441, 50.644, 8.991)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.758563, 0.888438, 0.9865
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.550229, 0.680104, 0.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.725358, 0.765506, 0.683224 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 65.852 93.289 40.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -6.97 7.999 -22.577
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 55.852 83.289 30.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 3.03 17.999 -12.577
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 55.852 83.289 30.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 3.03 17.999 -12.577
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.163453
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.819760e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.284100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.891800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.386980e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.923891e-02
Vprtstp: contraction number = 7.923891e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.076596e-02
Vprtstp: contraction number = 1.358671e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.005153e-03
Vprtstp: contraction number = 1.862493e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.088072e-04
Vprtstp: contraction number = 2.038783e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.462705e-05
Vprtstp: contraction number = 2.314711e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.257033e-05
Vprtstp: contraction number = 2.385188e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.165575e-06
Vprtstp: contraction number = 2.731717e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.768344e-06
Vprtstp: contraction number = 2.868093e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.925568e-07
Vprtstp: contraction number = 3.350913e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.892690e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.387830e-01
Vpmg_setPart:  lower corner = (-6.97, 7.999, -22.577)
Vpmg_setPart:  upper corner = (65.852, 93.289, 40.559)
Vpmg_setPart:  actual minima = (-6.97, 7.999, -22.577)
Vpmg_setPart:  actual maxima = (65.852, 93.289, 40.559)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 3.03, 17.999, -12.577
VPMG::focusFillBound -- New mesh maxs = 55.852, 83.289, 30.559
VPMG::focusFillBound -- Old mesh mins = -6.97, 7.999, -22.577
VPMG::focusFillBound -- Old mesh maxs = 65.852, 93.289, 40.559
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.164058
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.357750e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.321600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.119200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.174580e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.062278e-01
Vprtstp: contraction number = 1.062278e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.525516e-02
Vprtstp: contraction number = 1.436081e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.675881e-03
Vprtstp: contraction number = 1.754082e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.399389e-04
Vprtstp: contraction number = 2.017799e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.346435e-04
Vprtstp: contraction number = 2.493681e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.748224e-05
Vprtstp: contraction number = 2.783813e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.267511e-05
Vprtstp: contraction number = 3.381632e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.398677e-06
Vprtstp: contraction number = 3.470325e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.749105e-06
Vprtstp: contraction number = 3.976435e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.566975e-07
Vprtstp: contraction number = 3.754476e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.044290e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.565600e-01
Vpmg_setPart:  lower corner = (3.03, 17.999, -12.577)
Vpmg_setPart:  upper corner = (55.852, 83.289, 30.559)
Vpmg_setPart:  actual minima = (3.03, 17.999, -12.577)
Vpmg_setPart:  actual maxima = (55.852, 83.289, 30.559)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.240504e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:35 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1397 atoms
Valist_getStatistics:  Max atom coordinate:  (45.852, 73.289, 20.559)
Valist_getStatistics:  Min atom coordinate:  (13.03, 27.999, -2.577)
Valist_getStatistics:  Molecule center:  (29.441, 50.644, 8.991)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.758563, 0.888438, 0.9865
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.550229, 0.680104, 0.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.725358, 0.765506, 0.683224 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 65.852 93.289 40.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -6.97 7.999 -22.577
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 55.852 83.289 30.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 3.03 17.999 -12.577
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 55.852 83.289 30.559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 3.03 17.999 -12.577
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.164255
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.824020e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.253200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.650300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.353500e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1688048.115833
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.679530e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.334566e+05
Vprtstp: contraction number = 1.334566e+05
Vnewton: Attempting damping, relres = 0.076904
Vnewton: Attempting damping, relres = 0.530434
Vnewton: Damping accepted, relres = 0.076904
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.690446e-02
Vprtstp: contraction number = 7.690446e-02
Vnewton: Using errtol_s: 129818.422179
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.294440e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.923173e+04
Vprtstp: contraction number = 1.923173e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.047820e-02
Vprtstp: contraction number = 1.362495e-01
Vnewton: Using errtol_s: 17687.699211
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.751950e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.379718e+03
Vprtstp: contraction number = 3.379718e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.803561e-03
Vprtstp: contraction number = 1.721251e-01
Vnewton: Using errtol_s: 3044.497548
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.222340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.630734e+02
Vprtstp: contraction number = 6.630734e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.535313e-04
Vprtstp: contraction number = 1.960185e-01
Vnewton: Using errtol_s: 596.777887
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.688420e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.412943e+02
Vprtstp: contraction number = 1.412943e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.533270e-05
Vprtstp: contraction number = 2.130863e-01
Vnewton: Using errtol_s: 127.165218
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.143740e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.240774e+01
Vprtstp: contraction number = 3.240774e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.727852e-05
Vprtstp: contraction number = 2.293628e-01
Vnewton: Using errtol_s: 29.166974
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.606680e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.205470e+00
Vprtstp: contraction number = 8.205470e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.374830e-06
Vprtstp: contraction number = 2.531947e-01
Vnewton: Using errtol_s: 7.384923
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.070570e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.339045e+00
Vprtstp: contraction number = 2.339045e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.247085e-06
Vprtstp: contraction number = 2.850592e-01
Vnewton: Using errtol_s: 2.105140
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.537780e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.431246e-01
Vprtstp: contraction number = 7.431246e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.962044e-07
Vprtstp: contraction number = 3.177043e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.530360e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.984060e-01
Vpmg_setPart:  lower corner = (-6.97, 7.999, -22.577)
Vpmg_setPart:  upper corner = (65.852, 93.289, 40.559)
Vpmg_setPart:  actual minima = (-6.97, 7.999, -22.577)
Vpmg_setPart:  actual maxima = (65.852, 93.289, 40.559)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 3.03, 17.999, -12.577
VPMG::focusFillBound -- New mesh maxs = 55.852, 83.289, 30.559
VPMG::focusFillBound -- Old mesh mins = -6.97, 7.999, -22.577
VPMG::focusFillBound -- Old mesh maxs = 65.852, 93.289, 40.559
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.163055
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.337200e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.233800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.613500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.168620e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2211477.293599
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.200946e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.527556e+05
Vprtstp: contraction number = 2.527556e+05
Vnewton: Attempting damping, relres = 0.107100
Vnewton: Attempting damping, relres = 0.548372
Vnewton: Damping accepted, relres = 0.107100
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.071003e-01
Vprtstp: contraction number = 1.071003e-01
Vnewton: Using errtol_s: 236849.989067
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.264865e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.641764e+04
Vprtstp: contraction number = 3.641764e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.497704e-02
Vprtstp: contraction number = 1.398412e-01
Vnewton: Using errtol_s: 33121.383057
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.313006e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.068278e+03
Vprtstp: contraction number = 6.068278e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.470280e-03
Vprtstp: contraction number = 1.649378e-01
Vnewton: Using errtol_s: 5462.969030
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.359998e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.122727e+03
Vprtstp: contraction number = 1.122727e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.569165e-04
Vprtstp: contraction number = 1.849654e-01
Vnewton: Using errtol_s: 1010.460464
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.409123e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.254487e+02
Vprtstp: contraction number = 2.254487e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.175048e-05
Vprtstp: contraction number = 2.008036e-01
Vnewton: Using errtol_s: 202.904109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.457902e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.809222e+01
Vprtstp: contraction number = 4.809222e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.957200e-05
Vprtstp: contraction number = 2.133176e-01
Vnewton: Using errtol_s: 43.283026
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.505696e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.144648e+01
Vprtstp: contraction number = 1.144648e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.658351e-06
Vprtstp: contraction number = 2.380110e-01
Vnewton: Using errtol_s: 10.301837
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.554047e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.270661e+00
Vprtstp: contraction number = 3.270661e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.331054e-06
Vprtstp: contraction number = 2.857350e-01
Vnewton: Using errtol_s: 2.943595
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.602645e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.080761e+00
Vprtstp: contraction number = 1.080761e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.398349e-07
Vprtstp: contraction number = 3.304411e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.700230e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.150190e-01
Vpmg_setPart:  lower corner = (3.03, 17.999, -12.577)
Vpmg_setPart:  upper corner = (55.852, 83.289, 30.559)
Vpmg_setPart:  actual minima = (3.03, 17.999, -12.577)
Vpmg_setPart:  actual maxima = (55.852, 83.289, 30.559)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.756601e+00
