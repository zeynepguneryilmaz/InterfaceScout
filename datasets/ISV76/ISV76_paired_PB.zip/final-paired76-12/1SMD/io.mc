##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:23 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7644 atoms
Valist_getStatistics:  Max atom coordinate:  (36.52, 95.782, 47.472)
Valist_getStatistics:  Min atom coordinate:  (-18.739, 23.032, -9.902)
Valist_getStatistics:  Molecule center:  (8.8905, 59.407, 18.785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.992281, 0.880859, 1.01431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.783948, 0.724609, 0.805979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790046, 0.822616, 0.794606 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 56.52 115.782 67.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.739 3.032 -29.902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 46.52 105.782 57.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -28.739 13.032 -19.902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 46.52 105.782 57.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -28.739 13.032 -19.902
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7998326 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.054651
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.327732e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.586700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.029900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.451142e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.561853e-02
Vprtstp: contraction number = 4.561853e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.044777e-03
Vprtstp: contraction number = 1.325071e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.157487e-03
Vprtstp: contraction number = 1.914855e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.435338e-04
Vprtstp: contraction number = 2.103987e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.801453e-05
Vprtstp: contraction number = 2.792817e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.719692e-05
Vprtstp: contraction number = 2.528418e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.035584e-06
Vprtstp: contraction number = 2.928190e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.359340e-06
Vprtstp: contraction number = 2.699468e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.002015e-07
Vprtstp: contraction number = 2.944087e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.310710e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.333600e-01
Vpmg_setPart:  lower corner = (-38.739, 3.032, -29.902)
Vpmg_setPart:  upper corner = (56.52, 115.782, 67.472)
Vpmg_setPart:  actual minima = (-38.739, 3.032, -29.902)
Vpmg_setPart:  actual maxima = (56.52, 115.782, 67.472)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7998326 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -28.739, 13.032, -19.902
VPMG::focusFillBound -- New mesh maxs = 46.52, 105.782, 57.472
VPMG::focusFillBound -- Old mesh mins = -38.739, 3.032, -29.902
VPMG::focusFillBound -- Old mesh maxs = 56.52, 115.782, 67.472
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.046157
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.404958e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.550400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.961100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.391037e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.753612e-02
Vprtstp: contraction number = 5.753612e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.394919e-03
Vprtstp: contraction number = 1.285266e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.308993e-03
Vprtstp: contraction number = 1.770125e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.729985e-04
Vprtstp: contraction number = 2.085562e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.629118e-05
Vprtstp: contraction number = 2.794564e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.105240e-05
Vprtstp: contraction number = 2.759480e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.179859e-06
Vprtstp: contraction number = 3.410470e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.135982e-06
Vprtstp: contraction number = 2.974964e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.511242e-07
Vprtstp: contraction number = 3.516529e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.537500e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.543530e-01
Vpmg_setPart:  lower corner = (-28.739, 13.032, -19.902)
Vpmg_setPart:  upper corner = (46.52, 105.782, 57.472)
Vpmg_setPart:  actual minima = (-28.739, 13.032, -19.902)
Vpmg_setPart:  actual maxima = (46.52, 105.782, 57.472)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.134839e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:29 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7644 atoms
Valist_getStatistics:  Max atom coordinate:  (36.52, 95.782, 47.472)
Valist_getStatistics:  Min atom coordinate:  (-18.739, 23.032, -9.902)
Valist_getStatistics:  Molecule center:  (8.8905, 59.407, 18.785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.992281, 0.880859, 1.01431
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.783948, 0.724609, 0.805979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790046, 0.822616, 0.794606 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 56.52 115.782 67.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.739 3.032 -29.902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 46.52 105.782 57.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -28.739 13.032 -19.902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 46.52 105.782 57.472
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -28.739 13.032 -19.902
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7998326 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.057611
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.334249e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.504500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.989100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.443742e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7820456.656084
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.516072e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.527728e+05
Vprtstp: contraction number = 3.527728e+05
Vnewton: Attempting damping, relres = 0.041599
Vnewton: Attempting damping, relres = 0.515101
Vnewton: Damping accepted, relres = 0.041599
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.159932e-02
Vprtstp: contraction number = 4.159932e-02
Vnewton: Using errtol_s: 325325.663293
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.657744e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.199307e+04
Vprtstp: contraction number = 4.199307e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.918639e-03
Vprtstp: contraction number = 1.182385e-01
Vnewton: Using errtol_s: 38466.002990
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.766567e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.246880e+03
Vprtstp: contraction number = 6.246880e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.221013e-04
Vprtstp: contraction number = 1.468092e-01
Vnewton: Using errtol_s: 5647.161612
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.876404e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.072410e+03
Vprtstp: contraction number = 1.072410e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.234300e-04
Vprtstp: contraction number = 1.709318e-01
Vnewton: Using errtol_s: 965.279275
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.986418e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.056959e+02
Vprtstp: contraction number = 2.056959e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.367217e-05
Vprtstp: contraction number = 1.917862e-01
Vnewton: Using errtol_s: 185.127216
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.096922e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.364172e+01
Vprtstp: contraction number = 4.364172e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.022415e-06
Vprtstp: contraction number = 2.121653e-01
Vnewton: Using errtol_s: 39.277575
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.207285e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.033185e+01
Vprtstp: contraction number = 1.033185e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.189018e-06
Vprtstp: contraction number = 2.367423e-01
Vnewton: Using errtol_s: 9.298662
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.314566e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.730523e+00
Vprtstp: contraction number = 2.730523e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.142362e-07
Vprtstp: contraction number = 2.642822e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.505090e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.038870e+00
Vpmg_setPart:  lower corner = (-38.739, 3.032, -29.902)
Vpmg_setPart:  upper corner = (56.52, 115.782, 67.472)
Vpmg_setPart:  actual minima = (-38.739, 3.032, -29.902)
Vpmg_setPart:  actual maxima = (56.52, 115.782, 67.472)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7998326 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -28.739, 13.032, -19.902
VPMG::focusFillBound -- New mesh maxs = 46.52, 105.782, 57.472
VPMG::focusFillBound -- Old mesh mins = -38.739, 3.032, -29.902
VPMG::focusFillBound -- Old mesh maxs = 56.52, 115.782, 67.472
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.050109
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.410137e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.600300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.100400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.898609e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9740160.872919
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.973373e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.881674e+05
Vprtstp: contraction number = 5.881674e+05
Vnewton: Attempting damping, relres = 0.055086
Vnewton: Attempting damping, relres = 0.523070
Vnewton: Damping accepted, relres = 0.055086
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.508555e-02
Vprtstp: contraction number = 5.508555e-02
Vnewton: Using errtol_s: 536542.117846
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.118561e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.968767e+04
Vprtstp: contraction number = 6.968767e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.496384e-03
Vprtstp: contraction number = 1.179326e-01
Vnewton: Using errtol_s: 63275.825219
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.228415e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.772335e+03
Vprtstp: contraction number = 9.772335e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.043724e-04
Vprtstp: contraction number = 1.392117e-01
Vnewton: Using errtol_s: 8808.732920
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.338486e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.523659e+03
Vprtstp: contraction number = 1.523659e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.407902e-04
Vprtstp: contraction number = 1.556772e-01
Vnewton: Using errtol_s: 1371.318790
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.451240e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.601633e+02
Vprtstp: contraction number = 2.601633e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.403938e-05
Vprtstp: contraction number = 1.707462e-01
Vnewton: Using errtol_s: 234.147441
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.561919e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.854639e+01
Vprtstp: contraction number = 4.854639e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.485733e-06
Vprtstp: contraction number = 1.865994e-01
Vnewton: Using errtol_s: 43.691761
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.673482e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.904165e+00
Vprtstp: contraction number = 9.904165e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.151543e-07
Vprtstp: contraction number = 2.040144e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 8.566100e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.476300e-01
Vpmg_setPart:  lower corner = (-28.739, 13.032, -19.902)
Vpmg_setPart:  upper corner = (46.52, 105.782, 57.472)
Vpmg_setPart:  actual minima = (-28.739, 13.032, -19.902)
Vpmg_setPart:  actual maxima = (46.52, 105.782, 57.472)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.024648e+00
