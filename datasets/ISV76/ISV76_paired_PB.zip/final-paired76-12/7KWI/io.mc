##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:37 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (26.302, 19.88, 28.451)
Valist_getStatistics:  Min atom coordinate:  (-29.368, -16.781, -24.217)
Valist_getStatistics:  Molecule center:  (-1.533, 1.5495, 2.117)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.996563, 0.798552, 0.965292
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.788229, 0.590219, 0.756958
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790948, 0.739111, 0.784176 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 46.302 39.88 48.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -49.368 -36.781 -44.217
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 36.302 29.88 38.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -39.368 -26.781 -34.217
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 36.302 29.88 38.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -39.368 -26.781 -34.217
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.273500
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.440940e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.059400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.517300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.314920e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.715107e-02
Vprtstp: contraction number = 6.715107e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.206396e-03
Vprtstp: contraction number = 1.222080e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.401316e-03
Vprtstp: contraction number = 1.707590e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.376911e-04
Vprtstp: contraction number = 1.696198e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.972054e-05
Vprtstp: contraction number = 2.091813e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.001904e-05
Vprtstp: contraction number = 2.015070e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.328778e-06
Vprtstp: contraction number = 2.324353e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.047225e-07
Vprtstp: contraction number = 2.167328e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.684210e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.462550e-01
Vpmg_setPart:  lower corner = (-49.368, -36.781, -44.217)
Vpmg_setPart:  upper corner = (46.302, 39.88, 48.451)
Vpmg_setPart:  actual minima = (-49.368, -36.781, -44.217)
Vpmg_setPart:  actual maxima = (46.302, 39.88, 48.451)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -39.368, -26.781, -34.217
VPMG::focusFillBound -- New mesh maxs = 36.302, 29.88, 38.451
VPMG::focusFillBound -- Old mesh mins = -49.368, -36.781, -44.217
VPMG::focusFillBound -- Old mesh maxs = 46.302, 39.88, 48.451
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.276815
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.029690e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.931200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.262800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.378507e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.028274e-02
Vprtstp: contraction number = 9.028274e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.246395e-02
Vprtstp: contraction number = 1.380547e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.137477e-03
Vprtstp: contraction number = 1.714927e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.735053e-04
Vprtstp: contraction number = 1.747412e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.356926e-05
Vprtstp: contraction number = 1.969698e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.457334e-05
Vprtstp: contraction number = 1.980901e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.181532e-06
Vprtstp: contraction number = 2.183118e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.847172e-07
Vprtstp: contraction number = 2.152162e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.745270e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.477180e-01
Vpmg_setPart:  lower corner = (-39.368, -26.781, -34.217)
Vpmg_setPart:  upper corner = (36.302, 29.88, 38.451)
Vpmg_setPart:  actual minima = (-39.368, -26.781, -34.217)
Vpmg_setPart:  actual maxima = (36.302, 29.88, 38.451)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.838947e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (26.302, 19.88, 28.451)
Valist_getStatistics:  Min atom coordinate:  (-29.368, -16.781, -24.217)
Valist_getStatistics:  Molecule center:  (-1.533, 1.5495, 2.117)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.996563, 0.798552, 0.965292
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.788229, 0.590219, 0.756958
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790948, 0.739111, 0.784176 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 46.302 39.88 48.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -49.368 -36.781 -44.217
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 36.302 29.88 38.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -39.368 -26.781 -34.217
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 36.302 29.88 38.451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -39.368 -26.781 -34.217
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.274207
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.430790e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.868800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.721300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.181590e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2720914.750660
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.673310e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.795776e+05
Vprtstp: contraction number = 1.795776e+05
Vnewton: Attempting damping, relres = 0.061185
Vnewton: Attempting damping, relres = 0.524842
Vnewton: Damping accepted, relres = 0.061185
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.118493e-02
Vprtstp: contraction number = 6.118493e-02
Vnewton: Using errtol_s: 166478.979765
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.666830e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.324812e+04
Vprtstp: contraction number = 2.324812e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.704635e-03
Vprtstp: contraction number = 1.259237e-01
Vnewton: Using errtol_s: 20963.655897
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.407110e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.650080e+03
Vprtstp: contraction number = 3.650080e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.207421e-03
Vprtstp: contraction number = 1.567136e-01
Vnewton: Using errtol_s: 3285.289831
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.154290e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.482227e+02
Vprtstp: contraction number = 6.482227e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.144160e-04
Vprtstp: contraction number = 1.775818e-01
Vnewton: Using errtol_s: 583.407734
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.911000e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.254932e+02
Vprtstp: contraction number = 1.254932e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.150966e-05
Vprtstp: contraction number = 1.935940e-01
Vnewton: Using errtol_s: 112.944258
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.711220e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.585497e+01
Vprtstp: contraction number = 2.585497e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.552084e-06
Vprtstp: contraction number = 2.060263e-01
Vnewton: Using errtol_s: 23.269492
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.051115e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.589254e+00
Vprtstp: contraction number = 5.589254e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.848764e-06
Vprtstp: contraction number = 2.161770e-01
Vnewton: Using errtol_s: 5.030330
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.130016e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.250127e+00
Vprtstp: contraction number = 1.250127e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.135058e-07
Vprtstp: contraction number = 2.236661e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.701290e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.357540e-01
Vpmg_setPart:  lower corner = (-49.368, -36.781, -44.217)
Vpmg_setPart:  upper corner = (46.302, 39.88, 48.451)
Vpmg_setPart:  actual minima = (-49.368, -36.781, -44.217)
Vpmg_setPart:  actual maxima = (46.302, 39.88, 48.451)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -39.368, -26.781, -34.217
VPMG::focusFillBound -- New mesh maxs = 36.302, 29.88, 38.451
VPMG::focusFillBound -- Old mesh mins = -49.368, -36.781, -44.217
VPMG::focusFillBound -- Old mesh maxs = 46.302, 39.88, 48.451
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.270528
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.958490e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.914700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.894600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.754788e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3354229.035272
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.805855e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.158463e+05
Vprtstp: contraction number = 3.158463e+05
Vnewton: Attempting damping, relres = 0.086125
Vnewton: Attempting damping, relres = 0.538149
Vnewton: Damping accepted, relres = 0.086125
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.612507e-02
Vprtstp: contraction number = 8.612507e-02
Vnewton: Using errtol_s: 288883.198399
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.910252e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.499881e+04
Vprtstp: contraction number = 4.499881e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.208669e-02
Vprtstp: contraction number = 1.403388e-01
Vnewton: Using errtol_s: 40541.532251
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.988669e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.427974e+03
Vprtstp: contraction number = 7.427974e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.993125e-03
Vprtstp: contraction number = 1.649024e-01
Vnewton: Using errtol_s: 6685.396510
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.066364e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.326110e+03
Vprtstp: contraction number = 1.326110e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.558213e-04
Vprtstp: contraction number = 1.785244e-01
Vnewton: Using errtol_s: 1193.506137
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.143062e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.508221e+02
Vprtstp: contraction number = 2.508221e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.730018e-05
Vprtstp: contraction number = 1.891404e-01
Vnewton: Using errtol_s: 225.740229
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.220785e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.992262e+01
Vprtstp: contraction number = 4.992262e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.339514e-05
Vprtstp: contraction number = 1.990357e-01
Vnewton: Using errtol_s: 44.930373
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.298490e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.038709e+01
Vprtstp: contraction number = 1.038709e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.787043e-06
Vprtstp: contraction number = 2.080637e-01
Vnewton: Using errtol_s: 9.348381
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.376730e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.244294e+00
Vprtstp: contraction number = 2.244294e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.021846e-07
Vprtstp: contraction number = 2.160657e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.800900e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.484900e-01
Vpmg_setPart:  lower corner = (-39.368, -26.781, -34.217)
Vpmg_setPart:  upper corner = (36.302, 29.88, 38.451)
Vpmg_setPart:  actual minima = (-39.368, -26.781, -34.217)
Vpmg_setPart:  actual maxima = (36.302, 29.88, 38.451)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.629633e+00
