##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:14 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1960 atoms
Valist_getStatistics:  Max atom coordinate:  (20.054, 38.799, 41.285)
Valist_getStatistics:  Min atom coordinate:  (-18.505, 5.196, -2.53)
Valist_getStatistics:  Molecule center:  (0.7745, 21.9975, 19.3775)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.818323, 0.766698, 0.873073
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.60999, 0.558365, 0.66474
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.745414, 0.728272, 0.761379 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 40.054 58.799 61.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.505 -14.804 -22.53
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 30.054 48.799 51.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -28.505 -4.804 -12.53
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 30.054 48.799 51.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -28.505 -4.804 -12.53
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.246486
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.195960e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.861900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.488000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.030390e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.340892e-02
Vprtstp: contraction number = 6.340892e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.679890e-03
Vprtstp: contraction number = 1.211169e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.271095e-03
Vprtstp: contraction number = 1.655095e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.528612e-04
Vprtstp: contraction number = 1.989318e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.090668e-05
Vprtstp: contraction number = 2.804174e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.057767e-05
Vprtstp: contraction number = 2.902077e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.915199e-06
Vprtstp: contraction number = 3.360536e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.160871e-06
Vprtstp: contraction number = 3.124814e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.512622e-07
Vprtstp: contraction number = 3.476663e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.245880e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.998390e-01
Vpmg_setPart:  lower corner = (-38.505, -14.804, -22.53)
Vpmg_setPart:  upper corner = (40.054, 58.799, 61.285)
Vpmg_setPart:  actual minima = (-38.505, -14.804, -22.53)
Vpmg_setPart:  actual maxima = (40.054, 58.799, 61.285)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -28.505, -4.804, -12.53
VPMG::focusFillBound -- New mesh maxs = 30.054, 48.799, 51.285
VPMG::focusFillBound -- Old mesh mins = -38.505, -14.804, -22.53
VPMG::focusFillBound -- Old mesh maxs = 40.054, 58.799, 61.285
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.244759
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.900480e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.927700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.306800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.393718e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.333718e-02
Vprtstp: contraction number = 9.333718e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.234081e-02
Vprtstp: contraction number = 1.322175e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.065229e-03
Vprtstp: contraction number = 1.673496e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.192476e-04
Vprtstp: contraction number = 2.030029e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.189962e-04
Vprtstp: contraction number = 2.838328e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.655344e-05
Vprtstp: contraction number = 3.071815e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.357067e-05
Vprtstp: contraction number = 3.712556e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.828350e-06
Vprtstp: contraction number = 3.557931e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.956833e-06
Vprtstp: contraction number = 4.052798e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.162689e-07
Vprtstp: contraction number = 3.660349e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.517200e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.254240e-01
Vpmg_setPart:  lower corner = (-28.505, -4.804, -12.53)
Vpmg_setPart:  upper corner = (30.054, 48.799, 51.285)
Vpmg_setPart:  actual minima = (-28.505, -4.804, -12.53)
Vpmg_setPart:  actual maxima = (30.054, 48.799, 51.285)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.935979e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:17 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1960 atoms
Valist_getStatistics:  Max atom coordinate:  (20.054, 38.799, 41.285)
Valist_getStatistics:  Min atom coordinate:  (-18.505, 5.196, -2.53)
Valist_getStatistics:  Molecule center:  (0.7745, 21.9975, 19.3775)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.818323, 0.766698, 0.873073
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.60999, 0.558365, 0.66474
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.745414, 0.728272, 0.761379 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 40.054 58.799 61.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.505 -14.804 -22.53
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 30.054 48.799 51.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -28.505 -4.804 -12.53
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 30.054 48.799 51.285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -28.505 -4.804 -12.53
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.249118
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.267310e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.929900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.807400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.030910e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2529638.122826
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.557030e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.586200e+05
Vprtstp: contraction number = 1.586200e+05
Vnewton: Attempting damping, relres = 0.058321
Vnewton: Attempting damping, relres = 0.523910
Vnewton: Damping accepted, relres = 0.058321
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.832129e-02
Vprtstp: contraction number = 5.832129e-02
Vnewton: Using errtol_s: 147531.763724
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.595600e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.962537e+04
Vprtstp: contraction number = 1.962537e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.014324e-03
Vprtstp: contraction number = 1.202704e-01
Vnewton: Using errtol_s: 17743.702373
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.391780e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.907328e+03
Vprtstp: contraction number = 2.907328e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.034593e-03
Vprtstp: contraction number = 1.474972e-01
Vnewton: Using errtol_s: 2617.146659
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.208080e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.875492e+02
Vprtstp: contraction number = 4.875492e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.734635e-04
Vprtstp: contraction number = 1.676634e-01
Vnewton: Using errtol_s: 438.799792
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.971200e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.922442e+01
Vprtstp: contraction number = 8.922442e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.174448e-05
Vprtstp: contraction number = 1.830039e-01
Vnewton: Using errtol_s: 80.302058
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.740860e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.743906e+01
Vprtstp: contraction number = 1.743906e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.204508e-06
Vprtstp: contraction number = 1.954515e-01
Vnewton: Using errtol_s: 15.695161
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.054142e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.939012e+00
Vprtstp: contraction number = 3.939012e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.401430e-06
Vprtstp: contraction number = 2.258729e-01
Vnewton: Using errtol_s: 3.545111
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.134459e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.017339e+00
Vprtstp: contraction number = 1.017339e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.619510e-07
Vprtstp: contraction number = 2.582725e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.901560e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.578700e-01
Vpmg_setPart:  lower corner = (-38.505, -14.804, -22.53)
Vpmg_setPart:  upper corner = (40.054, 58.799, 61.285)
Vpmg_setPart:  actual minima = (-38.505, -14.804, -22.53)
Vpmg_setPart:  actual maxima = (40.054, 58.799, 61.285)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -28.505, -4.804, -12.53
VPMG::focusFillBound -- New mesh maxs = 30.054, 48.799, 51.285
VPMG::focusFillBound -- Old mesh mins = -38.505, -14.804, -22.53
VPMG::focusFillBound -- Old mesh maxs = 40.054, 58.799, 61.285
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.245037
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.902970e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.950600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.886800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.754476e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3118800.121048
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.811253e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.097436e+05
Vprtstp: contraction number = 3.097436e+05
Vnewton: Attempting damping, relres = 0.090851
Vnewton: Attempting damping, relres = 0.541977
Vnewton: Damping accepted, relres = 0.090851
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.085065e-02
Vprtstp: contraction number = 9.085065e-02
Vnewton: Using errtol_s: 283345.002922
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.918200e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.089382e+04
Vprtstp: contraction number = 4.089382e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.182543e-02
Vprtstp: contraction number = 1.301634e-01
Vnewton: Using errtol_s: 36881.151412
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.999584e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.373331e+03
Vprtstp: contraction number = 6.373331e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.839307e-03
Vprtstp: contraction number = 1.555382e-01
Vnewton: Using errtol_s: 5736.429405
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.077765e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.088795e+03
Vprtstp: contraction number = 1.088795e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.141981e-04
Vprtstp: contraction number = 1.708242e-01
Vnewton: Using errtol_s: 979.921108
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.157286e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.936275e+02
Vprtstp: contraction number = 1.936275e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.587564e-05
Vprtstp: contraction number = 1.778357e-01
Vnewton: Using errtol_s: 174.264951
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.238346e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.448767e+01
Vprtstp: contraction number = 3.448767e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.952197e-06
Vprtstp: contraction number = 1.781133e-01
Vnewton: Using errtol_s: 31.038912
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.320652e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.415210e+00
Vprtstp: contraction number = 6.415210e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.851253e-06
Vprtstp: contraction number = 1.860145e-01
Vnewton: Using errtol_s: 5.773689
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.403216e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.341377e+00
Vprtstp: contraction number = 1.341377e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.870844e-07
Vprtstp: contraction number = 2.090932e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.098180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.785400e-01
Vpmg_setPart:  lower corner = (-28.505, -4.804, -12.53)
Vpmg_setPart:  upper corner = (30.054, 48.799, 51.285)
Vpmg_setPart:  actual minima = (-28.505, -4.804, -12.53)
Vpmg_setPart:  actual maxima = (30.054, 48.799, 51.285)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.656819e+00
