##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:04 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5022 atoms
Valist_getStatistics:  Max atom coordinate:  (178.19, 150.73, 116.286)
Valist_getStatistics:  Min atom coordinate:  (76.358, 47.241, 21.062)
Valist_getStatistics:  Molecule center:  (127.274, 98.9855, 68.674)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.88645, 0.896806, 0.84515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.76145, 0.771806, 0.72015
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.858988, 0.860616, 0.852097 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 198.19 170.73 136.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 56.358 27.241 1.062
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 188.19 160.73 126.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 66.358 37.241 11.062
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 188.19 160.73 126.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 66.358 37.241 11.062
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.728690
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.190690e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.578400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.086490e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.651434e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.422150e-02
Vprtstp: contraction number = 7.422150e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.625592e-03
Vprtstp: contraction number = 1.296874e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.483212e-03
Vprtstp: contraction number = 1.540904e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.694452e-04
Vprtstp: contraction number = 1.816633e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.045411e-05
Vprtstp: contraction number = 1.872518e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.175052e-05
Vprtstp: contraction number = 2.328952e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.566771e-06
Vprtstp: contraction number = 2.184389e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.886829e-07
Vprtstp: contraction number = 2.683072e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.712695e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.158431e+00
Vpmg_setPart:  lower corner = (56.358, 27.241, 1.062)
Vpmg_setPart:  upper corner = (198.19, 170.73, 136.286)
Vpmg_setPart:  actual minima = (56.358, 27.241, 1.062)
Vpmg_setPart:  actual maxima = (198.19, 170.73, 136.286)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 66.358, 37.241, 11.062
VPMG::focusFillBound -- New mesh maxs = 188.19, 160.73, 126.286
VPMG::focusFillBound -- Old mesh mins = 56.358, 27.241, 1.062
VPMG::focusFillBound -- Old mesh maxs = 198.19, 170.73, 136.286
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.723151
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.271062e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.704500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.082080e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.096280e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.342681e-02
Vprtstp: contraction number = 8.342681e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.139418e-02
Vprtstp: contraction number = 1.365770e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.833023e-03
Vprtstp: contraction number = 1.608736e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.519353e-04
Vprtstp: contraction number = 1.919972e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.892090e-05
Vprtstp: contraction number = 1.958340e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.703446e-05
Vprtstp: contraction number = 2.471595e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.939897e-06
Vprtstp: contraction number = 2.312898e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.130077e-06
Vprtstp: contraction number = 2.868291e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.923126e-07
Vprtstp: contraction number = 2.586661e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.930548e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.380416e+00
Vpmg_setPart:  lower corner = (66.358, 37.241, 11.062)
Vpmg_setPart:  upper corner = (188.19, 160.73, 126.286)
Vpmg_setPart:  actual minima = (66.358, 37.241, 11.062)
Vpmg_setPart:  actual maxima = (188.19, 160.73, 126.286)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.921492e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:14 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5022 atoms
Valist_getStatistics:  Max atom coordinate:  (178.19, 150.73, 116.286)
Valist_getStatistics:  Min atom coordinate:  (76.358, 47.241, 21.062)
Valist_getStatistics:  Molecule center:  (127.274, 98.9855, 68.674)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.88645, 0.896806, 0.84515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.76145, 0.771806, 0.72015
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.858988, 0.860616, 0.852097 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 198.19 170.73 136.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 56.358 27.241 1.062
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 188.19 160.73 126.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 66.358 37.241 11.062
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 188.19 160.73 126.286
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 66.358 37.241 11.062
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.739151
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.211476e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.782800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.751910e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.537348e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5793044.424715
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.791400e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.102502e+05
Vprtstp: contraction number = 4.102502e+05
Vnewton: Attempting damping, relres = 0.065664
Vnewton: Attempting damping, relres = 0.527093
Vnewton: Damping accepted, relres = 0.065664
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.566406e-02
Vprtstp: contraction number = 6.566406e-02
Vnewton: Using errtol_s: 380394.797806
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.324227e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.101676e+04
Vprtstp: contraction number = 5.101676e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.051703e-03
Vprtstp: contraction number = 1.226196e-01
Vnewton: Using errtol_s: 46643.873371
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.743826e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.442270e+03
Vprtstp: contraction number = 7.442270e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.161441e-03
Vprtstp: contraction number = 1.442478e-01
Vnewton: Using errtol_s: 6728.277821
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.165403e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.207605e+03
Vprtstp: contraction number = 1.207605e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.876398e-04
Vprtstp: contraction number = 1.615578e-01
Vnewton: Using errtol_s: 1087.005747
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.585658e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.125770e+02
Vprtstp: contraction number = 2.125770e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.302581e-05
Vprtstp: contraction number = 1.760064e-01
Vnewton: Using errtol_s: 191.320009
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.011860e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.973132e+01
Vprtstp: contraction number = 3.973132e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.172611e-06
Vprtstp: contraction number = 1.869026e-01
Vnewton: Using errtol_s: 35.758212
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.435345e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.741599e+00
Vprtstp: contraction number = 7.741599e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.202725e-06
Vprtstp: contraction number = 1.948487e-01
Vnewton: Using errtol_s: 6.967440
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.858151e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.551822e+00
Vprtstp: contraction number = 1.551822e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.410890e-07
Vprtstp: contraction number = 2.004523e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.654533e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.965389e+00
Vpmg_setPart:  lower corner = (56.358, 27.241, 1.062)
Vpmg_setPart:  upper corner = (198.19, 170.73, 136.286)
Vpmg_setPart:  actual minima = (56.358, 27.241, 1.062)
Vpmg_setPart:  actual maxima = (198.19, 170.73, 136.286)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 66.358, 37.241, 11.062
VPMG::focusFillBound -- New mesh maxs = 188.19, 160.73, 126.286
VPMG::focusFillBound -- Old mesh mins = 56.358, 27.241, 1.062
VPMG::focusFillBound -- Old mesh maxs = 198.19, 170.73, 136.286
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.726783
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.278461e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.790700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.760670e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.794991e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6313252.133867
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.051485e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.293016e+05
Vprtstp: contraction number = 5.293016e+05
Vnewton: Attempting damping, relres = 0.077179
Vnewton: Attempting damping, relres = 0.533588
Vnewton: Damping accepted, relres = 0.077179
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.717886e-02
Vprtstp: contraction number = 7.717886e-02
Vnewton: Using errtol_s: 487249.631295
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.601155e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.864934e+04
Vprtstp: contraction number = 6.864934e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.902390e-03
Vprtstp: contraction number = 1.283044e-01
Vnewton: Using errtol_s: 62516.286333
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.026082e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.040735e+04
Vprtstp: contraction number = 1.040735e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.487905e-03
Vprtstp: contraction number = 1.502572e-01
Vnewton: Using errtol_s: 9393.521913
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.456104e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.742401e+03
Vprtstp: contraction number = 1.742401e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.484070e-04
Vprtstp: contraction number = 1.669508e-01
Vnewton: Using errtol_s: 1568.256176
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.890768e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.140941e+02
Vprtstp: contraction number = 3.140941e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.477650e-05
Vprtstp: contraction number = 1.802546e-01
Vnewton: Using errtol_s: 282.685318
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.325840e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.006743e+01
Vprtstp: contraction number = 6.006743e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.563052e-06
Vprtstp: contraction number = 1.912399e-01
Vnewton: Using errtol_s: 54.060708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.755462e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.205531e+01
Vprtstp: contraction number = 1.205531e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.718573e-06
Vprtstp: contraction number = 2.006963e-01
Vnewton: Using errtol_s: 10.849784
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.018501e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.508457e+00
Vprtstp: contraction number = 2.508457e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.575987e-07
Vprtstp: contraction number = 2.080789e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.727922e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.039505e+00
Vpmg_setPart:  lower corner = (66.358, 37.241, 11.062)
Vpmg_setPart:  upper corner = (188.19, 160.73, 126.286)
Vpmg_setPart:  actual minima = (66.358, 37.241, 11.062)
Vpmg_setPart:  actual maxima = (188.19, 160.73, 126.286)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.144567e+01
