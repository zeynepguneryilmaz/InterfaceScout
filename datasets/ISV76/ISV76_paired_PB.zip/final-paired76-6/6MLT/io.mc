##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9027 atoms
Valist_getStatistics:  Max atom coordinate:  (57.168, 63.229, 158.542)
Valist_getStatistics:  Min atom coordinate:  (-21.507, -1.455, 74.004)
Valist_getStatistics:  Molecule center:  (17.8305, 30.887, 116.273)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.927148, 0.817844, 0.778362
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.770898, 0.661594, 0.653362
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.831473, 0.808949, 0.839406 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 77.168 83.229 178.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -41.507 -21.455 54.004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 67.168 73.229 168.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -31.507 -11.455 64.004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 67.168 73.229 168.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -31.507 -11.455 64.004
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6242876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.287062
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.720771e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.881200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.539240e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.992122e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.606999e-02
Vprtstp: contraction number = 6.606999e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.090634e-02
Vprtstp: contraction number = 1.650725e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.907468e-03
Vprtstp: contraction number = 3.582750e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.205662e-03
Vprtstp: contraction number = 3.085532e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.001303e-04
Vprtstp: contraction number = 4.977600e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.146399e-04
Vprtstp: contraction number = 3.576555e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.097277e-04
Vprtstp: contraction number = 5.112175e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.081937e-05
Vprtstp: contraction number = 3.720062e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.069630e-05
Vprtstp: contraction number = 5.070216e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.845971e-06
Vprtstp: contraction number = 3.791001e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.943157e-06
Vprtstp: contraction number = 5.025710e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.511100e-06
Vprtstp: contraction number = 3.832207e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.545557e-07
Vprtstp: contraction number = 4.993421e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.629774e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.877866e+00
Vpmg_setPart:  lower corner = (-41.507, -21.455, 54.004)
Vpmg_setPart:  upper corner = (77.168, 83.229, 178.542)
Vpmg_setPart:  actual minima = (-41.507, -21.455, 54.004)
Vpmg_setPart:  actual maxima = (77.168, 83.229, 178.542)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6242876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -31.507, -11.455, 64.004
VPMG::focusFillBound -- New mesh maxs = 67.168, 73.229, 168.542
VPMG::focusFillBound -- Old mesh mins = -41.507, -21.455, 54.004
VPMG::focusFillBound -- Old mesh maxs = 77.168, 83.229, 178.542
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.279969
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.843105e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.827500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.518990e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.717826e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.971907e-02
Vprtstp: contraction number = 7.971907e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.208977e-02
Vprtstp: contraction number = 1.516547e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.844587e-03
Vprtstp: contraction number = 3.180033e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.175338e-03
Vprtstp: contraction number = 3.057124e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.523170e-04
Vprtstp: contraction number = 5.550039e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.554986e-04
Vprtstp: contraction number = 3.916787e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.527478e-04
Vprtstp: contraction number = 5.978418e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.412755e-05
Vprtstp: contraction number = 4.198264e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.812529e-05
Vprtstp: contraction number = 5.945229e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.653087e-05
Vprtstp: contraction number = 4.335932e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.719844e-06
Vprtstp: contraction number = 5.879815e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.293844e-06
Vprtstp: contraction number = 4.417606e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.501884e-06
Vprtstp: contraction number = 5.826675e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.118361e-06
Vprtstp: contraction number = 4.470074e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.471819e-07
Vprtstp: contraction number = 5.786880e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.840323e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.084941e+00
Vpmg_setPart:  lower corner = (-31.507, -11.455, 64.004)
Vpmg_setPart:  upper corner = (67.168, 73.229, 168.542)
Vpmg_setPart:  actual minima = (-31.507, -11.455, 64.004)
Vpmg_setPart:  actual maxima = (67.168, 73.229, 168.542)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.150155e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9027 atoms
Valist_getStatistics:  Max atom coordinate:  (57.168, 63.229, 158.542)
Valist_getStatistics:  Min atom coordinate:  (-21.507, -1.455, 74.004)
Valist_getStatistics:  Molecule center:  (17.8305, 30.887, 116.273)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.927148, 0.817844, 0.778362
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.770898, 0.661594, 0.653362
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.831473, 0.808949, 0.839406 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 77.168 83.229 178.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -41.507 -21.455 54.004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 67.168 73.229 168.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -31.507 -11.455 64.004
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 67.168 73.229 168.542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -31.507 -11.455 64.004
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6242876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.291332
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.723696e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.860700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.142410e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.951830e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 11258288.277506
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.120231e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.780261e+05
Vprtstp: contraction number = 6.780261e+05
Vnewton: Attempting damping, relres = 0.079725
Vnewton: Attempting damping, relres = 0.523071
Vnewton: Damping accepted, relres = 0.079725
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.972496e-02
Vprtstp: contraction number = 7.972496e-02
Vnewton: Using errtol_s: 897566.627467
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.456385e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.636908e+04
Vprtstp: contraction number = 9.636908e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.504609e-02
Vprtstp: contraction number = 1.887249e-01
Vnewton: Using errtol_s: 169393.214326
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.720459e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.098769e+04
Vprtstp: contraction number = 2.098769e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.852273e-03
Vprtstp: contraction number = 2.560315e-01
Vnewton: Using errtol_s: 43370.002251
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.981160e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.077155e+03
Vprtstp: contraction number = 6.077155e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.121234e-03
Vprtstp: contraction number = 2.910578e-01
Vnewton: Using errtol_s: 12623.177888
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.244427e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.934410e+03
Vprtstp: contraction number = 1.934410e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.981321e-04
Vprtstp: contraction number = 2.658964e-01
Vnewton: Using errtol_s: 3356.457419
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.505224e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.823264e+02
Vprtstp: contraction number = 5.823264e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.120169e-05
Vprtstp: contraction number = 2.052838e-01
Vnewton: Using errtol_s: 689.026236
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.766748e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.340922e+02
Vprtstp: contraction number = 1.340922e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.098791e-05
Vprtstp: contraction number = 1.795360e-01
Vnewton: Using errtol_s: 123.705007
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.028400e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.713465e+01
Vprtstp: contraction number = 2.713465e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.169777e-06
Vprtstp: contraction number = 1.974696e-01
Vnewton: Using errtol_s: 24.427976
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.294139e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.750831e+00
Vprtstp: contraction number = 5.750831e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.597297e-07
Vprtstp: contraction number = 2.118788e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.543721e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.748013e+00
Vpmg_setPart:  lower corner = (-41.507, -21.455, 54.004)
Vpmg_setPart:  upper corner = (77.168, 83.229, 178.542)
Vpmg_setPart:  actual minima = (-41.507, -21.455, 54.004)
Vpmg_setPart:  actual maxima = (77.168, 83.229, 178.542)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -18
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6242876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -31.507, -11.455, 64.004
VPMG::focusFillBound -- New mesh maxs = 67.168, 73.229, 168.542
VPMG::focusFillBound -- Old mesh mins = -41.507, -21.455, 54.004
VPMG::focusFillBound -- Old mesh maxs = 77.168, 83.229, 178.542
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.286992
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.853030e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.604600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.134740e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.557174e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12742818.709587
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.725649e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.929236e+05
Vprtstp: contraction number = 9.929236e+05
Vnewton: Attempting damping, relres = 0.089884
Vnewton: Attempting damping, relres = 0.531793
Vnewton: Damping accepted, relres = 0.089884
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.988374e-02
Vprtstp: contraction number = 8.988374e-02
Vnewton: Using errtol_s: 1145372.183693
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.062711e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.398462e+05
Vprtstp: contraction number = 1.398462e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.534786e-02
Vprtstp: contraction number = 1.707523e-01
Vnewton: Using errtol_s: 195574.955635
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.326666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.706315e+04
Vprtstp: contraction number = 2.706315e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.504128e-03
Vprtstp: contraction number = 2.283138e-01
Vnewton: Using errtol_s: 44652.466314
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.589249e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.657667e+03
Vprtstp: contraction number = 6.657667e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.168247e-04
Vprtstp: contraction number = 2.616413e-01
Vnewton: Using errtol_s: 11682.931166
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.843606e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.968126e+03
Vprtstp: contraction number = 1.968126e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.242077e-04
Vprtstp: contraction number = 2.445481e-01
Vnewton: Using errtol_s: 2857.038648
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.102148e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.623468e+02
Vprtstp: contraction number = 5.623468e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.549703e-05
Vprtstp: contraction number = 2.029235e-01
Vnewton: Using errtol_s: 579.760418
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.360405e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.294226e+02
Vprtstp: contraction number = 1.294226e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.201846e-06
Vprtstp: contraction number = 2.022516e-01
Vnewton: Using errtol_s: 117.257449
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.618623e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.009937e+01
Vprtstp: contraction number = 3.009937e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.126013e-06
Vprtstp: contraction number = 2.310420e-01
Vnewton: Using errtol_s: 27.091396
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.876964e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.527726e+00
Vprtstp: contraction number = 7.527726e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.316685e-07
Vprtstp: contraction number = 2.500778e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.519112e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.718524e+00
Vpmg_setPart:  lower corner = (-31.507, -11.455, 64.004)
Vpmg_setPart:  upper corner = (67.168, 73.229, 168.542)
Vpmg_setPart:  actual minima = (-31.507, -11.455, 64.004)
Vpmg_setPart:  actual maxima = (67.168, 73.229, 168.542)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.683185e+00
