##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:55 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (52.53, 57.314, 88.942)
Valist_getStatistics:  Min atom coordinate:  (1.051, 21.809, 33.755)
Valist_getStatistics:  Molecule center:  (26.7905, 39.5615, 61.3485)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.952906, 0.78651, 0.991531
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.744573, 0.578177, 0.783198
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.781371, 0.735117, 0.789887 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 72.53 77.314 108.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -18.949 1.809 13.755
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 62.53 67.314 98.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -8.949 11.809 23.755
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 62.53 67.314 98.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -8.949 11.809 23.755
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.275760
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.450650e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.860400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.217000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.261800e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.293311e-02
Vprtstp: contraction number = 6.293311e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.502891e-03
Vprtstp: contraction number = 1.351100e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.424400e-03
Vprtstp: contraction number = 1.675195e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.574383e-04
Vprtstp: contraction number = 1.807346e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.108185e-05
Vprtstp: contraction number = 1.984236e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.972233e-06
Vprtstp: contraction number = 1.952207e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.134044e-06
Vprtstp: contraction number = 2.139986e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.341060e-07
Vprtstp: contraction number = 2.034194e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.657650e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.371660e-01
Vpmg_setPart:  lower corner = (-18.949, 1.809, 13.755)
Vpmg_setPart:  upper corner = (72.53, 77.314, 108.942)
Vpmg_setPart:  actual minima = (-18.949, 1.809, 13.755)
Vpmg_setPart:  actual maxima = (72.53, 77.314, 108.942)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -8.949, 11.809, 23.755
VPMG::focusFillBound -- New mesh maxs = 62.53, 67.314, 98.942
VPMG::focusFillBound -- Old mesh mins = -18.949, 1.809, 13.755
VPMG::focusFillBound -- Old mesh maxs = 72.53, 77.314, 108.942
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.276984
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.059770e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.875600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.095100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.370704e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.841358e-02
Vprtstp: contraction number = 8.841358e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.322655e-02
Vprtstp: contraction number = 1.495986e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.377038e-03
Vprtstp: contraction number = 1.797172e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.716365e-04
Vprtstp: contraction number = 1.984135e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.854336e-05
Vprtstp: contraction number = 2.089392e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.149534e-05
Vprtstp: contraction number = 2.181308e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.833237e-06
Vprtstp: contraction number = 2.248505e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.104670e-06
Vprtstp: contraction number = 2.285570e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.804859e-07
Vprtstp: contraction number = 2.539091e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.998960e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.703190e-01
Vpmg_setPart:  lower corner = (-8.949, 11.809, 23.755)
Vpmg_setPart:  upper corner = (62.53, 67.314, 98.942)
Vpmg_setPart:  actual minima = (-8.949, 11.809, 23.755)
Vpmg_setPart:  actual maxima = (62.53, 67.314, 98.942)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.858662e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:58 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (52.53, 57.314, 88.942)
Valist_getStatistics:  Min atom coordinate:  (1.051, 21.809, 33.755)
Valist_getStatistics:  Molecule center:  (26.7905, 39.5615, 61.3485)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.952906, 0.78651, 0.991531
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.744573, 0.578177, 0.783198
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.781371, 0.735117, 0.789887 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 72.53 77.314 108.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -18.949 1.809 13.755
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 62.53 67.314 98.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -8.949 11.809 23.755
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 62.53 67.314 98.942
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -8.949 11.809 23.755
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.278260
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.483770e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.880000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.851900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.249270e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2710934.560086
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.787510e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.751228e+05
Vprtstp: contraction number = 1.751228e+05
Vnewton: Attempting damping, relres = 0.064580
Vnewton: Attempting damping, relres = 0.523548
Vnewton: Damping accepted, relres = 0.064580
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.458027e-02
Vprtstp: contraction number = 6.458027e-02
Vnewton: Using errtol_s: 175072.889011
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.799880e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.502349e+04
Vprtstp: contraction number = 2.502349e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.362136e-03
Vprtstp: contraction number = 1.449690e-01
Vnewton: Using errtol_s: 25380.137045
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.559850e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.458275e+03
Vprtstp: contraction number = 4.458275e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.667697e-03
Vprtstp: contraction number = 1.781321e-01
Vnewton: Using errtol_s: 4521.016764
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.316710e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.782021e+02
Vprtstp: contraction number = 8.782021e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.109393e-04
Vprtstp: contraction number = 1.864483e-01
Vnewton: Using errtol_s: 842.936020
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.079720e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.725789e+02
Vprtstp: contraction number = 1.725789e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.788665e-05
Vprtstp: contraction number = 1.861671e-01
Vnewton: Using errtol_s: 156.926919
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.837420e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.342011e+01
Vprtstp: contraction number = 3.342011e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.110225e-05
Vprtstp: contraction number = 1.917929e-01
Vnewton: Using errtol_s: 30.097466
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.060097e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.711012e+00
Vprtstp: contraction number = 6.711012e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.228083e-06
Vprtstp: contraction number = 2.006876e-01
Vnewton: Using errtol_s: 6.040188
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.136852e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.397260e+00
Vprtstp: contraction number = 1.397260e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.638768e-07
Vprtstp: contraction number = 2.081954e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.694980e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.367450e-01
Vpmg_setPart:  lower corner = (-18.949, 1.809, 13.755)
Vpmg_setPart:  upper corner = (72.53, 77.314, 108.942)
Vpmg_setPart:  actual minima = (-18.949, 1.809, 13.755)
Vpmg_setPart:  actual maxima = (72.53, 77.314, 108.942)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -8.949, 11.809, 23.755
VPMG::focusFillBound -- New mesh maxs = 62.53, 67.314, 98.942
VPMG::focusFillBound -- Old mesh mins = -18.949, 1.809, 13.755
VPMG::focusFillBound -- Old mesh maxs = 72.53, 77.314, 108.942
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.276630
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.076670e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.900600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.816300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.771102e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3432272.488689
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.823301e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.264508e+05
Vprtstp: contraction number = 3.264508e+05
Vnewton: Attempting damping, relres = 0.089850
Vnewton: Attempting damping, relres = 0.538561
Vnewton: Damping accepted, relres = 0.089850
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.984960e-02
Vprtstp: contraction number = 8.984960e-02
Vnewton: Using errtol_s: 308388.326866
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.922573e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.947741e+04
Vprtstp: contraction number = 4.947741e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.356596e-02
Vprtstp: contraction number = 1.509851e-01
Vnewton: Using errtol_s: 46562.055887
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.996979e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.874141e+03
Vprtstp: contraction number = 8.874141e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.410938e-03
Vprtstp: contraction number = 1.777197e-01
Vnewton: Using errtol_s: 8274.995789
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.070613e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.706022e+03
Vprtstp: contraction number = 1.706022e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.528784e-04
Vprtstp: contraction number = 1.878433e-01
Vnewton: Using errtol_s: 1554.402136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.144400e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.363109e+02
Vprtstp: contraction number = 3.363109e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.826027e-05
Vprtstp: contraction number = 1.948873e-01
Vnewton: Using errtol_s: 302.933293
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.217039e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.846404e+01
Vprtstp: contraction number = 6.846404e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.795288e-05
Vprtstp: contraction number = 2.034084e-01
Vnewton: Using errtol_s: 61.619190
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.288875e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.447569e+01
Vprtstp: contraction number = 1.447569e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.795775e-06
Vprtstp: contraction number = 2.114298e-01
Vnewton: Using errtol_s: 13.028134
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.364259e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.173950e+00
Vprtstp: contraction number = 3.173950e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.322637e-07
Vprtstp: contraction number = 2.192605e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.494820e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.163360e-01
Vpmg_setPart:  lower corner = (-8.949, 11.809, 23.755)
Vpmg_setPart:  upper corner = (62.53, 67.314, 98.942)
Vpmg_setPart:  actual minima = (-8.949, 11.809, 23.755)
Vpmg_setPart:  actual maxima = (62.53, 67.314, 98.942)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.609460e+00
