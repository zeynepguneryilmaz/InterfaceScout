##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:29 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3240 atoms
Valist_getStatistics:  Max atom coordinate:  (48.922, 99.072, 37.738)
Valist_getStatistics:  Min atom coordinate:  (13.821, 45.616, -7.69)
Valist_getStatistics:  Molecule center:  (31.3715, 72.344, 15.024)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.782302, 0.9735, 0.889875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.573969, 0.765167, 0.681542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.733692, 0.785996, 0.765885 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 68.922 119.072 57.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -6.179 25.616 -27.69
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.922 109.072 47.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 3.821 35.616 -17.69
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.922 109.072 47.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 3.821 35.616 -17.69
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.406214
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.056690e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.927400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.087800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.885930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.618396e-02
Vprtstp: contraction number = 5.618396e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.697456e-03
Vprtstp: contraction number = 1.370045e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.732089e-03
Vprtstp: contraction number = 2.250210e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.670042e-04
Vprtstp: contraction number = 2.696190e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.452134e-04
Vprtstp: contraction number = 3.109466e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.395155e-05
Vprtstp: contraction number = 3.026687e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.531735e-05
Vprtstp: contraction number = 3.485053e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.840482e-06
Vprtstp: contraction number = 3.160130e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.734742e-06
Vprtstp: contraction number = 3.583821e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.539863e-07
Vprtstp: contraction number = 3.193479e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.157970e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.874170e-01
Vpmg_setPart:  lower corner = (-6.179, 25.616, -27.69)
Vpmg_setPart:  upper corner = (68.922, 119.072, 57.738)
Vpmg_setPart:  actual minima = (-6.179, 25.616, -27.69)
Vpmg_setPart:  actual maxima = (68.922, 119.072, 57.738)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 3.821, 35.616, -17.69
VPMG::focusFillBound -- New mesh maxs = 58.922, 109.072, 47.738
VPMG::focusFillBound -- Old mesh mins = -6.179, 25.616, -27.69
VPMG::focusFillBound -- Old mesh maxs = 68.922, 119.072, 57.738
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.404720
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.757000e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.865200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.157500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.754186e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.136303e-02
Vprtstp: contraction number = 8.136303e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.180619e-02
Vprtstp: contraction number = 1.451051e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.499163e-03
Vprtstp: contraction number = 2.116824e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.816068e-04
Vprtstp: contraction number = 2.727341e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.305220e-04
Vprtstp: contraction number = 3.382038e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.163520e-05
Vprtstp: contraction number = 3.541319e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.449990e-05
Vprtstp: contraction number = 4.226105e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.301289e-05
Vprtstp: contraction number = 3.771864e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.774440e-06
Vprtstp: contraction number = 4.437476e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.189025e-06
Vprtstp: contraction number = 3.790886e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.820844e-07
Vprtstp: contraction number = 4.486401e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.588770e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.306420e-01
Vpmg_setPart:  lower corner = (3.821, 35.616, -17.69)
Vpmg_setPart:  upper corner = (58.922, 109.072, 47.738)
Vpmg_setPart:  actual minima = (3.821, 35.616, -17.69)
Vpmg_setPart:  actual maxima = (58.922, 109.072, 47.738)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.299444e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:32 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3240 atoms
Valist_getStatistics:  Max atom coordinate:  (48.922, 99.072, 37.738)
Valist_getStatistics:  Min atom coordinate:  (13.821, 45.616, -7.69)
Valist_getStatistics:  Molecule center:  (31.3715, 72.344, 15.024)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.782302, 0.9735, 0.889875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.573969, 0.765167, 0.681542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.733692, 0.785996, 0.765885 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 68.922 119.072 57.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -6.179 25.616 -27.69
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.922 109.072 47.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 3.821 35.616 -17.69
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.922 109.072 47.738
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 3.821 35.616 -17.69
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.401205
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.975970e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.063500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.003800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.799830e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3676418.142435
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.321300e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.055617e+05
Vprtstp: contraction number = 2.055617e+05
Vnewton: Attempting damping, relres = 0.051378
Vnewton: Attempting damping, relres = 0.520172
Vnewton: Damping accepted, relres = 0.051378
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.137772e-02
Vprtstp: contraction number = 5.137772e-02
Vnewton: Using errtol_s: 188885.979726
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.316960e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.643039e+04
Vprtstp: contraction number = 2.643039e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.483326e-03
Vprtstp: contraction number = 1.261895e-01
Vnewton: Using errtol_s: 23835.418747
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.068310e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.182535e+03
Vprtstp: contraction number = 4.182535e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.023959e-03
Vprtstp: contraction number = 1.579374e-01
Vnewton: Using errtol_s: 3764.503034
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.803180e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.367993e+02
Vprtstp: contraction number = 7.367993e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.803736e-04
Vprtstp: contraction number = 1.761531e-01
Vnewton: Using errtol_s: 663.128708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.052913e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.418266e+02
Vprtstp: contraction number = 1.418266e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.471978e-05
Vprtstp: contraction number = 1.924882e-01
Vnewton: Using errtol_s: 127.644434
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.124291e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.099765e+01
Vprtstp: contraction number = 3.099765e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.588342e-06
Vprtstp: contraction number = 2.185596e-01
Vnewton: Using errtol_s: 27.897918
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.197816e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.634741e+00
Vprtstp: contraction number = 7.634741e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.869012e-06
Vprtstp: contraction number = 2.463005e-01
Vnewton: Using errtol_s: 6.871270
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.268327e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.986188e+00
Vprtstp: contraction number = 1.986188e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.862259e-07
Vprtstp: contraction number = 2.601513e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.413530e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.125880e-01
Vpmg_setPart:  lower corner = (-6.179, 25.616, -27.69)
Vpmg_setPart:  upper corner = (68.922, 119.072, 57.738)
Vpmg_setPart:  actual minima = (-6.179, 25.616, -27.69)
Vpmg_setPart:  actual maxima = (68.922, 119.072, 57.738)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 3.821, 35.616, -17.69
VPMG::focusFillBound -- New mesh maxs = 58.922, 109.072, 47.738
VPMG::focusFillBound -- Old mesh mins = -6.179, 25.616, -27.69
VPMG::focusFillBound -- Old mesh maxs = 68.922, 119.072, 57.738
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.400217
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.707600e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.915100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.984500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.063329e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4627811.689810
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.115281e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.005482e+05
Vprtstp: contraction number = 4.005482e+05
Vnewton: Attempting damping, relres = 0.078719
Vnewton: Attempting damping, relres = 0.535397
Vnewton: Damping accepted, relres = 0.078719
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.871925e-02
Vprtstp: contraction number = 7.871925e-02
Vnewton: Using errtol_s: 364297.862428
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.217923e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.566326e+04
Vprtstp: contraction number = 5.566326e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.083529e-02
Vprtstp: contraction number = 1.376447e-01
Vnewton: Using errtol_s: 50143.674173
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.294666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.212211e+03
Vprtstp: contraction number = 9.212211e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.791606e-03
Vprtstp: contraction number = 1.653491e-01
Vnewton: Using errtol_s: 8291.213866
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.371925e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.666825e+03
Vprtstp: contraction number = 1.666825e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.241608e-04
Vprtstp: contraction number = 1.809331e-01
Vnewton: Using errtol_s: 1500.154992
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.449578e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.174851e+02
Vprtstp: contraction number = 3.174851e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.174353e-05
Vprtstp: contraction number = 1.904719e-01
Vnewton: Using errtol_s: 285.737412
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.527541e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.790912e+01
Vprtstp: contraction number = 6.790912e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.320673e-05
Vprtstp: contraction number = 2.138966e-01
Vnewton: Using errtol_s: 61.118275
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.603498e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.692285e+01
Vprtstp: contraction number = 1.692285e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.291099e-06
Vprtstp: contraction number = 2.491986e-01
Vnewton: Using errtol_s: 15.230586
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.679791e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.560870e+00
Vprtstp: contraction number = 4.560870e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.869815e-07
Vprtstp: contraction number = 2.695092e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.734810e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.424830e-01
Vpmg_setPart:  lower corner = (3.821, 35.616, -17.69)
Vpmg_setPart:  upper corner = (58.922, 109.072, 47.738)
Vpmg_setPart:  actual minima = (3.821, 35.616, -17.69)
Vpmg_setPart:  actual maxima = (58.922, 109.072, 47.738)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.931127e+00
