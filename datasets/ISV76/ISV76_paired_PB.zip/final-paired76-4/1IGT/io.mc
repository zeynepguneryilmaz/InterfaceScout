##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:00 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 225, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20149 atoms
Valist_getStatistics:  Max atom coordinate:  (51.224, 57.144, 74.381)
Valist_getStatistics:  Min atom coordinate:  (-54.335, -90.406, -56.357)
Valist_getStatistics:  Molecule center:  (-1.5555, -16.631, 9.012)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.909744, 0.837277, 0.88926
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.784744, 0.747991, 0.785094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.862599, 0.893362, 0.882861 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 71.224 77.144 94.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -74.335 -110.406 -76.357
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 61.224 67.144 84.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -64.335 -100.406 -66.357
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 61.224 67.144 84.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -64.335 -100.406 -66.357
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105852 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.429287
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.474447e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.446340e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 113, 097)
Vbuildops: Galer: (041, 057, 049)
Vbuildops: Galer: (021, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.651910e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.519885e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.967105e-02
Vprtstp: contraction number = 5.967105e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.307271e-03
Vprtstp: contraction number = 1.392178e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.369695e-03
Vprtstp: contraction number = 1.648791e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.597322e-04
Vprtstp: contraction number = 2.626367e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.101077e-04
Vprtstp: contraction number = 3.060825e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.954221e-05
Vprtstp: contraction number = 3.591229e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.387670e-05
Vprtstp: contraction number = 3.509339e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.527902e-06
Vprtstp: contraction number = 3.983586e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.010581e-06
Vprtstp: contraction number = 3.637150e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.244451e-07
Vprtstp: contraction number = 4.100532e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.100457e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.099074e+00
Vpmg_setPart:  lower corner = (-74.335, -110.406, -76.357)
Vpmg_setPart:  upper corner = (71.224, 77.144, 94.381)
Vpmg_setPart:  actual minima = (-74.335, -110.406, -76.357)
Vpmg_setPart:  actual maxima = (71.224, 77.144, 94.381)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105852 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -64.335, -100.406, -66.357
VPMG::focusFillBound -- New mesh maxs = 61.224, 67.144, 84.381
VPMG::focusFillBound -- Old mesh mins = -74.335, -110.406, -76.357
VPMG::focusFillBound -- Old mesh maxs = 71.224, 77.144, 94.381
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.422444
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.661774e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.454240e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 113, 097)
Vbuildops: Galer: (041, 057, 049)
Vbuildops: Galer: (021, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.626290e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.531485e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.856634e-02
Vprtstp: contraction number = 6.856634e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.689903e-03
Vprtstp: contraction number = 1.413216e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.683451e-03
Vprtstp: contraction number = 1.737325e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.711747e-04
Vprtstp: contraction number = 2.798862e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.493567e-04
Vprtstp: contraction number = 3.169880e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.034383e-05
Vprtstp: contraction number = 4.040248e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.352426e-05
Vprtstp: contraction number = 3.898371e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.063526e-05
Vprtstp: contraction number = 4.520977e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.268589e-06
Vprtstp: contraction number = 4.013618e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.983595e-06
Vprtstp: contraction number = 4.646958e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.984526e-07
Vprtstp: contraction number = 4.025280e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.534953e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.532667e+00
Vpmg_setPart:  lower corner = (-64.335, -100.406, -66.357)
Vpmg_setPart:  upper corner = (61.224, 67.144, 84.381)
Vpmg_setPart:  actual minima = (-64.335, -100.406, -66.357)
Vpmg_setPart:  actual maxima = (61.224, 67.144, 84.381)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.149617e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:27 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 225, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20149 atoms
Valist_getStatistics:  Max atom coordinate:  (51.224, 57.144, 74.381)
Valist_getStatistics:  Min atom coordinate:  (-54.335, -90.406, -56.357)
Valist_getStatistics:  Molecule center:  (-1.5555, -16.631, 9.012)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.909744, 0.837277, 0.88926
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.784744, 0.747991, 0.785094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.862599, 0.893362, 0.882861 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 71.224 77.144 94.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -74.335 -110.406 -76.357
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 61.224 67.144 84.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -64.335 -100.406 -66.357
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 61.224 67.144 84.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -64.335 -100.406 -66.357
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105852 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.433656
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.480008e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.454950e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 113, 097)
Vbuildops: Galer: (041, 057, 049)
Vbuildops: Galer: (021, 029, 025)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.359370e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.085590e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 22699391.035334
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.508034e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.373028e+06
Vprtstp: contraction number = 1.373028e+06
Vnewton: Attempting damping, relres = 0.055613
Vnewton: Attempting damping, relres = 0.522322
Vnewton: Damping accepted, relres = 0.055613
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.561261e-02
Vprtstp: contraction number = 5.561261e-02
Vnewton: Using errtol_s: 1262372.435609
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.477619e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.692326e+05
Vprtstp: contraction number = 1.692326e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.768667e-03
Vprtstp: contraction number = 1.217110e-01
Vnewton: Using errtol_s: 153644.613784
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.236140e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.493438e+04
Vprtstp: contraction number = 2.493438e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.922037e-04
Vprtstp: contraction number = 1.465878e-01
Vnewton: Using errtol_s: 22522.419147
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.996785e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.060521e+03
Vprtstp: contraction number = 4.060521e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.610176e-04
Vprtstp: contraction number = 1.622828e-01
Vnewton: Using errtol_s: 3655.000366
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.759615e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.048963e+02
Vprtstp: contraction number = 7.048963e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.794828e-05
Vprtstp: contraction number = 1.735729e-01
Vnewton: Using errtol_s: 634.408856
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.528424e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.345949e+02
Vprtstp: contraction number = 1.345949e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.336508e-06
Vprtstp: contraction number = 1.909423e-01
Vnewton: Using errtol_s: 121.135485
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.030340e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.003526e+01
Vprtstp: contraction number = 3.003526e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.190858e-06
Vprtstp: contraction number = 2.231530e-01
Vnewton: Using errtol_s: 27.031749
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.109758e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.628228e+00
Vprtstp: contraction number = 7.628228e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.024489e-07
Vprtstp: contraction number = 2.539757e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.618201e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.177296e+00
Vpmg_setPart:  lower corner = (-74.335, -110.406, -76.357)
Vpmg_setPart:  upper corner = (71.224, 77.144, 94.381)
Vpmg_setPart:  actual minima = (-74.335, -110.406, -76.357)
Vpmg_setPart:  actual maxima = (71.224, 77.144, 94.381)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105852 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -64.335, -100.406, -66.357
VPMG::focusFillBound -- New mesh maxs = 61.224, 67.144, 84.381
VPMG::focusFillBound -- Old mesh mins = -74.335, -110.406, -76.357
VPMG::focusFillBound -- Old mesh maxs = 71.224, 77.144, 94.381
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.420228
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.667704e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.459220e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 113, 097)
Vbuildops: Galer: (041, 057, 049)
Vbuildops: Galer: (021, 029, 025)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.198090e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.695055e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 25096623.851611
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.737503e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.764639e+06
Vprtstp: contraction number = 1.764639e+06
Vnewton: Attempting damping, relres = 0.064294
Vnewton: Attempting damping, relres = 0.527395
Vnewton: Damping accepted, relres = 0.064294
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.429435e-02
Vprtstp: contraction number = 6.429435e-02
Vnewton: Using errtol_s: 1613571.225537
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.836392e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.194646e+05
Vprtstp: contraction number = 2.194646e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.922179e-03
Vprtstp: contraction number = 1.232173e-01
Vnewton: Using errtol_s: 198819.953764
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.914237e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.218433e+04
Vprtstp: contraction number = 3.218433e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.157000e-03
Vprtstp: contraction number = 1.460457e-01
Vnewton: Using errtol_s: 29036.797015
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.991074e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.168433e+03
Vprtstp: contraction number = 5.168433e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.853588e-04
Vprtstp: contraction number = 1.602064e-01
Vnewton: Using errtol_s: 4651.880361
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.067966e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.748608e+02
Vprtstp: contraction number = 8.748608e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.137387e-05
Vprtstp: contraction number = 1.692602e-01
Vnewton: Using errtol_s: 787.378233
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.144739e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.616310e+02
Vprtstp: contraction number = 1.616310e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.796318e-06
Vprtstp: contraction number = 1.847499e-01
Vnewton: Using errtol_s: 145.468021
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.222509e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.558475e+01
Vprtstp: contraction number = 3.558475e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.276120e-06
Vprtstp: contraction number = 2.201604e-01
Vnewton: Using errtol_s: 32.026296
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.300127e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.013767e+00
Vprtstp: contraction number = 9.013767e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.232463e-07
Vprtstp: contraction number = 2.533041e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.656732e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.200866e+00
Vpmg_setPart:  lower corner = (-64.335, -100.406, -66.357)
Vpmg_setPart:  upper corner = (61.224, 67.144, 84.381)
Vpmg_setPart:  actual minima = (-64.335, -100.406, -66.357)
Vpmg_setPart:  actual maxima = (61.224, 67.144, 84.381)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.525152e+01
