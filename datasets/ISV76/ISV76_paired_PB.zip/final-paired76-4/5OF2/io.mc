##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:59 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2946 atoms
Valist_getStatistics:  Max atom coordinate:  (9.444, 13.862, 14.228)
Valist_getStatistics:  Min atom coordinate:  (-31.035, -21.111, -56.717)
Valist_getStatistics:  Molecule center:  (-10.7955, -3.6245, -21.2445)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.838323, 0.780969, 0.866758
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.62999, 0.572635, 0.710508
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.751488, 0.733237, 0.81973 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 29.444 33.862 34.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -51.035 -41.111 -76.717
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 19.444 23.862 24.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -41.035 -31.111 -66.717
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 19.444 23.862 24.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -41.035 -31.111 -66.717
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.363605
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.976180e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.776000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.775900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.091530e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.975802e-02
Vprtstp: contraction number = 6.975802e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.527990e-03
Vprtstp: contraction number = 1.222510e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.547659e-03
Vprtstp: contraction number = 1.814800e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.869782e-04
Vprtstp: contraction number = 1.854273e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.992255e-05
Vprtstp: contraction number = 2.436511e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.523730e-05
Vprtstp: contraction number = 2.179169e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.239079e-06
Vprtstp: contraction number = 2.782040e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.187062e-06
Vprtstp: contraction number = 2.800282e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.754414e-07
Vprtstp: contraction number = 3.162779e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.429350e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.439180e-01
Vpmg_setPart:  lower corner = (-51.035, -41.111, -76.717)
Vpmg_setPart:  upper corner = (29.444, 33.862, 34.228)
Vpmg_setPart:  actual minima = (-51.035, -41.111, -76.717)
Vpmg_setPart:  actual maxima = (29.444, 33.862, 34.228)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -41.035, -31.111, -66.717
VPMG::focusFillBound -- New mesh maxs = 19.444, 23.862, 24.228
VPMG::focusFillBound -- Old mesh mins = -51.035, -41.111, -76.717
VPMG::focusFillBound -- Old mesh maxs = 29.444, 33.862, 34.228
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.362909
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.873090e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.619500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.877500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.943045e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.967362e-02
Vprtstp: contraction number = 9.967362e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.396924e-02
Vprtstp: contraction number = 1.401498e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.536648e-03
Vprtstp: contraction number = 1.815881e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.128125e-04
Vprtstp: contraction number = 2.021615e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.297350e-04
Vprtstp: contraction number = 2.529872e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.155683e-05
Vprtstp: contraction number = 2.432407e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.012745e-05
Vprtstp: contraction number = 3.209274e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.962163e-06
Vprtstp: contraction number = 2.924885e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.124521e-06
Vprtstp: contraction number = 3.796285e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.773741e-07
Vprtstp: contraction number = 3.355864e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.996710e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.000600e-01
Vpmg_setPart:  lower corner = (-41.035, -31.111, -66.717)
Vpmg_setPart:  upper corner = (19.444, 23.862, 24.228)
Vpmg_setPart:  actual minima = (-41.035, -31.111, -66.717)
Vpmg_setPart:  actual maxima = (19.444, 23.862, 24.228)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.703245e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:27:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2946 atoms
Valist_getStatistics:  Max atom coordinate:  (9.444, 13.862, 14.228)
Valist_getStatistics:  Min atom coordinate:  (-31.035, -21.111, -56.717)
Valist_getStatistics:  Molecule center:  (-10.7955, -3.6245, -21.2445)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.838323, 0.780969, 0.866758
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.62999, 0.572635, 0.710508
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.751488, 0.733237, 0.81973 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 29.444 33.862 34.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -51.035 -41.111 -76.717
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 19.444 23.862 24.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -41.035 -31.111 -66.717
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 19.444 23.862 24.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -41.035 -31.111 -66.717
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.362401
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.003840e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.628500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.127600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.024160e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3569413.328419
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.784640e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.476945e+05
Vprtstp: contraction number = 2.476945e+05
Vnewton: Attempting damping, relres = 0.066585
Vnewton: Attempting damping, relres = 0.526550
Vnewton: Damping accepted, relres = 0.066585
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.658530e-02
Vprtstp: contraction number = 6.658530e-02
Vnewton: Using errtol_s: 237670.443318
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.243840e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.085369e+04
Vprtstp: contraction number = 3.085369e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.257996e-03
Vprtstp: contraction number = 1.240213e-01
Vnewton: Using errtol_s: 29476.200364
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.036695e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.642198e+03
Vprtstp: contraction number = 4.642198e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.201945e-03
Vprtstp: contraction number = 1.455492e-01
Vnewton: Using errtol_s: 4290.237355
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.149159e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.932727e+02
Vprtstp: contraction number = 7.932727e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.004468e-04
Vprtstp: contraction number = 1.667688e-01
Vnewton: Using errtol_s: 715.477643
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.259409e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.502532e+02
Vprtstp: contraction number = 1.502532e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.788584e-05
Vprtstp: contraction number = 1.890069e-01
Vnewton: Using errtol_s: 135.230240
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.370803e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.062795e+01
Vprtstp: contraction number = 3.062795e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.722609e-06
Vprtstp: contraction number = 2.038389e-01
Vnewton: Using errtol_s: 27.565185
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.482944e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.630365e+00
Vprtstp: contraction number = 6.630365e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.671795e-06
Vprtstp: contraction number = 2.164806e-01
Vnewton: Using errtol_s: 5.967329
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.594518e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.572459e+00
Vprtstp: contraction number = 1.572459e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.964833e-07
Vprtstp: contraction number = 2.371602e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.777140e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.069035e+00
Vpmg_setPart:  lower corner = (-51.035, -41.111, -76.717)
Vpmg_setPart:  upper corner = (29.444, 33.862, 34.228)
Vpmg_setPart:  actual minima = (-51.035, -41.111, -76.717)
Vpmg_setPart:  actual maxima = (29.444, 33.862, 34.228)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -41.035, -31.111, -66.717
VPMG::focusFillBound -- New mesh maxs = 19.444, 23.862, 24.228
VPMG::focusFillBound -- Old mesh mins = -51.035, -41.111, -76.717
VPMG::focusFillBound -- Old mesh maxs = 29.444, 33.862, 34.228
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.359777
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.844410e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.711300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.296700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.461983e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4272498.258509
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.537521e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.537843e+05
Vprtstp: contraction number = 4.537843e+05
Vnewton: Attempting damping, relres = 0.098645
Vnewton: Attempting damping, relres = 0.544373
Vnewton: Damping accepted, relres = 0.098645
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.864524e-02
Vprtstp: contraction number = 9.864524e-02
Vnewton: Using errtol_s: 421461.635703
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.684171e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.396312e+04
Vprtstp: contraction number = 6.396312e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.378748e-02
Vprtstp: contraction number = 1.397683e-01
Vnewton: Using errtol_s: 58906.985359
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.794811e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.048829e+04
Vprtstp: contraction number = 1.048829e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.223500e-03
Vprtstp: contraction number = 1.612695e-01
Vnewton: Using errtol_s: 9499.899352
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.904979e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.870067e+03
Vprtstp: contraction number = 1.870067e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.939695e-04
Vprtstp: contraction number = 1.771844e-01
Vnewton: Using errtol_s: 1683.233889
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.015181e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.553546e+02
Vprtstp: contraction number = 3.553546e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.485541e-05
Vprtstp: contraction number = 1.900031e-01
Vnewton: Using errtol_s: 319.819612
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.126574e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.110772e+01
Vprtstp: contraction number = 7.110772e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.497882e-05
Vprtstp: contraction number = 2.001033e-01
Vnewton: Using errtol_s: 63.996967
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.237733e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.480287e+01
Vprtstp: contraction number = 1.480287e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.118219e-06
Vprtstp: contraction number = 2.081752e-01
Vnewton: Using errtol_s: 13.322583
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.349518e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.136528e+00
Vprtstp: contraction number = 3.136528e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.607084e-07
Vprtstp: contraction number = 2.118865e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.715240e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.065695e+00
Vpmg_setPart:  lower corner = (-41.035, -31.111, -66.717)
Vpmg_setPart:  upper corner = (19.444, 23.862, 24.228)
Vpmg_setPart:  actual minima = (-41.035, -31.111, -66.717)
Vpmg_setPart:  actual maxima = (19.444, 23.862, 24.228)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.692743e+00
