##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:51 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3606 atoms
Valist_getStatistics:  Max atom coordinate:  (34.682, 90.446, 8.189)
Valist_getStatistics:  Min atom coordinate:  (-17.88, 48.793, -28.523)
Valist_getStatistics:  Molecule center:  (8.401, 69.6195, -10.167)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.964187, 0.850552, 0.799083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.755854, 0.642219, 0.59075
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.783929, 0.755061, 0.739285 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.682 110.446 28.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -37.88 28.793 -48.523
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.682 100.446 18.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.88 38.793 -38.523
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.682 100.446 18.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.88 38.793 -38.523
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.463276
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.799220e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.884700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.285000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.653410e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.835679e-02
Vprtstp: contraction number = 5.835679e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.482036e-03
Vprtstp: contraction number = 1.282119e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.301196e-03
Vprtstp: contraction number = 1.739093e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.838941e-04
Vprtstp: contraction number = 2.181794e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.450854e-05
Vprtstp: contraction number = 2.624519e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.087206e-05
Vprtstp: contraction number = 2.801298e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.409911e-06
Vprtstp: contraction number = 3.071048e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.965258e-06
Vprtstp: contraction number = 3.065968e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.423076e-07
Vprtstp: contraction number = 3.268312e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.008990e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.740120e-01
Vpmg_setPart:  lower corner = (-37.88, 28.793, -48.523)
Vpmg_setPart:  upper corner = (54.682, 110.446, 28.189)
Vpmg_setPart:  actual minima = (-37.88, 28.793, -48.523)
Vpmg_setPart:  actual maxima = (54.682, 110.446, 28.189)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.88, 38.793, -38.523
VPMG::focusFillBound -- New mesh maxs = 44.682, 100.446, 18.189
VPMG::focusFillBound -- Old mesh mins = -37.88, 28.793, -48.523
VPMG::focusFillBound -- Old mesh maxs = 54.682, 110.446, 28.189
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.460498
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.544060e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.894200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.134800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.894521e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.722144e-02
Vprtstp: contraction number = 8.722144e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.243569e-02
Vprtstp: contraction number = 1.425761e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.212265e-03
Vprtstp: contraction number = 1.778964e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.687348e-04
Vprtstp: contraction number = 2.118801e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.222381e-04
Vprtstp: contraction number = 2.607831e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.512327e-05
Vprtstp: contraction number = 2.873349e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.121153e-05
Vprtstp: contraction number = 3.192051e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.675847e-06
Vprtstp: contraction number = 3.278631e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.263594e-06
Vprtstp: contraction number = 3.437560e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.313239e-07
Vprtstp: contraction number = 3.413468e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.284610e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.999780e-01
Vpmg_setPart:  lower corner = (-27.88, 38.793, -38.523)
Vpmg_setPart:  upper corner = (44.682, 100.446, 18.189)
Vpmg_setPart:  actual minima = (-27.88, 38.793, -38.523)
Vpmg_setPart:  actual maxima = (44.682, 100.446, 18.189)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.417989e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:54 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3606 atoms
Valist_getStatistics:  Max atom coordinate:  (34.682, 90.446, 8.189)
Valist_getStatistics:  Min atom coordinate:  (-17.88, 48.793, -28.523)
Valist_getStatistics:  Molecule center:  (8.401, 69.6195, -10.167)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.964187, 0.850552, 0.799083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.755854, 0.642219, 0.59075
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.783929, 0.755061, 0.739285 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.682 110.446 28.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -37.88 28.793 -48.523
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.682 100.446 18.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.88 38.793 -38.523
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.682 100.446 18.189
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.88 38.793 -38.523
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.461589
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.788120e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.870000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.948800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.588130e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4080030.657090
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.102540e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.467398e+05
Vprtstp: contraction number = 2.467398e+05
Vnewton: Attempting damping, relres = 0.055773
Vnewton: Attempting damping, relres = 0.522179
Vnewton: Damping accepted, relres = 0.055773
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.577316e-02
Vprtstp: contraction number = 5.577316e-02
Vnewton: Using errtol_s: 227556.194478
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.146360e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.108963e+04
Vprtstp: contraction number = 3.108963e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.875816e-03
Vprtstp: contraction number = 1.232818e-01
Vnewton: Using errtol_s: 28053.541801
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.927430e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.769390e+03
Vprtstp: contraction number = 4.769390e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.052213e-03
Vprtstp: contraction number = 1.530309e-01
Vnewton: Using errtol_s: 4293.059774
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.069858e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.188000e+02
Vprtstp: contraction number = 8.188000e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.806218e-04
Vprtstp: contraction number = 1.716591e-01
Vnewton: Using errtol_s: 736.942645
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.148229e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.481840e+02
Vprtstp: contraction number = 1.481840e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.268749e-05
Vprtstp: contraction number = 1.809720e-01
Vnewton: Using errtol_s: 133.365973
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.226889e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.020830e+01
Vprtstp: contraction number = 3.020830e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.663546e-06
Vprtstp: contraction number = 2.038561e-01
Vnewton: Using errtol_s: 27.187472
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.305829e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.270033e+00
Vprtstp: contraction number = 7.270033e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.603672e-06
Vprtstp: contraction number = 2.406634e-01
Vnewton: Using errtol_s: 6.543030
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.383896e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.975383e+00
Vprtstp: contraction number = 1.975383e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.357430e-07
Vprtstp: contraction number = 2.717158e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.841940e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.519430e-01
Vpmg_setPart:  lower corner = (-37.88, 28.793, -48.523)
Vpmg_setPart:  upper corner = (54.682, 110.446, 28.189)
Vpmg_setPart:  actual minima = (-37.88, 28.793, -48.523)
Vpmg_setPart:  actual maxima = (54.682, 110.446, 28.189)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.88, 38.793, -38.523
VPMG::focusFillBound -- New mesh maxs = 44.682, 100.446, 18.189
VPMG::focusFillBound -- Old mesh mins = -37.88, 28.793, -48.523
VPMG::focusFillBound -- Old mesh maxs = 54.682, 110.446, 28.189
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.458240
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.545310e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.913200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.187700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.270821e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5089531.899242
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.322832e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.835167e+05
Vprtstp: contraction number = 4.835167e+05
Vnewton: Attempting damping, relres = 0.086470
Vnewton: Attempting damping, relres = 0.539138
Vnewton: Damping accepted, relres = 0.086470
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.647028e-02
Vprtstp: contraction number = 8.647028e-02
Vnewton: Using errtol_s: 440093.241650
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.426143e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.812394e+04
Vprtstp: contraction number = 6.812394e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.205987e-02
Vprtstp: contraction number = 1.394683e-01
Vnewton: Using errtol_s: 61379.078134
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.504735e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.152561e+04
Vprtstp: contraction number = 1.152561e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.038218e-03
Vprtstp: contraction number = 1.690083e-01
Vnewton: Using errtol_s: 10373.576631
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.581981e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.154968e+03
Vprtstp: contraction number = 2.154968e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.810733e-04
Vprtstp: contraction number = 1.869639e-01
Vnewton: Using errtol_s: 1939.484512
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.661085e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.255082e+02
Vprtstp: contraction number = 4.255082e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.524418e-05
Vprtstp: contraction number = 1.974533e-01
Vnewton: Using errtol_s: 382.957666
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.741090e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.519431e+01
Vprtstp: contraction number = 8.519431e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.506522e-05
Vprtstp: contraction number = 2.002178e-01
Vnewton: Using errtol_s: 76.674924
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.821324e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.822545e+01
Vprtstp: contraction number = 1.822545e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.222872e-06
Vprtstp: contraction number = 2.139280e-01
Vnewton: Using errtol_s: 16.402912
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.901231e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.183674e+00
Vprtstp: contraction number = 4.183674e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.398140e-07
Vprtstp: contraction number = 2.295511e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.911000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.620480e-01
Vpmg_setPart:  lower corner = (-27.88, 38.793, -38.523)
Vpmg_setPart:  upper corner = (44.682, 100.446, 18.189)
Vpmg_setPart:  actual minima = (-27.88, 38.793, -38.523)
Vpmg_setPart:  actual maxima = (44.682, 100.446, 18.189)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.158929e+00
