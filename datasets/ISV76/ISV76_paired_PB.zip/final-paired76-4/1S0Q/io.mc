##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:43 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3220 atoms
Valist_getStatistics:  Max atom coordinate:  (74.595, 57.231, 34.496)
Valist_getStatistics:  Min atom coordinate:  (29.847, 18.37, -13.039)
Valist_getStatistics:  Molecule center:  (52.221, 37.8005, 10.7285)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.882792, 0.821469, 0.911823
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.674458, 0.613135, 0.70349
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.764006, 0.746389, 0.77152 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 94.595 77.231 54.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 9.847 -1.63 -33.039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.595 67.231 44.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 19.847 8.37 -23.039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.595 67.231 44.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 19.847 8.37 -23.039
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 27.3712
Vpbe_ctor2:  solute dimensions = 47.558 x 41.294 x 50.117
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.528, 51.641, 60.315)
Vclist_setupGrid:  Grid lower corner = (23.457, 11.98, -19.429)
Vclist_assignAtoms:  Have 6608766 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.402179
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.048200e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.871100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.122300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.866140e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.444834e-02
Vprtstp: contraction number = 5.444834e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.794071e-03
Vprtstp: contraction number = 1.247801e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.183666e-03
Vprtstp: contraction number = 1.742204e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.834655e-04
Vprtstp: contraction number = 2.394811e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.976117e-05
Vprtstp: contraction number = 2.461011e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.081584e-05
Vprtstp: contraction number = 2.983872e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.735523e-06
Vprtstp: contraction number = 2.755364e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.853309e-06
Vprtstp: contraction number = 3.231282e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.337461e-07
Vprtstp: contraction number = 2.879962e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.921450e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.629240e-01
Vpmg_setPart:  lower corner = (9.847, -1.63, -33.039)
Vpmg_setPart:  upper corner = (94.595, 77.231, 54.496)
Vpmg_setPart:  actual minima = (9.847, -1.63, -33.039)
Vpmg_setPart:  actual maxima = (94.595, 77.231, 54.496)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 27.3712
Vpbe_ctor2:  solute dimensions = 47.558 x 41.294 x 50.117
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.528, 51.641, 60.315)
Vclist_setupGrid:  Grid lower corner = (23.457, 11.98, -19.429)
Vclist_assignAtoms:  Have 6608766 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 19.847, 8.37, -23.039
VPMG::focusFillBound -- New mesh maxs = 84.595, 67.231, 44.496
VPMG::focusFillBound -- Old mesh mins = 9.847, -1.63, -33.039
VPMG::focusFillBound -- Old mesh maxs = 94.595, 77.231, 54.496
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.399919
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.729610e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.912600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.161500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.726103e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.012136e-02
Vprtstp: contraction number = 8.012136e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.046872e-02
Vprtstp: contraction number = 1.306608e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.854490e-03
Vprtstp: contraction number = 1.771458e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.623380e-04
Vprtstp: contraction number = 2.493074e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.299443e-04
Vprtstp: contraction number = 2.810592e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.570473e-05
Vprtstp: contraction number = 3.517254e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.489202e-05
Vprtstp: contraction number = 3.258311e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.718847e-06
Vprtstp: contraction number = 3.840209e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.927500e-06
Vprtstp: contraction number = 3.370434e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.547701e-07
Vprtstp: contraction number = 3.915799e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.218700e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.940370e-01
Vpmg_setPart:  lower corner = (19.847, 8.37, -23.039)
Vpmg_setPart:  upper corner = (84.595, 67.231, 44.496)
Vpmg_setPart:  actual minima = (19.847, 8.37, -23.039)
Vpmg_setPart:  actual maxima = (84.595, 67.231, 44.496)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.235054e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:46 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3220 atoms
Valist_getStatistics:  Max atom coordinate:  (74.595, 57.231, 34.496)
Valist_getStatistics:  Min atom coordinate:  (29.847, 18.37, -13.039)
Valist_getStatistics:  Molecule center:  (52.221, 37.8005, 10.7285)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.882792, 0.821469, 0.911823
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.674458, 0.613135, 0.70349
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.764006, 0.746389, 0.77152 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 52.221 37.8005 10.7285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 94.595 77.231 54.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 9.847 -1.63 -33.039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.595 67.231 44.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 19.847 8.37 -23.039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.595 67.231 44.496
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 19.847 8.37 -23.039
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 27.3712
Vpbe_ctor2:  solute dimensions = 47.558 x 41.294 x 50.117
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.528, 51.641, 60.315)
Vclist_setupGrid:  Grid lower corner = (23.457, 11.98, -19.429)
Vclist_assignAtoms:  Have 6608766 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.398773
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.007740e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.012700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.841600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.807500e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3613244.184458
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.352260e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.986554e+05
Vprtstp: contraction number = 1.986554e+05
Vnewton: Attempting damping, relres = 0.050473
Vnewton: Attempting damping, relres = 0.519906
Vnewton: Damping accepted, relres = 0.050473
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.047339e-02
Vprtstp: contraction number = 5.047339e-02
Vnewton: Using errtol_s: 182372.684232
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.381370e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.361273e+04
Vprtstp: contraction number = 2.361273e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.887140e-03
Vprtstp: contraction number = 1.166385e-01
Vnewton: Using errtol_s: 21271.676072
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.177060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.508706e+03
Vprtstp: contraction number = 3.508706e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.740335e-04
Vprtstp: contraction number = 1.484649e-01
Vnewton: Using errtol_s: 3158.096390
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.962130e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.055586e+02
Vprtstp: contraction number = 6.055586e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.508369e-04
Vprtstp: contraction number = 1.725756e-01
Vnewton: Using errtol_s: 545.010428
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.073236e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.158933e+02
Vprtstp: contraction number = 1.158933e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.886719e-05
Vprtstp: contraction number = 1.913802e-01
Vnewton: Using errtol_s: 104.304206
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.149894e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.460253e+01
Vprtstp: contraction number = 2.460253e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.128089e-06
Vprtstp: contraction number = 2.122856e-01
Vnewton: Using errtol_s: 22.142281
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.226563e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.782134e+00
Vprtstp: contraction number = 5.782134e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.440235e-06
Vprtstp: contraction number = 2.350219e-01
Vnewton: Using errtol_s: 5.203921
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.303690e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.487816e+00
Vprtstp: contraction number = 1.487816e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.705906e-07
Vprtstp: contraction number = 2.573126e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.812140e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.496730e-01
Vpmg_setPart:  lower corner = (9.847, -1.63, -33.039)
Vpmg_setPart:  upper corner = (94.595, 77.231, 54.496)
Vpmg_setPart:  actual minima = (9.847, -1.63, -33.039)
Vpmg_setPart:  actual maxima = (94.595, 77.231, 54.496)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 27.3712
Vpbe_ctor2:  solute dimensions = 47.558 x 41.294 x 50.117
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.528, 51.641, 60.315)
Vclist_setupGrid:  Grid lower corner = (23.457, 11.98, -19.429)
Vclist_assignAtoms:  Have 6608766 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 19.847, 8.37, -23.039
VPMG::focusFillBound -- New mesh maxs = 84.595, 67.231, 44.496
VPMG::focusFillBound -- Old mesh mins = 9.847, -1.63, -33.039
VPMG::focusFillBound -- Old mesh maxs = 94.595, 77.231, 54.496
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.396579
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.711030e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.954400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.928100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.103887e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4536205.744885
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.156576e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.875304e+05
Vprtstp: contraction number = 3.875304e+05
Vnewton: Attempting damping, relres = 0.077649
Vnewton: Attempting damping, relres = 0.535074
Vnewton: Damping accepted, relres = 0.077649
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.764888e-02
Vprtstp: contraction number = 7.764888e-02
Vnewton: Using errtol_s: 352231.311241
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.259736e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.901435e+04
Vprtstp: contraction number = 4.901435e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.729465e-03
Vprtstp: contraction number = 1.253008e-01
Vnewton: Using errtol_s: 44134.857192
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.337458e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.411579e+03
Vprtstp: contraction number = 7.411579e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.470568e-03
Vprtstp: contraction number = 1.511458e-01
Vnewton: Using errtol_s: 6670.798235
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.415803e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.264083e+03
Vprtstp: contraction number = 1.264083e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.508035e-04
Vprtstp: contraction number = 1.705487e-01
Vnewton: Using errtol_s: 1137.696191
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.492727e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.336212e+02
Vprtstp: contraction number = 2.336212e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.635148e-05
Vprtstp: contraction number = 1.848120e-01
Vnewton: Using errtol_s: 210.259854
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.570513e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.546113e+01
Vprtstp: contraction number = 4.546113e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.019660e-06
Vprtstp: contraction number = 1.945927e-01
Vnewton: Using errtol_s: 40.915035
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.646558e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.193203e+00
Vprtstp: contraction number = 9.193203e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.823966e-06
Vprtstp: contraction number = 2.022211e-01
Vnewton: Using errtol_s: 8.273883
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.725738e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.941234e+00
Vprtstp: contraction number = 1.941234e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.851480e-07
Vprtstp: contraction number = 2.111597e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.798600e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.484650e-01
Vpmg_setPart:  lower corner = (19.847, 8.37, -23.039)
Vpmg_setPart:  upper corner = (84.595, 67.231, 44.496)
Vpmg_setPart:  actual minima = (19.847, 8.37, -23.039)
Vpmg_setPart:  actual maxima = (84.595, 67.231, 44.496)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.972605e+00
