##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:24:53 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 25541 atoms
Valist_getStatistics:  Max atom coordinate:  (-1.316, 5.918, -8.648)
Valist_getStatistics:  Min atom coordinate:  (-84.078, -96.185, -162.604)
Valist_getStatistics:  Molecule center:  (-42.697, -45.1335, -85.626)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.959078, 0.888144, 0.865875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.802828, 0.763144, 0.776589
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.837083, 0.859257, 0.896884 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 18.684 25.918 11.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -104.078 -116.185 -182.604
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 8.684 15.918 1.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -94.078 -106.185 -172.604
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 8.684 15.918 1.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -94.078 -106.185 -172.604
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 84.7278
Vpbe_ctor2:  solute dimensions = 85.576 x 104.864 x 156.599
Vpbe_ctor2:  solute charge = -25.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (95.542, 114.883, 166.736)
Vclist_setupGrid:  Grid lower corner = (-90.468, -102.575, -168.994)
Vclist_assignAtoms:  Have 8658732 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.284977
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.223848e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.736300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 113)
Vbuildops: Galer: (033, 041, 057)
Vbuildops: Galer: (017, 021, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.126800e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.752372e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.135863e-02
Vprtstp: contraction number = 6.135863e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.326053e-03
Vprtstp: contraction number = 1.356949e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.095816e-03
Vprtstp: contraction number = 2.517178e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.863460e-04
Vprtstp: contraction number = 2.797698e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.480680e-04
Vprtstp: contraction number = 4.230745e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.820826e-05
Vprtstp: contraction number = 3.555809e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.385317e-05
Vprtstp: contraction number = 4.971550e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.729519e-05
Vprtstp: contraction number = 3.943886e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.011258e-06
Vprtstp: contraction number = 5.210268e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.803487e-06
Vprtstp: contraction number = 4.220817e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.006266e-06
Vprtstp: contraction number = 5.274807e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 8.801565e-07
Vprtstp: contraction number = 4.387038e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.199520e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.669488e+00
Vpmg_setPart:  lower corner = (-104.078, -116.185, -182.604)
Vpmg_setPart:  upper corner = (18.684, 25.918, 11.352)
Vpmg_setPart:  actual minima = (-104.078, -116.185, -182.604)
Vpmg_setPart:  actual maxima = (18.684, 25.918, 11.352)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 84.7278
Vpbe_ctor2:  solute dimensions = 85.576 x 104.864 x 156.599
Vpbe_ctor2:  solute charge = -25.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (95.542, 114.883, 166.736)
Vclist_setupGrid:  Grid lower corner = (-90.468, -102.575, -168.994)
Vclist_assignAtoms:  Have 8658732 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -94.078, -106.185, -172.604
VPMG::focusFillBound -- New mesh maxs = 8.684, 15.918, 1.352
VPMG::focusFillBound -- Old mesh mins = -104.078, -116.185, -182.604
VPMG::focusFillBound -- Old mesh maxs = 18.684, 25.918, 11.352
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.280281
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.445615e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.865200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 113)
Vbuildops: Galer: (033, 041, 057)
Vbuildops: Galer: (017, 021, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.130640e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.489216e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.755863e-02
Vprtstp: contraction number = 6.755863e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.000117e-03
Vprtstp: contraction number = 1.332194e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.201025e-03
Vprtstp: contraction number = 2.445552e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.124221e-04
Vprtstp: contraction number = 2.782440e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.878140e-04
Vprtstp: contraction number = 4.699601e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.084695e-04
Vprtstp: contraction number = 3.768737e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.112451e-05
Vprtstp: contraction number = 5.635178e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.627710e-05
Vprtstp: contraction number = 4.298947e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.552999e-05
Vprtstp: contraction number = 5.910086e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.231697e-06
Vprtstp: contraction number = 4.656601e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.317270e-06
Vprtstp: contraction number = 5.969926e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.096361e-06
Vprtstp: contraction number = 4.855757e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.248922e-06
Vprtstp: contraction number = 5.957571e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.193759e-07
Vprtstp: contraction number = 4.959284e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.662910e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.136676e+00
Vpmg_setPart:  lower corner = (-94.078, -106.185, -172.604)
Vpmg_setPart:  upper corner = (8.684, 15.918, 1.352)
Vpmg_setPart:  actual minima = (-94.078, -106.185, -172.604)
Vpmg_setPart:  actual maxima = (8.684, 15.918, 1.352)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.958888e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:18 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 25541 atoms
Valist_getStatistics:  Max atom coordinate:  (-1.316, 5.918, -8.648)
Valist_getStatistics:  Min atom coordinate:  (-84.078, -96.185, -162.604)
Valist_getStatistics:  Molecule center:  (-42.697, -45.1335, -85.626)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.959078, 0.888144, 0.865875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.802828, 0.763144, 0.776589
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.837083, 0.859257, 0.896884 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -42.697 -45.1335 -85.626
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 18.684 25.918 11.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -104.078 -116.185 -182.604
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 8.684 15.918 1.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -94.078 -106.185 -172.604
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 8.684 15.918 1.352
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -94.078 -106.185 -172.604
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 84.7278
Vpbe_ctor2:  solute dimensions = 85.576 x 104.864 x 156.599
Vpbe_ctor2:  solute charge = -25.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (95.542, 114.883, 166.736)
Vclist_setupGrid:  Grid lower corner = (-90.468, -102.575, -168.994)
Vclist_assignAtoms:  Have 8658732 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.257021
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.184910e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 9.641500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 113)
Vbuildops: Galer: (033, 041, 057)
Vbuildops: Galer: (017, 021, 029)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.133410e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.603254e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 28920820.274970
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.894739e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.784507e+06
Vprtstp: contraction number = 1.784507e+06
Vnewton: Attempting damping, relres = 0.061864
Vnewton: Attempting damping, relres = 0.523143
Vnewton: Damping accepted, relres = 0.061864
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.186444e-02
Vprtstp: contraction number = 6.186444e-02
Vnewton: Using errtol_s: 1789170.287444
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.525165e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.293269e+05
Vprtstp: contraction number = 2.293269e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.387486e-03
Vprtstp: contraction number = 1.355785e-01
Vnewton: Using errtol_s: 242572.980369
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.019050e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.707926e+04
Vprtstp: contraction number = 3.707926e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.425921e-03
Vprtstp: contraction number = 1.700057e-01
Vnewton: Using errtol_s: 41238.796456
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.518485e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.402862e+03
Vprtstp: contraction number = 7.402862e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.955764e-04
Vprtstp: contraction number = 2.072881e-01
Vnewton: Using errtol_s: 8548.311905
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.017905e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.861579e+03
Vprtstp: contraction number = 1.861579e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.891356e-05
Vprtstp: contraction number = 2.331497e-01
Vnewton: Using errtol_s: 1993.036614
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.517291e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.118410e+02
Vprtstp: contraction number = 5.118410e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.642650e-05
Vprtstp: contraction number = 2.383639e-01
Vnewton: Using errtol_s: 475.067946
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.025016e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.358184e+02
Vprtstp: contraction number = 1.358184e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.226718e-06
Vprtstp: contraction number = 2.573109e-01
Vnewton: Using errtol_s: 122.240146
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.532027e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.554836e+01
Vprtstp: contraction number = 3.554836e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.106255e-06
Vprtstp: contraction number = 2.617291e-01
Vnewton: Using errtol_s: 31.993806
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.003841e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.036513e+01
Vprtstp: contraction number = 1.036513e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.225555e-07
Vprtstp: contraction number = 2.915743e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.822233e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.182698e+00
Vpmg_setPart:  lower corner = (-104.078, -116.185, -182.604)
Vpmg_setPart:  upper corner = (18.684, 25.918, 11.352)
Vpmg_setPart:  actual minima = (-104.078, -116.185, -182.604)
Vpmg_setPart:  actual maxima = (18.684, 25.918, 11.352)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 84.7278
Vpbe_ctor2:  solute dimensions = 85.576 x 104.864 x 156.599
Vpbe_ctor2:  solute charge = -25.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (95.542, 114.883, 166.736)
Vclist_setupGrid:  Grid lower corner = (-90.468, -102.575, -168.994)
Vclist_assignAtoms:  Have 8658732 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -94.078, -106.185, -172.604
VPMG::focusFillBound -- New mesh maxs = 8.684, 15.918, 1.352
VPMG::focusFillBound -- Old mesh mins = -104.078, -116.185, -182.604
VPMG::focusFillBound -- Old mesh maxs = 18.684, 25.918, 11.352
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.257792
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.415618e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 9.732900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 113)
Vbuildops: Galer: (033, 041, 057)
Vbuildops: Galer: (017, 021, 029)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.151240e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.622617e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 31841338.402527
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.652297e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.200812e+06
Vprtstp: contraction number = 2.200812e+06
Vnewton: Attempting damping, relres = 0.067398
Vnewton: Attempting damping, relres = 0.526979
Vnewton: Damping accepted, relres = 0.067398
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.739789e-02
Vprtstp: contraction number = 6.739789e-02
Vnewton: Using errtol_s: 2146039.026743
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.716777e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.804623e+05
Vprtstp: contraction number = 2.804623e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.915559e-03
Vprtstp: contraction number = 1.322825e-01
Vnewton: Using errtol_s: 283883.328590
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.767009e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.411389e+04
Vprtstp: contraction number = 4.411389e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.455529e-03
Vprtstp: contraction number = 1.632571e-01
Vnewton: Using errtol_s: 46345.976194
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.817259e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.341920e+03
Vprtstp: contraction number = 8.341920e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.855288e-04
Vprtstp: contraction number = 1.961685e-01
Vnewton: Using errtol_s: 9091.619253
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.867591e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.975018e+03
Vprtstp: contraction number = 1.975018e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.267742e-05
Vprtstp: contraction number = 2.195135e-01
Vnewton: Using errtol_s: 1995.732782
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.918415e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.034514e+02
Vprtstp: contraction number = 5.034514e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.434266e-05
Vprtstp: contraction number = 2.288330e-01
Vnewton: Using errtol_s: 456.689539
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.968738e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.189247e+02
Vprtstp: contraction number = 1.189247e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.361804e-06
Vprtstp: contraction number = 2.343919e-01
Vnewton: Using errtol_s: 107.044323
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.019290e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.613136e+01
Vprtstp: contraction number = 2.613136e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.386149e-07
Vprtstp: contraction number = 2.197079e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.363055e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.727729e+00
Vpmg_setPart:  lower corner = (-94.078, -106.185, -172.604)
Vpmg_setPart:  upper corner = (8.684, 15.918, 1.352)
Vpmg_setPart:  actual minima = (-94.078, -106.185, -172.604)
Vpmg_setPart:  actual maxima = (8.684, 15.918, 1.352)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.170867e+01
