##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:13 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 892 atoms
Valist_getStatistics:  Max atom coordinate:  (43.79, 24.093, 17.248)
Valist_getStatistics:  Min atom coordinate:  (16.941, -3.835, -16.916)
Valist_getStatistics:  Molecule center:  (30.3655, 10.129, 0.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.04452, 1.06137, 0.772542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.732016, 0.748875, 0.564208
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.700818, 0.705571, 0.730327 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 63.79 44.093 37.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -3.059 -23.835 -36.916
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 53.79 34.093 27.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 6.941 -13.835 -26.916
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 53.79 34.093 27.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 6.941 -13.835 -26.916
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.102135
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.760750e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.836000e-03
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.708400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.134680e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.304907e-02
Vprtstp: contraction number = 7.304907e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.044673e-02
Vprtstp: contraction number = 1.430098e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.923308e-03
Vprtstp: contraction number = 1.841063e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.706935e-04
Vprtstp: contraction number = 1.927374e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.616116e-05
Vprtstp: contraction number = 2.054559e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.581793e-05
Vprtstp: contraction number = 2.076903e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.422160e-06
Vprtstp: contraction number = 2.163469e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.484557e-07
Vprtstp: contraction number = 2.187085e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.084990e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.396890e-01
Vpmg_setPart:  lower corner = (-3.059, -23.835, -36.916)
Vpmg_setPart:  upper corner = (63.79, 44.093, 37.248)
Vpmg_setPart:  actual minima = (-3.059, -23.835, -36.916)
Vpmg_setPart:  actual maxima = (63.79, 44.093, 37.248)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 6.941, -13.835, -26.916
VPMG::focusFillBound -- New mesh maxs = 53.79, 34.093, 27.248
VPMG::focusFillBound -- Old mesh mins = -3.059, -23.835, -36.916
VPMG::focusFillBound -- Old mesh maxs = 63.79, 44.093, 37.248
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.101453
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.121610e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.998000e-03
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.771600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.672320e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.771697e-02
Vprtstp: contraction number = 9.771697e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.410285e-02
Vprtstp: contraction number = 1.443234e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.378492e-03
Vprtstp: contraction number = 1.686533e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.291852e-04
Vprtstp: contraction number = 1.804443e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.159606e-05
Vprtstp: contraction number = 1.901185e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.639110e-05
Vprtstp: contraction number = 2.008810e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.395639e-06
Vprtstp: contraction number = 2.071636e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.382331e-07
Vprtstp: contraction number = 2.174062e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.137840e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.458570e-01
Vpmg_setPart:  lower corner = (6.941, -13.835, -26.916)
Vpmg_setPart:  upper corner = (53.79, 34.093, 27.248)
Vpmg_setPart:  actual minima = (6.941, -13.835, -26.916)
Vpmg_setPart:  actual maxima = (53.79, 34.093, 27.248)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.492290e-01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:14 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 892 atoms
Valist_getStatistics:  Max atom coordinate:  (43.79, 24.093, 17.248)
Valist_getStatistics:  Min atom coordinate:  (16.941, -3.835, -16.916)
Valist_getStatistics:  Molecule center:  (30.3655, 10.129, 0.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.04452, 1.06137, 0.772542
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.732016, 0.748875, 0.564208
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.700818, 0.705571, 0.730327 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 63.79 44.093 37.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -3.059 -23.835 -36.916
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 53.79 34.093 27.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 6.941 -13.835 -26.916
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 53.79 34.093 27.248
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 6.941 -13.835 -26.916
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.102058
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.759380e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.256000e-03
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.671900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.115400e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 960116.890920
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.337980e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.194225e+04
Vprtstp: contraction number = 7.194225e+04
Vnewton: Attempting damping, relres = 0.069781
Vnewton: Attempting damping, relres = 0.528296
Vnewton: Damping accepted, relres = 0.069781
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.978068e-02
Vprtstp: contraction number = 6.978068e-02
Vnewton: Using errtol_s: 66997.606434
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.744660e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.086878e+04
Vprtstp: contraction number = 1.086878e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.020655e-02
Vprtstp: contraction number = 1.462662e-01
Vnewton: Using errtol_s: 9799.482109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.048610e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.986831e+03
Vprtstp: contraction number = 1.986831e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.862580e-03
Vprtstp: contraction number = 1.824887e-01
Vnewton: Using errtol_s: 1788.294895
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.359150e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.910850e+02
Vprtstp: contraction number = 3.910850e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.666033e-04
Vprtstp: contraction number = 1.968255e-01
Vnewton: Using errtol_s: 351.981992
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.664840e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.970889e+01
Vprtstp: contraction number = 7.970889e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.471823e-05
Vprtstp: contraction number = 2.038122e-01
Vnewton: Using errtol_s: 71.738234
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.972650e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.659193e+01
Vprtstp: contraction number = 1.659193e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.555305e-05
Vprtstp: contraction number = 2.081561e-01
Vnewton: Using errtol_s: 14.932750
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.287510e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.538318e+00
Vprtstp: contraction number = 3.538318e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.316770e-06
Vprtstp: contraction number = 2.132552e-01
Vnewton: Using errtol_s: 3.184487
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.603040e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.748678e-01
Vprtstp: contraction number = 7.748678e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.263502e-07
Vprtstp: contraction number = 2.189932e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.718930e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.012130e-01
Vpmg_setPart:  lower corner = (-3.059, -23.835, -36.916)
Vpmg_setPart:  upper corner = (63.79, 44.093, 37.248)
Vpmg_setPart:  actual minima = (-3.059, -23.835, -36.916)
Vpmg_setPart:  actual maxima = (63.79, 44.093, 37.248)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 6.941, -13.835, -26.916
VPMG::focusFillBound -- New mesh maxs = 53.79, 34.093, 27.248
VPMG::focusFillBound -- Old mesh mins = -3.059, -23.835, -36.916
VPMG::focusFillBound -- Old mesh maxs = 63.79, 44.093, 37.248
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.104868
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.150560e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.580000e-03
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.720700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.298260e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1332958.380551
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.545160e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.410638e+05
Vprtstp: contraction number = 1.410638e+05
Vnewton: Attempting damping, relres = 0.096935
Vnewton: Attempting damping, relres = 0.544621
Vnewton: Damping accepted, relres = 0.096935
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.693482e-02
Vprtstp: contraction number = 9.693482e-02
Vnewton: Using errtol_s: 129210.086555
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.972100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.075500e+04
Vprtstp: contraction number = 2.075500e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.402802e-02
Vprtstp: contraction number = 1.447160e-01
Vnewton: Using errtol_s: 18698.768630
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.291760e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.503681e+03
Vprtstp: contraction number = 3.503681e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.365740e-03
Vprtstp: contraction number = 1.686439e-01
Vnewton: Using errtol_s: 3153.433139
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.609670e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.322398e+02
Vprtstp: contraction number = 6.322398e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.268847e-04
Vprtstp: contraction number = 1.804445e-01
Vnewton: Using errtol_s: 569.019531
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.928190e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.199060e+02
Vprtstp: contraction number = 1.199060e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.095947e-05
Vprtstp: contraction number = 1.896519e-01
Vnewton: Using errtol_s: 107.915609
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.245100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.372594e+01
Vprtstp: contraction number = 2.372594e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.601952e-05
Vprtstp: contraction number = 1.978709e-01
Vnewton: Using errtol_s: 21.353355
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.561240e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.862251e+00
Vprtstp: contraction number = 4.862251e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.282943e-06
Vprtstp: contraction number = 2.049339e-01
Vnewton: Using errtol_s: 4.376026
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.869960e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.026285e+00
Vprtstp: contraction number = 1.026285e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.929373e-07
Vprtstp: contraction number = 2.110720e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.808940e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.111900e-01
Vpmg_setPart:  lower corner = (6.941, -13.835, -26.916)
Vpmg_setPart:  upper corner = (53.79, 34.093, 27.248)
Vpmg_setPart:  actual minima = (6.941, -13.835, -26.916)
Vpmg_setPart:  actual maxima = (53.79, 34.093, 27.248)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.079744e+00
