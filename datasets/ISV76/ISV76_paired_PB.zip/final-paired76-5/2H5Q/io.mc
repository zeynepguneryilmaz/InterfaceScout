##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:40 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3431 atoms
Valist_getStatistics:  Max atom coordinate:  (65.857, 41, 36.694)
Valist_getStatistics:  Min atom coordinate:  (14.654, -4.125, -7.327)
Valist_getStatistics:  Molecule center:  (40.2555, 18.4375, 14.6835)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.950031, 0.886719, 0.875219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.741698, 0.678385, 0.666885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.780709, 0.765051, 0.761964 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.857 61 56.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -5.346 -24.125 -27.327
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.857 51 46.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 4.654 -14.125 -17.327
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.857 51 46.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 4.654 -14.125 -17.327
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.423743
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.206450e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.142300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.283300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.092080e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.386208e-02
Vprtstp: contraction number = 5.386208e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.962144e-03
Vprtstp: contraction number = 1.292587e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.612122e-03
Vprtstp: contraction number = 2.315554e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.658791e-04
Vprtstp: contraction number = 3.510150e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.173080e-04
Vprtstp: contraction number = 3.840185e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.029139e-04
Vprtstp: contraction number = 4.735854e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.267639e-05
Vprtstp: contraction number = 4.146805e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.114984e-05
Vprtstp: contraction number = 4.955866e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.736734e-06
Vprtstp: contraction number = 4.130874e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.359607e-06
Vprtstp: contraction number = 4.989973e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.792054e-06
Vprtstp: contraction number = 4.110587e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 8.971618e-07
Vprtstp: contraction number = 5.006331e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.204810e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.972850e-01
Vpmg_setPart:  lower corner = (-5.346, -24.125, -27.327)
Vpmg_setPart:  upper corner = (85.857, 61, 56.694)
Vpmg_setPart:  actual minima = (-5.346, -24.125, -27.327)
Vpmg_setPart:  actual maxima = (85.857, 61, 56.694)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 4.654, -14.125, -17.327
VPMG::focusFillBound -- New mesh maxs = 75.857, 51, 46.694
VPMG::focusFillBound -- Old mesh mins = -5.346, -24.125, -27.327
VPMG::focusFillBound -- Old mesh maxs = 85.857, 61, 56.694
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.418742
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.869440e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.944400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.338400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.892880e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.725742e-02
Vprtstp: contraction number = 7.725742e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.870766e-03
Vprtstp: contraction number = 1.277646e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.601285e-03
Vprtstp: contraction number = 1.622250e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.708412e-04
Vprtstp: contraction number = 2.315897e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.143772e-04
Vprtstp: contraction number = 3.084264e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.087180e-05
Vprtstp: contraction number = 4.447722e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.158577e-05
Vprtstp: contraction number = 4.243170e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.145175e-05
Vprtstp: contraction number = 5.305230e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.007492e-06
Vprtstp: contraction number = 4.372688e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.699476e-06
Vprtstp: contraction number = 5.390875e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.181916e-06
Vprtstp: contraction number = 4.378314e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.381498e-07
Vprtstp: contraction number = 5.399283e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.194650e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.934770e-01
Vpmg_setPart:  lower corner = (4.654, -14.125, -17.327)
Vpmg_setPart:  upper corner = (75.857, 51, 46.694)
Vpmg_setPart:  actual minima = (4.654, -14.125, -17.327)
Vpmg_setPart:  actual maxima = (75.857, 51, 46.694)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.506851e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:43 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3431 atoms
Valist_getStatistics:  Max atom coordinate:  (65.857, 41, 36.694)
Valist_getStatistics:  Min atom coordinate:  (14.654, -4.125, -7.327)
Valist_getStatistics:  Molecule center:  (40.2555, 18.4375, 14.6835)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.950031, 0.886719, 0.875219
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.741698, 0.678385, 0.666885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.780709, 0.765051, 0.761964 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.857 61 56.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -5.346 -24.125 -27.327
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.857 51 46.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 4.654 -14.125 -17.327
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.857 51 46.694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 4.654 -14.125 -17.327
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.424732
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.272130e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.940200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.840100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.074490e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3669033.972969
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.608790e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.074623e+05
Vprtstp: contraction number = 2.074623e+05
Vnewton: Attempting damping, relres = 0.051637
Vnewton: Attempting damping, relres = 0.520282
Vnewton: Damping accepted, relres = 0.051637
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.163685e-02
Vprtstp: contraction number = 5.163685e-02
Vnewton: Using errtol_s: 189457.343838
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.658100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.501129e+04
Vprtstp: contraction number = 2.501129e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.137240e-03
Vprtstp: contraction number = 1.188539e-01
Vnewton: Using errtol_s: 22517.741345
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.485700e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.688400e+03
Vprtstp: contraction number = 3.688400e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.047913e-04
Vprtstp: contraction number = 1.474264e-01
Vnewton: Using errtol_s: 3319.710099
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.029606e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.117774e+02
Vprtstp: contraction number = 6.117774e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.500680e-04
Vprtstp: contraction number = 1.658592e-01
Vnewton: Using errtol_s: 550.604462
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.110136e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.079856e+02
Vprtstp: contraction number = 1.079856e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.648847e-05
Vprtstp: contraction number = 1.765098e-01
Vnewton: Using errtol_s: 97.187109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.191506e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.036023e+01
Vprtstp: contraction number = 2.036023e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.994286e-06
Vprtstp: contraction number = 1.885456e-01
Vnewton: Using errtol_s: 18.324206
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.272183e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.090947e+00
Vprtstp: contraction number = 4.090947e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.003494e-06
Vprtstp: contraction number = 2.009284e-01
Vnewton: Using errtol_s: 3.681852
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.351997e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.216453e-01
Vprtstp: contraction number = 9.216453e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.260761e-07
Vprtstp: contraction number = 2.252890e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.049690e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.733930e-01
Vpmg_setPart:  lower corner = (-5.346, -24.125, -27.327)
Vpmg_setPart:  upper corner = (85.857, 61, 56.694)
Vpmg_setPart:  actual minima = (-5.346, -24.125, -27.327)
Vpmg_setPart:  actual maxima = (85.857, 61, 56.694)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 4.654, -14.125, -17.327
VPMG::focusFillBound -- New mesh maxs = 75.857, 51, 46.694
VPMG::focusFillBound -- Old mesh mins = -5.346, -24.125, -27.327
VPMG::focusFillBound -- Old mesh maxs = 85.857, 61, 56.694
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.421849
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.930370e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.016300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.004800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.178828e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4607063.477971
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.233678e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.861775e+05
Vprtstp: contraction number = 3.861775e+05
Vnewton: Attempting damping, relres = 0.075942
Vnewton: Attempting damping, relres = 0.534027
Vnewton: Damping accepted, relres = 0.075942
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.594188e-02
Vprtstp: contraction number = 7.594188e-02
Vnewton: Using errtol_s: 349869.040004
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.343562e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.869382e+04
Vprtstp: contraction number = 4.869382e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.513860e-03
Vprtstp: contraction number = 1.252782e-01
Vnewton: Using errtol_s: 43830.955454
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.427154e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.225896e+03
Vprtstp: contraction number = 7.225896e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.411627e-03
Vprtstp: contraction number = 1.483758e-01
Vnewton: Using errtol_s: 6503.455269
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.511049e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.191818e+03
Vprtstp: contraction number = 1.191818e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.328252e-04
Vprtstp: contraction number = 1.649340e-01
Vnewton: Using errtol_s: 1072.640583
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.595584e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.068332e+02
Vprtstp: contraction number = 2.068332e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.040534e-05
Vprtstp: contraction number = 1.735437e-01
Vnewton: Using errtol_s: 186.149973
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.679393e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.673601e+01
Vprtstp: contraction number = 3.673601e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.176461e-06
Vprtstp: contraction number = 1.776117e-01
Vnewton: Using errtol_s: 33.062412
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.763010e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.994400e+00
Vprtstp: contraction number = 6.994400e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.366371e-06
Vprtstp: contraction number = 1.903963e-01
Vnewton: Using errtol_s: 6.294960
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.846600e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.478367e+00
Vprtstp: contraction number = 1.478367e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.888023e-07
Vprtstp: contraction number = 2.113644e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.299210e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.009460e-01
Vpmg_setPart:  lower corner = (4.654, -14.125, -17.327)
Vpmg_setPart:  upper corner = (75.857, 51, 46.694)
Vpmg_setPart:  actual minima = (4.654, -14.125, -17.327)
Vpmg_setPart:  actual maxima = (75.857, 51, 46.694)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.107459e+00
