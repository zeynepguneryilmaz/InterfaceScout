##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:50 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7002 atoms
Valist_getStatistics:  Max atom coordinate:  (124.994, 86.429, 69.912)
Valist_getStatistics:  Min atom coordinate:  (61.002, 24.367, 19.934)
Valist_getStatistics:  Molecule center:  (92.998, 55.398, 44.923)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.812438, 0.797359, 0.937271
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.656188, 0.641109, 0.728937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.807678, 0.804041, 0.777723 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 144.994 106.429 89.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 41.002 4.367 -0.066
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 134.994 96.429 79.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 51.002 14.367 9.934
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 134.994 96.429 79.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 51.002 14.367 9.934
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.907617
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.269832e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.517000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.943800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.435205e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.194894e-02
Vprtstp: contraction number = 6.194894e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.779521e-03
Vprtstp: contraction number = 1.417219e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.702411e-03
Vprtstp: contraction number = 1.939070e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.331637e-04
Vprtstp: contraction number = 2.544413e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.193932e-04
Vprtstp: contraction number = 2.756306e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.138242e-05
Vprtstp: contraction number = 3.466063e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.322526e-05
Vprtstp: contraction number = 3.195864e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.242757e-06
Vprtstp: contraction number = 3.964200e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.752268e-06
Vprtstp: contraction number = 3.342265e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.429072e-07
Vprtstp: contraction number = 4.239689e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.025150e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.482530e-01
Vpmg_setPart:  lower corner = (41.002, 4.367, -0.066)
Vpmg_setPart:  upper corner = (144.994, 106.429, 89.912)
Vpmg_setPart:  actual minima = (41.002, 4.367, -0.066)
Vpmg_setPart:  actual maxima = (144.994, 106.429, 89.912)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 51.002, 14.367, 9.934
VPMG::focusFillBound -- New mesh maxs = 134.994, 96.429, 79.912
VPMG::focusFillBound -- Old mesh mins = 41.002, 4.367, -0.066
VPMG::focusFillBound -- Old mesh maxs = 144.994, 106.429, 89.912
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.903537
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.396832e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.556100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.086400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.687805e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.102131e-02
Vprtstp: contraction number = 8.102131e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.098575e-02
Vprtstp: contraction number = 1.355909e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.862737e-03
Vprtstp: contraction number = 1.695593e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.179962e-04
Vprtstp: contraction number = 2.243990e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.090504e-04
Vprtstp: contraction number = 2.608886e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.604231e-05
Vprtstp: contraction number = 3.305105e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.215704e-05
Vprtstp: contraction number = 3.372993e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.732859e-06
Vprtstp: contraction number = 3.893100e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.763097e-06
Vprtstp: contraction number = 3.725227e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.248123e-07
Vprtstp: contraction number = 4.111017e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.201060e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.689360e-01
Vpmg_setPart:  lower corner = (51.002, 14.367, 9.934)
Vpmg_setPart:  upper corner = (134.994, 96.429, 79.912)
Vpmg_setPart:  actual minima = (51.002, 14.367, 9.934)
Vpmg_setPart:  actual maxima = (134.994, 96.429, 79.912)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.768601e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7002 atoms
Valist_getStatistics:  Max atom coordinate:  (124.994, 86.429, 69.912)
Valist_getStatistics:  Min atom coordinate:  (61.002, 24.367, 19.934)
Valist_getStatistics:  Molecule center:  (92.998, 55.398, 44.923)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.812438, 0.797359, 0.937271
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.656188, 0.641109, 0.728937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.807678, 0.804041, 0.777723 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 144.994 106.429 89.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 41.002 4.367 -0.066
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 134.994 96.429 79.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 51.002 14.367 9.934
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 134.994 96.429 79.912
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 51.002 14.367 9.934
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.912646
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.274800e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.355200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.939500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.416115e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8294377.330124
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.521528e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.185001e+05
Vprtstp: contraction number = 5.185001e+05
Vnewton: Attempting damping, relres = 0.103704
Vnewton: Attempting damping, relres = 0.524223
Vnewton: Damping accepted, relres = 0.103704
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.037037e-01
Vprtstp: contraction number = 1.037037e-01
Vnewton: Using errtol_s: 860157.854112
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.728011e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.648062e+04
Vprtstp: contraction number = 7.648062e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.361474e-02
Vprtstp: contraction number = 2.277135e-01
Vnewton: Using errtol_s: 195869.525645
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.892469e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.905297e+04
Vprtstp: contraction number = 1.905297e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.004453e-03
Vprtstp: contraction number = 2.966136e-01
Vnewton: Using errtol_s: 58097.572183
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.052953e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.667903e+03
Vprtstp: contraction number = 6.667903e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.201692e-03
Vprtstp: contraction number = 3.143276e-01
Vnewton: Using errtol_s: 18261.667885
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.213430e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.433722e+03
Vprtstp: contraction number = 2.433722e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.208431e-04
Vprtstp: contraction number = 2.819845e-01
Vnewton: Using errtol_s: 5149.507283
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.371223e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.270097e+02
Vprtstp: contraction number = 8.270097e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.348554e-04
Vprtstp: contraction number = 2.172133e-01
Vnewton: Using errtol_s: 1118.541439
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.529697e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.133082e+02
Vprtstp: contraction number = 2.133082e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.432253e-05
Vprtstp: contraction number = 1.803601e-01
Vnewton: Using errtol_s: 201.740204
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.687672e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.489579e+01
Vprtstp: contraction number = 4.489579e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.872721e-06
Vprtstp: contraction number = 2.003378e-01
Vnewton: Using errtol_s: 40.416189
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.848338e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.457474e+00
Vprtstp: contraction number = 9.457474e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.026228e-06
Vprtstp: contraction number = 2.106068e-01
Vnewton: Using errtol_s: 8.511925
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.013480e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.406266e+00
Vprtstp: contraction number = 2.406266e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.610982e-07
Vprtstp: contraction number = 2.544250e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.725033e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.846938e+00
Vpmg_setPart:  lower corner = (41.002, 4.367, -0.066)
Vpmg_setPart:  upper corner = (144.994, 106.429, 89.912)
Vpmg_setPart:  actual minima = (41.002, 4.367, -0.066)
Vpmg_setPart:  actual maxima = (144.994, 106.429, 89.912)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 51.002, 14.367, 9.934
VPMG::focusFillBound -- New mesh maxs = 134.994, 96.429, 79.912
VPMG::focusFillBound -- Old mesh mins = 41.002, 4.367, -0.066
VPMG::focusFillBound -- Old mesh maxs = 144.994, 106.429, 89.912
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.907085
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.399835e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.499700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.020500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.669687e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9901210.784235
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.769737e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.593135e+05
Vprtstp: contraction number = 8.593135e+05
Vnewton: Attempting damping, relres = 0.112302
Vnewton: Attempting damping, relres = 0.536330
Vnewton: Damping accepted, relres = 0.112302
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.123023e-01
Vprtstp: contraction number = 1.123023e-01
Vnewton: Using errtol_s: 1111928.946780
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.976868e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.230635e+05
Vprtstp: contraction number = 1.230635e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.198447e-02
Vprtstp: contraction number = 1.957615e-01
Vnewton: Using errtol_s: 217672.912013
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.136375e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.491405e+04
Vprtstp: contraction number = 2.491405e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.718489e-03
Vprtstp: contraction number = 2.601149e-01
Vnewton: Using errtol_s: 56619.966502
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.294156e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.691861e+03
Vprtstp: contraction number = 6.691861e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.618407e-03
Vprtstp: contraction number = 2.830131e-01
Vnewton: Using errtol_s: 16024.192222
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.455024e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.110585e+03
Vprtstp: contraction number = 2.110585e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.095762e-04
Vprtstp: contraction number = 2.530736e-01
Vnewton: Using errtol_s: 4055.300329
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.610046e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.587460e+02
Vprtstp: contraction number = 6.587460e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.007944e-05
Vprtstp: contraction number = 1.955178e-01
Vnewton: Using errtol_s: 792.883427
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.763148e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.516666e+02
Vprtstp: contraction number = 1.516666e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.392559e-05
Vprtstp: contraction number = 1.738972e-01
Vnewton: Using errtol_s: 137.880198
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.911138e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.147367e+01
Vprtstp: contraction number = 3.147367e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.861497e-06
Vprtstp: contraction number = 2.054848e-01
Vnewton: Using errtol_s: 28.332283
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.065676e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.808954e+00
Vprtstp: contraction number = 6.808954e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.189212e-07
Vprtstp: contraction number = 2.162928e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.511977e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.636331e+00
Vpmg_setPart:  lower corner = (51.002, 14.367, 9.934)
Vpmg_setPart:  upper corner = (134.994, 96.429, 79.912)
Vpmg_setPart:  actual minima = (51.002, 14.367, 9.934)
Vpmg_setPart:  actual maxima = (134.994, 96.429, 79.912)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.539270e+00
