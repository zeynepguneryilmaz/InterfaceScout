##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7024 atoms
Valist_getStatistics:  Max atom coordinate:  (69.331, 30.413, 58.654)
Valist_getStatistics:  Min atom coordinate:  (0.469, -30.413, 10.198)
Valist_getStatistics:  Molecule center:  (34.9, 0, 34.426)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 34.9 0 34.426
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 34.9 0 34.426
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.850484, 0.787703, 0.921417
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.694234, 0.631453, 0.713083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.816281, 0.801638, 0.773899 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 34.9 0 34.426
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 89.331 50.413 78.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.531 -50.413 -9.802
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 79.331 40.413 68.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -9.531 -40.413 0.198
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 79.331 40.413 68.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -9.531 -40.413 0.198
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.1327
Vpbe_ctor2:  solute dimensions = 70.56 x 63.6 x 50.789
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (81.642, 73.606, 61.236)
Vclist_setupGrid:  Grid lower corner = (-5.921, -36.803, 3.808)
Vclist_assignAtoms:  Have 7967974 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.916923
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.247952e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.403100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.871800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.411705e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.764265e-02
Vprtstp: contraction number = 5.764265e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.519633e-03
Vprtstp: contraction number = 1.304526e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.617172e-03
Vprtstp: contraction number = 2.150600e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.046851e-04
Vprtstp: contraction number = 3.120788e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.163926e-04
Vprtstp: contraction number = 4.287676e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.241820e-05
Vprtstp: contraction number = 4.270857e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.939327e-05
Vprtstp: contraction number = 5.344539e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.166292e-05
Vprtstp: contraction number = 4.385804e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.207093e-05
Vprtstp: contraction number = 5.572162e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.244421e-06
Vprtstp: contraction number = 4.344670e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.957705e-06
Vprtstp: contraction number = 5.639718e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.274787e-06
Vprtstp: contraction number = 4.310055e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.231236e-07
Vprtstp: contraction number = 5.672505e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.613160e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.105709e+00
Vpmg_setPart:  lower corner = (-19.531, -50.413, -9.802)
Vpmg_setPart:  upper corner = (89.331, 50.413, 78.654)
Vpmg_setPart:  actual minima = (-19.531, -50.413, -9.802)
Vpmg_setPart:  actual maxima = (89.331, 50.413, 78.654)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.1327
Vpbe_ctor2:  solute dimensions = 70.56 x 63.6 x 50.789
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (81.642, 73.606, 61.236)
Vclist_setupGrid:  Grid lower corner = (-5.921, -36.803, 3.808)
Vclist_assignAtoms:  Have 7967974 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -9.531, -40.413, 0.198
VPMG::focusFillBound -- New mesh maxs = 79.331, 40.413, 68.654
VPMG::focusFillBound -- Old mesh mins = -19.531, -50.413, -9.802
VPMG::focusFillBound -- Old mesh maxs = 89.331, 50.413, 78.654
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.912810
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.358287e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.484600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.958800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.882066e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.640610e-02
Vprtstp: contraction number = 7.640610e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.853934e-03
Vprtstp: contraction number = 1.289679e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.755881e-03
Vprtstp: contraction number = 1.781909e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.560367e-04
Vprtstp: contraction number = 2.597196e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.760262e-04
Vprtstp: contraction number = 3.859913e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.633764e-05
Vprtstp: contraction number = 4.336720e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.162776e-05
Vprtstp: contraction number = 5.453111e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.928853e-05
Vprtstp: contraction number = 4.633574e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.119756e-05
Vprtstp: contraction number = 5.805293e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.150120e-06
Vprtstp: contraction number = 4.599324e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.043312e-06
Vprtstp: contraction number = 5.909206e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.387227e-06
Vprtstp: contraction number = 4.558280e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.272410e-07
Vprtstp: contraction number = 5.963272e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.504930e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.096867e+00
Vpmg_setPart:  lower corner = (-9.531, -40.413, 0.198)
Vpmg_setPart:  upper corner = (79.331, 40.413, 68.654)
Vpmg_setPart:  actual minima = (-9.531, -40.413, 0.198)
Vpmg_setPart:  actual maxima = (79.331, 40.413, 68.654)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.189211e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:31 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7024 atoms
Valist_getStatistics:  Max atom coordinate:  (69.331, 30.413, 58.654)
Valist_getStatistics:  Min atom coordinate:  (0.469, -30.413, 10.198)
Valist_getStatistics:  Molecule center:  (34.9, 0, 34.426)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 34.9 0 34.426
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 34.9 0 34.426
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.850484, 0.787703, 0.921417
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.694234, 0.631453, 0.713083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.816281, 0.801638, 0.773899 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 34.9 0 34.426
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 89.331 50.413 78.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.531 -50.413 -9.802
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 79.331 40.413 68.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -9.531 -40.413 0.198
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 79.331 40.413 68.654
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -9.531 -40.413 0.198
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.1327
Vpbe_ctor2:  solute dimensions = 70.56 x 63.6 x 50.789
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (81.642, 73.606, 61.236)
Vclist_setupGrid:  Grid lower corner = (-5.921, -36.803, 3.808)
Vclist_assignAtoms:  Have 7967974 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.920144
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.254738e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.394900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.821900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.395505e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8009163.772639
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.494394e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.649717e+05
Vprtstp: contraction number = 4.649717e+05
Vnewton: Attempting damping, relres = 0.054421
Vnewton: Attempting damping, relres = 0.521249
Vnewton: Damping accepted, relres = 0.054421
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.442123e-02
Vprtstp: contraction number = 5.442123e-02
Vnewton: Using errtol_s: 435868.551141
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.693155e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.718819e+04
Vprtstp: contraction number = 5.718819e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.497944e-03
Vprtstp: contraction number = 1.194009e-01
Vnewton: Using errtol_s: 52043.101473
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.845637e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.597622e+03
Vprtstp: contraction number = 8.597622e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.670194e-04
Vprtstp: contraction number = 1.488193e-01
Vnewton: Using errtol_s: 7745.017075
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.003006e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.461081e+03
Vprtstp: contraction number = 1.461081e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.642303e-04
Vprtstp: contraction number = 1.698314e-01
Vnewton: Using errtol_s: 1315.347240
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.157807e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.684181e+02
Vprtstp: contraction number = 2.684181e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.016619e-05
Vprtstp: contraction number = 1.836823e-01
Vnewton: Using errtol_s: 241.605985
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.308859e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.225290e+01
Vprtstp: contraction number = 5.225290e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.871957e-06
Vprtstp: contraction number = 1.946536e-01
Vnewton: Using errtol_s: 47.029467
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.459489e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.098055e+01
Vprtstp: contraction number = 1.098055e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.233912e-06
Vprtstp: contraction number = 2.101364e-01
Vnewton: Using errtol_s: 9.882602
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.610246e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.502761e+00
Vprtstp: contraction number = 2.502761e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.812393e-07
Vprtstp: contraction number = 2.279249e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.333031e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.454099e+00
Vpmg_setPart:  lower corner = (-19.531, -50.413, -9.802)
Vpmg_setPart:  upper corner = (89.331, 50.413, 78.654)
Vpmg_setPart:  actual minima = (-19.531, -50.413, -9.802)
Vpmg_setPart:  actual maxima = (89.331, 50.413, 78.654)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.1327
Vpbe_ctor2:  solute dimensions = 70.56 x 63.6 x 50.789
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (81.642, 73.606, 61.236)
Vclist_setupGrid:  Grid lower corner = (-5.921, -36.803, 3.808)
Vclist_assignAtoms:  Have 7967974 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -9.531, -40.413, 0.198
VPMG::focusFillBound -- New mesh maxs = 79.331, 40.413, 68.654
VPMG::focusFillBound -- Old mesh mins = -19.531, -50.413, -9.802
VPMG::focusFillBound -- Old mesh maxs = 89.331, 50.413, 78.654
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.914047
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.361071e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.491800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.036700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.219148e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9592603.552640
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.317189e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.790568e+05
Vprtstp: contraction number = 7.790568e+05
Vnewton: Attempting damping, relres = 0.074800
Vnewton: Attempting damping, relres = 0.532891
Vnewton: Damping accepted, relres = 0.074800
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.479969e-02
Vprtstp: contraction number = 7.479969e-02
Vnewton: Using errtol_s: 717523.745569
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.518753e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.663041e+04
Vprtstp: contraction number = 9.663041e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.117175e-03
Vprtstp: contraction number = 1.218879e-01
Vnewton: Using errtol_s: 87457.448364
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.672548e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.415869e+04
Vprtstp: contraction number = 1.415869e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.329025e-03
Vprtstp: contraction number = 1.457716e-01
Vnewton: Using errtol_s: 12748.809533
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.824291e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.303027e+03
Vprtstp: contraction number = 2.303027e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.161615e-04
Vprtstp: contraction number = 1.626466e-01
Vnewton: Using errtol_s: 2073.551111
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.978347e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.963617e+02
Vprtstp: contraction number = 3.963617e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.719960e-05
Vprtstp: contraction number = 1.720917e-01
Vnewton: Using errtol_s: 356.840985
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.131573e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.942723e+01
Vprtstp: contraction number = 6.942723e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.514607e-06
Vprtstp: contraction number = 1.751257e-01
Vnewton: Using errtol_s: 62.492043
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.284388e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.315329e+01
Vprtstp: contraction number = 1.315329e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.234104e-06
Vprtstp: contraction number = 1.894365e-01
Vnewton: Using errtol_s: 11.838271
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.440598e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.808541e+00
Vprtstp: contraction number = 2.808541e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.635050e-07
Vprtstp: contraction number = 2.135193e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.337950e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.462383e+00
Vpmg_setPart:  lower corner = (-9.531, -40.413, 0.198)
Vpmg_setPart:  upper corner = (79.331, 40.413, 68.654)
Vpmg_setPart:  actual minima = (-9.531, -40.413, 0.198)
Vpmg_setPart:  actual maxima = (79.331, 40.413, 68.654)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.921867e+00
