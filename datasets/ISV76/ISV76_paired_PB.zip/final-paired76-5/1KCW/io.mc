##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:25:51 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16085 atoms
Valist_getStatistics:  Max atom coordinate:  (173.688, 74.257, 44.56)
Valist_getStatistics:  Min atom coordinate:  (96.627, -11.936, -38.103)
Valist_getStatistics:  Molecule center:  (135.157, 31.1605, 3.2285)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.914539, 0.788706, 0.958305
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.758289, 0.663706, 0.802055
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.829149, 0.841513, 0.836952 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 193.688 94.257 64.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 76.627 -31.936 -58.103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 183.688 84.257 54.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 86.627 -21.936 -48.103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 183.688 84.257 54.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 86.627 -21.936 -48.103
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -37
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9497282 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.419010
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.985074e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.614400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.704230e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.286294e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.581259e-02
Vprtstp: contraction number = 6.581259e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.270006e-02
Vprtstp: contraction number = 1.929731e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.934577e-03
Vprtstp: contraction number = 3.885475e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.764691e-03
Vprtstp: contraction number = 3.576174e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.001847e-03
Vprtstp: contraction number = 5.677181e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.220737e-04
Vprtstp: contraction number = 4.212956e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.624489e-04
Vprtstp: contraction number = 6.218082e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.192919e-04
Vprtstp: contraction number = 4.545338e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.661524e-05
Vprtstp: contraction number = 6.422501e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.618182e-05
Vprtstp: contraction number = 4.722536e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.343706e-05
Vprtstp: contraction number = 6.477578e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.127430e-05
Vprtstp: contraction number = 4.810458e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.306218e-06
Vprtstp: contraction number = 6.480420e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.548018e-06
Vprtstp: contraction number = 4.856162e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.295395e-06
Vprtstp: contraction number = 6.469516e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.120487e-06
Vprtstp: contraction number = 4.881453e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 7.235535e-07
Vprtstp: contraction number = 6.457493e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.299976e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.562250e+00
Vpmg_setPart:  lower corner = (76.627, -31.936, -58.103)
Vpmg_setPart:  upper corner = (193.688, 94.257, 64.56)
Vpmg_setPart:  actual minima = (76.627, -31.936, -58.103)
Vpmg_setPart:  actual maxima = (193.688, 94.257, 64.56)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -37
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9497282 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 86.627, -21.936, -48.103
VPMG::focusFillBound -- New mesh maxs = 183.688, 84.257, 54.56
VPMG::focusFillBound -- Old mesh mins = 76.627, -31.936, -58.103
VPMG::focusFillBound -- Old mesh maxs = 193.688, 94.257, 64.56
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.400958
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.121393e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.911400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.707540e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.982828e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.370073e-02
Vprtstp: contraction number = 7.370073e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.193821e-02
Vprtstp: contraction number = 1.619823e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.893220e-03
Vprtstp: contraction number = 3.261142e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.309141e-03
Vprtstp: contraction number = 3.362619e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.309684e-04
Vprtstp: contraction number = 5.583572e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.933356e-04
Vprtstp: contraction number = 4.012972e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.755837e-04
Vprtstp: contraction number = 5.985763e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.401116e-05
Vprtstp: contraction number = 4.215149e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.479782e-05
Vprtstp: contraction number = 6.052847e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.943150e-05
Vprtstp: contraction number = 4.337600e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.179797e-05
Vprtstp: contraction number = 6.071570e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.218787e-06
Vprtstp: contraction number = 4.423461e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.167935e-06
Vprtstp: contraction number = 6.070252e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.420855e-06
Vprtstp: contraction number = 4.485114e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 8.609694e-07
Vprtstp: contraction number = 6.059516e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.076952e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.343397e+00
Vpmg_setPart:  lower corner = (86.627, -21.936, -48.103)
Vpmg_setPart:  upper corner = (183.688, 84.257, 54.56)
Vpmg_setPart:  actual minima = (86.627, -21.936, -48.103)
Vpmg_setPart:  actual maxima = (183.688, 84.257, 54.56)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.166382e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:26:05 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16085 atoms
Valist_getStatistics:  Max atom coordinate:  (173.688, 74.257, 44.56)
Valist_getStatistics:  Min atom coordinate:  (96.627, -11.936, -38.103)
Valist_getStatistics:  Molecule center:  (135.157, 31.1605, 3.2285)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.914539, 0.788706, 0.958305
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.758289, 0.663706, 0.802055
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.829149, 0.841513, 0.836952 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 193.688 94.257 64.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 76.627 -31.936 -58.103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 183.688 84.257 54.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 86.627 -21.936 -48.103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 183.688 84.257 54.56
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 86.627 -21.936 -48.103
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -37
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9497282 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.419116
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.985793e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.604200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.164990e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.228872e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 17916263.678388
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.390349e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.035367e+06
Vprtstp: contraction number = 1.035367e+06
Vnewton: Attempting damping, relres = 38.425271
Vnewton: Attempting damping, relres = 0.553271
Vnewton: Attempting damping, relres = 0.761185
Vnewton: Damping accepted, relres = 0.553271
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.532707e-01
Vprtstp: contraction number = 5.532707e-01
Vnewton: Using errtol_s: 9912544.185271
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.805782e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.843015e+05
Vprtstp: contraction number = 5.843015e+05
Vnewton: Attempting damping, relres = 0.039644
Vnewton: Attempting damping, relres = 0.291802
Vnewton: Damping accepted, relres = 0.039644
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.964354e-02
Vprtstp: contraction number = 7.165306e-02
Vnewton: Using errtol_s: 710264.091073
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.160314e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.332095e+04
Vprtstp: contraction number = 8.332095e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.082064e-03
Vprtstp: contraction number = 1.786436e-01
Vnewton: Using errtol_s: 126884.125915
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.427754e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.634705e+04
Vprtstp: contraction number = 1.634705e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.504341e-03
Vprtstp: contraction number = 2.124156e-01
Vnewton: Using errtol_s: 26952.164019
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.696124e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.912542e+03
Vprtstp: contraction number = 3.912542e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.896560e-04
Vprtstp: contraction number = 1.925468e-01
Vnewton: Using errtol_s: 5189.552467
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.963576e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.588116e+02
Vprtstp: contraction number = 9.588116e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.111678e-05
Vprtstp: contraction number = 1.764741e-01
Vnewton: Using errtol_s: 915.821739
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.231899e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.185053e+02
Vprtstp: contraction number = 2.185053e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.098210e-05
Vprtstp: contraction number = 2.148433e-01
Vnewton: Using errtol_s: 196.758172
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.503996e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.574192e+01
Vprtstp: contraction number = 4.574192e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.297988e-06
Vprtstp: contraction number = 2.092485e-01
Vnewton: Using errtol_s: 41.171359
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.772819e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.002727e+01
Vprtstp: contraction number = 1.002727e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.037076e-07
Vprtstp: contraction number = 2.191951e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.752106e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.955668e+00
Vpmg_setPart:  lower corner = (76.627, -31.936, -58.103)
Vpmg_setPart:  upper corner = (193.688, 94.257, 64.56)
Vpmg_setPart:  actual minima = (76.627, -31.936, -58.103)
Vpmg_setPart:  actual maxima = (193.688, 94.257, 64.56)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -37
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9497282 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 86.627, -21.936, -48.103
VPMG::focusFillBound -- New mesh maxs = 183.688, 84.257, 54.56
VPMG::focusFillBound -- Old mesh mins = 76.627, -31.936, -58.103
VPMG::focusFillBound -- Old mesh maxs = 193.688, 94.257, 64.56
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.396311
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.118558e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.822700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.152810e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.313258e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 20776957.009435
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.474814e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.505091e+06
Vprtstp: contraction number = 1.505091e+06
Vnewton: Attempting damping, relres = 46.094113
Vnewton: Attempting damping, relres = 0.557956
Vnewton: Attempting damping, relres = 0.764842
Vnewton: Damping accepted, relres = 0.557956
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.579565e-01
Vprtstp: contraction number = 5.579565e-01
Vnewton: Using errtol_s: 11592637.338195
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.892208e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.515610e+05
Vprtstp: contraction number = 8.515610e+05
Vnewton: Attempting damping, relres = 0.046226
Vnewton: Attempting damping, relres = 0.298190
Vnewton: Damping accepted, relres = 0.046226
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.622609e-02
Vprtstp: contraction number = 8.284893e-02
Vnewton: Using errtol_s: 960437.557498
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.023825e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.193082e+05
Vprtstp: contraction number = 1.193082e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.852850e-03
Vprtstp: contraction number = 1.698792e-01
Vnewton: Using errtol_s: 163158.331839
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.050599e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.235017e+04
Vprtstp: contraction number = 2.235017e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.609921e-03
Vprtstp: contraction number = 2.050111e-01
Vnewton: Using errtol_s: 33449.262309
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.076936e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.270419e+03
Vprtstp: contraction number = 5.270419e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.153356e-04
Vprtstp: contraction number = 1.958702e-01
Vnewton: Using errtol_s: 6551.714260
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.103324e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.351383e+03
Vprtstp: contraction number = 1.351383e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.114668e-05
Vprtstp: contraction number = 1.939099e-01
Vnewton: Using errtol_s: 1270.441977
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.129781e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.260897e+02
Vprtstp: contraction number = 3.260897e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.413950e-05
Vprtstp: contraction number = 2.312391e-01
Vnewton: Using errtol_s: 293.775806
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.156577e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.008649e+01
Vprtstp: contraction number = 7.008649e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.036286e-06
Vprtstp: contraction number = 2.147378e-01
Vnewton: Using errtol_s: 63.084779
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.183248e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.805291e+01
Vprtstp: contraction number = 1.805291e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.820143e-07
Vprtstp: contraction number = 2.575562e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.723431e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.929082e+00
Vpmg_setPart:  lower corner = (86.627, -21.936, -48.103)
Vpmg_setPart:  upper corner = (183.688, 84.257, 54.56)
Vpmg_setPart:  actual minima = (86.627, -21.936, -48.103)
Vpmg_setPart:  actual maxima = (183.688, 84.257, 54.56)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.266087e+01
