##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:46:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 513)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.650164, 0.675063, 0.522793
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.493914, 0.466729, 0.48373
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.895925
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.477151e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 513)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.020230e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 257)
Vbuildops: Galer: (033, 025, 129)
Vbuildops: Galer: (017, 013, 065)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.328020e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.258400e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 25538599753.787674
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.723664e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.408612e+09
Vprtstp: contraction number = 4.408612e+09
Vnewton: Attempting damping, relres = 121637405960958165197754501955584.000000
Vnewton: Attempting damping, relres = 110768264285135862135366728286208.000000
Vnewton: Attempting damping, relres = 99309804182068436717440826605568.000000
Vnewton: Attempting damping, relres = 86634906023125135504897113849856.000000
Vnewton: Attempting damping, relres = 65863518392446525862762053107712.000000
Vnewton: Attempting damping, relres = 32586089542955693553866648846336.000000
Vnewton: Attempting damping, relres = 12471912714484738243860465975296.000000
Vnewton: Attempting damping, relres = 4314942019482990518463121850368.000000
Vnewton: Attempting damping, relres = 856512457291139458363572617216.000000
Vnewton: Attempting damping, relres = 2924866531801334806478848.000000
Vnewton: Attempting damping, relres = 45910319.377869
Vnewton: Damping accepted, relres = 2924866531801334806478848.000000
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.924867e+24
Vprtstp: contraction number = 2.924867e+24
Vnewton: Using errtol_s: 74696995688923373034888290069643264.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.081837e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.093043e+08
Vprtstp: contraction number = 6.093043e+08
Vnewton: Attempting damping, relres = 28553113064928362193652891516928.000000
Vnewton: Attempting damping, relres = 19182931336198714530241932427264.000000
Vnewton: Attempting damping, relres = 10917836389881782593611815190528.000000
Vnewton: Attempting damping, relres = 4433922908335301708821357920256.000000
Vnewton: Attempting damping, relres = 753952099319993003895745937408.000000
Vnewton: Attempting damping, relres = 2834879489151636391067648.000000
Vnewton: Attempting damping, relres = 2879520679274779273854976.000000
Vnewton: Damping accepted, relres = 2834879489151636391067648.000000
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.834879e+24
Vprtstp: contraction number = 9.692338e-01
Vnewton: Using errtol_s: 72398852623665705065713696637976576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.782446e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.363611e+07
Vprtstp: contraction number = 2.363611e+07
Vnewton: Attempting damping, relres = 225384789602279558217962881024.000000
Vnewton: Attempting damping, relres = 1719441348842116427546624.000000
Vnewton: Attempting damping, relres = 2207806366064321732018176.000000
Vnewton: Damping accepted, relres = 1719441348842116427546624.000000
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.719441e+24
Vprtstp: contraction number = 6.065307e-01
Vnewton: Using errtol_s: 43912124408191619904941561300910080.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.078848e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.229185e+06
Vprtstp: contraction number = 4.229185e+06
Vnewton: Attempting damping, relres = 632547122539134153916416.000000
Vnewton: Attempting damping, relres = 1042893895650407549501440.000000
Vnewton: Damping accepted, relres = 632547122539134153916416.000000
Vnewton: Damping disabled
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.325471e+23
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 16154367787937034136811711651381248.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.161989e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.142271e+06
Vprtstp: contraction number = 2.142271e+06
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.327011e+23
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5942859794303994411459998272978944.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.226164e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.727316e+06
Vprtstp: contraction number = 1.727316e+06
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.560594e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2186255940088887473849953740128256.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.290652e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.517702e+06
Vprtstp: contraction number = 1.517702e+06
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.149267e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 804278613497616353206808447287296.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.354417e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.361450e+06
Vprtstp: contraction number = 1.361450e+06
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.158550e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 295877566879635675705969918083072.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.418324e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.216268e+06
Vprtstp: contraction number = 1.216268e+06
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.262069e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 108847273958850825253054348001280.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.482361e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.086508e+06
Vprtstp: contraction number = 1.086508e+06
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.567928e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 40042674317015686619974353289216.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.546249e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.848326e+05
Vprtstp: contraction number = 9.848326e+05
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.768083e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 14730876650754257475754902159360.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.610304e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.144516e+05
Vprtstp: contraction number = 9.144516e+05
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.121959e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5419186670244775079822084800512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.674379e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.431131e+05
Vprtstp: contraction number = 8.431131e+05
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.806252e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1993607363853485423619064463360.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.738060e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.634386e+05
Vprtstp: contraction number = 7.634386e+05
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.871759e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 733407162929660492747070504960.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.802482e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.826618e+05
Vprtstp: contraction number = 6.826618e+05
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.056461e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 269805417249707369394834767872.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.866280e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.211036e+05
Vprtstp: contraction number = 6.211036e+05
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.886504e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 99255866122847361476750999552.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.930082e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.841161e+05
Vprtstp: contraction number = 5.841161e+05
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.429765e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 36514192562258732152814305280.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.993771e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.614423e+05
Vprtstp: contraction number = 5.614423e+05
Vprtstp: iteration = 18
Vprtstp: relative residual = 5.259811e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 13432820754630909635057418240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.057548e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.354083e+05
Vprtstp: contraction number = 5.354083e+05
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.934976e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4941658592569638876507799552.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.121257e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.974155e+05
Vprtstp: contraction number = 4.974155e+05
Vprtstp: iteration = 20
Vprtstp: relative residual = 7.118380e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1817934601494640826744045568.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.186414e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.462164e+05
Vprtstp: contraction number = 4.462164e+05
Vprtstp: iteration = 21
Vprtstp: relative residual = 2.618706e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 668780765284058220738904064.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.250042e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.881521e+05
Vprtstp: contraction number = 3.881521e+05
Vprtstp: iteration = 22
Vprtstp: relative residual = 9.633680e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 246030694198920273928912896.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.313604e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.306354e+05
Vprtstp: contraction number = 3.306354e+05
Vprtstp: iteration = 23
Vprtstp: relative residual = 3.544033e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 90509634292916843477729280.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.377054e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.799760e+05
Vprtstp: contraction number = 2.799760e+05
Vprtstp: iteration = 24
Vprtstp: relative residual = 1.303777e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 33296633684311512591630336.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.440537e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.453366e+05
Vprtstp: contraction number = 2.453366e+05
Vprtstp: iteration = 25
Vprtstp: relative residual = 4.796327e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 12249146992674425597329408.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.504341e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.229438e+05
Vprtstp: contraction number = 2.229438e+05
Vprtstp: iteration = 26
Vprtstp: relative residual = 1.764470e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4506209350491702414016512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.567951e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.045017e+05
Vprtstp: contraction number = 2.045017e+05
Vprtstp: iteration = 27
Vprtstp: relative residual = 6.491122e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1657741777660486034128896.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.631632e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.858569e+05
Vprtstp: contraction number = 1.858569e+05
Vprtstp: iteration = 28
Vprtstp: relative residual = 2.387950e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 609849118772276446101504.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.696614e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.659664e+05
Vprtstp: contraction number = 1.659664e+05
Vprtstp: iteration = 29
Vprtstp: relative residual = 8.784779e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 224350953012846756102144.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.760532e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.488989e+05
Vprtstp: contraction number = 1.488989e+05
Vprtstp: iteration = 30
Vprtstp: relative residual = 3.231740e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 82534103220641584906240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.824331e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.363632e+05
Vprtstp: contraction number = 1.363632e+05
Vprtstp: iteration = 31
Vprtstp: relative residual = 1.188891e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 30362599770394594377728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.888187e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.279958e+05
Vprtstp: contraction number = 1.279958e+05
Vprtstp: iteration = 32
Vprtstp: relative residual = 4.373684e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 11169776236042261626880.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.951957e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.209901e+05
Vprtstp: contraction number = 1.209901e+05
Vprtstp: iteration = 33
Vprtstp: relative residual = 1.608988e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4109131039723313168384.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.015630e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.141335e+05
Vprtstp: contraction number = 1.141335e+05
Vprtstp: iteration = 34
Vprtstp: relative residual = 5.919137e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1511664830591592038400.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.079175e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.055598e+05
Vprtstp: contraction number = 1.055598e+05
Vprtstp: iteration = 35
Vprtstp: relative residual = 2.177529e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 556110413114679689216.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.143279e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.485906e+04
Vprtstp: contraction number = 9.485906e+04
Vprtstp: iteration = 36
Vprtstp: relative residual = 8.010681e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 204581588004545396736.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.207217e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.276259e+04
Vprtstp: contraction number = 8.276259e+04
Vprtstp: iteration = 37
Vprtstp: relative residual = 2.946965e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 75261360267525324800.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.271154e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.039101e+04
Vprtstp: contraction number = 7.039101e+04
Vprtstp: iteration = 38
Vprtstp: relative residual = 1.084128e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 27687107155606093824.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.335080e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.838650e+04
Vprtstp: contraction number = 5.838650e+04
Vprtstp: iteration = 39
Vprtstp: relative residual = 3.988283e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 10185517506760407040.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.398775e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.719599e+04
Vprtstp: contraction number = 4.719599e+04
Vprtstp: iteration = 40
Vprtstp: relative residual = 1.467207e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3747042487227361792.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.463385e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.812493e+04
Vprtstp: contraction number = 3.812493e+04
Vprtstp: iteration = 41
Vprtstp: relative residual = 5.397555e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1378459895126311168.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.527075e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.230179e+04
Vprtstp: contraction number = 3.230179e+04
Vprtstp: iteration = 42
Vprtstp: relative residual = 1.985649e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 507107054847000704.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.590966e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.891983e+04
Vprtstp: contraction number = 2.891983e+04
Vprtstp: iteration = 43
Vprtstp: relative residual = 7.304796e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 186554258969346208.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.655321e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.648267e+04
Vprtstp: contraction number = 2.648267e+04
Vprtstp: iteration = 44
Vprtstp: relative residual = 2.687284e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 68629475621807688.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.719314e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.434025e+04
Vprtstp: contraction number = 2.434025e+04
Vprtstp: iteration = 45
Vprtstp: relative residual = 9.885966e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 25247372288828208.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.783087e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.241194e+04
Vprtstp: contraction number = 2.241194e+04
Vprtstp: iteration = 46
Vprtstp: relative residual = 3.636843e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 9287988422896322.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.847355e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.064865e+04
Vprtstp: contraction number = 2.064865e+04
Vprtstp: iteration = 47
Vprtstp: relative residual = 1.337920e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3416859269451692.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.911636e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.894560e+04
Vprtstp: contraction number = 1.894560e+04
Vprtstp: iteration = 48
Vprtstp: relative residual = 4.921929e+04
Vprtstp: contraction number = 3.678792e-01
Vnewton: Using errtol_s: 1256991621520755.250000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.976522e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.718533e+04
Vprtstp: contraction number = 1.718533e+04
Vprtstp: iteration = 49
Vprtstp: relative residual = 1.810674e+04
Vprtstp: contraction number = 3.678790e-01
Vnewton: Using errtol_s: 462420781936957.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.040611e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.530255e+04
Vprtstp: contraction number = 1.530255e+04
Vprtstp: iteration = 50
Vprtstp: relative residual = 6.661077e+03
Vprtstp: contraction number = 3.678783e-01
Vnewton: Using errtol_s: 170114569296340.781250
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.104805e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.340372e+04
Vprtstp: contraction number = 1.340372e+04
Vprtstp: iteration = 51
Vprtstp: relative residual = 2.450455e+03
Vprtstp: contraction number = 3.678767e-01
Vnewton: Using errtol_s: 62581185463085.859375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.169160e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.161516e+04
Vprtstp: contraction number = 1.161516e+04
Vprtstp: iteration = 52
Vprtstp: relative residual = 9.014561e+02
Vprtstp: contraction number = 3.678730e-01
Vnewton: Using errtol_s: 23021925331426.011719
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.233481e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.005398e+04
Vprtstp: contraction number = 1.005398e+04
Vprtstp: iteration = 53
Vprtstp: relative residual = 3.316135e+02
Vprtstp: contraction number = 3.678643e-01
Vnewton: Using errtol_s: 8468944516886.936523
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.297798e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.624367e+03
Vprtstp: contraction number = 8.624367e+03
Vprtstp: iteration = 54
Vprtstp: relative residual = 1.219822e+02
Vprtstp: contraction number = 3.678445e-01
Vnewton: Using errtol_s: 3115254756864.401855
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.362206e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.216442e+03
Vprtstp: contraction number = 7.216442e+03
Vprtstp: iteration = 55
Vprtstp: relative residual = 4.486506e+01
Vprtstp: contraction number = 3.678000e-01
Vnewton: Using errtol_s: 1145790734337.832031
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.426616e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.869496e+03
Vprtstp: contraction number = 5.869496e+03
Vprtstp: iteration = 56
Vprtstp: relative residual = 1.649697e+01
Vprtstp: contraction number = 3.677020e-01
Vnewton: Using errtol_s: 421309520782.303406
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.491271e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.732482e+03
Vprtstp: contraction number = 4.732482e+03
Vprtstp: iteration = 57
Vprtstp: relative residual = 6.062467e+00
Vprtstp: contraction number = 3.674897e-01
Vnewton: Using errtol_s: 154826911149.164673
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.555860e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.893079e+03
Vprtstp: contraction number = 3.893079e+03
Vprtstp: iteration = 58
Vprtstp: relative residual = 2.225116e+00
Vprtstp: contraction number = 3.670315e-01
Vnewton: Using errtol_s: 56826346407.099739
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.620479e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.179685e+03
Vprtstp: contraction number = 3.179685e+03
Vprtstp: iteration = 59
Vprtstp: relative residual = 8.144481e-01
Vprtstp: contraction number = 3.660250e-01
Vnewton: Using errtol_s: 20799863246.263794
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.684888e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.484606e+03
Vprtstp: contraction number = 2.484606e+03
Vprtstp: iteration = 60
Vprtstp: relative residual = 2.962937e-01
Vprtstp: contraction number = 3.637970e-01
Vnewton: Using errtol_s: 7566927051.553210
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.749407e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.823163e+03
Vprtstp: contraction number = 1.823163e+03
Vprtstp: iteration = 61
Vprtstp: relative residual = 1.063487e-01
Vprtstp: contraction number = 3.589298e-01
Vnewton: Using errtol_s: 2715995635.790227
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.814265e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.248731e+03
Vprtstp: contraction number = 1.248731e+03
Vprtstp: iteration = 62
Vprtstp: relative residual = 3.708834e-02
Vprtstp: contraction number = 3.487429e-01
Vnewton: Using errtol_s: 947184274.840047
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.878956e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.655920e+02
Vprtstp: contraction number = 8.655920e+02
Vprtstp: iteration = 63
Vprtstp: relative residual = 1.219997e-02
Vprtstp: contraction number = 3.289436e-01
Vnewton: Using errtol_s: 311570181.710906
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.943665e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.413061e+02
Vprtstp: contraction number = 6.413061e+02
Vprtstp: iteration = 64
Vprtstp: relative residual = 3.585649e-03
Vprtstp: contraction number = 2.939063e-01
Vnewton: Using errtol_s: 91572445.921713
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.008255e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.894670e+02
Vprtstp: contraction number = 4.894670e+02
Vprtstp: iteration = 65
Vprtstp: relative residual = 8.536656e-04
Vprtstp: contraction number = 2.380784e-01
Vnewton: Using errtol_s: 21801423.624348
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.073141e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.496059e+02
Vprtstp: contraction number = 3.496059e+02
Vprtstp: iteration = 66
Vprtstp: relative residual = 1.319022e-04
Vprtstp: contraction number = 1.545128e-01
Vnewton: Using errtol_s: 3368598.344258
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.137941e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.944789e+02
Vprtstp: contraction number = 1.944789e+02
Vprtstp: iteration = 67
Vprtstp: relative residual = 7.517544e-06
Vprtstp: contraction number = 5.699330e-02
Vnewton: Using errtol_s: 191987.540790
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.202745e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.052243e+01
Vprtstp: contraction number = 6.052243e+01
Vprtstp: iteration = 68
Vprtstp: relative residual = 5.162849e-08
Vprtstp: contraction number = 6.867734e-03
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.724246e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.796207e+01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.64, 88.67, -12.701
VPMG::focusFillBound -- New mesh maxs = 142.861, 133.476, 234.969
VPMG::focusFillBound -- Old mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- Old mesh maxs = 152.861, 143.476, 244.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.886326
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.356870e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 513)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.013340e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 257)
Vbuildops: Galer: (033, 025, 129)
Vbuildops: Galer: (017, 013, 065)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.355340e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.860620e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 36360381.837061
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.908908e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.712305e+06
Vprtstp: contraction number = 4.712305e+06
Vnewton: Attempting damping, relres = 544.089100
Vnewton: Attempting damping, relres = 0.662227
Vnewton: Attempting damping, relres = 0.781684
Vnewton: Damping accepted, relres = 0.662227
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.622270e-01
Vprtstp: contraction number = 6.622270e-01
Vnewton: Using errtol_s: 24078828.346152
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.009886e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.691781e+06
Vprtstp: contraction number = 2.691781e+06
Vnewton: Attempting damping, relres = 0.099247
Vnewton: Attempting damping, relres = 0.372832
Vnewton: Damping accepted, relres = 0.099247
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.924749e-02
Vprtstp: contraction number = 1.498693e-01
Vnewton: Using errtol_s: 3608676.781392
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.093699e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.831013e+05
Vprtstp: contraction number = 3.831013e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.763754e-02
Vprtstp: contraction number = 1.777127e-01
Vnewton: Using errtol_s: 641307.542669
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.158176e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.666036e+04
Vprtstp: contraction number = 7.666036e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.678652e-03
Vprtstp: contraction number = 2.085695e-01
Vnewton: Using errtol_s: 133757.181625
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.222836e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.893800e+04
Vprtstp: contraction number = 1.893800e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.222976e-04
Vprtstp: contraction number = 1.963485e-01
Vnewton: Using errtol_s: 26263.018353
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.287374e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.534169e+03
Vprtstp: contraction number = 4.534169e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.261542e-04
Vprtstp: contraction number = 1.746568e-01
Vnewton: Using errtol_s: 4587.014354
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.351820e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.454948e+02
Vprtstp: contraction number = 9.454948e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.357109e-05
Vprtstp: contraction number = 1.868435e-01
Vnewton: Using errtol_s: 857.053704
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.416453e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.897628e+02
Vprtstp: contraction number = 1.897628e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.698053e-06
Vprtstp: contraction number = 1.993143e-01
Vnewton: Using errtol_s: 170.823017
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.481094e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.859501e+01
Vprtstp: contraction number = 3.859501e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.553195e-07
Vprtstp: contraction number = 2.033437e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.683004e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.405312e+00
Vpmg_setPart:  lower corner = (79.64, 88.67, -12.701)
Vpmg_setPart:  upper corner = (142.861, 133.476, 234.969)
Vpmg_setPart:  actual minima = (79.64, 88.67, -12.701)
Vpmg_setPart:  actual maxima = (142.861, 133.476, 234.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.680365e+01
