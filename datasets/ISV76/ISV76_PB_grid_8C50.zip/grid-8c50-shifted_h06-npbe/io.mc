##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:46:35 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 417)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.650164, 0.675063, 0.643437
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.493914, 0.466729, 0.595361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 153.161 143.776 245.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.94 78.97 -22.401
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 143.161 133.776 235.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.94 88.97 -12.401
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 143.161 133.776 235.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.94 88.97 -12.401
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.900358
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.811608e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.175540e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.350820e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.353338e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 25550252672.364388
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.604995e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.451615e+09
Vprtstp: contraction number = 3.451615e+09
Vnewton: Attempting damping, relres = 121555178060165058703852530827264.000000
Vnewton: Attempting damping, relres = 110669037015492292373302468411392.000000
Vnewton: Attempting damping, relres = 99191657970014722253302364372992.000000
Vnewton: Attempting damping, relres = 86488210923782237533076910505984.000000
Vnewton: Attempting damping, relres = 65567116850247512129010990579712.000000
Vnewton: Attempting damping, relres = 32125629021244507988284850307072.000000
Vnewton: Attempting damping, relres = 12335453183529344427671607574528.000000
Vnewton: Attempting damping, relres = 4275541683949275157011374276608.000000
Vnewton: Attempting damping, relres = 848925679409511988452122427392.000000
Vnewton: Attempting damping, relres = 451599752731902391353344.000000
Vnewton: Attempting damping, relres = 25868825.074878
Vnewton: Damping accepted, relres = 451599752731902391353344.000000
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.515998e+23
Vprtstp: contraction number = 4.515998e+23
Vnewton: Using errtol_s: 11538487789077384376114383087992832.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.901109e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.492010e+08
Vprtstp: contraction number = 4.492010e+08
Vnewton: Attempting damping, relres = 29444023836023914887321181224960.000000
Vnewton: Attempting damping, relres = 19542130367388018505925087199232.000000
Vnewton: Attempting damping, relres = 10988699544238768740548973953024.000000
Vnewton: Attempting damping, relres = 4380015305724126434141533110272.000000
Vnewton: Attempting damping, relres = 794419050915902520260460281856.000000
Vnewton: Attempting damping, relres = 437708588513777080598528.000000
Vnewton: Attempting damping, relres = 444598347517081545605120.000000
Vnewton: Damping accepted, relres = 437708588513777080598528.000000
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.377086e+23
Vprtstp: contraction number = 9.692401e-01
Vnewton: Using errtol_s: 11183565033390976815233657194151936.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.847570e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.805470e+07
Vprtstp: contraction number = 1.805470e+07
Vnewton: Attempting damping, relres = 211271665406921081045037088768.000000
Vnewton: Attempting damping, relres = 265506742738442843586560.000000
Vnewton: Attempting damping, relres = 340887791491618913124352.000000
Vnewton: Damping accepted, relres = 265506742738442843586560.000000
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.655067e+23
Vprtstp: contraction number = 6.065834e-01
Vnewton: Using errtol_s: 6783764363183662366258926402404352.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.436375e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.360920e+06
Vprtstp: contraction number = 3.360920e+06
Vnewton: Attempting damping, relres = 97674472145865312043008.000000
Vnewton: Attempting damping, relres = 161037979831299825729536.000000
Vnewton: Damping accepted, relres = 97674472145865312043008.000000
Vnewton: Damping disabled
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.767447e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2495607442966675968250760373731328.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.943778e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.755997e+06
Vprtstp: contraction number = 1.755997e+06
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.593243e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 918082671501900804807112517484544.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.347143e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.448689e+06
Vprtstp: contraction number = 1.448689e+06
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.321880e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 337743740141295585186431511822336.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.749107e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.274155e+06
Vprtstp: contraction number = 1.274155e+06
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.862926e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 124248978382336393091527150141440.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.149177e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.135492e+06
Vprtstp: contraction number = 1.135492e+06
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.788970e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 45708644733415231164405470199808.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.554171e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.010665e+06
Vprtstp: contraction number = 1.010665e+06
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.581254e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 16815270681233416354220008800256.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.961527e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.970481e+05
Vprtstp: contraction number = 8.970481e+05
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.421108e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 6185992381358515812749860143104.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.410831e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.118755e+05
Vprtstp: contraction number = 8.118755e+05
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.906759e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2275699420345033360462028210176.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.817501e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.484818e+05
Vprtstp: contraction number = 7.484818e+05
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.276614e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 837183031030691662065083351040.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.022108e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.896003e+05
Vprtstp: contraction number = 6.896003e+05
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.205399e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 307982425613776068016414392320.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.061854e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.186985e+05
Vprtstp: contraction number = 6.186985e+05
Vprtstp: iteration = 14
Vprtstp: relative residual = 4.434414e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 113300402625425626799408152576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.105947e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.515838e+05
Vprtstp: contraction number = 5.515838e+05
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.631330e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 41680888802339698363206729728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.145777e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.999415e+05
Vprtstp: contraction number = 4.999415e+05
Vprtstp: iteration = 16
Vprtstp: relative residual = 6.001327e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 15333542080134136305436065792.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.185646e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.695066e+05
Vprtstp: contraction number = 4.695066e+05
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.207765e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5640894891618470299539865600.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.225379e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.494364e+05
Vprtstp: contraction number = 4.494364e+05
Vprtstp: iteration = 18
Vprtstp: relative residual = 8.121913e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2075169260435492444013854720.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.270645e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.231452e+05
Vprtstp: contraction number = 4.231452e+05
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.987885e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 763412107865148627913539584.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.310611e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.890286e+05
Vprtstp: contraction number = 3.890286e+05
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.099181e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 280843619624935909553602560.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.350395e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.456199e+05
Vprtstp: contraction number = 3.456199e+05
Vprtstp: iteration = 21
Vprtstp: relative residual = 4.043662e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 103316593844189457155096576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.390259e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.956762e+05
Vprtstp: contraction number = 2.956762e+05
Vprtstp: iteration = 22
Vprtstp: relative residual = 1.487580e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 38008050807136958013243392.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.430470e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.477826e+05
Vprtstp: contraction number = 2.477826e+05
Vprtstp: iteration = 23
Vprtstp: relative residual = 5.472502e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 13982380490945659404288000.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.470529e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.131704e+05
Vprtstp: contraction number = 2.131704e+05
Vprtstp: iteration = 24
Vprtstp: relative residual = 2.013221e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5143830321255377354620928.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.511103e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.886016e+05
Vprtstp: contraction number = 1.886016e+05
Vprtstp: iteration = 25
Vprtstp: relative residual = 7.406226e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1892309424064195886841856.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.550860e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.721786e+05
Vprtstp: contraction number = 1.721786e+05
Vprtstp: iteration = 26
Vprtstp: relative residual = 2.724598e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 696141733448182229106688.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.591066e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.564526e+05
Vprtstp: contraction number = 1.564526e+05
Vprtstp: iteration = 27
Vprtstp: relative residual = 1.002324e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 256096231877038854635520.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.631440e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.393804e+05
Vprtstp: contraction number = 1.393804e+05
Vprtstp: iteration = 28
Vprtstp: relative residual = 3.687343e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 94212538669032328396800.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.671237e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.230189e+05
Vprtstp: contraction number = 1.230189e+05
Vprtstp: iteration = 29
Vprtstp: relative residual = 1.356498e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 34658856076902949453824.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.710725e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.109432e+05
Vprtstp: contraction number = 1.109432e+05
Vprtstp: iteration = 30
Vprtstp: relative residual = 4.990276e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 12750280605210377191424.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.749998e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.032470e+05
Vprtstp: contraction number = 1.032470e+05
Vprtstp: iteration = 31
Vprtstp: relative residual = 1.835820e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4690566103821389398016.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.789319e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.800683e+04
Vprtstp: contraction number = 9.800683e+04
Vprtstp: iteration = 32
Vprtstp: relative residual = 6.753604e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1725562837049239404544.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.828914e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.340957e+04
Vprtstp: contraction number = 9.340957e+04
Vprtstp: iteration = 33
Vprtstp: relative residual = 2.484512e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 634799092197642076160.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.868906e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.825830e+04
Vprtstp: contraction number = 8.825830e+04
Vprtstp: iteration = 34
Vprtstp: relative residual = 9.140009e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 233529535291713617920.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.912608e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.210371e+04
Vprtstp: contraction number = 8.210371e+04
Vprtstp: iteration = 35
Vprtstp: relative residual = 3.362421e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 85910714938179682304.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.952617e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.436791e+04
Vprtstp: contraction number = 7.436791e+04
Vprtstp: iteration = 36
Vprtstp: relative residual = 1.236966e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 31604785800287473664.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.992506e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.504612e+04
Vprtstp: contraction number = 6.504612e+04
Vprtstp: iteration = 37
Vprtstp: relative residual = 4.550542e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 11626750936898158592.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.032317e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.507392e+04
Vprtstp: contraction number = 5.507392e+04
Vprtstp: iteration = 38
Vprtstp: relative residual = 1.674051e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4277242635794692608.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.072357e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.528714e+04
Vprtstp: contraction number = 4.528714e+04
Vprtstp: iteration = 39
Vprtstp: relative residual = 6.158490e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1573509629223497728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.112495e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.652181e+04
Vprtstp: contraction number = 3.652181e+04
Vprtstp: iteration = 40
Vprtstp: relative residual = 2.265582e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 578861841789672448.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.152170e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.983589e+04
Vprtstp: contraction number = 2.983589e+04
Vprtstp: iteration = 41
Vprtstp: relative residual = 8.334609e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 212951369669403936.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.191734e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.559630e+04
Vprtstp: contraction number = 2.559630e+04
Vprtstp: iteration = 42
Vprtstp: relative residual = 3.066131e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 78340429739544560.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.232162e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.288062e+04
Vprtstp: contraction number = 2.288062e+04
Vprtstp: iteration = 43
Vprtstp: relative residual = 1.127967e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 28819832448474696.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.271360e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.082099e+04
Vprtstp: contraction number = 2.082099e+04
Vprtstp: iteration = 44
Vprtstp: relative residual = 4.149557e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 10602222855818738.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.310862e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.907442e+04
Vprtstp: contraction number = 1.907442e+04
Vprtstp: iteration = 45
Vprtstp: relative residual = 1.526536e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3900338884186347.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.351564e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.744727e+04
Vprtstp: contraction number = 1.744727e+04
Vprtstp: iteration = 46
Vprtstp: relative residual = 5.615810e+04
Vprtstp: contraction number = 3.678792e-01
Vnewton: Using errtol_s: 1434853616884023.500000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.391294e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.593939e+04
Vprtstp: contraction number = 1.593939e+04
Vprtstp: iteration = 47
Vprtstp: relative residual = 2.065938e+04
Vprtstp: contraction number = 3.678789e-01
Vnewton: Using errtol_s: 527852337840636.437500
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.430846e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.460797e+04
Vprtstp: contraction number = 1.460797e+04
Vprtstp: iteration = 48
Vprtstp: relative residual = 7.600131e+03
Vprtstp: contraction number = 3.678780e-01
Vnewton: Using errtol_s: 194185277184535.750000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.470922e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.338767e+04
Vprtstp: contraction number = 1.338767e+04
Vprtstp: iteration = 49
Vprtstp: relative residual = 2.795905e+03
Vprtstp: contraction number = 3.678759e-01
Vnewton: Using errtol_s: 71436087651635.984375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.511009e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.218804e+04
Vprtstp: contraction number = 1.218804e+04
Vprtstp: iteration = 50
Vprtstp: relative residual = 1.028532e+03
Vprtstp: contraction number = 3.678708e-01
Vnewton: Using errtol_s: 26279247169617.457031
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.550833e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.092769e+04
Vprtstp: contraction number = 1.092769e+04
Vprtstp: iteration = 51
Vprtstp: relative residual = 3.783538e+02
Vprtstp: contraction number = 3.678582e-01
Vnewton: Using errtol_s: 9667036007993.810547
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.590767e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.545438e+03
Vprtstp: contraction number = 9.545438e+03
Vprtstp: iteration = 52
Vprtstp: relative residual = 1.391692e+02
Vprtstp: contraction number = 3.678281e-01
Vnewton: Using errtol_s: 3555807135016.663086
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.631638e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.100281e+03
Vprtstp: contraction number = 8.100281e+03
Vprtstp: iteration = 53
Vprtstp: relative residual = 5.118046e+01
Vprtstp: contraction number = 3.677572e-01
Vnewton: Using errtol_s: 1307673693247.919434
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.678523e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.727471e+03
Vprtstp: contraction number = 6.727471e+03
Vprtstp: iteration = 54
Vprtstp: relative residual = 1.881361e+01
Vprtstp: contraction number = 3.675937e-01
Vnewton: Using errtol_s: 480692603416.225708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.724433e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.564489e+03
Vprtstp: contraction number = 5.564489e+03
Vprtstp: iteration = 55
Vprtstp: relative residual = 6.908881e+00
Vprtstp: contraction number = 3.672277e-01
Vnewton: Using errtol_s: 176523652108.784760
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.764924e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.521843e+03
Vprtstp: contraction number = 4.521843e+03
Vprtstp: iteration = 56
Vprtstp: relative residual = 2.531638e+00
Vprtstp: contraction number = 3.664324e-01
Vnewton: Using errtol_s: 64683988211.210243
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.805629e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.495719e+03
Vprtstp: contraction number = 3.495719e+03
Vprtstp: iteration = 57
Vprtstp: relative residual = 9.234126e-01
Vprtstp: contraction number = 3.647491e-01
Vnewton: Using errtol_s: 23593424896.011982
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.845701e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.506462e+03
Vprtstp: contraction number = 2.506462e+03
Vprtstp: iteration = 58
Vprtstp: relative residual = 3.335825e-01
Vprtstp: contraction number = 3.612497e-01
Vnewton: Using errtol_s: 8523117209.383275
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.886156e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.706859e+03
Vprtstp: contraction number = 1.706859e+03
Vprtstp: iteration = 59
Vprtstp: relative residual = 1.180907e-01
Vprtstp: contraction number = 3.540075e-01
Vnewton: Using errtol_s: 3017247671.042934
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.926551e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.183941e+03
Vprtstp: contraction number = 1.183941e+03
Vprtstp: iteration = 60
Vprtstp: relative residual = 4.009078e-02
Vprtstp: contraction number = 3.394914e-01
Vnewton: Using errtol_s: 1024329573.191014
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.966803e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.541513e+02
Vprtstp: contraction number = 8.541513e+02
Vprtstp: iteration = 61
Vprtstp: relative residual = 1.251676e-02
Vprtstp: contraction number = 3.122103e-01
Vnewton: Using errtol_s: 319806255.659988
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.008206e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.925978e+02
Vprtstp: contraction number = 5.925978e+02
Vprtstp: iteration = 62
Vprtstp: relative residual = 3.337458e-03
Vprtstp: contraction number = 2.666392e-01
Vnewton: Using errtol_s: 85272884.276165
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.049020e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.421731e+02
Vprtstp: contraction number = 3.421731e+02
Vprtstp: iteration = 63
Vprtstp: relative residual = 6.686618e-04
Vprtstp: contraction number = 2.003507e-01
Vnewton: Using errtol_s: 17084479.131265
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.090601e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.371723e+02
Vprtstp: contraction number = 1.371723e+02
Vprtstp: iteration = 64
Vprtstp: relative residual = 7.886468e-05
Vprtstp: contraction number = 1.179440e-01
Vnewton: Using errtol_s: 2015012.570028
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.130722e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.098891e+01
Vprtstp: contraction number = 3.098891e+01
Vprtstp: iteration = 65
Vprtstp: relative residual = 2.966206e-06
Vprtstp: contraction number = 3.761134e-02
Vnewton: Using errtol_s: 75787.322113
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.171891e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.063279e+00
Vprtstp: contraction number = 4.063279e+00
Vprtstp: iteration = 66
Vprtstp: relative residual = 8.708540e-09
Vprtstp: contraction number = 2.935918e-03
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.869010e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.919621e+01
Vpmg_setPart:  lower corner = (69.94, 78.97, -22.401)
Vpmg_setPart:  upper corner = (153.161, 143.776, 245.269)
Vpmg_setPart:  actual minima = (69.94, 78.97, -22.401)
Vpmg_setPart:  actual maxima = (153.161, 143.776, 245.269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.94, 88.97, -12.401
VPMG::focusFillBound -- New mesh maxs = 143.161, 133.776, 235.269
VPMG::focusFillBound -- Old mesh mins = 69.94, 78.97, -22.401
VPMG::focusFillBound -- Old mesh maxs = 153.161, 143.776, 245.269
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.078033
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.536706e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.220840e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.970940e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.606603e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 35670155.035808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.633494e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.443880e+06
Vprtstp: contraction number = 4.443880e+06
Vnewton: Attempting damping, relres = 535.914250
Vnewton: Attempting damping, relres = 0.660982
Vnewton: Attempting damping, relres = 0.780338
Vnewton: Damping accepted, relres = 0.660982
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.609817e-01
Vprtstp: contraction number = 6.609817e-01
Vnewton: Using errtol_s: 23577320.346768
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.699741e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.548921e+06
Vprtstp: contraction number = 2.548921e+06
Vnewton: Attempting damping, relres = 0.097387
Vnewton: Attempting damping, relres = 0.371027
Vnewton: Damping accepted, relres = 0.097387
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.738737e-02
Vprtstp: contraction number = 1.473375e-01
Vnewton: Using errtol_s: 3473822.505238
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.753758e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.917696e+05
Vprtstp: contraction number = 3.917696e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.816546e-02
Vprtstp: contraction number = 1.865279e-01
Vnewton: Using errtol_s: 647964.651065
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.795307e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.170684e+04
Vprtstp: contraction number = 8.170684e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.882444e-03
Vprtstp: contraction number = 2.137267e-01
Vnewton: Using errtol_s: 138487.366837
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.837648e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.000504e+04
Vprtstp: contraction number = 2.000504e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.669641e-04
Vprtstp: contraction number = 1.975467e-01
Vnewton: Using errtol_s: 27357.727652
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.879872e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.738427e+03
Vprtstp: contraction number = 4.738427e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.344023e-04
Vprtstp: contraction number = 1.752393e-01
Vnewton: Using errtol_s: 4794.150109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.921471e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.008368e+03
Vprtstp: contraction number = 1.008368e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.563775e-05
Vprtstp: contraction number = 1.907538e-01
Vnewton: Using errtol_s: 914.502493
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.966226e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.086997e+02
Vprtstp: contraction number = 2.086997e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.267181e-06
Vprtstp: contraction number = 2.054463e-01
Vnewton: Using errtol_s: 187.881172
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.008098e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.348603e+01
Vprtstp: contraction number = 4.348603e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.097216e-06
Vprtstp: contraction number = 2.083119e-01
Vnewton: Using errtol_s: 39.137876
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.050472e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.153397e+00
Vprtstp: contraction number = 9.153397e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.309511e-07
Vprtstp: contraction number = 2.104882e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.770064e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.244524e+00
Vpmg_setPart:  lower corner = (79.94, 88.97, -12.401)
Vpmg_setPart:  upper corner = (143.161, 133.776, 235.269)
Vpmg_setPart:  actual minima = (79.94, 88.97, -12.401)
Vpmg_setPart:  actual maxima = (143.161, 133.776, 235.269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.163783e+01
