##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:46:43 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 449)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.770131, 0.818797, 0.686763
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.520131, 0.506297, 0.597478
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.67538, 0.618342, 0.869991 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 172.861 163.476 264.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 49.64 58.67 -42.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 69.64 78.67 -22.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.840475
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.452323e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 449)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.512860e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 225)
Vbuildops: Galer: (041, 033, 113)
Vbuildops: Galer: (021, 017, 057)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.281870e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.504824e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1641743514.413225
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.170520e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.561093e+08
Vprtstp: contraction number = 2.561093e+08
Vnewton: Attempting damping, relres = 1151840544284135247960464833904640.000000
Vnewton: Attempting damping, relres = 578539066495965407658006624075776.000000
Vnewton: Attempting damping, relres = 219381515453181928216249365430272.000000
Vnewton: Attempting damping, relres = 59827628539618456625001495789568.000000
Vnewton: Attempting damping, relres = 1619155169786160792272891805696.000000
Vnewton: Attempting damping, relres = 99810096510738.125000
Vnewton: Attempting damping, relres = 2569.724665
Vnewton: Attempting damping, relres = 0.985054
Vnewton: Attempting damping, relres = 0.996713
Vnewton: Damping accepted, relres = 0.985054
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.850536e-01
Vprtstp: contraction number = 9.850536e-01
Vnewton: Using errtol_s: 1617205319.845623
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.644896e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.474503e+08
Vprtstp: contraction number = 1.474503e+08
Vnewton: Attempting damping, relres = 443645823742859571299542460530688.000000
Vnewton: Attempting damping, relres = 127389766774213731418759734755328.000000
Vnewton: Attempting damping, relres = 9610132395546547077001578020864.000000
Vnewton: Attempting damping, relres = 161075689899792.906250
Vnewton: Attempting damping, relres = 106180.455833
Vnewton: Attempting damping, relres = 3.894427
Vnewton: Attempting damping, relres = 0.945116
Vnewton: Attempting damping, relres = 0.975963
Vnewton: Damping accepted, relres = 0.945116
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.451159e-01
Vprtstp: contraction number = 9.594563e-01
Vnewton: Using errtol_s: 1551637826.319488
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.282964e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.086213e+07
Vprtstp: contraction number = 6.086213e+07
Vnewton: Attempting damping, relres = 49537295433079206043481255444480.000000
Vnewton: Attempting damping, relres = 7772055433162302423040.000000
Vnewton: Attempting damping, relres = 889836232.965867
Vnewton: Attempting damping, relres = 421.014328
Vnewton: Attempting damping, relres = 0.883661
Vnewton: Attempting damping, relres = 0.898843
Vnewton: Damping accepted, relres = 0.883661
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.836614e-01
Vprtstp: contraction number = 9.349768e-01
Vnewton: Using errtol_s: 1450745299.798333
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.544731e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.537476e+07
Vprtstp: contraction number = 1.537476e+07
Vnewton: Attempting damping, relres = 876126956.003849
Vnewton: Attempting damping, relres = 409.677059
Vnewton: Attempting damping, relres = 0.855065
Vnewton: Attempting damping, relres = 0.741434
Vnewton: Attempting damping, relres = 0.822763
Vnewton: Damping accepted, relres = 0.741434
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.414342e-01
Vprtstp: contraction number = 8.390479e-01
Vnewton: Using errtol_s: 1217244838.879389
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.777566e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.327727e+06
Vprtstp: contraction number = 6.327727e+06
Vnewton: Attempting damping, relres = 16.323133
Vnewton: Attempting damping, relres = 0.267406
Vnewton: Attempting damping, relres = 0.519356
Vnewton: Damping accepted, relres = 0.267406
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.674058e-01
Vprtstp: contraction number = 3.606602e-01
Vnewton: Using errtol_s: 439011806.145486
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.952096e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.613202e+06
Vprtstp: contraction number = 2.613202e+06
Vnewton: Attempting damping, relres = 0.053088
Vnewton: Attempting damping, relres = 0.146362
Vnewton: Damping accepted, relres = 0.053088
Vnewton: Damping disabled
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.308767e-02
Vprtstp: contraction number = 1.985284e-01
Vnewton: Using errtol_s: 87156330.173239
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.098033e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.464220e+05
Vprtstp: contraction number = 9.464220e+05
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.620645e-03
Vprtstp: contraction number = 1.623851e-01
Vnewton: Using errtol_s: 14152887.559946
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.212136e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.441630e+05
Vprtstp: contraction number = 3.441630e+05
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.134291e-03
Vprtstp: contraction number = 1.315785e-01
Vnewton: Using errtol_s: 1862215.123702
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.326944e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.335739e+04
Vprtstp: contraction number = 9.335739e+04
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.176497e-04
Vprtstp: contraction number = 1.037209e-01
Vnewton: Using errtol_s: 193150.603999
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.441204e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.155592e+04
Vprtstp: contraction number = 2.155592e+04
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.542946e-05
Vprtstp: contraction number = 1.311475e-01
Vnewton: Using errtol_s: 25331.213520
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.554931e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.494463e+03
Vprtstp: contraction number = 4.494463e+03
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.612024e-06
Vprtstp: contraction number = 1.692881e-01
Vnewton: Using errtol_s: 4288.273381
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.670907e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.528778e+02
Vprtstp: contraction number = 8.528778e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.704630e-07
Vprtstp: contraction number = 1.801144e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.210401e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.310718e+01
Vpmg_setPart:  lower corner = (49.64, 58.67, -42.701)
Vpmg_setPart:  upper corner = (172.861, 163.476, 264.969)
Vpmg_setPart:  actual minima = (49.64, 58.67, -42.701)
Vpmg_setPart:  actual maxima = (172.861, 163.476, 264.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- New mesh maxs = 152.861, 143.476, 244.969
VPMG::focusFillBound -- Old mesh mins = 49.64, 58.67, -42.701
VPMG::focusFillBound -- Old mesh maxs = 172.861, 163.476, 264.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.815920
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.236553e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 449)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.510270e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 225)
Vbuildops: Galer: (041, 033, 113)
Vbuildops: Galer: (021, 017, 057)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.276380e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.389825e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 28384545.105236
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.456833e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.412387e+06
Vprtstp: contraction number = 3.412387e+06
Vnewton: Attempting damping, relres = 1053.117091
Vnewton: Attempting damping, relres = 0.716171
Vnewton: Attempting damping, relres = 0.780431
Vnewton: Damping accepted, relres = 0.716171
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.161713e-01
Vprtstp: contraction number = 7.161713e-01
Vnewton: Using errtol_s: 20328196.535277
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.632249e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.969929e+06
Vprtstp: contraction number = 1.969929e+06
Vnewton: Attempting damping, relres = 0.113560
Vnewton: Attempting damping, relres = 0.402667
Vnewton: Damping accepted, relres = 0.113560
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.135604e-01
Vprtstp: contraction number = 1.585660e-01
Vnewton: Using errtol_s: 3223361.212592
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.779323e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.208446e+05
Vprtstp: contraction number = 3.208446e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.440170e-02
Vprtstp: contraction number = 2.148785e-01
Vnewton: Using errtol_s: 692631.073892
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.893325e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.636286e+04
Vprtstp: contraction number = 7.636286e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.828922e-03
Vprtstp: contraction number = 2.388736e-01
Vnewton: Using errtol_s: 165451.285356
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.007820e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.132718e+04
Vprtstp: contraction number = 2.132718e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.246513e-03
Vprtstp: contraction number = 2.138497e-01
Vnewton: Using errtol_s: 35381.702911
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.123295e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.486158e+03
Vprtstp: contraction number = 5.486158e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.169830e-04
Vprtstp: contraction number = 1.740720e-01
Vnewton: Using errtol_s: 6158.962721
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.237338e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.179869e+03
Vprtstp: contraction number = 1.179869e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.824570e-05
Vprtstp: contraction number = 1.762613e-01
Vnewton: Using errtol_s: 1085.586792
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.352886e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.368612e+02
Vprtstp: contraction number = 2.368612e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.517822e-06
Vprtstp: contraction number = 1.965665e-01
Vnewton: Using errtol_s: 213.389944
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.468077e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.816842e+01
Vprtstp: contraction number = 4.816842e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.527389e-06
Vprtstp: contraction number = 2.031691e-01
Vnewton: Using errtol_s: 43.354242
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.583284e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.881597e+00
Vprtstp: contraction number = 9.881597e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.133209e-07
Vprtstp: contraction number = 2.051350e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.283471e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.383633e+01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.927792e+01
