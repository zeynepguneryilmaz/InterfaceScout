##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:49:09 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 417)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.650164, 0.675063, 0.643437
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.493914, 0.466729, 0.595361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.55 111.373 111.434
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 153.161 143.776 245.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.94 78.97 -22.401
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 143.161 133.776 235.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.94 88.97 -12.401
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 143.161 133.776 235.269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.94 88.97 -12.401
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.921444
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.293033e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.656090e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.139030e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.021172e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.369924e-01
Vprtstp: contraction number = 1.369924e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.712437e-02
Vprtstp: contraction number = 1.250023e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.094986e-03
Vprtstp: contraction number = 1.223395e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.964997e-04
Vprtstp: contraction number = 1.415282e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.168195e-05
Vprtstp: contraction number = 1.405801e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.561808e-06
Vprtstp: contraction number = 2.293993e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.158343e-06
Vprtstp: contraction number = 2.257254e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.601586e-07
Vprtstp: contraction number = 3.058636e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.940919e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.599390e+00
Vpmg_setPart:  lower corner = (69.94, 78.97, -22.401)
Vpmg_setPart:  upper corner = (153.161, 143.776, 245.269)
Vpmg_setPart:  actual minima = (69.94, 78.97, -22.401)
Vpmg_setPart:  actual maxima = (153.161, 143.776, 245.269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.94, 88.97, -12.401
VPMG::focusFillBound -- New mesh maxs = 143.161, 133.776, 235.269
VPMG::focusFillBound -- Old mesh mins = 69.94, 78.97, -22.401
VPMG::focusFillBound -- Old mesh maxs = 153.161, 143.776, 245.269
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.906557
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.014901e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.666750e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.164030e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.266406e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.112638e-02
Vprtstp: contraction number = 9.112638e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.501367e-03
Vprtstp: contraction number = 9.329206e-02
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.079395e-04
Vprtstp: contraction number = 9.503641e-02
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.196090e-05
Vprtstp: contraction number = 1.014444e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.216142e-06
Vprtstp: contraction number = 1.124456e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.629709e-06
Vprtstp: contraction number = 1.768321e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.789306e-07
Vprtstp: contraction number = 2.325142e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.693811e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.357884e+00
Vpmg_setPart:  lower corner = (79.94, 88.97, -12.401)
Vpmg_setPart:  upper corner = (143.161, 133.776, 235.269)
Vpmg_setPart:  actual minima = (79.94, 88.97, -12.401)
Vpmg_setPart:  actual maxima = (143.161, 133.776, 235.269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.585699e+01
