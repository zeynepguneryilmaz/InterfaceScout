##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:47:08 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 321)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.866885, 1.01259, 0.836469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.658552, 0.700094, 0.773969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.164620
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.714362e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.171500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 161)
Vbuildops: Galer: (025, 017, 081)
Vbuildops: Galer: (013, 009, 041)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.774500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.903126e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 17509067737.693539
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.022204e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.871558e+09
Vprtstp: contraction number = 2.871558e+09
Vnewton: Attempting damping, relres = 175365240844564499612696836046848.000000
Vnewton: Attempting damping, relres = 159633071511225533075275198234624.000000
Vnewton: Attempting damping, relres = 143007995834011379745527882055680.000000
Vnewton: Attempting damping, relres = 124572452197234000753608005517312.000000
Vnewton: Attempting damping, relres = 93833902232890949580628231716864.000000
Vnewton: Attempting damping, relres = 45579442961656632986251680546816.000000
Vnewton: Attempting damping, relres = 17318324713293798108355719331840.000000
Vnewton: Attempting damping, relres = 5829578309123307050187628740608.000000
Vnewton: Attempting damping, relres = 1043391347924466840838630014976.000000
Vnewton: Attempting damping, relres = 52493661142599480639488.000000
Vnewton: Attempting damping, relres = 9303551.640404
Vnewton: Damping accepted, relres = 52493661142599480639488.000000
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.249366e+22
Vprtstp: contraction number = 5.249366e+22
Vnewton: Using errtol_s: 919115068745305432768575392710656.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.744915e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.038804e+08
Vprtstp: contraction number = 3.038804e+08
Vnewton: Attempting damping, relres = 48222122996449571393194900324352.000000
Vnewton: Attempting damping, relres = 30673581849148121872119864754176.000000
Vnewton: Attempting damping, relres = 16321242989055125826276184555520.000000
Vnewton: Attempting damping, relres = 5857886929197911025442598420480.000000
Vnewton: Attempting damping, relres = 153341282037867927143467450368.000000
Vnewton: Attempting damping, relres = 50878635358922026778624.000000
Vnewton: Attempting damping, relres = 51679822360258468118528.000000
Vnewton: Damping accepted, relres = 50878635358922026778624.000000
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.087864e+22
Vprtstp: contraction number = 9.692339e-01
Vnewton: Using errtol_s: 890837472900775229609740672696320.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.272210e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.195422e+07
Vprtstp: contraction number = 1.195422e+07
Vnewton: Attempting damping, relres = 11805733721008682421918367744.000000
Vnewton: Attempting damping, relres = 197943975510451234671689728.000000
Vnewton: Attempting damping, relres = 39624321059142529712128.000000
Vnewton: Attempting damping, relres = 44900238111979518033920.000000
Vnewton: Damping accepted, relres = 39624321059142529712128.000000
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.962432e+22
Vprtstp: contraction number = 7.788008e-01
Vnewton: Using errtol_s: 693784921484643087969845237514240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.639646e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.814009e+06
Vprtstp: contraction number = 2.814009e+06
Vnewton: Attempting damping, relres = 14576973088035467952128.000000
Vnewton: Attempting damping, relres = 24033365592667165032448.000000
Vnewton: Damping accepted, relres = 14576973088035467952128.000000
Vnewton: Damping disabled
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.457697e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 255229209208948733309528534155264.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.898038e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.385916e+06
Vprtstp: contraction number = 1.385916e+06
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.362569e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 93893578854415538652511429722112.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.103117e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.139010e+06
Vprtstp: contraction number = 1.139010e+06
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.972779e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 34541517318549839885280944848896.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.311659e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.260656e+05
Vprtstp: contraction number = 9.260656e+05
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.257448e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 12707114088361647972589192085504.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.516460e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.437421e+05
Vprtstp: contraction number = 7.437421e+05
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.669866e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4674686029728140531778841477120.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.725866e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.024858e+05
Vprtstp: contraction number = 6.024858e+05
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.821887e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1719720884268378926175567740928.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.935626e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.015205e+05
Vprtstp: contraction number = 5.015205e+05
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.613270e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 632649957875498930303571853312.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.142538e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.368867e+05
Vprtstp: contraction number = 4.368867e+05
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.329248e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 232738912960380361920626032640.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.350694e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.834236e+05
Vprtstp: contraction number = 3.834236e+05
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.890030e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 85619861238712197315190325248.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.557572e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.405930e+05
Vprtstp: contraction number = 3.405930e+05
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.798941e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 31497786705674476737120960512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.767528e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.025548e+05
Vprtstp: contraction number = 3.025548e+05
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.617936e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 11587388171420605647515811840.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.974502e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.698665e+05
Vprtstp: contraction number = 2.698665e+05
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.434602e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4262761885138875556206477312.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.181455e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.349842e+05
Vprtstp: contraction number = 2.349842e+05
Vprtstp: iteration = 16
Vprtstp: relative residual = 8.956402e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1568182460151797513711517696.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.387668e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.999370e+05
Vprtstp: contraction number = 1.999370e+05
Vprtstp: iteration = 17
Vprtstp: relative residual = 3.294876e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 576902087095489464398512128.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.592416e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.718801e+05
Vprtstp: contraction number = 1.718801e+05
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.212117e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 212230417411332097401946112.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.801100e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.501386e+05
Vprtstp: contraction number = 1.501386e+05
Vprtstp: iteration = 19
Vprtstp: relative residual = 4.459130e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 78075207356861738936958976.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.010277e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.327863e+05
Vprtstp: contraction number = 1.327863e+05
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.640422e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 28722263651787265496055808.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.217177e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.190488e+05
Vprtstp: contraction number = 1.190488e+05
Vprtstp: iteration = 21
Vprtstp: relative residual = 6.034776e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 10566330301398184202600448.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.421756e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.067949e+05
Vprtstp: contraction number = 1.067949e+05
Vprtstp: iteration = 22
Vprtstp: relative residual = 2.220070e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3887135686511306980982784.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.622382e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.447757e+04
Vprtstp: contraction number = 9.447757e+04
Vprtstp: iteration = 23
Vprtstp: relative residual = 8.167181e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1429997304111331603906560.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.833391e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.424898e+04
Vprtstp: contraction number = 8.424898e+04
Vprtstp: iteration = 24
Vprtstp: relative residual = 3.004538e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 526066609113151102255104.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.041933e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.652688e+04
Vprtstp: contraction number = 7.652688e+04
Vprtstp: iteration = 25
Vprtstp: relative residual = 1.105308e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 193529090179497419866112.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.249237e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.016885e+04
Vprtstp: contraction number = 7.016885e+04
Vprtstp: iteration = 26
Vprtstp: relative residual = 4.066200e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 71195373545647656402944.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.456964e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.469535e+04
Vprtstp: contraction number = 6.469535e+04
Vprtstp: iteration = 27
Vprtstp: relative residual = 1.495871e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 26191314233964151963648.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.661772e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.984010e+04
Vprtstp: contraction number = 5.984010e+04
Vprtstp: iteration = 28
Vprtstp: relative residual = 5.503003e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 9635246043934559830016.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.866004e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.471682e+04
Vprtstp: contraction number = 5.471682e+04
Vprtstp: iteration = 29
Vprtstp: relative residual = 2.024442e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3544608930190575271936.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.007163e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.888729e+04
Vprtstp: contraction number = 4.888729e+04
Vprtstp: iteration = 30
Vprtstp: relative residual = 7.447505e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1303988752408397742080.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.027763e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.260231e+04
Vprtstp: contraction number = 4.260231e+04
Vprtstp: iteration = 31
Vprtstp: relative residual = 2.739784e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 479710653528559779840.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.048391e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.633899e+04
Vprtstp: contraction number = 3.633899e+04
Vprtstp: iteration = 32
Vprtstp: relative residual = 1.007910e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 176475687142880608256.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.068833e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.097096e+04
Vprtstp: contraction number = 3.097096e+04
Vprtstp: iteration = 33
Vprtstp: relative residual = 3.707895e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 64921777165369663488.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.089182e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.695099e+04
Vprtstp: contraction number = 2.695099e+04
Vprtstp: iteration = 34
Vprtstp: relative residual = 1.364058e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 23883387102431453184.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.109286e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.390618e+04
Vprtstp: contraction number = 2.390618e+04
Vprtstp: iteration = 35
Vprtstp: relative residual = 5.018090e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 8786207099569560576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.129655e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.141116e+04
Vprtstp: contraction number = 2.141116e+04
Vprtstp: iteration = 36
Vprtstp: relative residual = 1.846052e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3232264956914496512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.150374e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.932697e+04
Vprtstp: contraction number = 1.932697e+04
Vprtstp: iteration = 37
Vprtstp: relative residual = 6.791246e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1189083825231096320.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.171377e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.760924e+04
Vprtstp: contraction number = 1.760924e+04
Vprtstp: iteration = 38
Vprtstp: relative residual = 2.498360e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 437439492344484608.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.192245e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.615046e+04
Vprtstp: contraction number = 1.615046e+04
Vprtstp: iteration = 39
Vprtstp: relative residual = 9.190952e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 160924995252926112.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.212611e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.479024e+04
Vprtstp: contraction number = 1.479024e+04
Vprtstp: iteration = 40
Vprtstp: relative residual = 3.381162e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 59200996637372016.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.232986e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.345816e+04
Vprtstp: contraction number = 1.345816e+04
Vprtstp: iteration = 41
Vprtstp: relative residual = 1.243860e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 21778828919038260.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.252912e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.213830e+04
Vprtstp: contraction number = 1.213830e+04
Vprtstp: iteration = 42
Vprtstp: relative residual = 4.575905e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 8011982817688609.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.272822e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.080048e+04
Vprtstp: contraction number = 1.080048e+04
Vprtstp: iteration = 43
Vprtstp: relative residual = 1.683381e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2947443215301358.500000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.293042e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.463517e+03
Vprtstp: contraction number = 9.463517e+03
Vprtstp: iteration = 44
Vprtstp: relative residual = 6.192810e+04
Vprtstp: contraction number = 3.678793e-01
Vnewton: Using errtol_s: 1084303262539765.375000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.313477e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.155521e+03
Vprtstp: contraction number = 8.155521e+03
Vprtstp: iteration = 45
Vprtstp: relative residual = 2.278205e+04
Vprtstp: contraction number = 3.678790e-01
Vnewton: Using errtol_s: 398892423426523.625000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.334039e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.913248e+03
Vprtstp: contraction number = 6.913248e+03
Vprtstp: iteration = 46
Vprtstp: relative residual = 8.381024e+03
Vprtstp: contraction number = 3.678784e-01
Vnewton: Using errtol_s: 146743913466397.562500
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.354592e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.799924e+03
Vprtstp: contraction number = 5.799924e+03
Vprtstp: iteration = 47
Vprtstp: relative residual = 3.083186e+03
Vprtstp: contraction number = 3.678770e-01
Vnewton: Using errtol_s: 53983706207754.453125
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.374742e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.879649e+03
Vprtstp: contraction number = 4.879649e+03
Vprtstp: iteration = 48
Vprtstp: relative residual = 1.134222e+03
Vprtstp: contraction number = 3.678736e-01
Vnewton: Using errtol_s: 19859177815520.890625
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.395084e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.107324e+03
Vprtstp: contraction number = 4.107324e+03
Vprtstp: iteration = 49
Vprtstp: relative residual = 4.172415e+02
Vprtstp: contraction number = 3.678656e-01
Vnewton: Using errtol_s: 7305509219433.924805
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.414965e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.389637e+03
Vprtstp: contraction number = 3.389637e+03
Vprtstp: iteration = 50
Vprtstp: relative residual = 1.534813e+02
Vprtstp: contraction number = 3.678476e-01
Vnewton: Using errtol_s: 2687313788050.032715
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.434817e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.705584e+03
Vprtstp: contraction number = 2.705584e+03
Vprtstp: iteration = 51
Vprtstp: relative residual = 5.645145e+01
Vprtstp: contraction number = 3.678068e-01
Vnewton: Using errtol_s: 988412245823.836670
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.454884e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.067495e+03
Vprtstp: contraction number = 2.067495e+03
Vprtstp: iteration = 52
Vprtstp: relative residual = 2.075812e+01
Vprtstp: contraction number = 3.677164e-01
Vnewton: Using errtol_s: 363455398288.907776
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.474859e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.502682e+03
Vprtstp: contraction number = 1.502682e+03
Vprtstp: iteration = 53
Vprtstp: relative residual = 7.629037e+00
Vprtstp: contraction number = 3.675205e-01
Vnewton: Using errtol_s: 133577320495.301651
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.495129e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.073220e+03
Vprtstp: contraction number = 1.073220e+03
Vprtstp: iteration = 54
Vprtstp: relative residual = 2.800653e+00
Vprtstp: contraction number = 3.671044e-01
Vnewton: Using errtol_s: 49036819645.917725
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.515463e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.898928e+02
Vprtstp: contraction number = 7.898928e+02
Vprtstp: iteration = 55
Vprtstp: relative residual = 1.025622e+00
Vprtstp: contraction number = 3.662081e-01
Vnewton: Using errtol_s: 17957679238.952122
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.535646e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.166164e+02
Vprtstp: contraction number = 6.166164e+02
Vprtstp: iteration = 56
Vprtstp: relative residual = 3.736020e-01
Vprtstp: contraction number = 3.642689e-01
Vnewton: Using errtol_s: 6541423241.227729
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.556144e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.068299e+02
Vprtstp: contraction number = 5.068299e+02
Vprtstp: iteration = 57
Vprtstp: relative residual = 1.345171e-01
Vprtstp: contraction number = 3.600546e-01
Vnewton: Using errtol_s: 2355269591.011776
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.576506e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.097892e+02
Vprtstp: contraction number = 4.097892e+02
Vprtstp: iteration = 58
Vprtstp: relative residual = 4.722795e-02
Vprtstp: contraction number = 3.510924e-01
Vnewton: Using errtol_s: 826917298.696014
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.596604e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.995498e+02
Vprtstp: contraction number = 2.995498e+02
Vprtstp: iteration = 59
Vprtstp: relative residual = 1.575027e-02
Vprtstp: contraction number = 3.334948e-01
Vnewton: Using errtol_s: 275772580.176727
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.617044e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.730784e+02
Vprtstp: contraction number = 1.730784e+02
Vprtstp: iteration = 60
Vprtstp: relative residual = 4.749230e-03
Vprtstp: contraction number = 3.015332e-01
Vnewton: Using errtol_s: 83154584.891544
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.638281e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.817041e+01
Vprtstp: contraction number = 6.817041e+01
Vprtstp: iteration = 61
Vprtstp: relative residual = 1.187139e-03
Vprtstp: contraction number = 2.499645e-01
Vnewton: Using errtol_s: 20785692.387586
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.659455e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.998098e+01
Vprtstp: contraction number = 1.998098e+01
Vprtstp: iteration = 62
Vprtstp: relative residual = 2.038586e-04
Vprtstp: contraction number = 1.717226e-01
Vnewton: Using errtol_s: 3569373.763334
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.679989e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.849464e+00
Vprtstp: contraction number = 4.849464e+00
Vprtstp: iteration = 63
Vprtstp: relative residual = 1.481633e-05
Vprtstp: contraction number = 7.267943e-02
Vnewton: Using errtol_s: 259420.055200
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.700154e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.702043e-01
Vprtstp: contraction number = 7.702043e-01
Vprtstp: iteration = 64
Vprtstp: relative residual = 1.561100e-07
Vprtstp: contraction number = 1.053635e-02
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.425427e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.440682e+01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.64, 88.67, -12.701
VPMG::focusFillBound -- New mesh maxs = 142.861, 133.476, 234.969
VPMG::focusFillBound -- Old mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- Old mesh maxs = 152.861, 143.476, 244.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.151333
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.915537e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.159000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 161)
Vbuildops: Galer: (025, 017, 081)
Vbuildops: Galer: (013, 009, 041)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.761100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.023071e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 29473512.967362
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.035331e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.635373e+06
Vprtstp: contraction number = 2.635373e+06
Vnewton: Attempting damping, relres = 823.665020
Vnewton: Attempting damping, relres = 0.671147
Vnewton: Attempting damping, relres = 0.772237
Vnewton: Damping accepted, relres = 0.671147
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.711471e-01
Vprtstp: contraction number = 6.711471e-01
Vnewton: Using errtol_s: 19781061.932782
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.065923e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.488240e+06
Vprtstp: contraction number = 1.488240e+06
Vnewton: Attempting damping, relres = 0.087538
Vnewton: Attempting damping, relres = 0.368341
Vnewton: Damping accepted, relres = 0.087538
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.753794e-02
Vprtstp: contraction number = 1.304303e-01
Vnewton: Using errtol_s: 2580050.570169
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.091612e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.323096e+05
Vprtstp: contraction number = 2.323096e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.785292e-02
Vprtstp: contraction number = 2.039450e-01
Vnewton: Using errtol_s: 526188.376340
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.112317e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.793838e+04
Vprtstp: contraction number = 5.793838e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.177918e-03
Vprtstp: contraction number = 2.340187e-01
Vnewton: Using errtol_s: 123137.906868
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.132457e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.721614e+04
Vprtstp: contraction number = 1.721614e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.983168e-04
Vprtstp: contraction number = 2.150155e-01
Vnewton: Using errtol_s: 26476.552494
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.152077e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.627799e+03
Vprtstp: contraction number = 4.627799e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.684314e-04
Vprtstp: contraction number = 1.874966e-01
Vnewton: Using errtol_s: 4964.264814
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.171626e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.112112e+03
Vprtstp: contraction number = 1.112112e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.459939e-05
Vprtstp: contraction number = 2.054213e-01
Vnewton: Using errtol_s: 1019.765558
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.191190e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.579571e+02
Vprtstp: contraction number = 2.579571e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.887903e-06
Vprtstp: contraction number = 2.279781e-01
Vnewton: Using errtol_s: 232.484225
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.211528e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.999480e+01
Vprtstp: contraction number = 5.999480e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.832315e-06
Vprtstp: contraction number = 2.322943e-01
Vnewton: Using errtol_s: 54.004761
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.232112e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.394428e+01
Vprtstp: contraction number = 1.394428e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.258120e-07
Vprtstp: contraction number = 2.323902e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.256125e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.408010e+00
Vpmg_setPart:  lower corner = (79.64, 88.67, -12.701)
Vpmg_setPart:  upper corner = (142.861, 133.476, 234.969)
Vpmg_setPart:  actual minima = (79.64, 88.67, -12.701)
Vpmg_setPart:  actual maxima = (142.861, 133.476, 234.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.289831e+01
