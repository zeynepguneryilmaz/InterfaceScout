##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 16:49:09 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 417)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.650164, 0.675063, 0.643437
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.493914, 0.466729, 0.595361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.251 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.429344
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.582894e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.312350e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.275170e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.141687e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 25537230311.448135
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.474667e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.449564e+09
Vprtstp: contraction number = 3.449564e+09
Vnewton: Attempting damping, relres = 121609786519986264108957075243008.000000
Vnewton: Attempting damping, relres = 110727745156833250747684537499648.000000
Vnewton: Attempting damping, relres = 99238243443490416256355158458368.000000
Vnewton: Attempting damping, relres = 86517279779940878514791762624512.000000
Vnewton: Attempting damping, relres = 65409144895950397138205633675264.000000
Vnewton: Attempting damping, relres = 32140839514673408504898395308032.000000
Vnewton: Attempting damping, relres = 12356352127573588450161626972160.000000
Vnewton: Attempting damping, relres = 4280388252258107028366191230976.000000
Vnewton: Attempting damping, relres = 858965695360275572024158453760.000000
Vnewton: Attempting damping, relres = 18601792798790673552637952.000000
Vnewton: Attempting damping, relres = 114238619.922266
Vnewton: Damping accepted, relres = 18601792798790673552637952.000000
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.860179e+25
Vprtstp: contraction number = 1.860179e+25
Vnewton: Using errtol_s: 475038266908554777450382028387123200.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.120705e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.488192e+08
Vprtstp: contraction number = 4.488192e+08
Vnewton: Attempting damping, relres = 29466688707564568423000782667776.000000
Vnewton: Attempting damping, relres = 19562792874871981204130532163584.000000
Vnewton: Attempting damping, relres = 11000190101770488243788110102528.000000
Vnewton: Attempting damping, relres = 4382058552293678549684172357632.000000
Vnewton: Attempting damping, relres = 791767728830223142242654093312.000000
Vnewton: Attempting damping, relres = 18029476978592523917197312.000000
Vnewton: Attempting damping, relres = 18313398732322283999723520.000000
Vnewton: Damping accepted, relres = 18029476978592523917197312.000000
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.802948e+25
Vprtstp: contraction number = 9.692333e-01
Vnewton: Using errtol_s: 460422905997269296763343067989147648.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.338396e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.807121e+07
Vprtstp: contraction number = 1.807121e+07
Vnewton: Attempting damping, relres = 210613596529266203997031628800.000000
Vnewton: Attempting damping, relres = 10935776837715723944984576.000000
Vnewton: Attempting damping, relres = 14041370789295426172354560.000000
Vnewton: Damping accepted, relres = 10935776837715723944984576.000000
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.093578e+25
Vprtstp: contraction number = 6.065499e-01
Vnewton: Using errtol_s: 279269451739346416747186670268317696.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.094486e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.373263e+06
Vprtstp: contraction number = 3.373263e+06
Vnewton: Attempting damping, relres = 4023047471834283288559616.000000
Vnewton: Attempting damping, relres = 6632883939849480592949248.000000
Vnewton: Damping accepted, relres = 4023047471834283288559616.000000
Vnewton: Damping disabled
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.023047e+24
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 102737489842121247053593333454602240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.739248e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.759232e+06
Vprtstp: contraction number = 1.759232e+06
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.479996e+24
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 37795010350475898042645111768088576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.257927e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.448487e+06
Vprtstp: contraction number = 1.448487e+06
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.444603e+23
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 13904007286802398890403165378707456.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.775273e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.270630e+06
Vprtstp: contraction number = 1.270630e+06
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.002957e+23
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5114998430712355031094688481280000.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.029132e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.135090e+06
Vprtstp: contraction number = 1.135090e+06
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.368468e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1881702764283352648048699445870592.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.080924e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.012634e+06
Vprtstp: contraction number = 1.012634e+06
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.710708e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 692239761375293569515219444563968.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.132574e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.963820e+05
Vprtstp: contraction number = 8.963820e+05
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.972138e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 254660776571406746413343996641280.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.184010e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.093487e+05
Vprtstp: contraction number = 8.093487e+05
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.668544e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 93684464173370615025124862066688.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.235703e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.468676e+05
Vprtstp: contraction number = 7.468676e+05
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.349582e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 34464588326547402960948632223744.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.287381e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.866636e+05
Vprtstp: contraction number = 6.866636e+05
Vprtstp: iteration = 13
Vprtstp: relative residual = 4.964835e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 12678813493773472058309716475904.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.338765e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.199922e+05
Vprtstp: contraction number = 6.199922e+05
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.826461e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4664274822806229438446063058944.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.390387e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.518125e+05
Vprtstp: contraction number = 5.518125e+05
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.719174e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1715890815284046317591357030400.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.442109e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.980345e+05
Vprtstp: contraction number = 4.980345e+05
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.471846e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 631240954237887934149823561728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.494076e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.680606e+05
Vprtstp: contraction number = 4.680606e+05
Vprtstp: iteration = 17
Vprtstp: relative residual = 9.093413e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 232220569489573385009526472704.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.545687e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.481254e+05
Vprtstp: contraction number = 4.481254e+05
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.345280e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 85429173332334746158900445184.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.597595e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.231653e+05
Vprtstp: contraction number = 4.231653e+05
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.230660e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 31427636545238985689542950912.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.648850e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.899104e+05
Vprtstp: contraction number = 3.899104e+05
Vprtstp: iteration = 20
Vprtstp: relative residual = 4.527344e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 11561581369601205938727944192.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.700168e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.455771e+05
Vprtstp: contraction number = 3.455771e+05
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.665517e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 4253268093307281937929338880.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.751556e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.941816e+05
Vprtstp: contraction number = 2.941816e+05
Vprtstp: iteration = 22
Vprtstp: relative residual = 6.127093e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1564689889318134686928601088.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.803738e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.466794e+05
Vprtstp: contraction number = 2.466794e+05
Vprtstp: iteration = 23
Vprtstp: relative residual = 2.254032e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 575617242088950944155828224.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.855768e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.118109e+05
Vprtstp: contraction number = 2.118109e+05
Vprtstp: iteration = 24
Vprtstp: relative residual = 8.292119e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 211757749348338925540737024.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.909279e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.889399e+05
Vprtstp: contraction number = 1.889399e+05
Vprtstp: iteration = 25
Vprtstp: relative residual = 3.050500e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 77901322493986030737162240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.961067e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.722899e+05
Vprtstp: contraction number = 1.722899e+05
Vprtstp: iteration = 26
Vprtstp: relative residual = 1.122216e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 28658294985605276590145536.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.012499e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.568638e+05
Vprtstp: contraction number = 1.568638e+05
Vprtstp: iteration = 27
Vprtstp: relative residual = 4.128403e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 10542797544230423235657728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.064052e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.393367e+05
Vprtstp: contraction number = 1.393367e+05
Vprtstp: iteration = 28
Vprtstp: relative residual = 1.518755e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3878478468955307776147456.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.115740e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.236138e+05
Vprtstp: contraction number = 1.236138e+05
Vprtstp: iteration = 29
Vprtstp: relative residual = 5.587186e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1426812491754686669389824.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.167815e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.114342e+05
Vprtstp: contraction number = 1.114342e+05
Vprtstp: iteration = 30
Vprtstp: relative residual = 2.055411e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 524894982123171807756288.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.220303e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.034418e+05
Vprtstp: contraction number = 1.034418e+05
Vprtstp: iteration = 31
Vprtstp: relative residual = 7.561434e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 193098072697156797464576.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.272459e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.793377e+04
Vprtstp: contraction number = 9.793377e+04
Vprtstp: iteration = 32
Vprtstp: relative residual = 2.781696e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 71036811075108462395392.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.324509e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.339806e+04
Vprtstp: contraction number = 9.339806e+04
Vprtstp: iteration = 33
Vprtstp: relative residual = 1.023329e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 26132982360911084781568.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.376723e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.830280e+04
Vprtstp: contraction number = 8.830280e+04
Vprtstp: iteration = 34
Vprtstp: relative residual = 3.764616e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 9613786947072783548416.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.428946e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.245058e+04
Vprtstp: contraction number = 8.245058e+04
Vprtstp: iteration = 35
Vprtstp: relative residual = 1.384925e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3536714569628654764032.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.480575e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.479121e+04
Vprtstp: contraction number = 7.479121e+04
Vprtstp: iteration = 36
Vprtstp: relative residual = 5.094854e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1301084579456035061760.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.536095e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.542100e+04
Vprtstp: contraction number = 6.542100e+04
Vprtstp: iteration = 37
Vprtstp: relative residual = 1.874292e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 478642268005429608448.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.589320e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.526038e+04
Vprtstp: contraction number = 5.526038e+04
Vprtstp: iteration = 38
Vprtstp: relative residual = 6.895135e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 176082650073347948544.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.641264e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.523427e+04
Vprtstp: contraction number = 4.523427e+04
Vprtstp: iteration = 39
Vprtstp: relative residual = 2.536578e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 64777186907579629568.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.693095e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.620341e+04
Vprtstp: contraction number = 3.620341e+04
Vprtstp: iteration = 40
Vprtstp: relative residual = 9.331550e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 23830195318924918784.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.744800e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.935501e+04
Vprtstp: contraction number = 2.935501e+04
Vprtstp: iteration = 41
Vprtstp: relative residual = 3.432886e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 8766638935721742336.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.796824e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.523886e+04
Vprtstp: contraction number = 2.523886e+04
Vprtstp: iteration = 42
Vprtstp: relative residual = 1.262888e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3225066231486625792.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.849311e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.281542e+04
Vprtstp: contraction number = 2.281542e+04
Vprtstp: iteration = 43
Vprtstp: relative residual = 4.645905e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1186435561908864256.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.901800e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.093499e+04
Vprtstp: contraction number = 2.093499e+04
Vprtstp: iteration = 44
Vprtstp: relative residual = 1.709133e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 436465250493867456.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.953496e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.925522e+04
Vprtstp: contraction number = 1.925522e+04
Vprtstp: iteration = 45
Vprtstp: relative residual = 6.287549e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 160566591499128832.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.005175e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.775210e+04
Vprtstp: contraction number = 1.775210e+04
Vprtstp: iteration = 46
Vprtstp: relative residual = 2.313060e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 59069147072468384.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.057599e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.634366e+04
Vprtstp: contraction number = 1.634366e+04
Vprtstp: iteration = 47
Vprtstp: relative residual = 8.509272e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 21730323999476084.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.109873e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.494887e+04
Vprtstp: contraction number = 1.494887e+04
Vprtstp: iteration = 48
Vprtstp: relative residual = 3.130386e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 7994138696360736.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.162153e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.349816e+04
Vprtstp: contraction number = 1.349816e+04
Vprtstp: iteration = 49
Vprtstp: relative residual = 1.151604e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2940878585549876.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.214294e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.196300e+04
Vprtstp: contraction number = 1.196300e+04
Vprtstp: iteration = 50
Vprtstp: relative residual = 4.236513e+04
Vprtstp: contraction number = 3.678792e-01
Vnewton: Using errtol_s: 1081888142375760.750000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.266249e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.047991e+04
Vprtstp: contraction number = 1.047991e+04
Vprtstp: iteration = 51
Vprtstp: relative residual = 1.558524e+04
Vprtstp: contraction number = 3.678789e-01
Vnewton: Using errtol_s: 398003839595328.125000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.320215e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.148225e+03
Vprtstp: contraction number = 9.148225e+03
Vprtstp: iteration = 52
Vprtstp: relative residual = 5.733469e+03
Vprtstp: contraction number = 3.678782e-01
Vnewton: Using errtol_s: 146416925408825.968750
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.372662e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.903146e+03
Vprtstp: contraction number = 7.903146e+03
Vprtstp: iteration = 53
Vprtstp: relative residual = 2.109208e+03
Vprtstp: contraction number = 3.678764e-01
Vnewton: Using errtol_s: 53863332923791.546875
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.424858e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.713028e+03
Vprtstp: contraction number = 6.713028e+03
Vprtstp: iteration = 54
Vprtstp: relative residual = 7.759192e+02
Vprtstp: contraction number = 3.678723e-01
Vnewton: Using errtol_s: 19814828016416.578125
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.477048e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.589900e+03
Vprtstp: contraction number = 5.589900e+03
Vprtstp: iteration = 55
Vprtstp: relative residual = 2.854318e+02
Vprtstp: contraction number = 3.678628e-01
Vnewton: Using errtol_s: 7289137529766.037109
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.528852e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.573367e+03
Vprtstp: contraction number = 4.573367e+03
Vprtstp: iteration = 56
Vprtstp: relative residual = 1.049935e+02
Vprtstp: contraction number = 3.678410e-01
Vnewton: Using errtol_s: 2681243512454.635742
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.580968e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.738047e+03
Vprtstp: contraction number = 3.738047e+03
Vprtstp: iteration = 57
Vprtstp: relative residual = 3.861577e+01
Vprtstp: contraction number = 3.677920e-01
Vnewton: Using errtol_s: 986139851045.029541
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.633445e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.107752e+03
Vprtstp: contraction number = 3.107752e+03
Vprtstp: iteration = 58
Vprtstp: relative residual = 1.419841e+01
Vprtstp: contraction number = 3.676842e-01
Vnewton: Using errtol_s: 362588042113.353943
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.685535e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.549228e+03
Vprtstp: contraction number = 2.549228e+03
Vprtstp: iteration = 59
Vprtstp: relative residual = 5.217222e+00
Vprtstp: contraction number = 3.674512e-01
Vnewton: Using errtol_s: 133233398450.910736
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.737398e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.979276e+03
Vprtstp: contraction number = 1.979276e+03
Vprtstp: iteration = 60
Vprtstp: relative residual = 1.914426e+00
Vprtstp: contraction number = 3.669437e-01
Vnewton: Using errtol_s: 48889150039.866745
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.789583e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.431930e+03
Vprtstp: contraction number = 1.431930e+03
Vprtstp: iteration = 61
Vprtstp: relative residual = 7.003311e-01
Vprtstp: contraction number = 3.658177e-01
Vnewton: Using errtol_s: 17884516252.538284
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.841985e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.742919e+02
Vprtstp: contraction number = 9.742919e+02
Vprtstp: iteration = 62
Vprtstp: relative residual = 2.544299e-01
Vprtstp: contraction number = 3.632994e-01
Vnewton: Using errtol_s: 6497434280.124823
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.894717e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.894531e+02
Vprtstp: contraction number = 6.894531e+02
Vprtstp: iteration = 63
Vprtstp: relative residual = 9.102482e-02
Vprtstp: contraction number = 3.577600e-01
Vnewton: Using errtol_s: 2324521775.437346
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.947344e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.309981e+02
Vprtstp: contraction number = 5.309981e+02
Vprtstp: iteration = 64
Vprtstp: relative residual = 3.150971e-02
Vprtstp: contraction number = 3.461662e-01
Vnewton: Using errtol_s: 804670789.352820
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.000160e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.127084e+02
Vprtstp: contraction number = 4.127084e+02
Vprtstp: iteration = 65
Vprtstp: relative residual = 1.019446e-02
Vprtstp: contraction number = 3.235338e-01
Vnewton: Using errtol_s: 260338191.384566
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.052928e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.979558e+02
Vprtstp: contraction number = 2.979558e+02
Vprtstp: iteration = 66
Vprtstp: relative residual = 2.887150e-03
Vprtstp: contraction number = 2.832079e-01
Vnewton: Using errtol_s: 73729820.614926
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.105881e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.776536e+02
Vprtstp: contraction number = 1.776536e+02
Vprtstp: iteration = 67
Vprtstp: relative residual = 6.353016e-04
Vprtstp: contraction number = 2.200445e-01
Vnewton: Using errtol_s: 16223844.085460
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.158628e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.932250e+01
Vprtstp: contraction number = 6.932250e+01
Vprtstp: iteration = 68
Vprtstp: relative residual = 8.446545e-05
Vprtstp: contraction number = 1.329533e-01
Vnewton: Using errtol_s: 2157013.735932
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.211269e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.345904e+01
Vprtstp: contraction number = 1.345904e+01
Vprtstp: iteration = 69
Vprtstp: relative residual = 3.571351e-06
Vprtstp: contraction number = 4.228179e-02
Vnewton: Using errtol_s: 91202.406700
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.264623e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.675917e+00
Vprtstp: contraction number = 1.675917e+00
Vprtstp: iteration = 70
Vprtstp: relative residual = 1.236173e-08
Vprtstp: contraction number = 3.461359e-03
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.890250e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.941666e+01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.64, 88.67, -12.701
VPMG::focusFillBound -- New mesh maxs = 142.861, 133.476, 234.969
VPMG::focusFillBound -- Old mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- Old mesh maxs = 152.861, 143.476, 244.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.434881
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.181859e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 417)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.310220e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 209)
Vbuildops: Galer: (033, 025, 105)
Vbuildops: Galer: (017, 013, 053)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.176390e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.774834e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 35691421.792589
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.807579e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.416462e+06
Vprtstp: contraction number = 4.416462e+06
Vnewton: Attempting damping, relres = 556.458903
Vnewton: Attempting damping, relres = 0.660322
Vnewton: Attempting damping, relres = 0.780121
Vnewton: Damping accepted, relres = 0.660322
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.603224e-01
Vprtstp: contraction number = 6.603224e-01
Vnewton: Using errtol_s: 23567846.541856
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.884794e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.532480e+06
Vprtstp: contraction number = 2.532480e+06
Vnewton: Attempting damping, relres = 0.096826
Vnewton: Attempting damping, relres = 0.370428
Vnewton: Damping accepted, relres = 0.096826
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.682614e-02
Vprtstp: contraction number = 1.466346e-01
Vnewton: Using errtol_s: 3455862.703607
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.950475e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.893869e+05
Vprtstp: contraction number = 3.893869e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.807551e-02
Vprtstp: contraction number = 1.866801e-01
Vnewton: Using errtol_s: 645140.642176
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.003362e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.156486e+04
Vprtstp: contraction number = 8.156486e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.871655e-03
Vprtstp: contraction number = 2.141934e-01
Vnewton: Using errtol_s: 138184.871181
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.056375e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.005636e+04
Vprtstp: contraction number = 2.005636e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.676633e-04
Vprtstp: contraction number = 1.982778e-01
Vnewton: Using errtol_s: 27398.996253
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.109332e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.745066e+03
Vprtstp: contraction number = 4.745066e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.348136e-04
Vprtstp: contraction number = 1.756155e-01
Vnewton: Using errtol_s: 4811.689765
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.162392e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.002347e+03
Vprtstp: contraction number = 1.002347e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.548383e-05
Vprtstp: contraction number = 1.890301e-01
Vnewton: Using errtol_s: 909.554226
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.214944e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.071186e+02
Vprtstp: contraction number = 2.071186e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.224179e-06
Vprtstp: contraction number = 2.049997e-01
Vnewton: Using errtol_s: 186.458359
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.268970e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.320973e+01
Vprtstp: contraction number = 4.320973e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.089600e-06
Vprtstp: contraction number = 2.085687e-01
Vnewton: Using errtol_s: 38.889374
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.323226e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.094985e+00
Vprtstp: contraction number = 9.094985e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.293406e-07
Vprtstp: contraction number = 2.104815e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.888900e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.392801e+00
Vpmg_setPart:  lower corner = (79.64, 88.67, -12.701)
Vpmg_setPart:  upper corner = (142.861, 133.476, 234.969)
Vpmg_setPart:  actual minima = (79.64, 88.67, -12.701)
Vpmg_setPart:  actual maxima = (142.861, 133.476, 234.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.459924e+01
