##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:49 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11770 atoms
Valist_getStatistics:  Max atom coordinate:  (46.965, 62.976, 76.535)
Valist_getStatistics:  Min atom coordinate:  (-32.976, -0.079, 1.65)
Valist_getStatistics:  Molecule center:  (6.9945, 31.4485, 39.0925)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.937039, 0.805117, 0.897539
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.780789, 0.648867, 0.741289
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.833251, 0.805929, 0.825913 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.965 82.976 96.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -52.976 -20.079 -18.35
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.965 72.976 86.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -42.976 -10.079 -8.35
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.965 72.976 86.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -42.976 -10.079 -8.35
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -21
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880698 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.334490
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.719639e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.362200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 9.972100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.908294e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12954039.917396
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.002268e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.356393e+05
Vprtstp: contraction number = 7.356393e+05
Vnewton: Attempting damping, relres = 0.054254
Vnewton: Attempting damping, relres = 0.520547
Vnewton: Damping accepted, relres = 0.054254
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.425383e-02
Vprtstp: contraction number = 5.425383e-02
Vnewton: Using errtol_s: 702806.280603
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.189740e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.239997e+04
Vprtstp: contraction number = 9.239997e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.808358e-03
Vprtstp: contraction number = 1.254908e-01
Vnewton: Using errtol_s: 88195.738644
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.339131e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.405881e+04
Vprtstp: contraction number = 1.405881e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.028293e-03
Vprtstp: contraction number = 1.510339e-01
Vnewton: Using errtol_s: 13320.547982
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.488786e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.374276e+03
Vprtstp: contraction number = 2.374276e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.697507e-04
Vprtstp: contraction number = 1.650801e-01
Vnewton: Using errtol_s: 2198.957653
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.638429e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.096095e+02
Vprtstp: contraction number = 4.096095e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.850645e-05
Vprtstp: contraction number = 1.679312e-01
Vnewton: Using errtol_s: 369.273642
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.789382e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.960011e+01
Vprtstp: contraction number = 6.960011e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.835826e-06
Vprtstp: contraction number = 1.696397e-01
Vnewton: Using errtol_s: 62.643477
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.938043e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.470634e+01
Vprtstp: contraction number = 1.470634e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.021748e-06
Vprtstp: contraction number = 2.112871e-01
Vnewton: Using errtol_s: 13.235760
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.086968e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.628824e+00
Vprtstp: contraction number = 3.628824e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.521189e-07
Vprtstp: contraction number = 2.467526e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.293357e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.456487e+00
Vpmg_setPart:  lower corner = (-52.976, -20.079, -18.35)
Vpmg_setPart:  upper corner = (66.965, 82.976, 96.535)
Vpmg_setPart:  actual minima = (-52.976, -20.079, -18.35)
Vpmg_setPart:  actual maxima = (66.965, 82.976, 96.535)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -21
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880698 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -42.976, -10.079, -8.35
VPMG::focusFillBound -- New mesh maxs = 56.965, 72.976, 86.535
VPMG::focusFillBound -- Old mesh mins = -52.976, -20.079, -18.35
VPMG::focusFillBound -- Old mesh maxs = 66.965, 82.976, 96.535
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.356157
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.880187e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.384500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 9.942600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.249594e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 15277338.557002
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.346863e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.182170e+06
Vprtstp: contraction number = 1.182170e+06
Vnewton: Attempting damping, relres = 0.072050
Vnewton: Attempting damping, relres = 0.530774
Vnewton: Damping accepted, relres = 0.072050
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.204969e-02
Vprtstp: contraction number = 7.204969e-02
Vnewton: Using errtol_s: 1100727.493695
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.541730e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.574233e+05
Vprtstp: contraction number = 1.574233e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.554117e-03
Vprtstp: contraction number = 1.326046e-01
Vnewton: Using errtol_s: 145961.477824
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.694732e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.503896e+04
Vprtstp: contraction number = 2.503896e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.506497e-03
Vprtstp: contraction number = 1.576804e-01
Vnewton: Using errtol_s: 23015.259079
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.847633e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.482672e+03
Vprtstp: contraction number = 4.482672e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.660085e-04
Vprtstp: contraction number = 1.765742e-01
Vnewton: Using errtol_s: 4063.901720
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.002173e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.789091e+02
Vprtstp: contraction number = 8.789091e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.178965e-05
Vprtstp: contraction number = 1.946917e-01
Vnewton: Using errtol_s: 791.208081
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.156716e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.970758e+02
Vprtstp: contraction number = 1.970758e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.160999e-05
Vprtstp: contraction number = 2.241758e-01
Vnewton: Using errtol_s: 177.369728
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.310564e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.422165e+01
Vprtstp: contraction number = 5.422165e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.194254e-06
Vprtstp: contraction number = 2.751298e-01
Vnewton: Using errtol_s: 48.799701
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.465525e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.734813e+01
Vprtstp: contraction number = 1.734813e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.021994e-06
Vprtstp: contraction number = 3.199477e-01
Vnewton: Using errtol_s: 15.613350
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.618096e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.132492e+00
Vprtstp: contraction number = 6.132492e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.612703e-07
Vprtstp: contraction number = 3.534955e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.485883e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.649156e+00
Vpmg_setPart:  lower corner = (-42.976, -10.079, -8.35)
Vpmg_setPart:  upper corner = (56.965, 72.976, 86.535)
Vpmg_setPart:  actual minima = (-42.976, -10.079, -8.35)
Vpmg_setPart:  actual maxima = (56.965, 72.976, 86.535)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.055434e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11770 atoms
Valist_getStatistics:  Max atom coordinate:  (46.965, 62.976, 76.535)
Valist_getStatistics:  Min atom coordinate:  (-32.976, -0.079, 1.65)
Valist_getStatistics:  Molecule center:  (6.9945, 31.4485, 39.0925)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.937039, 0.805117, 0.897539
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.780789, 0.648867, 0.741289
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.833251, 0.805929, 0.825913 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 66.965 82.976 96.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -52.976 -20.079 -18.35
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 56.965 72.976 86.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -42.976 -10.079 -8.35
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 56.965 72.976 86.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -42.976 -10.079 -8.35
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -21
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880698 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.342117
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.726900e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.351500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.020270e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.920463e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.110957e-02
Vprtstp: contraction number = 5.110957e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.333815e-03
Vprtstp: contraction number = 1.239262e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.428291e-04
Vprtstp: contraction number = 1.488564e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.547021e-04
Vprtstp: contraction number = 1.640829e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.558024e-05
Vprtstp: contraction number = 1.653516e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.543709e-06
Vprtstp: contraction number = 1.776257e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.698130e-07
Vprtstp: contraction number = 2.134408e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.423510e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.101610e-01
Vpmg_setPart:  lower corner = (-52.976, -20.079, -18.35)
Vpmg_setPart:  upper corner = (66.965, 82.976, 96.535)
Vpmg_setPart:  actual minima = (-52.976, -20.079, -18.35)
Vpmg_setPart:  actual maxima = (66.965, 82.976, 96.535)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -21
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880698 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -42.976, -10.079, -8.35
VPMG::focusFillBound -- New mesh maxs = 56.965, 72.976, 86.535
VPMG::focusFillBound -- Old mesh mins = -52.976, -20.079, -18.35
VPMG::focusFillBound -- Old mesh maxs = 66.965, 82.976, 96.535
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.345669
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.867774e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.380300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.771500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.498501e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.970434e-02
Vprtstp: contraction number = 6.970434e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.216716e-03
Vprtstp: contraction number = 1.322259e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.444914e-03
Vprtstp: contraction number = 1.567710e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.537134e-04
Vprtstp: contraction number = 1.755906e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.020166e-05
Vprtstp: contraction number = 1.978676e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.192892e-05
Vprtstp: contraction number = 2.376200e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.474512e-06
Vprtstp: contraction number = 2.912680e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.161155e-06
Vprtstp: contraction number = 3.341924e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.197639e-07
Vprtstp: contraction number = 3.615053e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.851840e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.485290e-01
Vpmg_setPart:  lower corner = (-42.976, -10.079, -8.35)
Vpmg_setPart:  upper corner = (56.965, 72.976, 86.535)
Vpmg_setPart:  actual minima = (-42.976, -10.079, -8.35)
Vpmg_setPart:  actual maxima = (56.965, 72.976, 86.535)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.508853e+00
