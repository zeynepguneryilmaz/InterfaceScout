##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11095 atoms
Valist_getStatistics:  Max atom coordinate:  (-3.331, 72.827, 39.722)
Valist_getStatistics:  Min atom coordinate:  (-82.399, -8.218, -29.691)
Valist_getStatistics:  Molecule center:  (-42.865, 32.3045, 5.0155)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.930219, 0.945664, 0.854789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.773969, 0.789414, 0.698539
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.832029, 0.834772, 0.817206 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 16.669 92.827 59.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -102.399 -28.218 -49.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 6.669 82.827 49.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -92.399 -18.218 -39.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 6.669 82.827 49.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -92.399 -18.218 -39.691
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479361 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.315589
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.709505e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.699600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.034280e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.908180e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 11979968.032437
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.005368e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.645625e+05
Vprtstp: contraction number = 6.645625e+05
Vnewton: Attempting damping, relres = 0.054310
Vnewton: Attempting damping, relres = 0.520064
Vnewton: Damping accepted, relres = 0.054310
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.430974e-02
Vprtstp: contraction number = 5.430974e-02
Vnewton: Using errtol_s: 650628.985742
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.193769e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.479248e+04
Vprtstp: contraction number = 8.479248e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.292132e-03
Vprtstp: contraction number = 1.342693e-01
Vnewton: Using errtol_s: 87359.506363
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.344077e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.404314e+04
Vprtstp: contraction number = 1.404314e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.304563e-03
Vprtstp: contraction number = 1.789001e-01
Vnewton: Using errtol_s: 15628.627870
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.496383e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.921571e+03
Vprtstp: contraction number = 2.921571e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.783676e-04
Vprtstp: contraction number = 2.133799e-01
Vnewton: Using errtol_s: 3334.834927
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.646813e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.214743e+02
Vprtstp: contraction number = 7.214743e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.229534e-05
Vprtstp: contraction number = 2.237880e-01
Vnewton: Using errtol_s: 746.296188
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.804105e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.824389e+02
Vprtstp: contraction number = 1.824389e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.400388e-05
Vprtstp: contraction number = 2.247981e-01
Vnewton: Using errtol_s: 167.765994
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.960502e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.346479e+01
Vprtstp: contraction number = 4.346479e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.266820e-06
Vprtstp: contraction number = 2.332797e-01
Vnewton: Using errtol_s: 39.136400
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.118174e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.033691e+01
Vprtstp: contraction number = 1.033691e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.765673e-07
Vprtstp: contraction number = 2.377135e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.329035e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.501523e+00
Vpmg_setPart:  lower corner = (-102.399, -28.218, -49.691)
Vpmg_setPart:  upper corner = (16.669, 92.827, 59.722)
Vpmg_setPart:  actual minima = (-102.399, -28.218, -49.691)
Vpmg_setPart:  actual maxima = (16.669, 92.827, 59.722)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479361 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -92.399, -18.218, -39.691
VPMG::focusFillBound -- New mesh maxs = 6.669, 82.827, 49.722
VPMG::focusFillBound -- Old mesh mins = -102.399, -28.218, -49.691
VPMG::focusFillBound -- Old mesh maxs = 16.669, 92.827, 59.722
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.314377
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.859557e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.804100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.066590e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.277491e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 14218284.347612
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.380722e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.032939e+06
Vprtstp: contraction number = 1.032939e+06
Vnewton: Attempting damping, relres = 0.068361
Vnewton: Attempting damping, relres = 0.528610
Vnewton: Damping accepted, relres = 0.068361
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.836091e-02
Vprtstp: contraction number = 6.836091e-02
Vnewton: Using errtol_s: 971974.926399
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.583190e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.338109e+05
Vprtstp: contraction number = 1.338109e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.031210e-03
Vprtstp: contraction number = 1.321107e-01
Vnewton: Using errtol_s: 128408.315845
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.741658e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.126129e+04
Vprtstp: contraction number = 2.126129e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.486471e-03
Vprtstp: contraction number = 1.645926e-01
Vnewton: Using errtol_s: 21135.060942
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.902949e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.969214e+03
Vprtstp: contraction number = 3.969214e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.801983e-04
Vprtstp: contraction number = 1.884991e-01
Vnewton: Using errtol_s: 3983.939104
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.057277e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.505479e+02
Vprtstp: contraction number = 8.505479e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.639368e-05
Vprtstp: contraction number = 2.012634e-01
Vnewton: Using errtol_s: 801.821311
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.211153e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.897179e+02
Vprtstp: contraction number = 1.897179e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.203118e-05
Vprtstp: contraction number = 2.133427e-01
Vnewton: Using errtol_s: 171.062717
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.371879e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.257350e+01
Vprtstp: contraction number = 4.257350e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.695038e-06
Vprtstp: contraction number = 2.240045e-01
Vnewton: Using errtol_s: 38.318813
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.526136e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.067823e+01
Vprtstp: contraction number = 1.067823e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.759192e-07
Vprtstp: contraction number = 2.508014e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.367025e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.543192e+00
Vpmg_setPart:  lower corner = (-92.399, -18.218, -39.691)
Vpmg_setPart:  upper corner = (6.669, 82.827, 49.722)
Vpmg_setPart:  actual minima = (-92.399, -18.218, -39.691)
Vpmg_setPart:  actual maxima = (6.669, 82.827, 49.722)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.982631e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:10 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11095 atoms
Valist_getStatistics:  Max atom coordinate:  (-3.331, 72.827, 39.722)
Valist_getStatistics:  Min atom coordinate:  (-82.399, -8.218, -29.691)
Valist_getStatistics:  Molecule center:  (-42.865, 32.3045, 5.0155)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.930219, 0.945664, 0.854789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.773969, 0.789414, 0.698539
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.832029, 0.834772, 0.817206 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 16.669 92.827 59.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -102.399 -28.218 -49.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 6.669 82.827 49.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -92.399 -18.218 -39.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 6.669 82.827 49.722
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -92.399 -18.218 -39.691
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479361 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.254933
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.636415e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.920600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.083650e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.842884e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.992553e-02
Vprtstp: contraction number = 4.992553e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.240394e-03
Vprtstp: contraction number = 1.249940e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.582209e-04
Vprtstp: contraction number = 1.535513e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.630187e-04
Vprtstp: contraction number = 1.701264e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.926498e-05
Vprtstp: contraction number = 1.795192e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.655568e-06
Vprtstp: contraction number = 1.932538e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.263312e-06
Vprtstp: contraction number = 2.233749e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.231067e-07
Vprtstp: contraction number = 2.557616e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.686180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.501520e-01
Vpmg_setPart:  lower corner = (-102.399, -28.218, -49.691)
Vpmg_setPart:  upper corner = (16.669, 92.827, 59.722)
Vpmg_setPart:  actual minima = (-102.399, -28.218, -49.691)
Vpmg_setPart:  actual maxima = (16.669, 92.827, 59.722)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 3
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479361 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -92.399, -18.218, -39.691
VPMG::focusFillBound -- New mesh maxs = 6.669, 82.827, 49.722
VPMG::focusFillBound -- Old mesh mins = -102.399, -28.218, -49.691
VPMG::focusFillBound -- Old mesh maxs = 16.669, 92.827, 59.722
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.243805
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.769746e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.767600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.083260e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.465489e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.540045e-02
Vprtstp: contraction number = 6.540045e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.390940e-03
Vprtstp: contraction number = 1.283010e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.292515e-03
Vprtstp: contraction number = 1.540370e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.203951e-04
Vprtstp: contraction number = 1.705164e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.985670e-05
Vprtstp: contraction number = 1.808420e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.497641e-06
Vprtstp: contraction number = 1.881149e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.619901e-06
Vprtstp: contraction number = 2.160548e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.028632e-07
Vprtstp: contraction number = 2.486961e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.873170e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.669820e-01
Vpmg_setPart:  lower corner = (-92.399, -18.218, -39.691)
Vpmg_setPart:  upper corner = (6.669, 82.827, 49.722)
Vpmg_setPart:  actual minima = (-92.399, -18.218, -39.691)
Vpmg_setPart:  actual maxima = (6.669, 82.827, 49.722)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.490790e+00
