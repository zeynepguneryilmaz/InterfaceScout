##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:53 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2486 atoms
Valist_getStatistics:  Max atom coordinate:  (9.194, 36.011, 10.98)
Valist_getStatistics:  Min atom coordinate:  (-35.21, -3.962, -29.901)
Valist_getStatistics:  Molecule center:  (-13.008, 16.0245, -9.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.879208, 0.833052, 0.84251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.670875, 0.624719, 0.634177
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763044, 0.749916, 0.752723 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 29.194 56.011 30.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -55.21 -23.962 -49.901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 19.194 46.011 20.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -45.21 -13.962 -39.901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 19.194 46.011 20.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -45.21 -13.962 -39.901
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.312759
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.989040e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.870600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.138800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.896700e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.102454e-02
Vprtstp: contraction number = 7.102454e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.703004e-03
Vprtstp: contraction number = 1.366148e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.237245e-03
Vprtstp: contraction number = 2.305725e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.458992e-04
Vprtstp: contraction number = 2.887029e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.499690e-04
Vprtstp: contraction number = 3.870093e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.252248e-05
Vprtstp: contraction number = 3.701358e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.086832e-05
Vprtstp: contraction number = 4.417123e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.583888e-05
Vprtstp: contraction number = 3.875587e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.185148e-06
Vprtstp: contraction number = 4.536400e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.815878e-06
Vprtstp: contraction number = 3.919025e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.284356e-06
Vprtstp: contraction number = 4.561122e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.055398e-07
Vprtstp: contraction number = 3.936133e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.227180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.037280e-01
Vpmg_setPart:  lower corner = (-55.21, -23.962, -49.901)
Vpmg_setPart:  upper corner = (29.194, 56.011, 30.98)
Vpmg_setPart:  actual minima = (-55.21, -23.962, -49.901)
Vpmg_setPart:  actual maxima = (29.194, 56.011, 30.98)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -45.21, -13.962, -39.901
VPMG::focusFillBound -- New mesh maxs = 19.194, 46.011, 20.98
VPMG::focusFillBound -- Old mesh mins = -55.21, -23.962, -49.901
VPMG::focusFillBound -- Old mesh maxs = 29.194, 56.011, 30.98
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.306493
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.604780e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.912800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.400900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.649341e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.669793e-02
Vprtstp: contraction number = 9.669793e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.319291e-02
Vprtstp: contraction number = 1.364342e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.442951e-03
Vprtstp: contraction number = 1.851716e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.484750e-04
Vprtstp: contraction number = 2.245133e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.734044e-04
Vprtstp: contraction number = 3.161574e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.884147e-05
Vprtstp: contraction number = 3.393308e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.525999e-05
Vprtstp: contraction number = 4.292890e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.003454e-05
Vprtstp: contraction number = 3.972502e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.747175e-06
Vprtstp: contraction number = 4.730836e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.986432e-06
Vprtstp: contraction number = 4.184450e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.644062e-07
Vprtstp: contraction number = 4.854968e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.910020e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.651320e-01
Vpmg_setPart:  lower corner = (-45.21, -13.962, -39.901)
Vpmg_setPart:  upper corner = (19.194, 46.011, 20.98)
Vpmg_setPart:  actual minima = (-45.21, -13.962, -39.901)
Vpmg_setPart:  actual maxima = (19.194, 46.011, 20.98)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.225087e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2486 atoms
Valist_getStatistics:  Max atom coordinate:  (9.194, 36.011, 10.98)
Valist_getStatistics:  Min atom coordinate:  (-35.21, -3.962, -29.901)
Valist_getStatistics:  Molecule center:  (-13.008, 16.0245, -9.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.879208, 0.833052, 0.84251
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.670875, 0.624719, 0.634177
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763044, 0.749916, 0.752723 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 29.194 56.011 30.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -55.21 -23.962 -49.901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 19.194 46.011 20.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -45.21 -13.962 -39.901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 19.194 46.011 20.98
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -45.21 -13.962 -39.901
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.310784
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.968430e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.868900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.963800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.744020e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2835799.109822
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.291110e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.913974e+05
Vprtstp: contraction number = 1.913974e+05
Vnewton: Attempting damping, relres = 0.069160
Vnewton: Attempting damping, relres = 0.525556
Vnewton: Damping accepted, relres = 0.069160
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.916021e-02
Vprtstp: contraction number = 6.916021e-02
Vnewton: Using errtol_s: 196124.471720
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.343720e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.495327e+04
Vprtstp: contraction number = 2.495327e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.047588e-03
Vprtstp: contraction number = 1.308207e-01
Vnewton: Using errtol_s: 25657.142128
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.144290e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.987506e+03
Vprtstp: contraction number = 3.987506e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.393978e-03
Vprtstp: contraction number = 1.540717e-01
Vnewton: Using errtol_s: 3953.040246
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.959220e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.142421e+02
Vprtstp: contraction number = 7.142421e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.328444e-04
Vprtstp: contraction number = 1.670360e-01
Vnewton: Using errtol_s: 660.300011
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.777280e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.336255e+02
Vprtstp: contraction number = 1.336255e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.246539e-05
Vprtstp: contraction number = 1.823767e-01
Vnewton: Using errtol_s: 120.423317
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.061141e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.630746e+01
Vprtstp: contraction number = 2.630746e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.349434e-06
Vprtstp: contraction number = 1.966174e-01
Vnewton: Using errtol_s: 23.677318
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.146507e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.404383e+00
Vprtstp: contraction number = 5.404383e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.715196e-06
Vprtstp: contraction number = 2.054266e-01
Vnewton: Using errtol_s: 4.863950
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.230327e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.138827e+00
Vprtstp: contraction number = 1.138827e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.614306e-07
Vprtstp: contraction number = 2.107227e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.176100e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.857190e-01
Vpmg_setPart:  lower corner = (-55.21, -23.962, -49.901)
Vpmg_setPart:  upper corner = (29.194, 56.011, 30.98)
Vpmg_setPart:  actual minima = (-55.21, -23.962, -49.901)
Vpmg_setPart:  actual maxima = (29.194, 56.011, 30.98)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -45.21, -13.962, -39.901
VPMG::focusFillBound -- New mesh maxs = 19.194, 46.011, 20.98
VPMG::focusFillBound -- Old mesh mins = -55.21, -23.962, -49.901
VPMG::focusFillBound -- Old mesh maxs = 29.194, 56.011, 30.98
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.309832
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.638160e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.879800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.014100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.926777e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3565630.413700
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.981565e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.612156e+05
Vprtstp: contraction number = 3.612156e+05
Vnewton: Attempting damping, relres = 0.096900
Vnewton: Attempting damping, relres = 0.542664
Vnewton: Damping accepted, relres = 0.096900
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.690026e-02
Vprtstp: contraction number = 9.690026e-02
Vnewton: Using errtol_s: 345510.508485
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.088547e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.858313e+04
Vprtstp: contraction number = 4.858313e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.285901e-02
Vprtstp: contraction number = 1.327036e-01
Vnewton: Using errtol_s: 45850.488434
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.170439e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.732318e+03
Vprtstp: contraction number = 7.732318e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.988079e-03
Vprtstp: contraction number = 1.546059e-01
Vnewton: Using errtol_s: 7088.755411
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.252066e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.363443e+03
Vprtstp: contraction number = 1.363443e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.445962e-04
Vprtstp: contraction number = 1.733312e-01
Vnewton: Using errtol_s: 1228.702655
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.335024e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.604931e+02
Vprtstp: contraction number = 2.604931e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.575165e-05
Vprtstp: contraction number = 1.908078e-01
Vnewton: Using errtol_s: 234.446087
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.417176e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.188663e+01
Vprtstp: contraction number = 5.188663e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.309670e-05
Vprtstp: contraction number = 1.991844e-01
Vnewton: Using errtol_s: 46.697995
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.497794e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.031247e+01
Vprtstp: contraction number = 1.031247e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.602968e-06
Vprtstp: contraction number = 1.987499e-01
Vnewton: Using errtol_s: 9.281223
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.581299e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.014392e+00
Vprtstp: contraction number = 2.014392e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.084523e-07
Vprtstp: contraction number = 1.953356e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.160100e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.847640e-01
Vpmg_setPart:  lower corner = (-45.21, -13.962, -39.901)
Vpmg_setPart:  upper corner = (19.194, 46.011, 20.98)
Vpmg_setPart:  actual minima = (-45.21, -13.962, -39.901)
Vpmg_setPart:  actual maxima = (19.194, 46.011, 20.98)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.833068e+00
