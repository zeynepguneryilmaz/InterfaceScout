##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:00 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8701 atoms
Valist_getStatistics:  Max atom coordinate:  (74.16, 40.994, 76.405)
Valist_getStatistics:  Min atom coordinate:  (3.877, -27.049, 28.812)
Valist_getStatistics:  Molecule center:  (39.0185, 6.9725, 52.6085)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.861586, 0.844086, 0.912427
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.705336, 0.687836, 0.704094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.818648, 0.814889, 0.771671 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 94.16 60.994 96.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -16.123 -47.049 8.812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.16 50.994 86.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -6.123 -37.049 18.812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.16 50.994 86.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -6.123 -37.049 18.812
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -27
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9200260 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.144837
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.499947e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.340100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.220600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.646439e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 10128942.918923
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.755338e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.401236e+05
Vprtstp: contraction number = 5.401236e+05
Vnewton: Attempting damping, relres = 0.054208
Vnewton: Attempting damping, relres = 0.519476
Vnewton: Damping accepted, relres = 0.054208
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.420801e-02
Vprtstp: contraction number = 5.420801e-02
Vnewton: Using errtol_s: 549069.887102
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.958243e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.687888e+04
Vprtstp: contraction number = 6.687888e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.777407e-03
Vprtstp: contraction number = 1.250259e-01
Vnewton: Using errtol_s: 68647.964159
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.123702e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.080144e+04
Vprtstp: contraction number = 1.080144e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.078132e-03
Vprtstp: contraction number = 1.590773e-01
Vnewton: Using errtol_s: 10920.333192
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.289655e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.137841e+03
Vprtstp: contraction number = 2.137841e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.150014e-04
Vprtstp: contraction number = 1.994204e-01
Vnewton: Using errtol_s: 2177.736776
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.453740e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.982653e+02
Vprtstp: contraction number = 4.982653e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.693330e-05
Vprtstp: contraction number = 2.182930e-01
Vnewton: Using errtol_s: 475.384731
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.618611e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.147066e+02
Vprtstp: contraction number = 1.147066e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.023315e-05
Vprtstp: contraction number = 2.180361e-01
Vnewton: Using errtol_s: 103.651037
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.785052e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.555737e+01
Vprtstp: contraction number = 2.555737e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.270929e-06
Vprtstp: contraction number = 2.219187e-01
Vnewton: Using errtol_s: 23.002105
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.948273e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.710031e+00
Vprtstp: contraction number = 5.710031e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.073608e-07
Vprtstp: contraction number = 2.234156e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.429692e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.553404e+00
Vpmg_setPart:  lower corner = (-16.123, -47.049, 8.812)
Vpmg_setPart:  upper corner = (94.16, 60.994, 96.405)
Vpmg_setPart:  actual minima = (-16.123, -47.049, 8.812)
Vpmg_setPart:  actual maxima = (94.16, 60.994, 96.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -27
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9200260 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -6.123, -37.049, 18.812
VPMG::focusFillBound -- New mesh maxs = 84.16, 50.994, 86.405
VPMG::focusFillBound -- Old mesh mins = -16.123, -47.049, 8.812
VPMG::focusFillBound -- Old mesh maxs = 94.16, 60.994, 96.405
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.141907
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.614481e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.321200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.024700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.817173e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12125603.007605
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.918610e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.812145e+05
Vprtstp: contraction number = 8.812145e+05
Vnewton: Attempting damping, relres = 0.070572
Vnewton: Attempting damping, relres = 0.529379
Vnewton: Damping accepted, relres = 0.070572
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.057151e-02
Vprtstp: contraction number = 7.057151e-02
Vnewton: Using errtol_s: 855722.077430
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.121455e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.074684e+05
Vprtstp: contraction number = 1.074684e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.706042e-03
Vprtstp: contraction number = 1.233648e-01
Vnewton: Using errtol_s: 105566.013849
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.277296e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.655114e+04
Vprtstp: contraction number = 1.655114e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.352362e-03
Vprtstp: contraction number = 1.553360e-01
Vnewton: Using errtol_s: 16398.207461
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.435144e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.112612e+03
Vprtstp: contraction number = 3.112612e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.622577e-04
Vprtstp: contraction number = 1.939256e-01
Vnewton: Using errtol_s: 3180.032992
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.594473e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.163638e+02
Vprtstp: contraction number = 7.163638e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.687157e-05
Vprtstp: contraction number = 2.168537e-01
Vnewton: Using errtol_s: 689.602067
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.753466e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.641280e+02
Vprtstp: contraction number = 1.641280e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.222016e-05
Vprtstp: contraction number = 2.148730e-01
Vnewton: Using errtol_s: 148.176852
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.913052e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.511901e+01
Vprtstp: contraction number = 3.511901e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.606785e-06
Vprtstp: contraction number = 2.133183e-01
Vnewton: Using errtol_s: 31.608836
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.073893e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.277824e+00
Vprtstp: contraction number = 7.277824e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.401834e-07
Vprtstp: contraction number = 2.072221e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.377683e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.499755e+00
Vpmg_setPart:  lower corner = (-6.123, -37.049, 18.812)
Vpmg_setPart:  upper corner = (84.16, 50.994, 86.405)
Vpmg_setPart:  actual minima = (-6.123, -37.049, 18.812)
Vpmg_setPart:  actual maxima = (84.16, 50.994, 86.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.546075e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8701 atoms
Valist_getStatistics:  Max atom coordinate:  (74.16, 40.994, 76.405)
Valist_getStatistics:  Min atom coordinate:  (3.877, -27.049, 28.812)
Valist_getStatistics:  Molecule center:  (39.0185, 6.9725, 52.6085)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.861586, 0.844086, 0.912427
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.705336, 0.687836, 0.704094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.818648, 0.814889, 0.771671 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 94.16 60.994 96.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -16.123 -47.049 8.812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.16 50.994 86.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -6.123 -37.049 18.812
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.16 50.994 86.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -6.123 -37.049 18.812
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -27
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9200260 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.146656
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.500570e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.549300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.153100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.671830e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.513933e-02
Vprtstp: contraction number = 5.513933e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.725022e-03
Vprtstp: contraction number = 1.401000e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.226538e-03
Vprtstp: contraction number = 2.882241e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.227466e-04
Vprtstp: contraction number = 3.695184e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.221289e-04
Vprtstp: contraction number = 5.130727e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.916887e-04
Vprtstp: contraction number = 4.541000e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.079524e-04
Vprtstp: contraction number = 5.631652e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.003435e-05
Vprtstp: contraction number = 4.634852e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.877091e-05
Vprtstp: contraction number = 5.750232e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.332926e-05
Vprtstp: contraction number = 4.632895e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.738710e-06
Vprtstp: contraction number = 5.805806e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.572643e-06
Vprtstp: contraction number = 4.616587e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.086502e-06
Vprtstp: contraction number = 5.840219e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.597757e-07
Vprtstp: contraction number = 4.599928e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.070125e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.218898e+00
Vpmg_setPart:  lower corner = (-16.123, -47.049, 8.812)
Vpmg_setPart:  upper corner = (94.16, 60.994, 96.405)
Vpmg_setPart:  actual minima = (-16.123, -47.049, 8.812)
Vpmg_setPart:  actual maxima = (94.16, 60.994, 96.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -27
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9200260 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -6.123, -37.049, 18.812
VPMG::focusFillBound -- New mesh maxs = 84.16, 50.994, 86.405
VPMG::focusFillBound -- Old mesh mins = -16.123, -47.049, 8.812
VPMG::focusFillBound -- Old mesh maxs = 94.16, 60.994, 96.405
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.141523
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.616284e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.488700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.199200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.511881e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.985044e-02
Vprtstp: contraction number = 6.985044e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.054090e-03
Vprtstp: contraction number = 1.296211e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.908213e-03
Vprtstp: contraction number = 2.107571e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.161436e-04
Vprtstp: contraction number = 2.704853e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.096752e-04
Vprtstp: contraction number = 4.062342e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.026951e-05
Vprtstp: contraction number = 3.828279e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.963475e-05
Vprtstp: contraction number = 4.937709e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.655767e-05
Vprtstp: contraction number = 4.177563e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.451139e-06
Vprtstp: contraction number = 5.104064e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.620327e-06
Vprtstp: contraction number = 4.283833e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.860290e-06
Vprtstp: contraction number = 5.138458e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 8.036900e-07
Vprtstp: contraction number = 4.320242e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.605620e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.009682e+00
Vpmg_setPart:  lower corner = (-6.123, -37.049, 18.812)
Vpmg_setPart:  upper corner = (84.16, 50.994, 86.405)
Vpmg_setPart:  actual minima = (-6.123, -37.049, 18.812)
Vpmg_setPart:  actual maxima = (84.16, 50.994, 86.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.715008e+00
