##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:54 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6622 atoms
Valist_getStatistics:  Max atom coordinate:  (-8.74, 32.263, 13.414)
Valist_getStatistics:  Min atom coordinate:  (-64.121, -43.559, -33.761)
Valist_getStatistics:  Molecule center:  (-36.4305, -5.648, -10.1735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.993552, 0.904859, 0.908073
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.785219, 0.748609, 0.69974
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790315, 0.827321, 0.770576 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 11.26 52.263 33.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -84.121 -63.559 -53.761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 1.26 42.263 23.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -74.121 -53.559 -43.761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 1.26 42.263 23.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -74.121 -53.559 -43.761
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.858994
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.129245e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.657400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.041900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.249678e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.912806e-02
Vprtstp: contraction number = 4.912806e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.918930e-03
Vprtstp: contraction number = 1.204796e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.092621e-03
Vprtstp: contraction number = 1.845978e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.047948e-04
Vprtstp: contraction number = 1.874344e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.353164e-05
Vprtstp: contraction number = 2.613916e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.256274e-05
Vprtstp: contraction number = 2.346789e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.708697e-06
Vprtstp: contraction number = 2.952140e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.745706e-07
Vprtstp: contraction number = 2.627798e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.702130e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.722680e-01
Vpmg_setPart:  lower corner = (-84.121, -63.559, -53.761)
Vpmg_setPart:  upper corner = (11.26, 52.263, 33.414)
Vpmg_setPart:  actual minima = (-84.121, -63.559, -53.761)
Vpmg_setPart:  actual maxima = (11.26, 52.263, 33.414)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -74.121, -53.559, -43.761
VPMG::focusFillBound -- New mesh maxs = 1.26, 42.263, 23.414
VPMG::focusFillBound -- Old mesh mins = -84.121, -63.559, -53.761
VPMG::focusFillBound -- Old mesh maxs = 11.26, 52.263, 33.414
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.851835
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.205785e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.476900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.908300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.927529e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.221098e-02
Vprtstp: contraction number = 6.221098e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.728942e-03
Vprtstp: contraction number = 1.242376e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.269165e-03
Vprtstp: contraction number = 1.642095e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.435307e-04
Vprtstp: contraction number = 1.918826e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.293602e-05
Vprtstp: contraction number = 2.584315e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.708310e-05
Vprtstp: contraction number = 2.714360e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.562854e-06
Vprtstp: contraction number = 3.256349e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.766034e-06
Vprtstp: contraction number = 3.174691e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.307448e-07
Vprtstp: contraction number = 3.571532e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.262360e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.248350e-01
Vpmg_setPart:  lower corner = (-74.121, -53.559, -43.761)
Vpmg_setPart:  upper corner = (1.26, 42.263, 23.414)
Vpmg_setPart:  actual minima = (-74.121, -53.559, -43.761)
Vpmg_setPart:  actual maxima = (1.26, 42.263, 23.414)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.609293e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:58 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6622 atoms
Valist_getStatistics:  Max atom coordinate:  (-8.74, 32.263, 13.414)
Valist_getStatistics:  Min atom coordinate:  (-64.121, -43.559, -33.761)
Valist_getStatistics:  Molecule center:  (-36.4305, -5.648, -10.1735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.993552, 0.904859, 0.908073
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.785219, 0.748609, 0.69974
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790315, 0.827321, 0.770576 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 11.26 52.263 33.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -84.121 -63.559 -53.761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 1.26 42.263 23.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -74.121 -53.559 -43.761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 1.26 42.263 23.414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -74.121 -53.559 -43.761
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.855582
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.120893e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.467500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.000800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.226439e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6850950.129913
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.299778e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.379244e+05
Vprtstp: contraction number = 3.379244e+05
Vnewton: Attempting damping, relres = 0.114514
Vnewton: Attempting damping, relres = 0.517535
Vnewton: Damping accepted, relres = 0.114514
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.145142e-01
Vprtstp: contraction number = 1.145142e-01
Vnewton: Using errtol_s: 784530.958323
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.441914e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.535963e+04
Vprtstp: contraction number = 4.535963e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.089101e-02
Vprtstp: contraction number = 2.697571e-01
Vnewton: Using errtol_s: 211632.789982
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.547787e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.073355e+04
Vprtstp: contraction number = 1.073355e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.026789e-02
Vprtstp: contraction number = 3.323910e-01
Vnewton: Using errtol_s: 70344.828661
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.654113e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.577480e+03
Vprtstp: contraction number = 4.577480e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.657007e-03
Vprtstp: contraction number = 3.561594e-01
Vnewton: Using errtol_s: 25053.973859
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.760329e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.476032e+03
Vprtstp: contraction number = 2.476032e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.310070e-03
Vprtstp: contraction number = 3.582356e-01
Vnewton: Using errtol_s: 8975.224572
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.865031e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.278788e+03
Vprtstp: contraction number = 1.278788e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.387994e-04
Vprtstp: contraction number = 3.349435e-01
Vnewton: Using errtol_s: 3006.192808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.969803e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.373648e+02
Vprtstp: contraction number = 5.373648e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.215131e-04
Vprtstp: contraction number = 2.769217e-01
Vnewton: Using errtol_s: 832.480066
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.075452e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.692841e+02
Vprtstp: contraction number = 1.692841e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.631991e-05
Vprtstp: contraction number = 2.166014e-01
Vnewton: Using errtol_s: 180.316371
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.183900e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.968718e+01
Vprtstp: contraction number = 3.968718e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.299463e-06
Vprtstp: contraction number = 2.013481e-01
Vnewton: Using errtol_s: 36.306354
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.290655e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.402922e+00
Vprtstp: contraction number = 8.402922e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.104936e-06
Vprtstp: contraction number = 2.084996e-01
Vnewton: Using errtol_s: 7.569861
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.398878e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.850383e+00
Vprtstp: contraction number = 1.850383e+00
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.431012e-07
Vprtstp: contraction number = 2.200138e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.252921e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.340136e+00
Vpmg_setPart:  lower corner = (-84.121, -63.559, -53.761)
Vpmg_setPart:  upper corner = (11.26, 52.263, 33.414)
Vpmg_setPart:  actual minima = (-84.121, -63.559, -53.761)
Vpmg_setPart:  actual maxima = (11.26, 52.263, 33.414)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -74.121, -53.559, -43.761
VPMG::focusFillBound -- New mesh maxs = 1.26, 42.263, 23.414
VPMG::focusFillBound -- Old mesh mins = -84.121, -63.559, -53.761
VPMG::focusFillBound -- Old mesh maxs = 11.26, 52.263, 33.414
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.848529
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.200666e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.474400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.073900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.771463e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8493494.227864
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.845410e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.657296e+05
Vprtstp: contraction number = 5.657296e+05
Vnewton: Attempting damping, relres = 0.097609
Vnewton: Attempting damping, relres = 0.526293
Vnewton: Damping accepted, relres = 0.097609
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.760888e-02
Vprtstp: contraction number = 9.760888e-02
Vnewton: Using errtol_s: 829040.467090
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.989561e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.487123e+04
Vprtstp: contraction number = 7.487123e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.109319e-02
Vprtstp: contraction number = 2.160991e-01
Vnewton: Using errtol_s: 179154.890346
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.098716e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.551165e+04
Vprtstp: contraction number = 1.551165e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.233337e-03
Vprtstp: contraction number = 2.955142e-01
Vnewton: Using errtol_s: 52942.812111
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.208119e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.367599e+03
Vprtstp: contraction number = 5.367599e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.106769e-03
Vprtstp: contraction number = 3.379841e-01
Vnewton: Using errtol_s: 17893.828973
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.316553e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.343540e+03
Vprtstp: contraction number = 2.343540e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.222128e-04
Vprtstp: contraction number = 3.428059e-01
Vnewton: Using errtol_s: 6134.109861
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.425733e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.629475e+02
Vprtstp: contraction number = 9.629475e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.180663e-04
Vprtstp: contraction number = 3.019419e-01
Vnewton: Using errtol_s: 1852.144485
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.532903e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.306147e+02
Vprtstp: contraction number = 3.306147e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.966310e-05
Vprtstp: contraction number = 2.277432e-01
Vnewton: Using errtol_s: 421.813266
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.639272e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.251432e+01
Vprtstp: contraction number = 8.251432e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.216537e-06
Vprtstp: contraction number = 1.855812e-01
Vnewton: Using errtol_s: 78.280606
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.746899e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.654885e+01
Vprtstp: contraction number = 1.654885e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.755777e-06
Vprtstp: contraction number = 1.905028e-01
Vnewton: Using errtol_s: 14.912678
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.855614e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.322473e+00
Vprtstp: contraction number = 3.322473e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.520813e-07
Vprtstp: contraction number = 2.005274e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.165376e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.253671e+00
Vpmg_setPart:  lower corner = (-74.121, -53.559, -43.761)
Vpmg_setPart:  upper corner = (1.26, 42.263, 23.414)
Vpmg_setPart:  actual minima = (-74.121, -53.559, -43.761)
Vpmg_setPart:  actual maxima = (1.26, 42.263, 23.414)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.191787e+00
