##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:46 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6138 atoms
Valist_getStatistics:  Max atom coordinate:  (55.695, 86.664, 91.68)
Valist_getStatistics:  Min atom coordinate:  (4.658, 40.155, 25.691)
Valist_getStatistics:  Molecule center:  (30.1765, 63.4095, 58.6855)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.948302, 0.901135, 0.828039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.739969, 0.692802, 0.671789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.780309, 0.76881, 0.811301 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.695 106.664 111.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -15.342 20.155 5.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.695 96.664 101.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -5.342 30.155 15.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.695 96.664 101.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -5.342 30.155 15.691
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8282611 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.059811
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.419991e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.822900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.482500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.588401e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7147429.411922
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.676330e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.775926e+05
Vprtstp: contraction number = 3.775926e+05
Vnewton: Attempting damping, relres = 46.543317
Vnewton: Attempting damping, relres = 0.526248
Vnewton: Attempting damping, relres = 0.759253
Vnewton: Damping accepted, relres = 0.526248
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.262480e-01
Vprtstp: contraction number = 5.262480e-01
Vnewton: Using errtol_s: 3761320.515468
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.865547e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.089360e+05
Vprtstp: contraction number = 2.089360e+05
Vnewton: Attempting damping, relres = 0.029116
Vnewton: Attempting damping, relres = 0.274615
Vnewton: Damping accepted, relres = 0.029116
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.911604e-02
Vprtstp: contraction number = 5.532760e-02
Vnewton: Using errtol_s: 208104.832904
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.020073e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.746143e+04
Vprtstp: contraction number = 2.746143e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.906577e-03
Vprtstp: contraction number = 1.341727e-01
Vnewton: Using errtol_s: 27921.984726
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.138886e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.049493e+03
Vprtstp: contraction number = 5.049493e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.936896e-04
Vprtstp: contraction number = 1.775697e-01
Vnewton: Using errtol_s: 4958.097623
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.257315e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.261934e+03
Vprtstp: contraction number = 1.261934e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.618955e-04
Vprtstp: contraction number = 2.333833e-01
Vnewton: Using errtol_s: 1157.137012
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.375649e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.131833e+02
Vprtstp: contraction number = 4.131833e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.212328e-05
Vprtstp: contraction number = 3.219562e-01
Vnewton: Using errtol_s: 372.547466
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.493690e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.600903e+02
Vprtstp: contraction number = 1.600903e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.015978e-05
Vprtstp: contraction number = 3.867712e-01
Vnewton: Using errtol_s: 144.090634
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.611125e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.864787e+01
Vprtstp: contraction number = 5.864787e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.386461e-06
Vprtstp: contraction number = 3.663959e-01
Vnewton: Using errtol_s: 52.794212
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.734573e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.204333e+01
Vprtstp: contraction number = 2.204333e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.775689e-06
Vprtstp: contraction number = 3.757806e-01
Vnewton: Using errtol_s: 19.839040
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.852999e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.888982e+00
Vprtstp: contraction number = 7.888982e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.934040e-07
Vprtstp: contraction number = 3.578946e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.348607e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.488434e+00
Vpmg_setPart:  lower corner = (-15.342, 20.155, 5.691)
Vpmg_setPart:  upper corner = (75.695, 106.664, 111.68)
Vpmg_setPart:  actual minima = (-15.342, 20.155, 5.691)
Vpmg_setPart:  actual maxima = (75.695, 106.664, 111.68)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8282611 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -5.342, 30.155, 15.691
VPMG::focusFillBound -- New mesh maxs = 65.695, 96.664, 101.68
VPMG::focusFillBound -- Old mesh mins = -15.342, 20.155, 5.691
VPMG::focusFillBound -- Old mesh maxs = 75.695, 106.664, 111.68
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.052930
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.562483e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.829000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.220400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.642574e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8728204.604746
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.732041e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.676343e+05
Vprtstp: contraction number = 6.676343e+05
Vnewton: Attempting damping, relres = 58.397038
Vnewton: Attempting damping, relres = 0.538812
Vnewton: Attempting damping, relres = 0.765278
Vnewton: Damping accepted, relres = 0.538812
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.388125e-01
Vprtstp: contraction number = 5.388125e-01
Vnewton: Using errtol_s: 4702865.520279
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.924844e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.727492e+05
Vprtstp: contraction number = 3.727492e+05
Vnewton: Attempting damping, relres = 0.041377
Vnewton: Attempting damping, relres = 0.287794
Vnewton: Damping accepted, relres = 0.041377
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.137733e-02
Vprtstp: contraction number = 7.679357e-02
Vnewton: Using errtol_s: 361149.838484
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.083536e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.988747e+04
Vprtstp: contraction number = 4.988747e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.717059e-03
Vprtstp: contraction number = 1.381688e-01
Vnewton: Using errtol_s: 49899.656727
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.206465e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.423620e+03
Vprtstp: contraction number = 8.423620e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.697769e-04
Vprtstp: contraction number = 1.696286e-01
Vnewton: Using errtol_s: 8464.411322
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.327259e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.760180e+03
Vprtstp: contraction number = 1.760180e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.908097e-04
Vprtstp: contraction number = 1.967563e-01
Vnewton: Using errtol_s: 1665.426059
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.446208e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.470431e+02
Vprtstp: contraction number = 4.470431e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.642963e-05
Vprtstp: contraction number = 2.433295e-01
Vnewton: Using errtol_s: 405.247279
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.566886e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.569757e+02
Vprtstp: contraction number = 1.569757e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.618996e-05
Vprtstp: contraction number = 3.486989e-01
Vnewton: Using errtol_s: 141.309273
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.685663e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.105165e+01
Vprtstp: contraction number = 5.105165e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.265560e-06
Vprtstp: contraction number = 3.252362e-01
Vnewton: Using errtol_s: 45.958887
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.805498e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.887705e+01
Vprtstp: contraction number = 1.887705e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.946492e-06
Vprtstp: contraction number = 3.696648e-01
Vnewton: Using errtol_s: 16.989382
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.926696e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.453237e+00
Vprtstp: contraction number = 6.453237e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.654447e-07
Vprtstp: contraction number = 3.418687e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.368227e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.505797e+00
Vpmg_setPart:  lower corner = (-5.342, 30.155, 15.691)
Vpmg_setPart:  upper corner = (65.695, 96.664, 101.68)
Vpmg_setPart:  actual minima = (-5.342, 30.155, 15.691)
Vpmg_setPart:  actual maxima = (65.695, 96.664, 101.68)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.320006e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:52 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6138 atoms
Valist_getStatistics:  Max atom coordinate:  (55.695, 86.664, 91.68)
Valist_getStatistics:  Min atom coordinate:  (4.658, 40.155, 25.691)
Valist_getStatistics:  Molecule center:  (30.1765, 63.4095, 58.6855)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.948302, 0.901135, 0.828039
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.739969, 0.692802, 0.671789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.780309, 0.76881, 0.811301 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.695 106.664 111.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -15.342 20.155 5.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 65.695 96.664 101.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -5.342 30.155 15.691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 65.695 96.664 101.68
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -5.342 30.155 15.691
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8282611 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.062796
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.426730e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.823900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.989600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.601842e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.711338e-02
Vprtstp: contraction number = 5.711338e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.158033e-02
Vprtstp: contraction number = 2.027603e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.913396e-03
Vprtstp: contraction number = 3.379349e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.491971e-03
Vprtstp: contraction number = 3.812472e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.420793e-04
Vprtstp: contraction number = 4.303564e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.776741e-04
Vprtstp: contraction number = 4.324608e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.202705e-04
Vprtstp: contraction number = 4.331355e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.521099e-05
Vprtstp: contraction number = 4.590567e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.365350e-05
Vprtstp: contraction number = 4.284202e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.129980e-05
Vprtstp: contraction number = 4.777220e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.794687e-06
Vprtstp: contraction number = 4.243161e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.349403e-06
Vprtstp: contraction number = 4.900013e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 9.918993e-07
Vprtstp: contraction number = 4.221921e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.808190e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.273520e-01
Vpmg_setPart:  lower corner = (-15.342, 20.155, 5.691)
Vpmg_setPart:  upper corner = (75.695, 106.664, 111.68)
Vpmg_setPart:  actual minima = (-15.342, 20.155, 5.691)
Vpmg_setPart:  actual maxima = (75.695, 106.664, 111.68)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8282611 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -5.342, 30.155, 15.691
VPMG::focusFillBound -- New mesh maxs = 65.695, 96.664, 101.68
VPMG::focusFillBound -- Old mesh mins = -15.342, 20.155, 5.691
VPMG::focusFillBound -- Old mesh maxs = 75.695, 106.664, 111.68
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.066529
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.579859e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.814000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.966400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.014553e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.370834e-02
Vprtstp: contraction number = 7.370834e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.107706e-02
Vprtstp: contraction number = 1.502823e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.789661e-03
Vprtstp: contraction number = 2.518414e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.062357e-03
Vprtstp: contraction number = 3.808193e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.580764e-04
Vprtstp: contraction number = 4.311888e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.323824e-04
Vprtstp: contraction number = 5.073005e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.054937e-04
Vprtstp: contraction number = 4.539660e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.624830e-05
Vprtstp: contraction number = 5.331910e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.545710e-05
Vprtstp: contraction number = 4.525843e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.376053e-05
Vprtstp: contraction number = 5.405381e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.212717e-06
Vprtstp: contraction number = 4.514881e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.376920e-06
Vprtstp: contraction number = 5.435496e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.523179e-06
Vprtstp: contraction number = 4.510556e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 8.301381e-07
Vprtstp: contraction number = 5.450038e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.862870e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.325200e-01
Vpmg_setPart:  lower corner = (-5.342, 30.155, 15.691)
Vpmg_setPart:  upper corner = (65.695, 96.664, 101.68)
Vpmg_setPart:  actual minima = (-5.342, 30.155, 15.691)
Vpmg_setPart:  actual maxima = (65.695, 96.664, 101.68)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 3.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.006318e+00
