##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:40 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2435 atoms
Valist_getStatistics:  Max atom coordinate:  (35.794, 39.414, 26.564)
Valist_getStatistics:  Min atom coordinate:  (-7.632, 0.81, -11.016)
Valist_getStatistics:  Molecule center:  (14.081, 20.112, 7.774)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.869021, 0.818792, 0.808125
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.660687, 0.610458, 0.599792
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.760267, 0.74556, 0.742202 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 55.794 59.414 46.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -27.632 -19.19 -31.016
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 45.794 49.414 36.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -17.632 -9.19 -21.016
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 45.794 49.414 36.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -17.632 -9.19 -21.016
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.0509
Vpbe_ctor2:  solute dimensions = 46.064 x 41.078 x 40.5062
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.206, 51.384, 50.36)
Vclist_setupGrid:  Grid lower corner = (-14.022, -5.58, -17.406)
Vclist_assignAtoms:  Have 5985747 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.398892
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.335500e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.795400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.210200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.522680e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2720275.858738
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.194690e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.706631e+05
Vprtstp: contraction number = 1.706631e+05
Vnewton: Attempting damping, relres = 0.057282
Vnewton: Attempting damping, relres = 0.522944
Vnewton: Damping accepted, relres = 0.057282
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.728229e-02
Vprtstp: contraction number = 5.728229e-02
Vnewton: Using errtol_s: 155823.625461
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.367320e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.114935e+04
Vprtstp: contraction number = 2.114935e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.002473e-03
Vprtstp: contraction number = 1.222450e-01
Vnewton: Using errtol_s: 19048.658098
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.025636e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.170187e+03
Vprtstp: contraction number = 3.170187e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.048896e-03
Vprtstp: contraction number = 1.497894e-01
Vnewton: Using errtol_s: 2853.287250
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.113931e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.356384e+02
Vprtstp: contraction number = 5.356384e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.772174e-04
Vprtstp: contraction number = 1.689561e-01
Vnewton: Using errtol_s: 482.080211
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.202992e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.711938e+01
Vprtstp: contraction number = 9.711938e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.213192e-05
Vprtstp: contraction number = 1.813136e-01
Vnewton: Using errtol_s: 87.407678
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.292869e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.851111e+01
Vprtstp: contraction number = 1.851111e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.124384e-06
Vprtstp: contraction number = 1.906013e-01
Vnewton: Using errtol_s: 16.660014
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.382655e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.665397e+00
Vprtstp: contraction number = 3.665397e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.212692e-06
Vprtstp: contraction number = 1.980105e-01
Vnewton: Using errtol_s: 3.298858
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.472548e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.513555e-01
Vprtstp: contraction number = 7.513555e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.485851e-07
Vprtstp: contraction number = 2.049861e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.847570e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.872650e-01
Vpmg_setPart:  lower corner = (-27.632, -19.19, -31.016)
Vpmg_setPart:  upper corner = (55.794, 59.414, 46.564)
Vpmg_setPart:  actual minima = (-27.632, -19.19, -31.016)
Vpmg_setPart:  actual maxima = (55.794, 59.414, 46.564)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.0509
Vpbe_ctor2:  solute dimensions = 46.064 x 41.078 x 40.5062
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.206, 51.384, 50.36)
Vclist_setupGrid:  Grid lower corner = (-14.022, -5.58, -17.406)
Vclist_assignAtoms:  Have 5985747 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -17.632, -9.19, -21.016
VPMG::focusFillBound -- New mesh maxs = 45.794, 49.414, 36.564
VPMG::focusFillBound -- Old mesh mins = -27.632, -19.19, -31.016
VPMG::focusFillBound -- Old mesh maxs = 55.794, 59.414, 46.564
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.394830
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.380610e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.857500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.267700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.383169e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3345755.308431
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.451541e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.313050e+05
Vprtstp: contraction number = 3.313050e+05
Vnewton: Attempting damping, relres = 0.089713
Vnewton: Attempting damping, relres = 0.541499
Vnewton: Damping accepted, relres = 0.089713
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.971298e-02
Vprtstp: contraction number = 8.971298e-02
Vnewton: Using errtol_s: 300157.693030
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.569900e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.302769e+04
Vprtstp: contraction number = 4.302769e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.157817e-02
Vprtstp: contraction number = 1.290579e-01
Vnewton: Using errtol_s: 38737.723984
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.660235e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.579640e+03
Vprtstp: contraction number = 6.579640e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.769930e-03
Vprtstp: contraction number = 1.528679e-01
Vnewton: Using errtol_s: 5921.753729
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.750375e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.119523e+03
Vprtstp: contraction number = 1.119523e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.011501e-04
Vprtstp: contraction number = 1.701480e-01
Vnewton: Using errtol_s: 1007.574457
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.841262e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.043764e+02
Vprtstp: contraction number = 2.043764e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.497681e-05
Vprtstp: contraction number = 1.825562e-01
Vnewton: Using errtol_s: 183.938962
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.931874e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.913311e+01
Vprtstp: contraction number = 3.913311e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.052672e-05
Vprtstp: contraction number = 1.914756e-01
Vnewton: Using errtol_s: 35.219816
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.022082e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.773492e+00
Vprtstp: contraction number = 7.773492e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.091051e-06
Vprtstp: contraction number = 1.986423e-01
Vnewton: Using errtol_s: 6.996144
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.112616e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.592642e+00
Vprtstp: contraction number = 1.592642e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.284168e-07
Vprtstp: contraction number = 2.048811e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.945810e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.985900e-01
Vpmg_setPart:  lower corner = (-17.632, -9.19, -21.016)
Vpmg_setPart:  upper corner = (45.794, 49.414, 36.564)
Vpmg_setPart:  actual minima = (-17.632, -9.19, -21.016)
Vpmg_setPart:  actual maxima = (45.794, 49.414, 36.564)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.407716e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:43 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2435 atoms
Valist_getStatistics:  Max atom coordinate:  (35.794, 39.414, 26.564)
Valist_getStatistics:  Min atom coordinate:  (-7.632, 0.81, -11.016)
Valist_getStatistics:  Molecule center:  (14.081, 20.112, 7.774)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.869021, 0.818792, 0.808125
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.660687, 0.610458, 0.599792
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.760267, 0.74556, 0.742202 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 14.081 20.112 7.774
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 55.794 59.414 46.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -27.632 -19.19 -31.016
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 45.794 49.414 36.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -17.632 -9.19 -21.016
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 45.794 49.414 36.564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -17.632 -9.19 -21.016
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.0509
Vpbe_ctor2:  solute dimensions = 46.064 x 41.078 x 40.5062
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.206, 51.384, 50.36)
Vclist_setupGrid:  Grid lower corner = (-14.022, -5.58, -17.406)
Vclist_assignAtoms:  Have 5985747 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.398594
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.349460e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.809000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.613200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.581090e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.984076e-02
Vprtstp: contraction number = 5.984076e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.538993e-03
Vprtstp: contraction number = 1.259842e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.288690e-03
Vprtstp: contraction number = 1.709366e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.598222e-04
Vprtstp: contraction number = 2.016173e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.467124e-05
Vprtstp: contraction number = 2.489058e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.589440e-05
Vprtstp: contraction number = 2.457723e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.762613e-06
Vprtstp: contraction number = 2.996410e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.259307e-06
Vprtstp: contraction number = 2.644152e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.198032e-07
Vprtstp: contraction number = 3.333604e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.175620e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.255680e-01
Vpmg_setPart:  lower corner = (-27.632, -19.19, -31.016)
Vpmg_setPart:  upper corner = (55.794, 59.414, 46.564)
Vpmg_setPart:  actual minima = (-27.632, -19.19, -31.016)
Vpmg_setPart:  actual maxima = (55.794, 59.414, 46.564)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.0509
Vpbe_ctor2:  solute dimensions = 46.064 x 41.078 x 40.5062
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.206, 51.384, 50.36)
Vclist_setupGrid:  Grid lower corner = (-14.022, -5.58, -17.406)
Vclist_assignAtoms:  Have 5985747 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -17.632, -9.19, -21.016
VPMG::focusFillBound -- New mesh maxs = 45.794, 49.414, 36.564
VPMG::focusFillBound -- Old mesh mins = -27.632, -19.19, -31.016
VPMG::focusFillBound -- Old mesh maxs = 55.794, 59.414, 46.564
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.392958
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.357490e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.875600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.756000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.925764e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.072612e-02
Vprtstp: contraction number = 9.072612e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.190294e-02
Vprtstp: contraction number = 1.311964e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.903308e-03
Vprtstp: contraction number = 1.599024e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.639229e-04
Vprtstp: contraction number = 1.912054e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.822637e-05
Vprtstp: contraction number = 2.149532e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.873221e-05
Vprtstp: contraction number = 2.394616e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.742575e-06
Vprtstp: contraction number = 2.531776e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.272161e-06
Vprtstp: contraction number = 2.682426e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.655380e-07
Vprtstp: contraction number = 2.873364e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.246060e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.349200e-01
Vpmg_setPart:  lower corner = (-17.632, -9.19, -21.016)
Vpmg_setPart:  upper corner = (45.794, 49.414, 36.564)
Vpmg_setPart:  actual minima = (-17.632, -9.19, -21.016)
Vpmg_setPart:  actual maxima = (45.794, 49.414, 36.564)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.484586e+00
