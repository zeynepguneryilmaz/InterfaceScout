##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6976 atoms
Valist_getStatistics:  Max atom coordinate:  (30.531, 30.518, 24.088)
Valist_getStatistics:  Min atom coordinate:  (-30.453, -30.45, -24.005)
Valist_getStatistics:  Molecule center:  (0.039, 0.034, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.788937, 0.788813, 0.917635
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.632687, 0.632563, 0.709302
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.801949, 0.801917, 0.772967 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 50.531 50.518 44.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -50.453 -50.45 -44.005
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 40.531 40.518 34.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -40.453 -40.45 -34.005
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 40.531 40.518 34.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -40.453 -40.45 -34.005
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.174285
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.641541e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.101000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.391210e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.889754e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.669031e-02
Vprtstp: contraction number = 5.669031e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.697224e-03
Vprtstp: contraction number = 1.357767e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.726183e-03
Vprtstp: contraction number = 2.242605e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.249737e-04
Vprtstp: contraction number = 2.461927e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.613359e-04
Vprtstp: contraction number = 3.796374e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.894877e-05
Vprtstp: contraction number = 3.033966e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.178911e-05
Vprtstp: contraction number = 4.451410e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.026227e-06
Vprtstp: contraction number = 3.224651e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.174874e-06
Vprtstp: contraction number = 4.518605e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.036889e-06
Vprtstp: contraction number = 3.265920e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.675132e-07
Vprtstp: contraction number = 4.508808e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.948010e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.010216e+00
Vpmg_setPart:  lower corner = (-50.453, -50.45, -44.005)
Vpmg_setPart:  upper corner = (50.531, 50.518, 44.088)
Vpmg_setPart:  actual minima = (-50.453, -50.45, -44.005)
Vpmg_setPart:  actual maxima = (50.531, 50.518, 44.088)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -40.453, -40.45, -34.005
VPMG::focusFillBound -- New mesh maxs = 40.531, 40.518, 34.088
VPMG::focusFillBound -- Old mesh mins = -50.453, -50.45, -44.005
VPMG::focusFillBound -- Old mesh maxs = 50.531, 50.518, 44.088
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.162589
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.830880e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.139100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.425270e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.743638e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.835900e-02
Vprtstp: contraction number = 7.835900e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.030781e-02
Vprtstp: contraction number = 1.315459e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.863347e-03
Vprtstp: contraction number = 1.807705e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.228228e-04
Vprtstp: contraction number = 2.269157e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.422139e-04
Vprtstp: contraction number = 3.363440e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.575196e-05
Vprtstp: contraction number = 3.217123e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.045061e-05
Vprtstp: contraction number = 4.469887e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.209502e-06
Vprtstp: contraction number = 3.525324e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.392886e-06
Vprtstp: contraction number = 4.706130e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.215201e-06
Vprtstp: contraction number = 3.581616e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.769152e-07
Vprtstp: contraction number = 4.747487e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.935610e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.013270e+00
Vpmg_setPart:  lower corner = (-40.453, -40.45, -34.005)
Vpmg_setPart:  upper corner = (40.531, 40.518, 34.088)
Vpmg_setPart:  actual minima = (-40.453, -40.45, -34.005)
Vpmg_setPart:  actual maxima = (40.531, 40.518, 34.088)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.957614e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:17 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6976 atoms
Valist_getStatistics:  Max atom coordinate:  (30.531, 30.518, 24.088)
Valist_getStatistics:  Min atom coordinate:  (-30.453, -30.45, -24.005)
Valist_getStatistics:  Molecule center:  (0.039, 0.034, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.788937, 0.788813, 0.917635
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.632687, 0.632563, 0.709302
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.801949, 0.801917, 0.772967 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 50.531 50.518 44.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -50.453 -50.45 -44.005
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 40.531 40.518 34.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -40.453 -40.45 -34.005
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 40.531 40.518 34.088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -40.453 -40.45 -34.005
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.178773
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.651887e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.066800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.096820e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.868264e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8620941.725979
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.986247e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.992745e+05
Vprtstp: contraction number = 4.992745e+05
Vnewton: Attempting damping, relres = 0.054042
Vnewton: Attempting damping, relres = 0.521329
Vnewton: Damping accepted, relres = 0.054042
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.404214e-02
Vprtstp: contraction number = 5.404214e-02
Vnewton: Using errtol_s: 465894.162617
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.207285e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.217206e+04
Vprtstp: contraction number = 6.217206e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.725895e-03
Vprtstp: contraction number = 1.244565e-01
Vnewton: Using errtol_s: 57983.544940
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.377017e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.613329e+03
Vprtstp: contraction number = 9.613329e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.028898e-03
Vprtstp: contraction number = 1.529757e-01
Vnewton: Using errtol_s: 8870.070775
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.544028e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.679603e+03
Vprtstp: contraction number = 1.679603e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.767750e-04
Vprtstp: contraction number = 1.718100e-01
Vnewton: Using errtol_s: 1523.967234
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.710849e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.126176e+02
Vprtstp: contraction number = 3.126176e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.269769e-05
Vprtstp: contraction number = 1.849678e-01
Vnewton: Using errtol_s: 281.884908
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.877827e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.138700e+01
Vprtstp: contraction number = 6.138700e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.411566e-06
Vprtstp: contraction number = 1.960862e-01
Vnewton: Using errtol_s: 55.273736
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.045835e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.295288e+01
Vprtstp: contraction number = 1.295288e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.352399e-06
Vprtstp: contraction number = 2.109311e-01
Vnewton: Using errtol_s: 11.658951
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.216811e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.960458e+00
Vprtstp: contraction number = 2.960458e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.090718e-07
Vprtstp: contraction number = 2.285360e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.472396e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.655918e+00
Vpmg_setPart:  lower corner = (-50.453, -50.45, -44.005)
Vpmg_setPart:  upper corner = (50.531, 50.518, 44.088)
Vpmg_setPart:  actual minima = (-50.453, -50.45, -44.005)
Vpmg_setPart:  actual maxima = (50.531, 50.518, 44.088)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -40.453, -40.45, -34.005
VPMG::focusFillBound -- New mesh maxs = 40.531, 40.518, 34.088
VPMG::focusFillBound -- Old mesh mins = -50.453, -50.45, -44.005
VPMG::focusFillBound -- Old mesh maxs = 50.531, 50.518, 44.088
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.169043
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.848079e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.133800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.132610e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.385699e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 10232574.047525
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.505254e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.543977e+05
Vprtstp: contraction number = 8.543977e+05
Vnewton: Attempting damping, relres = 0.077089
Vnewton: Attempting damping, relres = 0.534357
Vnewton: Damping accepted, relres = 0.077089
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.708883e-02
Vprtstp: contraction number = 7.708883e-02
Vnewton: Using errtol_s: 788817.210521
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.728496e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.095590e+05
Vprtstp: contraction number = 1.095590e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.911758e-03
Vprtstp: contraction number = 1.285758e-01
Vnewton: Using errtol_s: 101422.795307
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.903287e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.711200e+04
Vprtstp: contraction number = 1.711200e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.547421e-03
Vprtstp: contraction number = 1.561197e-01
Vnewton: Using errtol_s: 15834.096003
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.079734e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.023315e+03
Vprtstp: contraction number = 3.023315e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.692979e-04
Vprtstp: contraction number = 1.740302e-01
Vnewton: Using errtol_s: 2755.610955
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.247051e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.772708e+02
Vprtstp: contraction number = 5.772708e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.086557e-05
Vprtstp: contraction number = 1.888822e-01
Vnewton: Using errtol_s: 520.485755
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.412172e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.166021e+02
Vprtstp: contraction number = 1.166021e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.025734e-05
Vprtstp: contraction number = 2.016559e-01
Vnewton: Using errtol_s: 104.959035
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.579745e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.469698e+01
Vprtstp: contraction number = 2.469698e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.172248e-06
Vprtstp: contraction number = 2.117749e-01
Vnewton: Using errtol_s: 22.227684
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.749102e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.374179e+00
Vprtstp: contraction number = 5.374179e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.726840e-07
Vprtstp: contraction number = 2.176014e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.487149e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.675298e+00
Vpmg_setPart:  lower corner = (-40.453, -40.45, -34.005)
Vpmg_setPart:  upper corner = (40.531, 40.518, 34.088)
Vpmg_setPart:  actual minima = (-40.453, -40.45, -34.005)
Vpmg_setPart:  actual maxima = (40.531, 40.518, 34.088)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.294631e+00
