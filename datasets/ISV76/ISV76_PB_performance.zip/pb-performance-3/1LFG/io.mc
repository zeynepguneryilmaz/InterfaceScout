##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:48 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10528 atoms
Valist_getStatistics:  Max atom coordinate:  (36.822, 58.816, 41.541)
Valist_getStatistics:  Min atom coordinate:  (-54.508, -4.849, -26.513)
Valist_getStatistics:  Molecule center:  (-8.843, 26.9835, 7.514)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.820813, 0.809883, 0.844172
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.695812, 0.653633, 0.687922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.847712, 0.807071, 0.814907 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 56.822 78.816 61.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -74.508 -24.849 -46.513
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 46.822 68.816 51.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -64.508 -14.849 -36.513
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 46.822 68.816 51.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -64.508 -14.849 -36.513
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.975071
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.666080e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.507000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.667520e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.107188e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.945399e-02
Vprtstp: contraction number = 5.945399e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.749611e-03
Vprtstp: contraction number = 1.303464e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.859385e-03
Vprtstp: contraction number = 2.399327e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.671948e-04
Vprtstp: contraction number = 4.126068e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.047897e-04
Vprtstp: contraction number = 3.972781e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.746116e-04
Vprtstp: contraction number = 5.728922e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.637724e-05
Vprtstp: contraction number = 4.374121e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.510770e-05
Vprtstp: contraction number = 5.905909e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.008353e-05
Vprtstp: contraction number = 4.452350e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.185134e-05
Vprtstp: contraction number = 5.901026e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.316695e-06
Vprtstp: contraction number = 4.486154e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.129817e-06
Vprtstp: contraction number = 5.886772e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.409751e-06
Vprtstp: contraction number = 4.504261e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 8.282207e-07
Vprtstp: contraction number = 5.874942e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.774456e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.170141e+00
Vpmg_setPart:  lower corner = (-74.508, -24.849, -46.513)
Vpmg_setPart:  upper corner = (56.822, 78.816, 61.541)
Vpmg_setPart:  actual minima = (-74.508, -24.849, -46.513)
Vpmg_setPart:  actual maxima = (56.822, 78.816, 61.541)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -64.508, -14.849, -36.513
VPMG::focusFillBound -- New mesh maxs = 46.822, 68.816, 51.541
VPMG::focusFillBound -- Old mesh mins = -74.508, -24.849, -46.513
VPMG::focusFillBound -- Old mesh maxs = 56.822, 78.816, 61.541
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.953311
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.883630e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.503300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.799630e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.184663e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.599020e-02
Vprtstp: contraction number = 7.599020e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.847545e-03
Vprtstp: contraction number = 1.295897e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.936153e-03
Vprtstp: contraction number = 1.966128e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.093369e-04
Vprtstp: contraction number = 3.147153e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.436807e-04
Vprtstp: contraction number = 3.999112e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.360935e-04
Vprtstp: contraction number = 5.584910e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.403175e-05
Vprtstp: contraction number = 4.704984e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.898589e-05
Vprtstp: contraction number = 6.088525e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.855092e-05
Vprtstp: contraction number = 4.758369e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.143079e-05
Vprtstp: contraction number = 6.161844e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.447374e-06
Vprtstp: contraction number = 4.765527e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.367942e-06
Vprtstp: contraction number = 6.182690e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.606691e-06
Vprtstp: contraction number = 4.770543e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.948152e-07
Vprtstp: contraction number = 6.191701e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.764854e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.172134e+00
Vpmg_setPart:  lower corner = (-64.508, -14.849, -36.513)
Vpmg_setPart:  upper corner = (46.822, 68.816, 51.541)
Vpmg_setPart:  actual minima = (-64.508, -14.849, -36.513)
Vpmg_setPart:  actual maxima = (46.822, 68.816, 51.541)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.062959e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:59 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10528 atoms
Valist_getStatistics:  Max atom coordinate:  (36.822, 58.816, 41.541)
Valist_getStatistics:  Min atom coordinate:  (-54.508, -4.849, -26.513)
Valist_getStatistics:  Molecule center:  (-8.843, 26.9835, 7.514)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.820813, 0.809883, 0.844172
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.695812, 0.653633, 0.687922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.847712, 0.807071, 0.814907 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 56.822 78.816 61.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -74.508 -24.849 -46.513
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 46.822 68.816 51.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -64.508 -14.849 -36.513
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 46.822 68.816 51.541
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -64.508 -14.849 -36.513
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.976830
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.667176e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.395200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.851390e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.020089e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12807747.449188
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.217838e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.648481e+05
Vprtstp: contraction number = 7.648481e+05
Vnewton: Attempting damping, relres = 0.057379
Vnewton: Attempting damping, relres = 0.522538
Vnewton: Damping accepted, relres = 0.057379
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.737924e-02
Vprtstp: contraction number = 5.737924e-02
Vnewton: Using errtol_s: 734898.832383
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.582640e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.213533e+04
Vprtstp: contraction number = 9.213533e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.928175e-03
Vprtstp: contraction number = 1.207436e-01
Vnewton: Using errtol_s: 88734.310825
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.864776e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.342988e+04
Vprtstp: contraction number = 1.342988e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.900139e-04
Vprtstp: contraction number = 1.428968e-01
Vnewton: Using errtol_s: 12679.847767
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.142933e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.206519e+03
Vprtstp: contraction number = 2.206519e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.628038e-04
Vprtstp: contraction number = 1.644460e-01
Vnewton: Using errtol_s: 2085.149672
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.418420e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.136938e+02
Vprtstp: contraction number = 4.136938e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.944303e-05
Vprtstp: contraction number = 1.808498e-01
Vnewton: Using errtol_s: 377.098908
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.696818e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.022442e+01
Vprtstp: contraction number = 8.022442e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.637858e-06
Vprtstp: contraction number = 1.914836e-01
Vnewton: Using errtol_s: 72.208256
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.974899e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.597285e+01
Vprtstp: contraction number = 1.597285e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.122413e-06
Vprtstp: contraction number = 1.990851e-01
Vnewton: Using errtol_s: 14.375588
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.255125e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.875193e+00
Vprtstp: contraction number = 3.875193e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.723100e-07
Vprtstp: contraction number = 2.426111e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.441187e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.748538e+00
Vpmg_setPart:  lower corner = (-74.508, -24.849, -46.513)
Vpmg_setPart:  upper corner = (56.822, 78.816, 61.541)
Vpmg_setPart:  actual minima = (-74.508, -24.849, -46.513)
Vpmg_setPart:  actual maxima = (56.822, 78.816, 61.541)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -64.508, -14.849, -36.513
VPMG::focusFillBound -- New mesh maxs = 46.822, 68.816, 51.541
VPMG::focusFillBound -- Old mesh mins = -74.508, -24.849, -46.513
VPMG::focusFillBound -- Old mesh maxs = 56.822, 78.816, 61.541
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.945872
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.882923e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 8.627000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.857330e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.668208e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 14766112.036972
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.867641e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.176600e+06
Vprtstp: contraction number = 1.176600e+06
Vnewton: Attempting damping, relres = 0.074831
Vnewton: Attempting damping, relres = 0.532629
Vnewton: Damping accepted, relres = 0.074831
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.483100e-02
Vprtstp: contraction number = 7.483100e-02
Vnewton: Using errtol_s: 1104962.895469
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.232572e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.464550e+05
Vprtstp: contraction number = 1.464550e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.314010e-03
Vprtstp: contraction number = 1.244673e-01
Vnewton: Using errtol_s: 137531.712926
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.514996e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.183808e+04
Vprtstp: contraction number = 2.183808e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.372342e-03
Vprtstp: contraction number = 1.473417e-01
Vnewton: Using errtol_s: 20264.159000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.797024e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.633091e+03
Vprtstp: contraction number = 3.633091e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.282945e-04
Vprtstp: contraction number = 1.663539e-01
Vnewton: Using errtol_s: 3371.022317
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.008397e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.804521e+02
Vprtstp: contraction number = 6.804521e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.182318e-05
Vprtstp: contraction number = 1.831983e-01
Vnewton: Using errtol_s: 617.565694
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.037431e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.351064e+02
Vprtstp: contraction number = 1.351064e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.235411e-06
Vprtstp: contraction number = 1.969102e-01
Vnewton: Using errtol_s: 121.604995
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.066449e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.944728e+01
Vprtstp: contraction number = 2.944728e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.794833e-06
Vprtstp: contraction number = 2.179409e-01
Vnewton: Using errtol_s: 26.502708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.095047e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.164544e+00
Vprtstp: contraction number = 8.164544e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.976326e-07
Vprtstp: contraction number = 2.772584e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.492849e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.803557e+00
Vpmg_setPart:  lower corner = (-64.508, -14.849, -36.513)
Vpmg_setPart:  upper corner = (46.822, 68.816, 51.541)
Vpmg_setPart:  actual minima = (-64.508, -14.849, -36.513)
Vpmg_setPart:  actual maxima = (46.822, 68.816, 51.541)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.183930e+01
