##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4696 atoms
Valist_getStatistics:  Max atom coordinate:  (29.917, 37.404, 35.018)
Valist_getStatistics:  Min atom coordinate:  (-19.142, -22.327, -9.237)
Valist_getStatistics:  Molecule center:  (5.3875, 7.5385, 12.8905)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.927698, 0.779148, 0.877656
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.719365, 0.622898, 0.669323
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.77543, 0.799461, 0.762625 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 49.917 57.404 55.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.142 -42.327 -29.237
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 39.917 47.404 45.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.142 -32.327 -19.237
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 39.917 47.404 45.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.142 -32.327 -19.237
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7182395 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.835005
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.171043e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.849400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.436500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.347230e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.135243e-02
Vprtstp: contraction number = 5.135243e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.286413e-03
Vprtstp: contraction number = 1.418903e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.508082e-03
Vprtstp: contraction number = 2.069718e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.262594e-04
Vprtstp: contraction number = 3.489594e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.007513e-04
Vprtstp: contraction number = 3.814683e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.033443e-04
Vprtstp: contraction number = 5.147878e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.405821e-05
Vprtstp: contraction number = 4.263245e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.406661e-05
Vprtstp: contraction number = 5.462457e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.027190e-05
Vprtstp: contraction number = 4.268115e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.683042e-06
Vprtstp: contraction number = 5.532608e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.413178e-06
Vprtstp: contraction number = 4.246279e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.342727e-06
Vprtstp: contraction number = 5.564146e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.677935e-07
Vprtstp: contraction number = 4.228658e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.041520e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.564210e-01
Vpmg_setPart:  lower corner = (-39.142, -42.327, -29.237)
Vpmg_setPart:  upper corner = (49.917, 57.404, 55.018)
Vpmg_setPart:  actual minima = (-39.142, -42.327, -29.237)
Vpmg_setPart:  actual maxima = (49.917, 57.404, 55.018)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7182395 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.142, -32.327, -19.237
VPMG::focusFillBound -- New mesh maxs = 39.917, 47.404, 45.018
VPMG::focusFillBound -- Old mesh mins = -39.142, -42.327, -29.237
VPMG::focusFillBound -- Old mesh maxs = 49.917, 57.404, 55.018
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.803122
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.277689e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.941300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.755300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.491929e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.138277e-02
Vprtstp: contraction number = 7.138277e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.472931e-03
Vprtstp: contraction number = 1.327061e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.680273e-03
Vprtstp: contraction number = 1.773762e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.066943e-04
Vprtstp: contraction number = 2.420406e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.157984e-04
Vprtstp: contraction number = 2.847307e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.516426e-05
Vprtstp: contraction number = 3.900251e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.596262e-05
Vprtstp: contraction number = 3.534349e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.474559e-06
Vprtstp: contraction number = 4.682538e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.797249e-06
Vprtstp: contraction number = 3.742359e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.386895e-06
Vprtstp: contraction number = 4.958069e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.284232e-07
Vprtstp: contraction number = 3.810116e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.946000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.512360e-01
Vpmg_setPart:  lower corner = (-29.142, -32.327, -19.237)
Vpmg_setPart:  upper corner = (39.917, 47.404, 45.018)
Vpmg_setPart:  actual minima = (-29.142, -32.327, -19.237)
Vpmg_setPart:  actual maxima = (39.917, 47.404, 45.018)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.400999e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:43 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4696 atoms
Valist_getStatistics:  Max atom coordinate:  (29.917, 37.404, 35.018)
Valist_getStatistics:  Min atom coordinate:  (-19.142, -22.327, -9.237)
Valist_getStatistics:  Molecule center:  (5.3875, 7.5385, 12.8905)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.927698, 0.779148, 0.877656
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.719365, 0.622898, 0.669323
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.77543, 0.799461, 0.762625 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 49.917 57.404 55.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.142 -42.327 -29.237
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 39.917 47.404 45.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.142 -32.327 -19.237
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 39.917 47.404 45.018
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.142 -32.327 -19.237
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7182395 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.812355
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.155069e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.819900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.299700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.317120e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5471489.672535
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.406006e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.933451e+05
Vprtstp: contraction number = 2.933451e+05
Vnewton: Attempting damping, relres = 0.049979
Vnewton: Attempting damping, relres = 0.518968
Vnewton: Damping accepted, relres = 0.049979
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.997860e-02
Vprtstp: contraction number = 4.997860e-02
Vnewton: Using errtol_s: 273457.380375
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.568593e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.762872e+04
Vprtstp: contraction number = 3.762872e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.590731e-03
Vprtstp: contraction number = 1.318711e-01
Vnewton: Using errtol_s: 36061.114992
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.697140e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.292956e+03
Vprtstp: contraction number = 6.292956e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.132737e-03
Vprtstp: contraction number = 1.718682e-01
Vnewton: Using errtol_s: 6197.759618
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.821828e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.328759e+03
Vprtstp: contraction number = 1.328759e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.350309e-04
Vprtstp: contraction number = 2.074893e-01
Vnewton: Using errtol_s: 1285.968938
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.949204e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.491184e+02
Vprtstp: contraction number = 3.491184e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.914751e-05
Vprtstp: contraction number = 2.516585e-01
Vnewton: Using errtol_s: 323.625013
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.074815e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.036986e+02
Vprtstp: contraction number = 1.036986e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.720147e-05
Vprtstp: contraction number = 2.908233e-01
Vnewton: Using errtol_s: 94.117689
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.202137e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.268069e+01
Vprtstp: contraction number = 3.268069e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.389750e-06
Vprtstp: contraction number = 3.133307e-01
Vnewton: Using errtol_s: 29.489962
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.326236e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.064670e+01
Vprtstp: contraction number = 1.064670e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.752750e-06
Vprtstp: contraction number = 3.252006e-01
Vnewton: Using errtol_s: 9.590154
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.450637e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.517528e+00
Vprtstp: contraction number = 3.517528e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.787487e-07
Vprtstp: contraction number = 3.301946e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.224576e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.362955e+00
Vpmg_setPart:  lower corner = (-39.142, -42.327, -29.237)
Vpmg_setPart:  upper corner = (49.917, 57.404, 55.018)
Vpmg_setPart:  actual minima = (-39.142, -42.327, -29.237)
Vpmg_setPart:  actual maxima = (49.917, 57.404, 55.018)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7182395 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.142, -32.327, -19.237
VPMG::focusFillBound -- New mesh maxs = 39.917, 47.404, 45.018
VPMG::focusFillBound -- Old mesh mins = -39.142, -42.327, -29.237
VPMG::focusFillBound -- Old mesh maxs = 49.917, 57.404, 55.018
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.804368
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.280647e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.941000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 8.516000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.971645e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6685918.632525
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.061603e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.146527e+05
Vprtstp: contraction number = 5.146527e+05
Vnewton: Attempting damping, relres = 0.071004
Vnewton: Attempting damping, relres = 0.531244
Vnewton: Damping accepted, relres = 0.071004
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.100378e-02
Vprtstp: contraction number = 7.100378e-02
Vnewton: Using errtol_s: 474725.474727
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.226878e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.562524e+04
Vprtstp: contraction number = 6.562524e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.293500e-03
Vprtstp: contraction number = 1.308874e-01
Vnewton: Using errtol_s: 62135.584773
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.353161e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.058308e+04
Vprtstp: contraction number = 1.058308e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.552284e-03
Vprtstp: contraction number = 1.670290e-01
Vnewton: Using errtol_s: 10378.444936
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.480793e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.020545e+03
Vprtstp: contraction number = 2.020545e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.035382e-04
Vprtstp: contraction number = 1.955429e-01
Vnewton: Using errtol_s: 2029.431527
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.607407e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.546900e+02
Vprtstp: contraction number = 4.546900e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.656982e-05
Vprtstp: contraction number = 2.193128e-01
Vnewton: Using errtol_s: 445.080379
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.734312e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.101756e+02
Vprtstp: contraction number = 1.101756e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.518013e-05
Vprtstp: contraction number = 2.280333e-01
Vnewton: Using errtol_s: 101.493133
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.860795e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.434635e+01
Vprtstp: contraction number = 2.434635e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.282712e-06
Vprtstp: contraction number = 2.162505e-01
Vnewton: Using errtol_s: 21.947942
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.987385e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.182375e+00
Vprtstp: contraction number = 5.182375e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.976549e-07
Vprtstp: contraction number = 2.125240e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.106486e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.249166e+00
Vpmg_setPart:  lower corner = (-29.142, -32.327, -19.237)
Vpmg_setPart:  upper corner = (39.917, 47.404, 45.018)
Vpmg_setPart:  actual minima = (-29.142, -32.327, -19.237)
Vpmg_setPart:  actual maxima = (39.917, 47.404, 45.018)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.399868e+00
