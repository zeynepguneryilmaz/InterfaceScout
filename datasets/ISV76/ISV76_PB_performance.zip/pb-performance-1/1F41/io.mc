##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:42 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7052 atoms
Valist_getStatistics:  Max atom coordinate:  (44.437, 77.704, 74.629)
Valist_getStatistics:  Min atom coordinate:  (-1.437, 7.666, 19.933)
Valist_getStatistics:  Molecule center:  (21.5, 42.685, 47.281)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.894521, 0.859672, 0.986417
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.686187, 0.703422, 0.778083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.767101, 0.818245, 0.788798 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 64.437 97.704 94.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -21.437 -12.334 -0.067
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 54.437 87.704 84.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -11.437 -2.334 9.933
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 54.437 87.704 84.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -11.437 -2.334 9.933
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8829032 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.786260
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.052659e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.726300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.416500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.185669e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.355072e-02
Vprtstp: contraction number = 5.355072e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.595852e-03
Vprtstp: contraction number = 1.418441e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.133770e-03
Vprtstp: contraction number = 2.809125e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.885557e-04
Vprtstp: contraction number = 4.632906e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.310598e-04
Vprtstp: contraction number = 4.360501e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.170275e-04
Vprtstp: contraction number = 5.034743e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.090095e-04
Vprtstp: contraction number = 5.022841e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.388959e-05
Vprtstp: contraction number = 4.943569e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.818515e-05
Vprtstp: contraction number = 5.230166e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.374795e-05
Vprtstp: contraction number = 4.877729e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.310678e-06
Vprtstp: contraction number = 5.317649e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.540780e-06
Vprtstp: contraction number = 4.843299e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.897061e-06
Vprtstp: contraction number = 5.357748e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.153304e-07
Vprtstp: contraction number = 4.824992e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.029290e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.179530e-01
Vpmg_setPart:  lower corner = (-21.437, -12.334, -0.067)
Vpmg_setPart:  upper corner = (64.437, 97.704, 94.629)
Vpmg_setPart:  actual minima = (-21.437, -12.334, -0.067)
Vpmg_setPart:  actual maxima = (64.437, 97.704, 94.629)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8829032 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -11.437, -2.334, 9.933
VPMG::focusFillBound -- New mesh maxs = 54.437, 87.704, 84.629
VPMG::focusFillBound -- Old mesh mins = -21.437, -12.334, -0.067
VPMG::focusFillBound -- Old mesh maxs = 64.437, 97.704, 94.629
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.785293
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.157911e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.574300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.590200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.064173e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.282303e-02
Vprtstp: contraction number = 7.282303e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.013258e-02
Vprtstp: contraction number = 1.391398e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.366390e-03
Vprtstp: contraction number = 2.335426e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.895117e-04
Vprtstp: contraction number = 4.181524e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.146836e-04
Vprtstp: contraction number = 4.190790e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.269331e-04
Vprtstp: contraction number = 5.472439e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.104584e-04
Vprtstp: contraction number = 4.867442e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.927295e-05
Vprtstp: contraction number = 5.366090e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.020356e-05
Vprtstp: contraction number = 5.095675e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.581333e-05
Vprtstp: contraction number = 5.235583e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.253365e-06
Vprtstp: contraction number = 5.219246e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.252794e-06
Vprtstp: contraction number = 5.152800e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.250620e-06
Vprtstp: contraction number = 5.292098e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.148279e-06
Vprtstp: contraction number = 5.102057e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.127317e-07
Vprtstp: contraction number = 5.336086e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.550130e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.699050e-01
Vpmg_setPart:  lower corner = (-11.437, -2.334, 9.933)
Vpmg_setPart:  upper corner = (54.437, 87.704, 84.629)
Vpmg_setPart:  actual minima = (-11.437, -2.334, 9.933)
Vpmg_setPart:  actual maxima = (54.437, 87.704, 84.629)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.910963e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:46 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7052 atoms
Valist_getStatistics:  Max atom coordinate:  (44.437, 77.704, 74.629)
Valist_getStatistics:  Min atom coordinate:  (-1.437, 7.666, 19.933)
Valist_getStatistics:  Molecule center:  (21.5, 42.685, 47.281)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.894521, 0.859672, 0.986417
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.686187, 0.703422, 0.778083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.767101, 0.818245, 0.788798 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 64.437 97.704 94.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -21.437 -12.334 -0.067
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 54.437 87.704 84.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -11.437 -2.334 9.933
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 54.437 87.704 84.629
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -11.437 -2.334 9.933
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8829032 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.797781
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.055700e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.475100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.769400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.177880e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7530918.445701
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.234480e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.150218e+05
Vprtstp: contraction number = 4.150218e+05
Vnewton: Attempting damping, relres = 0.088228
Vnewton: Attempting damping, relres = 0.519836
Vnewton: Damping accepted, relres = 0.088228
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.822823e-02
Vprtstp: contraction number = 8.822823e-02
Vnewton: Using errtol_s: 664439.606147
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.344189e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.216931e+04
Vprtstp: contraction number = 5.216931e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.972649e-02
Vprtstp: contraction number = 2.235848e-01
Vnewton: Using errtol_s: 148558.586978
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.429058e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.953198e+03
Vprtstp: contraction number = 8.953198e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.944010e-03
Vprtstp: contraction number = 3.013212e-01
Vnewton: Using errtol_s: 44763.857808
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.513162e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.111274e+03
Vprtstp: contraction number = 2.111274e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.975700e-03
Vprtstp: contraction number = 3.323850e-01
Vnewton: Using errtol_s: 14878.836678
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.596785e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.128116e+02
Vprtstp: contraction number = 8.128116e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.764380e-04
Vprtstp: contraction number = 3.423789e-01
Vnewton: Using errtol_s: 5094.199136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.680648e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.315101e+02
Vprtstp: contraction number = 4.315101e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.233700e-04
Vprtstp: contraction number = 3.302150e-01
Vnewton: Using errtol_s: 1682.181203
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.765381e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.377805e+02
Vprtstp: contraction number = 2.377805e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.498835e-05
Vprtstp: contraction number = 2.909448e-01
Vnewton: Using errtol_s: 489.421942
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.849876e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.033799e+02
Vprtstp: contraction number = 1.033799e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.573444e-05
Vprtstp: contraction number = 2.421118e-01
Vnewton: Using errtol_s: 118.494812
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.937723e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.290824e+01
Vprtstp: contraction number = 3.290824e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.997769e-06
Vprtstp: contraction number = 2.540776e-01
Vnewton: Using errtol_s: 30.106874
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.028385e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.708792e+00
Vprtstp: contraction number = 9.708792e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.160641e-06
Vprtstp: contraction number = 2.903221e-01
Vnewton: Using errtol_s: 8.740692
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.118867e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.691614e+00
Vprtstp: contraction number = 2.691614e+00
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.216739e-07
Vprtstp: contraction number = 2.771519e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.007459e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.111980e+00
Vpmg_setPart:  lower corner = (-21.437, -12.334, -0.067)
Vpmg_setPart:  upper corner = (64.437, 97.704, 94.629)
Vpmg_setPart:  actual minima = (-21.437, -12.334, -0.067)
Vpmg_setPart:  actual maxima = (64.437, 97.704, 94.629)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -16
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8829032 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -11.437, -2.334, 9.933
VPMG::focusFillBound -- New mesh maxs = 54.437, 87.704, 84.629
VPMG::focusFillBound -- Old mesh mins = -21.437, -12.334, -0.067
VPMG::focusFillBound -- Old mesh maxs = 64.437, 97.704, 94.629
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.778747
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.149540e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.521800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.517300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.439927e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9279182.044236
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.496981e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.286561e+05
Vprtstp: contraction number = 7.286561e+05
Vnewton: Attempting damping, relres = 0.096219
Vnewton: Attempting damping, relres = 0.531440
Vnewton: Damping accepted, relres = 0.096219
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.621942e-02
Vprtstp: contraction number = 9.621942e-02
Vnewton: Using errtol_s: 892837.527670
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.608605e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.438496e+04
Vprtstp: contraction number = 9.438496e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.800815e-02
Vprtstp: contraction number = 1.871571e-01
Vnewton: Using errtol_s: 167100.885338
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.694836e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.508208e+04
Vprtstp: contraction number = 1.508208e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.641015e-03
Vprtstp: contraction number = 2.577175e-01
Vnewton: Using errtol_s: 43064.825822
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.782038e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.328794e+03
Vprtstp: contraction number = 3.328794e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.439312e-03
Vprtstp: contraction number = 3.101286e-01
Vnewton: Using errtol_s: 13355.634979
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.868923e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.244324e+03
Vprtstp: contraction number = 1.244324e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.856373e-04
Vprtstp: contraction number = 3.374094e-01
Vnewton: Using errtol_s: 4506.317299
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.953308e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.529799e+02
Vprtstp: contraction number = 6.529799e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.646829e-04
Vprtstp: contraction number = 3.391067e-01
Vnewton: Using errtol_s: 1528.122559
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.038135e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.358765e+02
Vprtstp: contraction number = 3.358765e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.185279e-05
Vprtstp: contraction number = 3.148644e-01
Vnewton: Using errtol_s: 481.151437
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.122116e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.341305e+02
Vprtstp: contraction number = 1.341305e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.457633e-05
Vprtstp: contraction number = 2.811100e-01
Vnewton: Using errtol_s: 135.256462
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.207238e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.216651e+01
Vprtstp: contraction number = 4.216651e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.125703e-06
Vprtstp: contraction number = 2.830412e-01
Vnewton: Using errtol_s: 38.283149
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.292567e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.216957e+01
Vprtstp: contraction number = 1.216957e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.180772e-06
Vprtstp: contraction number = 2.861990e-01
Vnewton: Using errtol_s: 10.956599
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.377710e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.950500e+00
Vprtstp: contraction number = 2.950500e+00
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.861723e-07
Vprtstp: contraction number = 2.423603e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.002041e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.104483e+00
Vpmg_setPart:  lower corner = (-11.437, -2.334, 9.933)
Vpmg_setPart:  upper corner = (54.437, 87.704, 84.629)
Vpmg_setPart:  actual minima = (-11.437, -2.334, 9.933)
Vpmg_setPart:  actual maxima = (54.437, 87.704, 84.629)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.640306e+00
