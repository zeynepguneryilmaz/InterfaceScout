##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:29 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9122 atoms
Valist_getStatistics:  Max atom coordinate:  (68.089, 61.673, 62.62)
Valist_getStatistics:  Min atom coordinate:  (-5.47, 0.123, -18.22)
Valist_getStatistics:  Molecule center:  (31.3095, 30.898, 22.2)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.88718, 0.793359, 0.944063
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.73093, 0.637109, 0.787813
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.82388, 0.803053, 0.834492 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 88.089 81.673 82.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -25.47 -19.877 -38.22
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 78.089 71.673 72.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -15.47 -9.877 -28.22
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 78.089 71.673 72.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -15.47 -9.877 -28.22
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -14.0008
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7026107 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.049164
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.425747e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.390100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.029630e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.616429e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 10374057.391023
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.713084e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.544709e+05
Vprtstp: contraction number = 6.544709e+05
Vnewton: Attempting damping, relres = 0.165604
Vnewton: Attempting damping, relres = 0.523991
Vnewton: Damping accepted, relres = 0.165604
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.656041e-01
Vprtstp: contraction number = 1.656041e-01
Vnewton: Using errtol_s: 1717986.623056
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.909871e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.539637e+04
Vprtstp: contraction number = 9.539637e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.644346e-02
Vprtstp: contraction number = 2.804487e-01
Vnewton: Using errtol_s: 481807.162661
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.066737e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.349429e+04
Vprtstp: contraction number = 2.349429e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.540166e-02
Vprtstp: contraction number = 3.316218e-01
Vnewton: Using errtol_s: 159777.750078
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.226508e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.830682e+03
Vprtstp: contraction number = 9.830682e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.407071e-03
Vprtstp: contraction number = 3.510706e-01
Vnewton: Using errtol_s: 56093.262816
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.385669e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.606893e+03
Vprtstp: contraction number = 5.606893e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.928000e-03
Vprtstp: contraction number = 3.565701e-01
Vnewton: Using errtol_s: 20001.180537
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.547683e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.481482e+03
Vprtstp: contraction number = 3.481482e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.955476e-04
Vprtstp: contraction number = 3.607612e-01
Vnewton: Using errtol_s: 7215.650446
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.706900e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.030708e+03
Vprtstp: contraction number = 2.030708e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.625990e-04
Vprtstp: contraction number = 3.775429e-01
Vnewton: Using errtol_s: 2724.217357
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.861838e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.049721e+03
Vprtstp: contraction number = 1.049721e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.045135e-04
Vprtstp: contraction number = 3.979965e-01
Vnewton: Using errtol_s: 1084.228924
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.018039e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.724515e+02
Vprtstp: contraction number = 4.724515e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.251580e-05
Vprtstp: contraction number = 4.067973e-01
Vnewton: Using errtol_s: 441.061386
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.175015e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.950111e+02
Vprtstp: contraction number = 1.950111e+02
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.710847e-05
Vprtstp: contraction number = 4.024025e-01
Vnewton: Using errtol_s: 177.484200
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.333887e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.795368e+01
Vprtstp: contraction number = 7.795368e+01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.791967e-06
Vprtstp: contraction number = 3.969945e-01
Vnewton: Using errtol_s: 70.460255
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.490412e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.091337e+01
Vprtstp: contraction number = 3.091337e+01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.686599e-06
Vprtstp: contraction number = 3.955554e-01
Vnewton: Using errtol_s: 27.870934
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.647337e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.227696e+01
Vprtstp: contraction number = 1.227696e+01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.065857e-06
Vprtstp: contraction number = 3.967308e-01
Vnewton: Using errtol_s: 11.057259
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.803717e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.897278e+00
Vprtstp: contraction number = 4.897278e+00
Vprtstp: iteration = 14
Vprtstp: relative residual = 4.249891e-07
Vprtstp: contraction number = 3.987300e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.307695e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.475741e+00
Vpmg_setPart:  lower corner = (-25.47, -19.877, -38.22)
Vpmg_setPart:  upper corner = (88.089, 81.673, 82.62)
Vpmg_setPart:  actual minima = (-25.47, -19.877, -38.22)
Vpmg_setPart:  actual maxima = (88.089, 81.673, 82.62)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.850000e-04
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -14.0008
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7026107 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -15.47, -9.877, -28.22
VPMG::focusFillBound -- New mesh maxs = 78.089, 71.673, 72.62
VPMG::focusFillBound -- Old mesh mins = -25.47, -19.877, -38.22
VPMG::focusFillBound -- Old mesh maxs = 88.089, 81.673, 82.62
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.037918
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.562558e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.868500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.058070e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.769746e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 12141885.338207
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.879145e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.026706e+06
Vprtstp: contraction number = 1.026706e+06
Vnewton: Attempting damping, relres = 0.132508
Vnewton: Attempting damping, relres = 0.534508
Vnewton: Damping accepted, relres = 0.132508
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.325081e-01
Vprtstp: contraction number = 1.325081e-01
Vnewton: Using errtol_s: 1608897.893505
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.103168e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.530336e+05
Vprtstp: contraction number = 1.530336e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.041849e-02
Vprtstp: contraction number = 2.295595e-01
Vnewton: Using errtol_s: 369337.875743
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.266242e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.384535e+04
Vprtstp: contraction number = 3.384535e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.959200e-03
Vprtstp: contraction number = 2.945313e-01
Vnewton: Using errtol_s: 108781.578573
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.428349e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.158966e+04
Vprtstp: contraction number = 1.158966e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.955938e-03
Vprtstp: contraction number = 3.299332e-01
Vnewton: Using errtol_s: 35890.657353
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.589393e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.494352e+03
Vprtstp: contraction number = 5.494352e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.006264e-03
Vprtstp: contraction number = 3.404213e-01
Vnewton: Using errtol_s: 12217.943285
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.752894e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.745480e+03
Vprtstp: contraction number = 2.745480e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.403614e-04
Vprtstp: contraction number = 3.382426e-01
Vnewton: Using errtol_s: 4132.629024
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.914426e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.256792e+03
Vprtstp: contraction number = 1.256792e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.183405e-04
Vprtstp: contraction number = 3.476907e-01
Vnewton: Using errtol_s: 1436.876571
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.076389e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.226757e+02
Vprtstp: contraction number = 5.226757e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.171003e-05
Vprtstp: contraction number = 3.524579e-01
Vnewton: Using errtol_s: 506.438451
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.237093e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.939950e+02
Vprtstp: contraction number = 1.939950e+02
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.459801e-05
Vprtstp: contraction number = 3.499880e-01
Vnewton: Using errtol_s: 177.247358
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.399708e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.958218e+01
Vprtstp: contraction number = 6.958218e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.178448e-06
Vprtstp: contraction number = 3.547366e-01
Vnewton: Using errtol_s: 62.876121
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.562615e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.538055e+01
Vprtstp: contraction number = 2.538055e+01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.884124e-06
Vprtstp: contraction number = 3.638396e-01
Vnewton: Using errtol_s: 22.876821
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.724408e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.488539e+00
Vprtstp: contraction number = 9.488539e+00
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.037422e-07
Vprtstp: contraction number = 3.735115e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.087920e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.365660e+00
Vpmg_setPart:  lower corner = (-15.47, -9.877, -28.22)
Vpmg_setPart:  upper corner = (78.089, 71.673, 72.62)
Vpmg_setPart:  actual minima = (-15.47, -9.877, -28.22)
Vpmg_setPart:  actual maxima = (78.089, 71.673, 72.62)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.196367e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:37 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9122 atoms
Valist_getStatistics:  Max atom coordinate:  (68.089, 61.673, 62.62)
Valist_getStatistics:  Min atom coordinate:  (-5.47, 0.123, -18.22)
Valist_getStatistics:  Molecule center:  (31.3095, 30.898, 22.2)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.88718, 0.793359, 0.944063
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.73093, 0.637109, 0.787813
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.82388, 0.803053, 0.834492 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 88.089 81.673 82.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -25.47 -19.877 -38.22
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 78.089 71.673 72.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -15.47 -9.877 -28.22
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 78.089 71.673 72.62
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -15.47 -9.877 -28.22
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -14.0008
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7026107 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.036887
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.422859e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.558000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.038500e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.616843e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.677849e-02
Vprtstp: contraction number = 5.677849e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.365459e-03
Vprtstp: contraction number = 1.297227e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.128872e-03
Vprtstp: contraction number = 1.532657e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.000482e-04
Vprtstp: contraction number = 1.772106e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.046877e-05
Vprtstp: contraction number = 2.522831e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.981059e-05
Vprtstp: contraction number = 3.925317e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.204212e-06
Vprtstp: contraction number = 3.636546e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.723323e-06
Vprtstp: contraction number = 3.780181e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.935121e-07
Vprtstp: contraction number = 3.648161e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.411840e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.012910e+00
Vpmg_setPart:  lower corner = (-25.47, -19.877, -38.22)
Vpmg_setPart:  upper corner = (88.089, 81.673, 82.62)
Vpmg_setPart:  actual minima = (-25.47, -19.877, -38.22)
Vpmg_setPart:  actual maxima = (88.089, 81.673, 82.62)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -14.0008
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7026107 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -15.47, -9.877, -28.22
VPMG::focusFillBound -- New mesh maxs = 78.089, 71.673, 72.62
VPMG::focusFillBound -- Old mesh mins = -25.47, -19.877, -38.22
VPMG::focusFillBound -- Old mesh maxs = 88.089, 81.673, 82.62
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.032691
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.552221e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.684800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.147680e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.201458e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.614524e-02
Vprtstp: contraction number = 7.614524e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.041414e-02
Vprtstp: contraction number = 1.367668e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.655685e-03
Vprtstp: contraction number = 1.589843e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.822397e-04
Vprtstp: contraction number = 1.704670e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.204919e-05
Vprtstp: contraction number = 1.844149e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.341853e-05
Vprtstp: contraction number = 2.578047e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.545943e-06
Vprtstp: contraction number = 3.387810e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.576349e-06
Vprtstp: contraction number = 3.467596e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.670424e-07
Vprtstp: contraction number = 3.597188e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.870590e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.733770e-01
Vpmg_setPart:  lower corner = (-15.47, -9.877, -28.22)
Vpmg_setPart:  upper corner = (78.089, 71.673, 72.62)
Vpmg_setPart:  actual minima = (-15.47, -9.877, -28.22)
Vpmg_setPart:  actual maxima = (78.089, 71.673, 72.62)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.306792e+00
