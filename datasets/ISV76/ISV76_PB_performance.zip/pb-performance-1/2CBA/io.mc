##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:22:10 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4072 atoms
Valist_getStatistics:  Max atom coordinate:  (16.346, 21.943, 43.345)
Valist_getStatistics:  Min atom coordinate:  (-30.723, -22.577, -10.573)
Valist_getStatistics:  Molecule center:  (-7.1885, -0.317, 16.386)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.906969, 0.880417, 0.978313
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.698635, 0.672083, 0.769979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.770297, 0.76337, 0.787048 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.346 41.943 63.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -50.723 -42.577 -30.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.346 31.943 53.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -40.723 -32.577 -20.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.346 31.943 53.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -40.723 -32.577 -20.573
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.0221
Vpbe_ctor2:  solute dimensions = 49.8062 x 47.107 x 56.8592
Vpbe_ctor2:  solute charge = 2.9643e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (59.849, 57.3, 66.698)
Vclist_setupGrid:  Grid lower corner = (-37.113, -28.967, -16.963)
Vclist_assignAtoms:  Have 6834501 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.442897
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.200740e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.846700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.121200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.118620e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.066971e-02
Vprtstp: contraction number = 5.066971e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.197045e-03
Vprtstp: contraction number = 1.223028e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.542505e-04
Vprtstp: contraction number = 1.539848e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.619468e-04
Vprtstp: contraction number = 1.697110e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.026872e-05
Vprtstp: contraction number = 1.869053e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.077064e-06
Vprtstp: contraction number = 2.007704e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.284432e-06
Vprtstp: contraction number = 2.113573e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.800398e-07
Vprtstp: contraction number = 2.180261e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.530920e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.323760e-01
Vpmg_setPart:  lower corner = (-50.723, -42.577, -30.573)
Vpmg_setPart:  upper corner = (36.346, 41.943, 63.345)
Vpmg_setPart:  actual minima = (-50.723, -42.577, -30.573)
Vpmg_setPart:  actual maxima = (36.346, 41.943, 63.345)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.0221
Vpbe_ctor2:  solute dimensions = 49.8062 x 47.107 x 56.8592
Vpbe_ctor2:  solute charge = 2.9643e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (59.849, 57.3, 66.698)
Vclist_setupGrid:  Grid lower corner = (-37.113, -28.967, -16.963)
Vclist_assignAtoms:  Have 6834501 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -40.723, -32.577, -20.573
VPMG::focusFillBound -- New mesh maxs = 26.346, 31.943, 53.345
VPMG::focusFillBound -- Old mesh mins = -50.723, -42.577, -30.573
VPMG::focusFillBound -- Old mesh maxs = 36.346, 41.943, 63.345
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.439452
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.927220e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.891900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.338600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.742054e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.235151e-02
Vprtstp: contraction number = 7.235151e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.263687e-03
Vprtstp: contraction number = 1.280372e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.427243e-03
Vprtstp: contraction number = 1.540686e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.493448e-04
Vprtstp: contraction number = 1.747038e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.929314e-05
Vprtstp: contraction number = 1.976907e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.027747e-05
Vprtstp: contraction number = 2.084970e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.501665e-06
Vprtstp: contraction number = 2.434125e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.767081e-07
Vprtstp: contraction number = 2.305297e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.550130e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.372720e-01
Vpmg_setPart:  lower corner = (-40.723, -32.577, -20.573)
Vpmg_setPart:  upper corner = (26.346, 31.943, 53.345)
Vpmg_setPart:  actual minima = (-40.723, -32.577, -20.573)
Vpmg_setPart:  actual maxima = (26.346, 31.943, 53.345)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.144059e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:22:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4072 atoms
Valist_getStatistics:  Max atom coordinate:  (16.346, 21.943, 43.345)
Valist_getStatistics:  Min atom coordinate:  (-30.723, -22.577, -10.573)
Valist_getStatistics:  Molecule center:  (-7.1885, -0.317, 16.386)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.906969, 0.880417, 0.978313
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.698635, 0.672083, 0.769979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.770297, 0.76337, 0.787048 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -7.1885 -0.317 16.386
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.346 41.943 63.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -50.723 -42.577 -30.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.346 31.943 53.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -40.723 -32.577 -20.573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.346 31.943 53.345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -40.723 -32.577 -20.573
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.0221
Vpbe_ctor2:  solute dimensions = 49.8062 x 47.107 x 56.8592
Vpbe_ctor2:  solute charge = 2.9643e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (59.849, 57.3, 66.698)
Vclist_setupGrid:  Grid lower corner = (-37.113, -28.967, -16.963)
Vclist_assignAtoms:  Have 6834501 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.443816
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.209160e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.879300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.147800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.125610e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4224277.039124
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.534200e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.273604e+05
Vprtstp: contraction number = 2.273604e+05
Vnewton: Attempting damping, relres = 0.049183
Vnewton: Attempting damping, relres = 0.518895
Vnewton: Damping accepted, relres = 0.049183
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.918290e-02
Vprtstp: contraction number = 4.918290e-02
Vnewton: Using errtol_s: 207762.209508
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.333520e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.775880e+04
Vprtstp: contraction number = 2.775880e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.917413e-03
Vprtstp: contraction number = 1.203144e-01
Vnewton: Using errtol_s: 24996.789947
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.973600e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.103189e+03
Vprtstp: contraction number = 4.103189e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.742818e-04
Vprtstp: contraction number = 1.477473e-01
Vnewton: Using errtol_s: 3693.208389
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.620630e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.735370e+02
Vprtstp: contraction number = 6.735370e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.435034e-04
Vprtstp: contraction number = 1.641386e-01
Vnewton: Using errtol_s: 606.198151
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.026726e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.180288e+02
Vprtstp: contraction number = 1.180288e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.514668e-05
Vprtstp: contraction number = 1.752340e-01
Vnewton: Using errtol_s: 106.226554
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.091350e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.162498e+01
Vprtstp: contraction number = 2.162498e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.607301e-06
Vprtstp: contraction number = 1.832171e-01
Vnewton: Using errtol_s: 19.462517
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.155935e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.096599e+00
Vprtstp: contraction number = 4.096599e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.727980e-07
Vprtstp: contraction number = 1.894380e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.927000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.720100e-01
Vpmg_setPart:  lower corner = (-50.723, -42.577, -30.573)
Vpmg_setPart:  upper corner = (36.346, 41.943, 63.345)
Vpmg_setPart:  actual minima = (-50.723, -42.577, -30.573)
Vpmg_setPart:  actual maxima = (36.346, 41.943, 63.345)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.0221
Vpbe_ctor2:  solute dimensions = 49.8062 x 47.107 x 56.8592
Vpbe_ctor2:  solute charge = 2.9643e-14
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (59.849, 57.3, 66.698)
Vclist_setupGrid:  Grid lower corner = (-37.113, -28.967, -16.963)
Vclist_assignAtoms:  Have 6834501 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -40.723, -32.577, -20.573
VPMG::focusFillBound -- New mesh maxs = 26.346, 31.943, 53.345
VPMG::focusFillBound -- Old mesh mins = -50.723, -42.577, -30.573
VPMG::focusFillBound -- Old mesh maxs = 36.346, 41.943, 63.345
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.433869
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.851870e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.894600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 4.992400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.970303e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5322758.976035
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.011583e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.194356e+05
Vprtstp: contraction number = 4.194356e+05
Vnewton: Attempting damping, relres = 0.071423
Vnewton: Attempting damping, relres = 0.531482
Vnewton: Damping accepted, relres = 0.071423
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.142286e-02
Vprtstp: contraction number = 7.142286e-02
Vnewton: Using errtol_s: 380166.643960
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.091976e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.345729e+04
Vprtstp: contraction number = 5.345729e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.041928e-03
Vprtstp: contraction number = 1.265971e-01
Vnewton: Using errtol_s: 48128.001594
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.157061e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.090566e+03
Vprtstp: contraction number = 8.090566e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.368088e-03
Vprtstp: contraction number = 1.513049e-01
Vnewton: Using errtol_s: 7282.003930
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.221222e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.363632e+03
Vprtstp: contraction number = 1.363632e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.305736e-04
Vprtstp: contraction number = 1.685371e-01
Vnewton: Using errtol_s: 1227.287784
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.285526e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.478102e+02
Vprtstp: contraction number = 2.478102e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.190118e-05
Vprtstp: contraction number = 1.817258e-01
Vnewton: Using errtol_s: 223.029880
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.349316e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.743712e+01
Vprtstp: contraction number = 4.743712e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.020922e-06
Vprtstp: contraction number = 1.914247e-01
Vnewton: Using errtol_s: 42.693432
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.413666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.485742e+00
Vprtstp: contraction number = 9.485742e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.603899e-06
Vprtstp: contraction number = 1.999645e-01
Vnewton: Using errtol_s: 8.537169
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.477108e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.973749e+00
Vprtstp: contraction number = 1.973749e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.337319e-07
Vprtstp: contraction number = 2.080753e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.559730e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.338030e-01
Vpmg_setPart:  lower corner = (-40.723, -32.577, -20.573)
Vpmg_setPart:  upper corner = (26.346, 31.943, 53.345)
Vpmg_setPart:  actual minima = (-40.723, -32.577, -20.573)
Vpmg_setPart:  actual maxima = (26.346, 31.943, 53.345)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.675022e+00
