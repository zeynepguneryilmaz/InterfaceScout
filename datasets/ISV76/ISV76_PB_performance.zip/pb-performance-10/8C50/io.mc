##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:32 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.866885, 1.01259, 1.04559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.658552, 0.700094, 0.967461
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.132700
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.612421e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.326100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 129)
Vbuildops: Galer: (025, 017, 065)
Vbuildops: Galer: (013, 009, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.073900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.772143e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.233926e-01
Vprtstp: contraction number = 1.233926e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.440341e-02
Vprtstp: contraction number = 1.167283e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.732501e-03
Vprtstp: contraction number = 1.202841e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.109491e-04
Vprtstp: contraction number = 1.217599e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.623297e-05
Vprtstp: contraction number = 1.243569e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.322224e-06
Vprtstp: contraction number = 1.266430e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.376209e-07
Vprtstp: contraction number = 1.317253e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.342230e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.584050e-01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.64, 88.67, -12.701
VPMG::focusFillBound -- New mesh maxs = 142.861, 133.476, 234.969
VPMG::focusFillBound -- Old mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- Old mesh maxs = 152.861, 143.476, 244.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.119913
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.793384e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.326400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 129)
Vbuildops: Galer: (025, 017, 065)
Vbuildops: Galer: (013, 009, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.893000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.125248e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.882004e-02
Vprtstp: contraction number = 8.882004e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.941347e-03
Vprtstp: contraction number = 8.940940e-02
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.765441e-04
Vprtstp: contraction number = 9.778494e-02
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.032219e-05
Vprtstp: contraction number = 1.034355e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.155292e-06
Vprtstp: contraction number = 1.139821e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.244961e-06
Vprtstp: contraction number = 1.359827e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.297979e-07
Vprtstp: contraction number = 1.845823e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.531210e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.745570e-01
Vpmg_setPart:  lower corner = (79.64, 88.67, -12.701)
Vpmg_setPart:  upper corner = (142.861, 133.476, 234.969)
Vpmg_setPart:  actual minima = (79.64, 88.67, -12.701)
Vpmg_setPart:  actual maxima = (142.861, 133.476, 234.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.987074e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.866885, 1.01259, 1.04559
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.658552, 0.700094, 0.967461
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.759676, 0.691387, 0.925281 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 152.861 143.476 244.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 69.64 78.67 -22.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 142.861 133.476 234.969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 79.64 88.67 -12.701
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.125624
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.603843e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.521500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 129)
Vbuildops: Galer: (025, 017, 065)
Vbuildops: Galer: (013, 009, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.923200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.762713e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 17506428818.301994
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.855766e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.290202e+09
Vprtstp: contraction number = 2.290202e+09
Vnewton: Attempting damping, relres = 175546638292803402464721721360384.000000
Vnewton: Attempting damping, relres = 159758837686446500617555737051136.000000
Vnewton: Attempting damping, relres = 143078008650127892773356500418560.000000
Vnewton: Attempting damping, relres = 124561070853254212348163961913344.000000
Vnewton: Attempting damping, relres = 93316391252146584630720102137856.000000
Vnewton: Attempting damping, relres = 45115135189973053705911978164224.000000
Vnewton: Attempting damping, relres = 17200244002353134378022586023936.000000
Vnewton: Attempting damping, relres = 5812459561814713940740302438400.000000
Vnewton: Attempting damping, relres = 1061021281459432734541247152128.000000
Vnewton: Attempting damping, relres = 284884287343691045011456.000000
Vnewton: Attempting damping, relres = 21677807.684654
Vnewton: Damping accepted, relres = 284884287343691045011456.000000
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.848843e+23
Vprtstp: contraction number = 2.848843e+23
Vnewton: Using errtol_s: 4987306497835019285081193634070528.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.378681e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.356881e+08
Vprtstp: contraction number = 2.356881e+08
Vnewton: Attempting damping, relres = 48846537720801273408640325255168.000000
Vnewton: Attempting damping, relres = 30775960341608720866002327306240.000000
Vnewton: Attempting damping, relres = 16155180480236064498205035855872.000000
Vnewton: Attempting damping, relres = 5781086840904815130776250089472.000000
Vnewton: Attempting damping, relres = 164514095685333487071904399360.000000
Vnewton: Attempting damping, relres = 276119342412030151753728.000000
Vnewton: Attempting damping, relres = 280467565848689018667008.000000
Vnewton: Damping accepted, relres = 276119342412030151753728.000000
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.761193e+23
Vprtstp: contraction number = 9.692333e-01
Vnewton: Using errtol_s: 4833863613292561068913975980195840.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.758984e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.464442e+06
Vprtstp: contraction number = 9.464442e+06
Vnewton: Attempting damping, relres = 14031768688605667591112884224.000000
Vnewton: Attempting damping, relres = 2722844891038428706858074112.000000
Vnewton: Attempting damping, relres = 215041966777516748177408.000000
Vnewton: Attempting damping, relres = 243674464422315293671424.000000
Vnewton: Damping accepted, relres = 215041966777516748177408.000000
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.150420e+23
Vprtstp: contraction number = 7.788008e-01
Vnewton: Using errtol_s: 3764616884338259456387118304067584.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.034489e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.322003e+06
Vprtstp: contraction number = 2.322003e+06
Vnewton: Attempting damping, relres = 79109518566520369709056.000000
Vnewton: Attempting damping, relres = 130429545975470801027072.000000
Vnewton: Damping accepted, relres = 79109518566520369709056.000000
Vnewton: Damping disabled
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.910952e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1384925155634928951858602564386816.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.225920e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.185458e+06
Vprtstp: contraction number = 1.185458e+06
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.910277e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 509485492319255569884185200951296.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.373252e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.555967e+05
Vprtstp: contraction number = 9.555967e+05
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.070631e+22
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 187429238199363541458179214802944.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.515940e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.700013e+05
Vprtstp: contraction number = 7.700013e+05
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.938631e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 68951363407971733969714360090624.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.657085e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.134136e+05
Vprtstp: contraction number = 6.134136e+05
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.448941e+21
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 25365789038533429009084181381120.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.799083e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.935792e+05
Vprtstp: contraction number = 4.935792e+05
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.330357e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 9331552296368318740271581888512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.942456e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.128732e+05
Vprtstp: contraction number = 4.128732e+05
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.960929e+20
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3432886244050089017971736313856.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.086762e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.557301e+05
Vprtstp: contraction number = 3.557301e+05
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.213854e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1262888273066274738433377173504.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.229956e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.128352e+05
Vprtstp: contraction number = 3.128352e+05
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.653829e+19
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 464590632157592286328887705600.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.371453e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.771309e+05
Vprtstp: contraction number = 2.771309e+05
Vprtstp: iteration = 13
Vprtstp: relative residual = 9.762890e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 170913342131621276625817042944.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.512336e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.453259e+05
Vprtstp: contraction number = 2.453259e+05
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.591567e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 62875504792124842597630869504.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.656825e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.172171e+05
Vprtstp: contraction number = 2.172171e+05
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.321264e+18
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 23130605566299049605713625088.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.800204e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.874258e+05
Vprtstp: contraction number = 1.874258e+05
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.860657e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 8509274249687235559004569600.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.945377e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.607230e+05
Vprtstp: contraction number = 1.607230e+05
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.788136e+17
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 3130387055749467141763497984.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.086645e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.384789e+05
Vprtstp: contraction number = 1.384789e+05
Vprtstp: iteration = 18
Vprtstp: relative residual = 6.578184e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1151605040719418738100666368.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.229973e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.210534e+05
Vprtstp: contraction number = 1.210534e+05
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.419979e+16
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 423651818830078231739105280.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.371233e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.073691e+05
Vprtstp: contraction number = 1.073691e+05
Vprtstp: iteration = 20
Vprtstp: relative residual = 8.902603e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 155852794362473049504088064.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.512480e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.551168e+04
Vprtstp: contraction number = 9.551168e+04
Vprtstp: iteration = 21
Vprtstp: relative residual = 3.275085e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 57335038895074903840522240.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.656361e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.534173e+04
Vprtstp: contraction number = 8.534173e+04
Vprtstp: iteration = 22
Vprtstp: relative residual = 1.204836e+15
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 21092382068263046304759808.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.801440e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.576197e+04
Vprtstp: contraction number = 7.576197e+04
Vprtstp: iteration = 23
Vprtstp: relative residual = 4.432345e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 7759453728247202281684992.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.951114e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.789969e+04
Vprtstp: contraction number = 6.789969e+04
Vprtstp: iteration = 24
Vprtstp: relative residual = 1.630569e+14
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2854543501343215914582016.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.097323e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.144349e+04
Vprtstp: contraction number = 6.144349e+04
Vprtstp: iteration = 25
Vprtstp: relative residual = 5.998527e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 1050127868073728081395712.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.244482e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.614883e+04
Vprtstp: contraction number = 5.614883e+04
Vprtstp: iteration = 26
Vprtstp: relative residual = 2.206735e+13
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 386320453265514785931264.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.389715e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.173989e+04
Vprtstp: contraction number = 5.173989e+04
Vprtstp: iteration = 27
Vprtstp: relative residual = 8.118124e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 142119352460413260267520.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.534570e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.789172e+04
Vprtstp: contraction number = 4.789172e+04
Vprtstp: iteration = 28
Vprtstp: relative residual = 2.986491e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 52282787962783115771904.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.678498e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.389400e+04
Vprtstp: contraction number = 4.389400e+04
Vprtstp: iteration = 29
Vprtstp: relative residual = 1.098669e+12
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 19233762818631923662848.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.821577e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.939429e+04
Vprtstp: contraction number = 3.939429e+04
Vprtstp: iteration = 30
Vprtstp: relative residual = 4.041776e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 7075705917341004988416.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.963566e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.451626e+04
Vprtstp: contraction number = 3.451626e+04
Vprtstp: iteration = 31
Vprtstp: relative residual = 1.486886e+11
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2603006738763539283968.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.103771e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.961066e+04
Vprtstp: contraction number = 2.961066e+04
Vprtstp: iteration = 32
Vprtstp: relative residual = 5.469949e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 957592664420591861760.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.241973e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.529778e+04
Vprtstp: contraction number = 2.529778e+04
Vprtstp: iteration = 33
Vprtstp: relative residual = 2.012282e+10
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 352278654255764340736.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.380796e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.198654e+04
Vprtstp: contraction number = 2.198654e+04
Vprtstp: iteration = 34
Vprtstp: relative residual = 7.402770e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 129596074463163383808.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.528362e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.948773e+04
Vprtstp: contraction number = 1.948773e+04
Vprtstp: iteration = 35
Vprtstp: relative residual = 2.723327e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 47675731450511540224.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.671454e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.746538e+04
Vprtstp: contraction number = 1.746538e+04
Vprtstp: iteration = 36
Vprtstp: relative residual = 1.001856e+09
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 17538921442504009728.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.814703e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.576813e+04
Vprtstp: contraction number = 1.576813e+04
Vprtstp: iteration = 37
Vprtstp: relative residual = 3.685622e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 6452208618124352512.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.959162e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.438787e+04
Vprtstp: contraction number = 1.438787e+04
Vprtstp: iteration = 38
Vprtstp: relative residual = 1.355865e+08
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2373634899914953216.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.102945e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.318069e+04
Vprtstp: contraction number = 1.318069e+04
Vprtstp: iteration = 39
Vprtstp: relative residual = 4.987948e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 873211479731088768.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.249292e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.204087e+04
Vprtstp: contraction number = 1.204087e+04
Vprtstp: iteration = 40
Vprtstp: relative residual = 1.834963e+07
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 321236550440744896.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.392426e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.093305e+04
Vprtstp: contraction number = 1.093305e+04
Vprtstp: iteration = 41
Vprtstp: relative residual = 6.750453e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 118176321960987088.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.537212e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.824974e+03
Vprtstp: contraction number = 9.824974e+03
Vprtstp: iteration = 42
Vprtstp: relative residual = 2.483353e+06
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 43474638629000952.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.680058e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.719775e+03
Vprtstp: contraction number = 8.719775e+03
Vprtstp: iteration = 43
Vprtstp: relative residual = 9.135744e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 15993425154637710.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.821564e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.662105e+03
Vprtstp: contraction number = 7.662105e+03
Vprtstp: iteration = 44
Vprtstp: relative residual = 3.360852e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 5883651745936688.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.962700e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.619475e+03
Vprtstp: contraction number = 6.619475e+03
Vprtstp: iteration = 45
Vprtstp: relative residual = 1.236388e+05
Vprtstp: contraction number = 3.678794e-01
Vnewton: Using errtol_s: 2164474000096263.000000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.010416e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.627838e+03
Vprtstp: contraction number = 5.627838e+03
Vprtstp: iteration = 46
Vprtstp: relative residual = 4.548415e+04
Vprtstp: contraction number = 3.678792e-01
Vnewton: Using errtol_s: 796265012749545.250000
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.024475e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.765307e+03
Vprtstp: contraction number = 4.765307e+03
Vprtstp: iteration = 47
Vprtstp: relative residual = 1.673266e+04
Vprtstp: contraction number = 3.678789e-01
Vnewton: Using errtol_s: 292929100051466.062500
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.038963e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.047698e+03
Vprtstp: contraction number = 4.047698e+03
Vprtstp: iteration = 48
Vprtstp: relative residual = 6.155579e+03
Vprtstp: contraction number = 3.678781e-01
Vnewton: Using errtol_s: 107762211426903.140625
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.053433e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.434130e+03
Vprtstp: contraction number = 3.434130e+03
Vprtstp: iteration = 49
Vprtstp: relative residual = 2.264492e+03
Vprtstp: contraction number = 3.678763e-01
Vnewton: Using errtol_s: 39643163580183.515625
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.067940e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.844636e+03
Vprtstp: contraction number = 2.844636e+03
Vprtstp: iteration = 50
Vprtstp: relative residual = 8.330431e+02
Vprtstp: contraction number = 3.678720e-01
Vnewton: Using errtol_s: 14583609686180.060547
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.082423e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.245078e+03
Vprtstp: contraction number = 2.245078e+03
Vprtstp: iteration = 51
Vprtstp: relative residual = 3.064450e+02
Vprtstp: contraction number = 3.678621e-01
Vnewton: Using errtol_s: 5364757352022.966797
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.096678e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.694390e+03
Vprtstp: contraction number = 1.694390e+03
Vprtstp: iteration = 52
Vprtstp: relative residual = 1.127226e+02
Vprtstp: contraction number = 3.678395e-01
Vnewton: Using errtol_s: 1973369478872.369873
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.111144e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.243036e+03
Vprtstp: contraction number = 1.243036e+03
Vprtstp: iteration = 53
Vprtstp: relative residual = 4.145805e+01
Vprtstp: contraction number = 3.677884e-01
Vnewton: Using errtol_s: 725782434852.510620
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.125871e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.208976e+02
Vprtstp: contraction number = 9.208976e+02
Vprtstp: iteration = 54
Vprtstp: relative residual = 1.524313e+01
Vprtstp: contraction number = 3.676760e-01
Vnewton: Using errtol_s: 266852805997.570770
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.140532e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.999526e+02
Vprtstp: contraction number = 6.999526e+02
Vprtstp: iteration = 55
Vprtstp: relative residual = 5.600836e+00
Vprtstp: contraction number = 3.674334e-01
Vnewton: Using errtol_s: 98050640872.338074
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.154945e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.430228e+02
Vprtstp: contraction number = 5.430228e+02
Vprtstp: iteration = 56
Vprtstp: relative residual = 2.055050e+00
Vprtstp: contraction number = 3.669184e-01
Vnewton: Using errtol_s: 35976579586.807281
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.169156e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.361573e+02
Vprtstp: contraction number = 4.361573e+02
Vprtstp: iteration = 57
Vprtstp: relative residual = 7.517322e-01
Vprtstp: contraction number = 3.657976e-01
Vnewton: Using errtol_s: 13160145992.334877
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.183734e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.458048e+02
Vprtstp: contraction number = 3.458048e+02
Vprtstp: iteration = 58
Vprtstp: relative residual = 2.731165e-01
Vprtstp: contraction number = 3.633163e-01
Vnewton: Using errtol_s: 4781295392.109690
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.197869e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.553397e+02
Vprtstp: contraction number = 2.553397e+02
Vprtstp: iteration = 59
Vprtstp: relative residual = 9.775595e-02
Vprtstp: contraction number = 3.579276e-01
Vnewton: Using errtol_s: 1711357532.816220
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.212364e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.647028e+02
Vprtstp: contraction number = 1.647028e+02
Vprtstp: iteration = 60
Vprtstp: relative residual = 3.388163e-02
Vprtstp: contraction number = 3.465941e-01
Vnewton: Using errtol_s: 593146340.731266
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.226687e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.939793e+01
Vprtstp: contraction number = 8.939793e+01
Vprtstp: iteration = 61
Vprtstp: relative residual = 1.098942e-02
Vprtstp: contraction number = 3.243473e-01
Vnewton: Using errtol_s: 192385426.403774
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.240961e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.518138e+01
Vprtstp: contraction number = 4.518138e+01
Vprtstp: iteration = 62
Vprtstp: relative residual = 3.129774e-03
Vprtstp: contraction number = 2.847990e-01
Vnewton: Using errtol_s: 54791174.463398
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.255021e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.091982e+01
Vprtstp: contraction number = 2.091982e+01
Vprtstp: iteration = 63
Vprtstp: relative residual = 6.981534e-04
Vprtstp: contraction number = 2.230683e-01
Vnewton: Using errtol_s: 12222173.382496
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.269425e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.471478e+00
Vprtstp: contraction number = 7.471478e+00
Vprtstp: iteration = 64
Vprtstp: relative residual = 9.496232e-05
Vprtstp: contraction number = 1.360193e-01
Vnewton: Using errtol_s: 1662451.037190
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.283714e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.685532e+00
Vprtstp: contraction number = 1.685532e+00
Vprtstp: iteration = 65
Vprtstp: relative residual = 4.246450e-06
Vprtstp: contraction number = 4.471722e-02
Vnewton: Using errtol_s: 74340.181226
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.298063e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.207309e-01
Vprtstp: contraction number = 2.207309e-01
Vprtstp: iteration = 66
Vprtstp: relative residual = 1.560014e-08
Vprtstp: contraction number = 3.673689e-03
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.032368e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.044673e+01
Vpmg_setPart:  lower corner = (69.64, 78.67, -22.701)
Vpmg_setPart:  upper corner = (152.861, 143.476, 244.969)
Vpmg_setPart:  actual minima = (69.64, 78.67, -22.701)
Vpmg_setPart:  actual maxima = (152.861, 143.476, 244.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 79.64, 88.67, -12.701
VPMG::focusFillBound -- New mesh maxs = 142.861, 133.476, 234.969
VPMG::focusFillBound -- Old mesh mins = 69.64, 78.67, -22.701
VPMG::focusFillBound -- Old mesh maxs = 152.861, 143.476, 244.969
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.114114
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.794301e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.508200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 129)
Vbuildops: Galer: (025, 017, 065)
Vbuildops: Galer: (013, 009, 033)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 7.063100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.600783e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 27651066.564422
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.610385e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.524956e+06
Vprtstp: contraction number = 2.524956e+06
Vnewton: Attempting damping, relres = 814.511626
Vnewton: Attempting damping, relres = 0.678728
Vnewton: Attempting damping, relres = 0.772046
Vnewton: Damping accepted, relres = 0.678728
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.787275e-01
Vprtstp: contraction number = 6.787275e-01
Vnewton: Using errtol_s: 18767539.743972
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.632447e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.444577e+06
Vprtstp: contraction number = 1.444577e+06
Vnewton: Attempting damping, relres = 0.091509
Vnewton: Attempting damping, relres = 0.372911
Vnewton: Damping accepted, relres = 0.091509
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.150911e-02
Vprtstp: contraction number = 1.348245e-01
Vnewton: Using errtol_s: 2530324.439609
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.650585e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.654667e+05
Vprtstp: contraction number = 2.654667e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.009681e-02
Vprtstp: contraction number = 2.196154e-01
Vnewton: Using errtol_s: 555698.135539
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.664605e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.186626e+04
Vprtstp: contraction number = 7.186626e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.923137e-03
Vprtstp: contraction number = 2.449711e-01
Vnewton: Using errtol_s: 136129.983754
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.678723e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.113325e+04
Vprtstp: contraction number = 2.113325e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.093587e-03
Vprtstp: contraction number = 2.221323e-01
Vnewton: Using errtol_s: 30238.859978
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.692504e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.684114e+03
Vprtstp: contraction number = 5.684114e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.146105e-04
Vprtstp: contraction number = 1.962444e-01
Vnewton: Using errtol_s: 5934.208360
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.706392e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.408212e+03
Vprtstp: contraction number = 1.408212e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.648355e-05
Vprtstp: contraction number = 2.165950e-01
Vnewton: Using errtol_s: 1285.319827
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.720463e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.457103e+02
Vprtstp: contraction number = 3.457103e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.126140e-05
Vprtstp: contraction number = 2.422664e-01
Vnewton: Using errtol_s: 311.389858
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.734452e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.643763e+01
Vprtstp: contraction number = 8.643763e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.813677e-06
Vprtstp: contraction number = 2.498513e-01
Vnewton: Using errtol_s: 77.801157
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.748353e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.195571e+01
Vprtstp: contraction number = 2.195571e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.146336e-07
Vprtstp: contraction number = 2.539857e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.581871e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.704548e+00
Vpmg_setPart:  lower corner = (79.64, 88.67, -12.701)
Vpmg_setPart:  upper corner = (142.861, 133.476, 234.969)
Vpmg_setPart:  actual minima = (79.64, 88.67, -12.701)
Vpmg_setPart:  actual maxima = (142.861, 133.476, 234.969)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.790335e+01
