##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:08 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13122 atoms
Valist_getStatistics:  Max atom coordinate:  (102.02, 72.619, 60.598)
Valist_getStatistics:  Min atom coordinate:  (23.733, -9.382, -5.922)
Valist_getStatistics:  Molecule center:  (62.8765, 31.6185, 27.338)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.924117, 0.953133, 0.832187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.767867, 0.796883, 0.675937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.83092, 0.836067, 0.812242 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 122.02 92.619 80.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 3.733 -29.382 -25.922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 112.02 82.619 70.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 13.733 -19.382 -15.922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 112.02 82.619 70.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 13.733 -19.382 -15.922
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9092340 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.835406
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.265205e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.479500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 9.135400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.456136e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 14503881.504864
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.584003e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.204223e+05
Vprtstp: contraction number = 7.204223e+05
Vnewton: Attempting damping, relres = 70.067564
Vnewton: Attempting damping, relres = 0.520756
Vnewton: Attempting damping, relres = 0.758248
Vnewton: Damping accepted, relres = 0.520756
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.207561e-01
Vprtstp: contraction number = 5.207561e-01
Vnewton: Using errtol_s: 7552985.384821
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.885731e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.006310e+05
Vprtstp: contraction number = 4.006310e+05
Vnewton: Attempting damping, relres = 0.026814
Vnewton: Attempting damping, relres = 0.270875
Vnewton: Damping accepted, relres = 0.026814
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.681392e-02
Vprtstp: contraction number = 5.149036e-02
Vnewton: Using errtol_s: 388905.973536
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.132915e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.121779e+04
Vprtstp: contraction number = 5.121779e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.602701e-03
Vprtstp: contraction number = 1.343593e-01
Vnewton: Using errtol_s: 52253.151213
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.325207e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.967754e+03
Vprtstp: contraction number = 8.967754e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.527309e-04
Vprtstp: contraction number = 1.811782e-01
Vnewton: Using errtol_s: 9467.131542
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.515485e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.146600e+03
Vprtstp: contraction number = 2.146600e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.507451e-04
Vprtstp: contraction number = 2.309453e-01
Vnewton: Using errtol_s: 2186.389229
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.706771e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.479807e+02
Vprtstp: contraction number = 6.479807e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.264914e-05
Vprtstp: contraction number = 2.829222e-01
Vnewton: Using errtol_s: 618.578030
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.897218e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.167184e+02
Vprtstp: contraction number = 2.167184e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.374651e-05
Vprtstp: contraction number = 3.223162e-01
Vnewton: Using errtol_s: 199.377717
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.088096e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.689159e+01
Vprtstp: contraction number = 7.689159e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.807092e-06
Vprtstp: contraction number = 3.496955e-01
Vnewton: Using errtol_s: 69.721491
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.280304e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.822104e+01
Vprtstp: contraction number = 2.822104e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.755447e-06
Vprtstp: contraction number = 3.651786e-01
Vnewton: Using errtol_s: 25.460799
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.471312e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.060562e+01
Vprtstp: contraction number = 1.060562e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.586096e-07
Vprtstp: contraction number = 3.751805e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.157865e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.316483e+00
Vpmg_setPart:  lower corner = (3.733, -29.382, -25.922)
Vpmg_setPart:  upper corner = (122.02, 92.619, 80.598)
Vpmg_setPart:  actual minima = (3.733, -29.382, -25.922)
Vpmg_setPart:  actual maxima = (122.02, 92.619, 80.598)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9092340 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 13.733, -19.382, -15.922
VPMG::focusFillBound -- New mesh maxs = 112.02, 82.619, 70.598
VPMG::focusFillBound -- Old mesh mins = 3.733, -29.382, -25.922
VPMG::focusFillBound -- Old mesh maxs = 122.02, 92.619, 80.598
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.820232
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.372152e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 4.425100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 9.314100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.154066e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 17174059.213871
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.291752e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.127559e+06
Vprtstp: contraction number = 1.127559e+06
Vnewton: Attempting damping, relres = 21.305103
Vnewton: Attempting damping, relres = 0.527049
Vnewton: Attempting damping, relres = 0.762322
Vnewton: Damping accepted, relres = 0.527049
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.270491e-01
Vprtstp: contraction number = 5.270491e-01
Vnewton: Using errtol_s: 9051572.327341
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.600978e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.288331e+05
Vprtstp: contraction number = 6.288331e+05
Vnewton: Attempting damping, relres = 0.034130
Vnewton: Attempting damping, relres = 0.278365
Vnewton: Damping accepted, relres = 0.034130
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.413041e-02
Vprtstp: contraction number = 6.475755e-02
Vnewton: Using errtol_s: 586157.614155
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.859110e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.136598e+04
Vprtstp: contraction number = 8.136598e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.455923e-03
Vprtstp: contraction number = 1.305558e-01
Vnewton: Using errtol_s: 76526.278173
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.051929e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.326402e+04
Vprtstp: contraction number = 1.326402e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.248229e-04
Vprtstp: contraction number = 1.626651e-01
Vnewton: Using errtol_s: 12448.152165
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.245266e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.595449e+03
Vprtstp: contraction number = 2.595449e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.400356e-04
Vprtstp: contraction number = 1.931997e-01
Vnewton: Using errtol_s: 2404.979626
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.437004e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.973914e+02
Vprtstp: contraction number = 5.973914e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.172601e-05
Vprtstp: contraction number = 2.265567e-01
Vnewton: Using errtol_s: 544.864364
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.628270e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.568978e+02
Vprtstp: contraction number = 1.568978e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.261188e-06
Vprtstp: contraction number = 2.603917e-01
Vnewton: Using errtol_s: 141.878137
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.821107e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.541178e+01
Vprtstp: contraction number = 4.541178e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.383448e-06
Vprtstp: contraction number = 2.885115e-01
Vnewton: Using errtol_s: 40.933474
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.015309e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.400607e+01
Vprtstp: contraction number = 1.400607e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.343236e-07
Vprtstp: contraction number = 3.080930e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.011538e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.172775e+00
Vpmg_setPart:  lower corner = (13.733, -19.382, -15.922)
Vpmg_setPart:  upper corner = (112.02, 82.619, 70.598)
Vpmg_setPart:  actual minima = (13.733, -19.382, -15.922)
Vpmg_setPart:  actual maxima = (112.02, 82.619, 70.598)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.653455e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:18 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13122 atoms
Valist_getStatistics:  Max atom coordinate:  (102.02, 72.619, 60.598)
Valist_getStatistics:  Min atom coordinate:  (23.733, -9.382, -5.922)
Valist_getStatistics:  Molecule center:  (62.8765, 31.6185, 27.338)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.924117, 0.953133, 0.832187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.767867, 0.796883, 0.675937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.83092, 0.836067, 0.812242 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 122.02 92.619 80.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 3.733 -29.382 -25.922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 112.02 82.619 70.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 13.733 -19.382 -15.922
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 112.02 82.619 70.598
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 13.733 -19.382 -15.922
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9092340 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.822672
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.250494e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.433100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.051800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.443295e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.470390e-02
Vprtstp: contraction number = 4.470390e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.421250e-03
Vprtstp: contraction number = 1.212702e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.276426e-04
Vprtstp: contraction number = 1.526664e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.481066e-04
Vprtstp: contraction number = 1.789500e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.025156e-05
Vprtstp: contraction number = 2.042553e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.134029e-06
Vprtstp: contraction number = 2.358235e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.964792e-06
Vprtstp: contraction number = 2.754112e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.218239e-07
Vprtstp: contraction number = 3.164834e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.195650e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.796480e-01
Vpmg_setPart:  lower corner = (3.733, -29.382, -25.922)
Vpmg_setPart:  upper corner = (122.02, 92.619, 80.598)
Vpmg_setPart:  actual minima = (3.733, -29.382, -25.922)
Vpmg_setPart:  actual maxima = (122.02, 92.619, 80.598)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9092340 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 13.733, -19.382, -15.922
VPMG::focusFillBound -- New mesh maxs = 112.02, 82.619, 70.598
VPMG::focusFillBound -- Old mesh mins = 3.733, -29.382, -25.922
VPMG::focusFillBound -- Old mesh maxs = 122.02, 92.619, 80.598
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.815689
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.367172e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.412200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.166500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.699086e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.913283e-02
Vprtstp: contraction number = 5.913283e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.372101e-03
Vprtstp: contraction number = 1.246702e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.128580e-03
Vprtstp: contraction number = 1.530880e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.985747e-04
Vprtstp: contraction number = 1.759510e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.819491e-05
Vprtstp: contraction number = 1.923453e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.898589e-06
Vprtstp: contraction number = 2.067969e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.788442e-06
Vprtstp: contraction number = 2.264255e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.376696e-07
Vprtstp: contraction number = 2.447212e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.606610e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.237200e-01
Vpmg_setPart:  lower corner = (13.733, -19.382, -15.922)
Vpmg_setPart:  upper corner = (112.02, 82.619, 70.598)
Vpmg_setPart:  actual minima = (13.733, -19.382, -15.922)
Vpmg_setPart:  actual maxima = (112.02, 82.619, 70.598)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.942292e+00
