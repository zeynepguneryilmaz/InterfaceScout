##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:28 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1988 atoms
Valist_getStatistics:  Max atom coordinate:  (28.914, 8.392, 14.489)
Valist_getStatistics:  Min atom coordinate:  (-3.551, -23.367, -59.228)
Valist_getStatistics:  Molecule center:  (12.6815, -7.4875, -22.3695)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.754844, 1.12123, 0.888414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.54651, 0.808734, 0.732164
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.724005, 0.721289, 0.824125 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 48.914 28.392 34.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -23.551 -43.367 -79.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 38.914 18.392 24.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -13.551 -33.367 -69.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 38.914 18.392 24.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -13.551 -33.367 -69.228
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.232384
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.908050e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.648400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 065)
Vbuildops: Galer: (025, 017, 033)
Vbuildops: Galer: (013, 009, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.308400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.571960e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2331911.209640
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.026140e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.899846e+05
Vprtstp: contraction number = 1.899846e+05
Vnewton: Attempting damping, relres = 0.076705
Vnewton: Attempting damping, relres = 0.531222
Vnewton: Damping accepted, relres = 0.076705
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.670525e-02
Vprtstp: contraction number = 7.670525e-02
Vnewton: Using errtol_s: 178869.836691
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.904050e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.096648e+04
Vprtstp: contraction number = 3.096648e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.202019e-02
Vprtstp: contraction number = 1.567062e-01
Vnewton: Using errtol_s: 28030.008020
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.573270e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.528969e+03
Vprtstp: contraction number = 6.528969e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.520222e-03
Vprtstp: contraction number = 2.096658e-01
Vnewton: Using errtol_s: 5876.933563
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.203820e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.537975e+03
Vprtstp: contraction number = 1.537975e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.935857e-04
Vprtstp: contraction number = 2.355291e-01
Vnewton: Using errtol_s: 1384.189152
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.831640e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.835665e+02
Vprtstp: contraction number = 3.835665e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.480376e-04
Vprtstp: contraction number = 2.493955e-01
Vnewton: Using errtol_s: 345.210494
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.481850e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.950597e+01
Vprtstp: contraction number = 9.950597e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.840430e-05
Vprtstp: contraction number = 2.594227e-01
Vnewton: Using errtol_s: 89.555425
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.141740e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.671983e+01
Vprtstp: contraction number = 2.671983e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.031251e-05
Vprtstp: contraction number = 2.685248e-01
Vnewton: Using errtol_s: 24.047850
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.791900e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.411770e+00
Vprtstp: contraction number = 7.411770e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.860569e-06
Vprtstp: contraction number = 2.773884e-01
Vnewton: Using errtol_s: 6.670594
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.042490e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.118339e+00
Vprtstp: contraction number = 2.118339e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.175721e-07
Vprtstp: contraction number = 2.858075e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.325770e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.906080e-01
Vpmg_setPart:  lower corner = (-23.551, -43.367, -79.228)
Vpmg_setPart:  upper corner = (48.914, 28.392, 34.489)
Vpmg_setPart:  actual minima = (-23.551, -43.367, -79.228)
Vpmg_setPart:  actual maxima = (48.914, 28.392, 34.489)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -13.551, -33.367, -69.228
VPMG::focusFillBound -- New mesh maxs = 38.914, 18.392, 24.489
VPMG::focusFillBound -- Old mesh mins = -23.551, -43.367, -79.228
VPMG::focusFillBound -- Old mesh maxs = 48.914, 28.392, 34.489
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.230804
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.491770e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.678600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 065)
Vbuildops: Galer: (025, 017, 033)
Vbuildops: Galer: (013, 009, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.287400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.599575e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2900523.153861
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.643987e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.280277e+05
Vprtstp: contraction number = 3.280277e+05
Vnewton: Attempting damping, relres = 0.104456
Vnewton: Attempting damping, relres = 0.546698
Vnewton: Damping accepted, relres = 0.104456
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.044557e-01
Vprtstp: contraction number = 1.044557e-01
Vnewton: Using errtol_s: 302976.145317
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.724566e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.475780e+04
Vprtstp: contraction number = 5.475780e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.705171e-02
Vprtstp: contraction number = 1.632435e-01
Vnewton: Using errtol_s: 49458.874391
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.785358e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.085033e+04
Vprtstp: contraction number = 1.085033e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.367067e-03
Vprtstp: contraction number = 1.974622e-01
Vnewton: Using errtol_s: 9766.255886
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.845538e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.327783e+03
Vprtstp: contraction number = 2.327783e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.222905e-04
Vprtstp: contraction number = 2.145162e-01
Vnewton: Using errtol_s: 2095.020260
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.905496e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.237954e+02
Vprtstp: contraction number = 5.237954e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.625282e-04
Vprtstp: contraction number = 2.250178e-01
Vnewton: Using errtol_s: 471.416769
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.965628e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.220976e+02
Vprtstp: contraction number = 1.220976e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.788553e-05
Vprtstp: contraction number = 2.331013e-01
Vnewton: Using errtol_s: 109.887861
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.025657e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.936030e+01
Vprtstp: contraction number = 2.936030e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.110176e-06
Vprtstp: contraction number = 2.404658e-01
Vnewton: Using errtol_s: 26.424277
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.085326e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.262660e+00
Vprtstp: contraction number = 7.262660e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.253523e-06
Vprtstp: contraction number = 2.473632e-01
Vnewton: Using errtol_s: 6.536394
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.147818e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.845163e+00
Vprtstp: contraction number = 1.845163e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.725336e-07
Vprtstp: contraction number = 2.540616e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.946690e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.531940e-01
Vpmg_setPart:  lower corner = (-13.551, -33.367, -69.228)
Vpmg_setPart:  upper corner = (38.914, 18.392, 24.489)
Vpmg_setPart:  actual minima = (-13.551, -33.367, -69.228)
Vpmg_setPart:  actual maxima = (38.914, 18.392, 24.489)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.353153e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:30 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1988 atoms
Valist_getStatistics:  Max atom coordinate:  (28.914, 8.392, 14.489)
Valist_getStatistics:  Min atom coordinate:  (-3.551, -23.367, -59.228)
Valist_getStatistics:  Molecule center:  (12.6815, -7.4875, -22.3695)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.754844, 1.12123, 0.888414
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.54651, 0.808734, 0.732164
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.724005, 0.721289, 0.824125 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 48.914 28.392 34.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -23.551 -43.367 -79.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 38.914 18.392 24.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -13.551 -33.367 -69.228
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 38.914 18.392 24.489
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -13.551 -33.367 -69.228
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.231653
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.914090e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.682300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 065)
Vbuildops: Galer: (025, 017, 033)
Vbuildops: Galer: (013, 009, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.646700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.636450e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.899543e-02
Vprtstp: contraction number = 7.899543e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.266555e-02
Vprtstp: contraction number = 1.603326e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.604718e-03
Vprtstp: contraction number = 2.056538e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.049547e-04
Vprtstp: contraction number = 2.322534e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.503885e-04
Vprtstp: contraction number = 2.485946e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.893665e-05
Vprtstp: contraction number = 2.589071e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.054466e-05
Vprtstp: contraction number = 2.708159e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.923099e-06
Vprtstp: contraction number = 2.772112e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.449178e-07
Vprtstp: contraction number = 2.890486e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.418840e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.058630e-01
Vpmg_setPart:  lower corner = (-23.551, -43.367, -79.228)
Vpmg_setPart:  upper corner = (48.914, 28.392, 34.489)
Vpmg_setPart:  actual minima = (-23.551, -43.367, -79.228)
Vpmg_setPart:  actual maxima = (48.914, 28.392, 34.489)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -13.551, -33.367, -69.228
VPMG::focusFillBound -- New mesh maxs = 38.914, 18.392, 24.489
VPMG::focusFillBound -- Old mesh mins = -23.551, -43.367, -79.228
VPMG::focusFillBound -- Old mesh maxs = 48.914, 28.392, 34.489
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.230564
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.523750e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.691000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 065)
Vbuildops: Galer: (025, 017, 033)
Vbuildops: Galer: (013, 009, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.595800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.223097e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.050703e-01
Vprtstp: contraction number = 1.050703e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.726695e-02
Vprtstp: contraction number = 1.643371e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.404630e-03
Vprtstp: contraction number = 1.971761e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.337804e-04
Vprtstp: contraction number = 2.155243e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.652994e-04
Vprtstp: contraction number = 2.252709e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.899916e-05
Vprtstp: contraction number = 2.359304e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.416837e-06
Vprtstp: contraction number = 2.414625e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.362900e-06
Vprtstp: contraction number = 2.509229e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.008800e-07
Vprtstp: contraction number = 2.542977e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.461040e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.091940e-01
Vpmg_setPart:  lower corner = (-13.551, -33.367, -69.228)
Vpmg_setPart:  upper corner = (38.914, 18.392, 24.489)
Vpmg_setPart:  actual minima = (-13.551, -33.367, -69.228)
Vpmg_setPart:  actual maxima = (38.914, 18.392, 24.489)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.634307e+00
