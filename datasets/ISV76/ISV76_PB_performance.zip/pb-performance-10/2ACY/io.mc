##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1563 atoms
Valist_getStatistics:  Max atom coordinate:  (32.283, 8.323, 33.714)
Valist_getStatistics:  Min atom coordinate:  (0.26, -22.512, -11.34)
Valist_getStatistics:  Molecule center:  (16.2715, -7.0945, 11.187)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.75024, 1.1068, 0.885979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.541906, 0.794297, 0.677646
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.722311, 0.717654, 0.764855 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 52.283 28.323 53.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.74 -42.512 -31.34
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 42.283 18.323 43.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -9.74 -32.512 -21.34
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 42.283 18.323 43.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -9.74 -32.512 -21.34
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.186890
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.112660e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.313300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.553000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.642900e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1712607.183759
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.988290e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.333005e+05
Vprtstp: contraction number = 1.333005e+05
Vnewton: Attempting damping, relres = 0.082357
Vnewton: Attempting damping, relres = 0.528822
Vnewton: Damping accepted, relres = 0.082357
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.235679e-02
Vprtstp: contraction number = 8.235679e-02
Vnewton: Using errtol_s: 141044.821754
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.618340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.239910e+04
Vprtstp: contraction number = 2.239910e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.451021e-02
Vprtstp: contraction number = 1.761872e-01
Vnewton: Using errtol_s: 24850.288613
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.075060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.121033e+03
Vprtstp: contraction number = 5.121033e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.353138e-03
Vprtstp: contraction number = 2.310882e-01
Vnewton: Using errtol_s: 5742.608951
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.523930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.337500e+03
Vprtstp: contraction number = 1.337500e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.303738e-04
Vprtstp: contraction number = 2.476408e-01
Vnewton: Using errtol_s: 1422.104123
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.966300e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.595991e+02
Vprtstp: contraction number = 3.595991e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.012918e-04
Vprtstp: contraction number = 2.424111e-01
Vnewton: Using errtol_s: 344.733788
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.413510e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.095889e+01
Vprtstp: contraction number = 9.095889e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.812493e-05
Vprtstp: contraction number = 2.390804e-01
Vnewton: Using errtol_s: 82.419098
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.863890e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.207078e+01
Vprtstp: contraction number = 2.207078e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.160378e-05
Vprtstp: contraction number = 2.411179e-01
Vnewton: Using errtol_s: 19.872717
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.318310e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.400497e+00
Vprtstp: contraction number = 5.400497e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.838151e-06
Vprtstp: contraction number = 2.445885e-01
Vnewton: Using errtol_s: 4.860638
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.798000e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.339990e+00
Vprtstp: contraction number = 1.339990e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.041877e-07
Vprtstp: contraction number = 2.481150e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.519300e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.974850e-01
Vpmg_setPart:  lower corner = (-19.74, -42.512, -31.34)
Vpmg_setPart:  upper corner = (52.283, 28.323, 53.714)
Vpmg_setPart:  actual minima = (-19.74, -42.512, -31.34)
Vpmg_setPart:  actual maxima = (52.283, 28.323, 53.714)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -9.74, -32.512, -21.34
VPMG::focusFillBound -- New mesh maxs = 42.283, 18.323, 43.714
VPMG::focusFillBound -- Old mesh mins = -19.74, -42.512, -31.34
VPMG::focusFillBound -- Old mesh maxs = 52.283, 28.323, 53.714
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.186417
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.597730e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.278000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.572300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.222620e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2226427.446157
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.257402e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.549329e+05
Vprtstp: contraction number = 2.549329e+05
Vnewton: Attempting damping, relres = 0.109751
Vnewton: Attempting damping, relres = 0.547357
Vnewton: Damping accepted, relres = 0.109751
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.097507e-01
Vprtstp: contraction number = 1.097507e-01
Vnewton: Using errtol_s: 244352.063076
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.320862e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.287528e+04
Vprtstp: contraction number = 4.287528e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.851801e-02
Vprtstp: contraction number = 1.687279e-01
Vnewton: Using errtol_s: 41228.999284
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.366155e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.736445e+03
Vprtstp: contraction number = 8.736445e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.751951e-03
Vprtstp: contraction number = 2.026109e-01
Vnewton: Using errtol_s: 8353.446421
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.410666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.905914e+03
Vprtstp: contraction number = 1.905914e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.933379e-04
Vprtstp: contraction number = 2.114468e-01
Vnewton: Using errtol_s: 1766.309372
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.455907e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.203317e+02
Vprtstp: contraction number = 4.203317e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.703059e-04
Vprtstp: contraction number = 2.146701e-01
Vnewton: Using errtol_s: 379.173816
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.500570e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.425822e+01
Vprtstp: contraction number = 9.425822e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.810399e-05
Vprtstp: contraction number = 2.237385e-01
Vnewton: Using errtol_s: 84.835775
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.546676e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.176439e+01
Vprtstp: contraction number = 2.176439e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.797944e-06
Vprtstp: contraction number = 2.308930e-01
Vnewton: Using errtol_s: 19.587985
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.594100e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.163072e+00
Vprtstp: contraction number = 5.163072e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.087095e-06
Vprtstp: contraction number = 2.372253e-01
Vnewton: Using errtol_s: 4.646765
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.642454e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.252354e+00
Vprtstp: contraction number = 1.252354e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.062455e-07
Vprtstp: contraction number = 2.425599e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.564180e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.015340e-01
Vpmg_setPart:  lower corner = (-9.74, -32.512, -21.34)
Vpmg_setPart:  upper corner = (42.283, 18.323, 43.714)
Vpmg_setPart:  actual minima = (-9.74, -32.512, -21.34)
Vpmg_setPart:  actual maxima = (42.283, 18.323, 43.714)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.803134e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:26 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1563 atoms
Valist_getStatistics:  Max atom coordinate:  (32.283, 8.323, 33.714)
Valist_getStatistics:  Min atom coordinate:  (0.26, -22.512, -11.34)
Valist_getStatistics:  Molecule center:  (16.2715, -7.0945, 11.187)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.75024, 1.1068, 0.885979
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.541906, 0.794297, 0.677646
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.722311, 0.717654, 0.764855 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 52.283 28.323 53.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.74 -42.512 -31.34
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 42.283 18.323 43.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -9.74 -32.512 -21.34
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 42.283 18.323 43.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -9.74 -32.512 -21.34
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.187295
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.128360e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.264300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.861900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.694560e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.559610e-02
Vprtstp: contraction number = 7.559610e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.174032e-02
Vprtstp: contraction number = 1.553033e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.430468e-03
Vprtstp: contraction number = 2.070189e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.539677e-04
Vprtstp: contraction number = 2.279263e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.314897e-04
Vprtstp: contraction number = 2.373599e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.246120e-05
Vprtstp: contraction number = 2.468726e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.007166e-06
Vprtstp: contraction number = 2.466688e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.033059e-06
Vprtstp: contraction number = 2.539049e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.131408e-07
Vprtstp: contraction number = 2.523984e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.814510e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.305010e-01
Vpmg_setPart:  lower corner = (-19.74, -42.512, -31.34)
Vpmg_setPart:  upper corner = (52.283, 28.323, 53.714)
Vpmg_setPart:  actual minima = (-19.74, -42.512, -31.34)
Vpmg_setPart:  actual maxima = (52.283, 28.323, 53.714)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -9.74, -32.512, -21.34
VPMG::focusFillBound -- New mesh maxs = 42.283, 18.323, 43.714
VPMG::focusFillBound -- Old mesh mins = -19.74, -42.512, -31.34
VPMG::focusFillBound -- Old mesh maxs = 52.283, 28.323, 53.714
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.184292
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.584450e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.272900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.777800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.589690e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.066919e-01
Vprtstp: contraction number = 1.066919e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.746800e-02
Vprtstp: contraction number = 1.637238e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.506242e-03
Vprtstp: contraction number = 2.007237e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.657022e-04
Vprtstp: contraction number = 2.183826e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.749992e-04
Vprtstp: contraction number = 2.285474e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.062129e-05
Vprtstp: contraction number = 2.321227e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.919039e-06
Vprtstp: contraction number = 2.441832e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.398228e-06
Vprtstp: contraction number = 2.417803e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.195033e-07
Vprtstp: contraction number = 2.583171e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.817600e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.297910e-01
Vpmg_setPart:  lower corner = (-9.74, -32.512, -21.34)
Vpmg_setPart:  upper corner = (42.283, 18.323, 43.714)
Vpmg_setPart:  actual minima = (-9.74, -32.512, -21.34)
Vpmg_setPart:  actual maxima = (42.283, 18.323, 43.714)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.265274e+00
