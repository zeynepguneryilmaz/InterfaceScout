##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:04 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1947 atoms
Valist_getStatistics:  Max atom coordinate:  (23.486, 41.445, 31.151)
Valist_getStatistics:  Min atom coordinate:  (-14.168, -3.2, -10.683)
Valist_getStatistics:  Molecule center:  (4.659, 19.1225, 10.234)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.808896, 0.881719, 0.852438
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.600562, 0.673385, 0.644104
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.742447, 0.763719, 0.755603 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 43.486 61.445 51.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.168 -23.2 -30.683
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 33.486 51.445 41.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -24.168 -13.2 -20.683
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 33.486 51.445 41.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -24.168 -13.2 -20.683
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5546
Vpbe_ctor2:  solute dimensions = 40.01 x 47.057 x 43.903
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (50.434, 57.425, 54.614)
Vclist_setupGrid:  Grid lower corner = (-20.558, -9.59, -17.073)
Vclist_assignAtoms:  Have 4464331 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.231502
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.006840e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.854300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.129200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.794140e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.907778e-02
Vprtstp: contraction number = 6.907778e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.266234e-03
Vprtstp: contraction number = 1.196656e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.404455e-03
Vprtstp: contraction number = 1.699027e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.419228e-04
Vprtstp: contraction number = 1.722538e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.033222e-05
Vprtstp: contraction number = 2.080508e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.438451e-06
Vprtstp: contraction number = 1.875230e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.097497e-06
Vprtstp: contraction number = 2.222289e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.400994e-07
Vprtstp: contraction number = 2.098213e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.427770e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.131810e-01
Vpmg_setPart:  lower corner = (-34.168, -23.2, -30.683)
Vpmg_setPart:  upper corner = (43.486, 61.445, 51.151)
Vpmg_setPart:  actual minima = (-34.168, -23.2, -30.683)
Vpmg_setPart:  actual maxima = (43.486, 61.445, 51.151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5546
Vpbe_ctor2:  solute dimensions = 40.01 x 47.057 x 43.903
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (50.434, 57.425, 54.614)
Vclist_setupGrid:  Grid lower corner = (-20.558, -9.59, -17.073)
Vclist_assignAtoms:  Have 4464331 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -24.168, -13.2, -20.683
VPMG::focusFillBound -- New mesh maxs = 33.486, 51.445, 41.151
VPMG::focusFillBound -- Old mesh mins = -34.168, -23.2, -30.683
VPMG::focusFillBound -- Old mesh maxs = 43.486, 61.445, 51.151
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.232408
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.622810e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.835700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.046800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.256536e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.820749e-02
Vprtstp: contraction number = 9.820749e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.309909e-02
Vprtstp: contraction number = 1.333818e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.257173e-03
Vprtstp: contraction number = 1.723153e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.461402e-04
Vprtstp: contraction number = 1.976544e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.124577e-04
Vprtstp: contraction number = 2.520680e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.903280e-05
Vprtstp: contraction number = 2.581664e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.947663e-06
Vprtstp: contraction number = 3.081916e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.602765e-06
Vprtstp: contraction number = 2.908877e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.765599e-07
Vprtstp: contraction number = 3.367802e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.705940e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.403430e-01
Vpmg_setPart:  lower corner = (-24.168, -13.2, -20.683)
Vpmg_setPart:  upper corner = (33.486, 51.445, 41.151)
Vpmg_setPart:  actual minima = (-24.168, -13.2, -20.683)
Vpmg_setPart:  actual maxima = (33.486, 51.445, 41.151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.713056e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:06 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1947 atoms
Valist_getStatistics:  Max atom coordinate:  (23.486, 41.445, 31.151)
Valist_getStatistics:  Min atom coordinate:  (-14.168, -3.2, -10.683)
Valist_getStatistics:  Molecule center:  (4.659, 19.1225, 10.234)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.808896, 0.881719, 0.852438
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.600562, 0.673385, 0.644104
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.742447, 0.763719, 0.755603 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.659 19.1225 10.234
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 43.486 61.445 51.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.168 -23.2 -30.683
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 33.486 51.445 41.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -24.168 -13.2 -20.683
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 33.486 51.445 41.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -24.168 -13.2 -20.683
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5546
Vpbe_ctor2:  solute dimensions = 40.01 x 47.057 x 43.903
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (50.434, 57.425, 54.614)
Vclist_setupGrid:  Grid lower corner = (-20.558, -9.59, -17.073)
Vclist_assignAtoms:  Have 4464331 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.232829
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.014970e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.844100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.819000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.756230e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2243943.595569
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.258440e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.550523e+05
Vprtstp: contraction number = 1.550523e+05
Vnewton: Attempting damping, relres = 0.063552
Vnewton: Attempting damping, relres = 0.525994
Vnewton: Damping accepted, relres = 0.063552
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.355205e-02
Vprtstp: contraction number = 6.355205e-02
Vnewton: Using errtol_s: 142607.214622
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.164930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.945279e+04
Vprtstp: contraction number = 1.945279e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.823809e-03
Vprtstp: contraction number = 1.231087e-01
Vnewton: Using errtol_s: 17556.186960
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.849240e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.925348e+03
Vprtstp: contraction number = 2.925348e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.173522e-03
Vprtstp: contraction number = 1.499937e-01
Vnewton: Using errtol_s: 2633.316618
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.540210e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.907272e+02
Vprtstp: contraction number = 4.907272e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.968238e-04
Vprtstp: contraction number = 1.677206e-01
Vnewton: Using errtol_s: 441.661512
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.232180e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.837967e+01
Vprtstp: contraction number = 8.837967e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.544736e-05
Vprtstp: contraction number = 1.800969e-01
Vnewton: Using errtol_s: 79.541878
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.929860e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.689616e+01
Vprtstp: contraction number = 1.689616e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.776706e-06
Vprtstp: contraction number = 1.911766e-01
Vnewton: Using errtol_s: 15.206545
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.653110e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.458398e+00
Vprtstp: contraction number = 3.458398e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.387093e-06
Vprtstp: contraction number = 2.046854e-01
Vnewton: Using errtol_s: 3.112558
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.035682e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.757869e-01
Vprtstp: contraction number = 7.757869e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.111523e-07
Vprtstp: contraction number = 2.243197e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.117330e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.776940e-01
Vpmg_setPart:  lower corner = (-34.168, -23.2, -30.683)
Vpmg_setPart:  upper corner = (43.486, 61.445, 51.151)
Vpmg_setPart:  actual minima = (-34.168, -23.2, -30.683)
Vpmg_setPart:  actual maxima = (43.486, 61.445, 51.151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5546
Vpbe_ctor2:  solute dimensions = 40.01 x 47.057 x 43.903
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (50.434, 57.425, 54.614)
Vclist_setupGrid:  Grid lower corner = (-20.558, -9.59, -17.073)
Vclist_assignAtoms:  Have 4464331 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -24.168, -13.2, -20.683
VPMG::focusFillBound -- New mesh maxs = 33.486, 51.445, 41.151
VPMG::focusFillBound -- Old mesh mins = -34.168, -23.2, -30.683
VPMG::focusFillBound -- Old mesh maxs = 43.486, 61.445, 51.151
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.232953
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.613030e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.860300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.726200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.616516e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2774796.066892
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.667035e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.897356e+05
Vprtstp: contraction number = 2.897356e+05
Vnewton: Attempting damping, relres = 0.094951
Vnewton: Attempting damping, relres = 0.543759
Vnewton: Damping accepted, relres = 0.094951
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.495057e-02
Vprtstp: contraction number = 9.495057e-02
Vnewton: Using errtol_s: 263468.477602
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.759802e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.877050e+04
Vprtstp: contraction number = 3.877050e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.258949e-02
Vprtstp: contraction number = 1.325900e-01
Vnewton: Using errtol_s: 34933.277297
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.830401e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.061954e+03
Vprtstp: contraction number = 6.061954e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.966258e-03
Vprtstp: contraction number = 1.561824e-01
Vnewton: Using errtol_s: 5455.964138
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.898917e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.043779e+03
Vprtstp: contraction number = 1.043779e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.385492e-04
Vprtstp: contraction number = 1.721795e-01
Vnewton: Using errtol_s: 939.404998
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.966607e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.911812e+02
Vprtstp: contraction number = 1.911812e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.200931e-05
Vprtstp: contraction number = 1.831619e-01
Vnewton: Using errtol_s: 172.063181
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.034902e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.613773e+01
Vprtstp: contraction number = 3.613773e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.172121e-05
Vprtstp: contraction number = 1.890234e-01
Vnewton: Using errtol_s: 32.523965
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.105078e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.001827e+00
Vprtstp: contraction number = 7.001827e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.271030e-06
Vprtstp: contraction number = 1.937539e-01
Vnewton: Using errtol_s: 6.301645
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.175466e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.453655e+00
Vprtstp: contraction number = 1.453655e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.714903e-07
Vprtstp: contraction number = 2.076108e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.099890e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.755650e-01
Vpmg_setPart:  lower corner = (-24.168, -13.2, -20.683)
Vpmg_setPart:  upper corner = (33.486, 51.445, 41.151)
Vpmg_setPart:  actual minima = (-24.168, -13.2, -20.683)
Vpmg_setPart:  actual maxima = (33.486, 51.445, 41.151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.409604e+00
