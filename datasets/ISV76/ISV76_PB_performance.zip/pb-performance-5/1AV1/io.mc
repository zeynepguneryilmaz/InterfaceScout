##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:58 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 193, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13204 atoms
Valist_getStatistics:  Max atom coordinate:  (96.299, 79.336, 79.835)
Valist_getStatistics:  Min atom coordinate:  (-15.857, -37.771, -28.399)
Valist_getStatistics:  Molecule center:  (40.221, 20.7825, 25.718)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.792479, 0.818266, 0.926463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.688312, 0.714099, 0.801463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.868556, 0.872698, 0.865078 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 116.299 99.336 99.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -35.857 -57.771 -48.399
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 106.299 89.336 89.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -25.857 -47.771 -38.399
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 106.299 89.336 89.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -25.857 -47.771 -38.399
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.024396
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.895984e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.227500e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 081)
Vbuildops: Galer: (049, 049, 041)
Vbuildops: Galer: (025, 025, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.145780e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.428969e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 15973624.372893
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.773238e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.154344e+06
Vprtstp: contraction number = 1.154344e+06
Vnewton: Attempting damping, relres = 0.070387
Vnewton: Attempting damping, relres = 0.527321
Vnewton: Damping accepted, relres = 0.070387
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.038709e-02
Vprtstp: contraction number = 7.038709e-02
Vnewton: Using errtol_s: 1124336.907878
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.565825e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.638338e+05
Vprtstp: contraction number = 1.638338e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.063625e-02
Vprtstp: contraction number = 1.511108e-01
Vnewton: Using errtol_s: 169899.450048
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.190123e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.844098e+04
Vprtstp: contraction number = 2.844098e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.051511e-03
Vprtstp: contraction number = 1.928791e-01
Vnewton: Using errtol_s: 32770.059603
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.815455e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.613639e+03
Vprtstp: contraction number = 5.613639e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.364281e-04
Vprtstp: contraction number = 2.127350e-01
Vnewton: Using errtol_s: 6971.339136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.440248e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.288810e+03
Vprtstp: contraction number = 1.288810e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.067306e-05
Vprtstp: contraction number = 2.077617e-01
Vnewton: Using errtol_s: 1448.377438
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.064127e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.873713e+02
Vprtstp: contraction number = 3.873713e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.248118e-05
Vprtstp: contraction number = 2.479367e-01
Vnewton: Using errtol_s: 359.105977
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.686554e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.508875e+02
Vprtstp: contraction number = 1.508875e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.503806e-06
Vprtstp: contraction number = 3.782633e-01
Vnewton: Using errtol_s: 135.836610
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.308321e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.412376e+01
Vprtstp: contraction number = 6.412376e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.612991e-06
Vprtstp: contraction number = 4.248675e-01
Vnewton: Using errtol_s: 57.712564
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.931352e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.025596e+01
Vprtstp: contraction number = 3.025596e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.704732e-06
Vprtstp: contraction number = 4.718339e-01
Vnewton: Using errtol_s: 27.230742
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.555005e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.327052e+01
Vprtstp: contraction number = 1.327052e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.477015e-07
Vprtstp: contraction number = 4.386036e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.611745e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.112364e+00
Vpmg_setPart:  lower corner = (-35.857, -57.771, -48.399)
Vpmg_setPart:  upper corner = (116.299, 99.336, 99.835)
Vpmg_setPart:  actual minima = (-35.857, -57.771, -48.399)
Vpmg_setPart:  actual maxima = (116.299, 99.336, 99.835)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -25.857, -47.771, -38.399
VPMG::focusFillBound -- New mesh maxs = 106.299, 89.336, 89.835
VPMG::focusFillBound -- Old mesh mins = -35.857, -57.771, -48.399
VPMG::focusFillBound -- Old mesh maxs = 116.299, 99.336, 99.835
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.019839
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.072742e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.230150e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 081)
Vbuildops: Galer: (049, 049, 041)
Vbuildops: Galer: (025, 025, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.119790e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.363207e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 17799289.456383
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.397662e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.534281e+06
Vprtstp: contraction number = 1.534281e+06
Vnewton: Attempting damping, relres = 0.082859
Vnewton: Attempting damping, relres = 0.534459
Vnewton: Damping accepted, relres = 0.082859
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.285915e-02
Vprtstp: contraction number = 8.285915e-02
Vnewton: Using errtol_s: 1474833.909085
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.477865e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.195306e+05
Vprtstp: contraction number = 2.195306e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.256253e-02
Vprtstp: contraction number = 1.516131e-01
Vnewton: Using errtol_s: 223604.157551
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.541254e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.717488e+04
Vprtstp: contraction number = 3.717488e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.360002e-03
Vprtstp: contraction number = 1.878604e-01
Vnewton: Using errtol_s: 42006.365839
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.604373e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.046940e+03
Vprtstp: contraction number = 7.046940e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.886914e-04
Vprtstp: contraction number = 2.070724e-01
Vnewton: Using errtol_s: 8698.359540
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.667271e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.768139e+03
Vprtstp: contraction number = 1.768139e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.111440e-04
Vprtstp: contraction number = 2.274319e-01
Vnewton: Using errtol_s: 1978.284242
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.730260e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.591330e+02
Vprtstp: contraction number = 6.591330e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.465590e-05
Vprtstp: contraction number = 3.118108e-01
Vnewton: Using errtol_s: 616.850441
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.793266e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.020615e+02
Vprtstp: contraction number = 3.020615e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.533057e-05
Vprtstp: contraction number = 4.423653e-01
Vnewton: Using errtol_s: 272.873239
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.856138e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.464650e+02
Vprtstp: contraction number = 1.464650e+02
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.413127e-06
Vprtstp: contraction number = 4.835520e-01
Vnewton: Using errtol_s: 131.948394
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.919002e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.449697e+01
Vprtstp: contraction number = 7.449697e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.768658e-06
Vprtstp: contraction number = 5.083763e-01
Vnewton: Using errtol_s: 67.079431
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.982626e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.864594e+01
Vprtstp: contraction number = 3.864594e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.954547e-06
Vprtstp: contraction number = 5.186320e-01
Vnewton: Using errtol_s: 34.789542
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.046895e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.051952e+01
Vprtstp: contraction number = 2.051952e+01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.037659e-06
Vprtstp: contraction number = 5.308951e-01
Vnewton: Using errtol_s: 18.469597
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.110768e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.104622e+01
Vprtstp: contraction number = 1.104622e+01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.585657e-07
Vprtstp: contraction number = 5.382940e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.975931e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.474653e+00
Vpmg_setPart:  lower corner = (-25.857, -47.771, -38.399)
Vpmg_setPart:  upper corner = (106.299, 89.336, 89.835)
Vpmg_setPart:  actual minima = (-25.857, -47.771, -38.399)
Vpmg_setPart:  actual maxima = (106.299, 89.336, 89.835)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.287365e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:21 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 193, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13204 atoms
Valist_getStatistics:  Max atom coordinate:  (96.299, 79.336, 79.835)
Valist_getStatistics:  Min atom coordinate:  (-15.857, -37.771, -28.399)
Valist_getStatistics:  Molecule center:  (40.221, 20.7825, 25.718)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.792479, 0.818266, 0.926463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.688312, 0.714099, 0.801463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.868556, 0.872698, 0.865078 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 116.299 99.336 99.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -35.857 -57.771 -48.399
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 106.299 89.336 89.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -25.857 -47.771 -38.399
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 106.299 89.336 89.835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -25.857 -47.771 -38.399
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.018548
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.891700e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.223450e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 081)
Vbuildops: Galer: (049, 049, 041)
Vbuildops: Galer: (025, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.920450e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.810523e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.635202e-02
Vprtstp: contraction number = 7.635202e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.427414e-02
Vprtstp: contraction number = 1.869517e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.945995e-03
Vprtstp: contraction number = 4.165572e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.312114e-03
Vprtstp: contraction number = 3.888523e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.259315e-03
Vprtstp: contraction number = 5.446594e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.003730e-04
Vprtstp: contraction number = 4.767458e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.221128e-04
Vprtstp: contraction number = 5.365212e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.627114e-04
Vprtstp: contraction number = 5.051378e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.498000e-05
Vprtstp: contraction number = 5.222745e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.423189e-05
Vprtstp: contraction number = 5.204977e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.271139e-05
Vprtstp: contraction number = 5.134618e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.203051e-05
Vprtstp: contraction number = 5.297125e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.115201e-06
Vprtstp: contraction number = 5.083079e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.274083e-06
Vprtstp: contraction number = 5.354008e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.654774e-06
Vprtstp: contraction number = 5.054160e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 8.918280e-07
Vprtstp: contraction number = 5.389424e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.403025e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.289546e+00
Vpmg_setPart:  lower corner = (-35.857, -57.771, -48.399)
Vpmg_setPart:  upper corner = (116.299, 99.336, 99.835)
Vpmg_setPart:  actual minima = (-35.857, -57.771, -48.399)
Vpmg_setPart:  actual maxima = (116.299, 99.336, 99.835)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -25.857, -47.771, -38.399
VPMG::focusFillBound -- New mesh maxs = 106.299, 89.336, 89.835
VPMG::focusFillBound -- Old mesh mins = -35.857, -57.771, -48.399
VPMG::focusFillBound -- Old mesh maxs = 116.299, 99.336, 99.835
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.011855
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.064731e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.227500e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 081)
Vbuildops: Galer: (049, 049, 041)
Vbuildops: Galer: (025, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.843390e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.318190e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.856123e-02
Vprtstp: contraction number = 8.856123e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.548885e-02
Vprtstp: contraction number = 1.748942e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.227590e-03
Vprtstp: contraction number = 4.020693e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.571793e-03
Vprtstp: contraction number = 4.129676e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.609169e-03
Vprtstp: contraction number = 6.256993e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.590478e-04
Vprtstp: contraction number = 5.338456e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.334001e-04
Vprtstp: contraction number = 6.209202e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.054574e-04
Vprtstp: contraction number = 5.726608e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.837616e-04
Vprtstp: contraction number = 6.015950e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.094314e-04
Vprtstp: contraction number = 5.955073e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.444409e-05
Vprtstp: contraction number = 5.888995e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.933614e-05
Vprtstp: contraction number = 6.103918e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.285140e-05
Vprtstp: contraction number = 5.809262e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.417720e-05
Vprtstp: contraction number = 6.204085e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 8.164877e-06
Vprtstp: contraction number = 5.759160e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 5.122038e-06
Vprtstp: contraction number = 6.273258e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.933560e-06
Vprtstp: contraction number = 5.727330e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.854721e-06
Vprtstp: contraction number = 6.322423e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.058443e-06
Vprtstp: contraction number = 5.706753e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 6.730246e-07
Vprtstp: contraction number = 6.358626e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.809637e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.692750e+00
Vpmg_setPart:  lower corner = (-25.857, -47.771, -38.399)
Vpmg_setPart:  upper corner = (106.299, 89.336, 89.835)
Vpmg_setPart:  actual minima = (-25.857, -47.771, -38.399)
Vpmg_setPart:  actual maxima = (106.299, 89.336, 89.835)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.126824e+01
