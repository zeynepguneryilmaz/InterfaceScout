##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:41 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3967 atoms
Valist_getStatistics:  Max atom coordinate:  (34.368, 40.014, 50.659)
Valist_getStatistics:  Min atom coordinate:  (-8.341, -6.715, 5.821)
Valist_getStatistics:  Molecule center:  (13.0135, 16.6495, 28.24)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.861552, 0.903427, 0.883729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.653219, 0.695094, 0.675396
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.758188, 0.769397, 0.764257 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.368 60.014 70.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -28.341 -26.715 -14.179
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.368 50.014 60.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -18.341 -16.715 -4.179
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.368 50.014 60.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -18.341 -16.715 -4.179
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7714453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.500292
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.166880e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.860100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.869100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.958240e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4543338.348811
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.449880e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.258427e+05
Vprtstp: contraction number = 2.258427e+05
Vnewton: Attempting damping, relres = 0.045479
Vnewton: Attempting damping, relres = 0.517594
Vnewton: Damping accepted, relres = 0.045479
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.547859e-02
Vprtstp: contraction number = 4.547859e-02
Vnewton: Using errtol_s: 206624.640117
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.455910e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.604378e+04
Vprtstp: contraction number = 2.604378e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.210497e-03
Vprtstp: contraction number = 1.145703e-01
Vnewton: Using errtol_s: 23673.052209
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.021633e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.759938e+03
Vprtstp: contraction number = 3.759938e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.473668e-04
Vprtstp: contraction number = 1.434348e-01
Vnewton: Using errtol_s: 3395.540452
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.098649e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.315370e+02
Vprtstp: contraction number = 6.315370e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.251208e-04
Vprtstp: contraction number = 1.674155e-01
Vnewton: Using errtol_s: 568.466101
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.175375e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.188611e+02
Vprtstp: contraction number = 1.188611e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.354539e-05
Vprtstp: contraction number = 1.881813e-01
Vnewton: Using errtol_s: 106.974689
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.253068e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.526211e+01
Vprtstp: contraction number = 2.526211e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.004227e-06
Vprtstp: contraction number = 2.125353e-01
Vnewton: Using errtol_s: 22.735898
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.331493e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.135580e+00
Vprtstp: contraction number = 6.135580e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.215411e-06
Vprtstp: contraction number = 2.428768e-01
Vnewton: Using errtol_s: 5.522022
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.408468e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.674130e+00
Vprtstp: contraction number = 1.674130e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.316321e-07
Vprtstp: contraction number = 2.728560e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.715890e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.381250e-01
Vpmg_setPart:  lower corner = (-28.341, -26.715, -14.179)
Vpmg_setPart:  upper corner = (54.368, 60.014, 70.659)
Vpmg_setPart:  actual minima = (-28.341, -26.715, -14.179)
Vpmg_setPart:  actual maxima = (54.368, 60.014, 70.659)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7714453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -18.341, -16.715, -4.179
VPMG::focusFillBound -- New mesh maxs = 44.368, 50.014, 60.659
VPMG::focusFillBound -- Old mesh mins = -28.341, -26.715, -14.179
VPMG::focusFillBound -- Old mesh maxs = 54.368, 60.014, 70.659
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.498537
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.961440e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.944500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.854900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.333368e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5697314.009211
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.383677e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.299424e+05
Vprtstp: contraction number = 4.299424e+05
Vnewton: Attempting damping, relres = 0.068435
Vnewton: Attempting damping, relres = 0.530807
Vnewton: Damping accepted, relres = 0.068435
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.843521e-02
Vprtstp: contraction number = 6.843521e-02
Vnewton: Using errtol_s: 389896.871503
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.485056e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.061534e+04
Vprtstp: contraction number = 5.061534e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.029543e-03
Vprtstp: contraction number = 1.173306e-01
Vnewton: Using errtol_s: 45746.825162
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.563003e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.106446e+03
Vprtstp: contraction number = 7.106446e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.123294e-03
Vprtstp: contraction number = 1.398952e-01
Vnewton: Using errtol_s: 6399.759874
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.639114e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.117142e+03
Vprtstp: contraction number = 1.117142e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.764765e-04
Vprtstp: contraction number = 1.571063e-01
Vnewton: Using errtol_s: 1005.442312
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.716513e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.941773e+02
Vprtstp: contraction number = 1.941773e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.067406e-05
Vprtstp: contraction number = 1.738138e-01
Vnewton: Using errtol_s: 174.759760
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.793079e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.909926e+01
Vprtstp: contraction number = 3.909926e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.176480e-06
Vprtstp: contraction number = 2.013584e-01
Vnewton: Using errtol_s: 35.189349
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.871231e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.611080e+00
Vprtstp: contraction number = 9.611080e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.518255e-06
Vprtstp: contraction number = 2.458123e-01
Vnewton: Using errtol_s: 8.649973
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.950760e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.746270e+00
Vprtstp: contraction number = 2.746270e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.338260e-07
Vprtstp: contraction number = 2.857400e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.774310e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.449180e-01
Vpmg_setPart:  lower corner = (-18.341, -16.715, -4.179)
Vpmg_setPart:  upper corner = (44.368, 50.014, 60.659)
Vpmg_setPart:  actual minima = (-18.341, -16.715, -4.179)
Vpmg_setPart:  actual maxima = (44.368, 50.014, 60.659)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.207816e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:45 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3967 atoms
Valist_getStatistics:  Max atom coordinate:  (34.368, 40.014, 50.659)
Valist_getStatistics:  Min atom coordinate:  (-8.341, -6.715, 5.821)
Valist_getStatistics:  Molecule center:  (13.0135, 16.6495, 28.24)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.861552, 0.903427, 0.883729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.653219, 0.695094, 0.675396
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.758188, 0.769397, 0.764257 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.368 60.014 70.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -28.341 -26.715 -14.179
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 44.368 50.014 60.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -18.341 -16.715 -4.179
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 44.368 50.014 60.659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -18.341 -16.715 -4.179
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7714453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.500700
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.171600e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.889100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.220900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.021910e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.723588e-02
Vprtstp: contraction number = 4.723588e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 5.301883e-03
Vprtstp: contraction number = 1.122427e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.028571e-04
Vprtstp: contraction number = 1.514287e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.569370e-04
Vprtstp: contraction number = 1.954732e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.817779e-05
Vprtstp: contraction number = 2.432682e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.141752e-05
Vprtstp: contraction number = 2.990620e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.405090e-06
Vprtstp: contraction number = 2.982336e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.169656e-06
Vprtstp: contraction number = 3.435024e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.640802e-07
Vprtstp: contraction number = 3.112711e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.974530e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.699920e-01
Vpmg_setPart:  lower corner = (-28.341, -26.715, -14.179)
Vpmg_setPart:  upper corner = (54.368, 60.014, 70.659)
Vpmg_setPart:  actual minima = (-28.341, -26.715, -14.179)
Vpmg_setPart:  actual maxima = (54.368, 60.014, 70.659)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7714453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -18.341, -16.715, -4.179
VPMG::focusFillBound -- New mesh maxs = 44.368, 50.014, 60.659
VPMG::focusFillBound -- Old mesh mins = -28.341, -26.715, -14.179
VPMG::focusFillBound -- Old mesh maxs = 54.368, 60.014, 70.659
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.502315
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.997070e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.998700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.158300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.974710e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.945664e-02
Vprtstp: contraction number = 6.945664e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.164197e-03
Vprtstp: contraction number = 1.175438e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.204577e-03
Vprtstp: contraction number = 1.475438e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.399020e-04
Vprtstp: contraction number = 1.991588e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.740119e-05
Vprtstp: contraction number = 2.809530e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.484105e-05
Vprtstp: contraction number = 3.685550e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.941989e-06
Vprtstp: contraction number = 3.599683e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.694191e-06
Vprtstp: contraction number = 4.131286e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.349520e-06
Vprtstp: contraction number = 3.653086e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.551461e-07
Vprtstp: contraction number = 4.113656e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.283200e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.013720e-01
Vpmg_setPart:  lower corner = (-18.341, -16.715, -4.179)
Vpmg_setPart:  upper corner = (44.368, 50.014, 60.659)
Vpmg_setPart:  actual minima = (-18.341, -16.715, -4.179)
Vpmg_setPart:  actual maxima = (44.368, 50.014, 60.659)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.497779e+00
