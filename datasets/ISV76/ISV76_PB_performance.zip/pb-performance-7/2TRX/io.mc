##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1653 atoms
Valist_getStatistics:  Max atom coordinate:  (47.533, 48.811, 16.711)
Valist_getStatistics:  Min atom coordinate:  (17.81, 13.783, -17.993)
Valist_getStatistics:  Molecule center:  (32.6715, 31.297, -0.641)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.08942, 0.781542, 0.778167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.776922, 0.573208, 0.569833
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.713151, 0.733433, 0.732277 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 67.533 68.811 36.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -2.19 -6.217 -37.993
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.533 58.811 26.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 7.81 3.783 -27.993
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.533 58.811 26.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 7.81 3.783 -27.993
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.206038
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.343420e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.293900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.596600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.886420e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.441663e-02
Vprtstp: contraction number = 7.441663e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.183077e-02
Vprtstp: contraction number = 1.589802e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.635064e-03
Vprtstp: contraction number = 2.227297e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.448427e-04
Vprtstp: contraction number = 2.447161e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.694437e-04
Vprtstp: contraction number = 2.627676e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.515124e-05
Vprtstp: contraction number = 2.664675e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.254801e-05
Vprtstp: contraction number = 2.779107e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.533166e-06
Vprtstp: contraction number = 2.815718e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.036400e-06
Vprtstp: contraction number = 2.933345e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.166257e-07
Vprtstp: contraction number = 3.055054e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.041260e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.506520e-01
Vpmg_setPart:  lower corner = (-2.19, -6.217, -37.993)
Vpmg_setPart:  upper corner = (67.533, 68.811, 36.711)
Vpmg_setPart:  actual minima = (-2.19, -6.217, -37.993)
Vpmg_setPart:  actual maxima = (67.533, 68.811, 36.711)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 7.81, 3.783, -27.993
VPMG::focusFillBound -- New mesh maxs = 57.533, 58.811, 26.711
VPMG::focusFillBound -- Old mesh mins = -2.19, -6.217, -37.993
VPMG::focusFillBound -- Old mesh maxs = 67.533, 68.811, 36.711
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.202317
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.879120e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.317800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.603300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.029021e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.095612e-01
Vprtstp: contraction number = 1.095612e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.814980e-02
Vprtstp: contraction number = 1.656591e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.771621e-03
Vprtstp: contraction number = 2.078051e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.665955e-04
Vprtstp: contraction number = 2.297674e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.154525e-04
Vprtstp: contraction number = 2.486194e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.683729e-05
Vprtstp: contraction number = 2.638043e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.748396e-05
Vprtstp: contraction number = 3.076142e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.620651e-06
Vprtstp: contraction number = 3.214747e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.043506e-06
Vprtstp: contraction number = 3.635711e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.482342e-07
Vprtstp: contraction number = 3.661522e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.052830e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.521300e-01
Vpmg_setPart:  lower corner = (7.81, 3.783, -27.993)
Vpmg_setPart:  upper corner = (57.533, 58.811, 26.711)
Vpmg_setPart:  actual minima = (7.81, 3.783, -27.993)
Vpmg_setPart:  actual maxima = (57.533, 58.811, 26.711)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.356683e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:40 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1653 atoms
Valist_getStatistics:  Max atom coordinate:  (47.533, 48.811, 16.711)
Valist_getStatistics:  Min atom coordinate:  (17.81, 13.783, -17.993)
Valist_getStatistics:  Molecule center:  (32.6715, 31.297, -0.641)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 1.08942, 0.781542, 0.778167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.776922, 0.573208, 0.569833
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.713151, 0.733433, 0.732277 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 67.533 68.811 36.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -2.19 -6.217 -37.993
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.533 58.811 26.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 7.81 3.783 -27.993
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.533 58.811 26.711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 7.81 3.783 -27.993
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.202920
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.298280e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.262500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.503800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.816940e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1817319.014913
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.153840e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.412322e+05
Vprtstp: contraction number = 1.412322e+05
Vnewton: Attempting damping, relres = 0.071189
Vnewton: Attempting damping, relres = 0.528748
Vnewton: Damping accepted, relres = 0.071189
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.118893e-02
Vprtstp: contraction number = 7.118893e-02
Vnewton: Using errtol_s: 129372.993153
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.819630e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.310743e+04
Vprtstp: contraction number = 2.310743e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.145149e-02
Vprtstp: contraction number = 1.608605e-01
Vnewton: Using errtol_s: 20811.010081
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.306270e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.050759e+03
Vprtstp: contraction number = 5.050759e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.501473e-03
Vprtstp: contraction number = 2.184408e-01
Vnewton: Using errtol_s: 4545.974078
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.781770e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.246578e+03
Vprtstp: contraction number = 1.246578e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.173585e-04
Vprtstp: contraction number = 2.467980e-01
Vnewton: Using errtol_s: 1121.937431
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.265860e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.249276e+02
Vprtstp: contraction number = 3.249276e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.609162e-04
Vprtstp: contraction number = 2.606527e-01
Vnewton: Using errtol_s: 292.436037
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.749630e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.765546e+01
Vprtstp: contraction number = 8.765546e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.341011e-05
Vprtstp: contraction number = 2.697684e-01
Vnewton: Using errtol_s: 78.890014
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.244720e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.429101e+01
Vprtstp: contraction number = 2.429101e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.202976e-05
Vprtstp: contraction number = 2.771189e-01
Vnewton: Using errtol_s: 21.861913
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.746060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.900272e+00
Vprtstp: contraction number = 6.900272e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.417257e-06
Vprtstp: contraction number = 2.840669e-01
Vnewton: Using errtol_s: 6.210245
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.242100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.005439e+00
Vprtstp: contraction number = 2.005439e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.931637e-07
Vprtstp: contraction number = 2.906319e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.803300e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.246540e-01
Vpmg_setPart:  lower corner = (-2.19, -6.217, -37.993)
Vpmg_setPart:  upper corner = (67.533, 68.811, 36.711)
Vpmg_setPart:  actual minima = (-2.19, -6.217, -37.993)
Vpmg_setPart:  actual maxima = (67.533, 68.811, 36.711)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 7.81, 3.783, -27.993
VPMG::focusFillBound -- New mesh maxs = 57.533, 58.811, 26.711
VPMG::focusFillBound -- Old mesh mins = -2.19, -6.217, -37.993
VPMG::focusFillBound -- Old mesh maxs = 67.533, 68.811, 36.711
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.203388
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.879280e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (065, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.297400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 049, 049)
Vbuildops: Galer: (017, 025, 025)
Vbuildops: Galer: (009, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.471700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.295881e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2357930.211446
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.331771e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.819868e+05
Vprtstp: contraction number = 2.819868e+05
Vnewton: Attempting damping, relres = 0.108489
Vnewton: Attempting damping, relres = 0.550033
Vnewton: Damping accepted, relres = 0.108489
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.084886e-01
Vprtstp: contraction number = 1.084886e-01
Vnewton: Using errtol_s: 255808.650630
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.395896e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.691835e+04
Vprtstp: contraction number = 4.691835e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.791277e-02
Vprtstp: contraction number = 1.651120e-01
Vnewton: Using errtol_s: 42237.069754
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.446156e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.613119e+03
Vprtstp: contraction number = 9.613119e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.669274e-03
Vprtstp: contraction number = 2.048412e-01
Vnewton: Using errtol_s: 8651.892661
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.498509e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.161299e+03
Vprtstp: contraction number = 2.161299e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.249497e-04
Vprtstp: contraction number = 2.248264e-01
Vnewton: Using errtol_s: 1945.173933
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.550048e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.085360e+02
Vprtstp: contraction number = 5.085360e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.941036e-04
Vprtstp: contraction number = 2.352914e-01
Vnewton: Using errtol_s: 457.682754
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.601000e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.229981e+02
Vprtstp: contraction number = 1.229981e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.694723e-05
Vprtstp: contraction number = 2.418669e-01
Vnewton: Using errtol_s: 110.698293
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.650807e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.033371e+01
Vprtstp: contraction number = 3.033371e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.157809e-05
Vprtstp: contraction number = 2.466193e-01
Vnewton: Using errtol_s: 27.300338
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.701092e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.367351e+00
Vprtstp: contraction number = 7.367351e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.812049e-06
Vprtstp: contraction number = 2.428767e-01
Vnewton: Using errtol_s: 6.630616
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.752666e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.844628e+00
Vprtstp: contraction number = 1.844628e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.040772e-07
Vprtstp: contraction number = 2.503787e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.943920e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.388260e-01
Vpmg_setPart:  lower corner = (7.81, 3.783, -27.993)
Vpmg_setPart:  upper corner = (57.533, 58.811, 26.711)
Vpmg_setPart:  actual minima = (7.81, 3.783, -27.993)
Vpmg_setPart:  actual maxima = (57.533, 58.811, 26.711)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.911762e+00
