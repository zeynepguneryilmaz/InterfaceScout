##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:44 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4626 atoms
Valist_getStatistics:  Max atom coordinate:  (17.127, 45.885, 40.672)
Valist_getStatistics:  Min atom coordinate:  (-36.074, -1.967, -12.37)
Valist_getStatistics:  Molecule center:  (-9.4735, 21.959, 14.151)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.970844, 0.915125, 0.969187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.76251, 0.706792, 0.760854
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.78541, 0.772344, 0.785043 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 37.127 65.885 60.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -56.074 -21.967 -32.37
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 27.127 55.885 50.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -46.074 -11.967 -22.37
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 27.127 55.885 50.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -46.074 -11.967 -22.37
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6905450 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.800934
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.077018e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.829000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.308500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.205119e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4597876.656885
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.272137e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.974615e+05
Vprtstp: contraction number = 1.974615e+05
Vnewton: Attempting damping, relres = 0.039301
Vnewton: Attempting damping, relres = 0.514228
Vnewton: Damping accepted, relres = 0.039301
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.930080e-02
Vprtstp: contraction number = 3.930080e-02
Vnewton: Using errtol_s: 180700.222562
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.393572e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.241794e+04
Vprtstp: contraction number = 2.241794e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.390513e-03
Vprtstp: contraction number = 1.117156e-01
Vnewton: Using errtol_s: 20187.035157
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.485195e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.148430e+03
Vprtstp: contraction number = 3.148430e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.163263e-04
Vprtstp: contraction number = 1.403768e-01
Vnewton: Using errtol_s: 2833.792220
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.577470e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.002683e+02
Vprtstp: contraction number = 5.002683e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.792556e-05
Vprtstp: contraction number = 1.588859e-01
Vnewton: Using errtol_s: 450.249636
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.671267e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.632366e+01
Vprtstp: contraction number = 8.632366e+01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.689727e-05
Vprtstp: contraction number = 1.725522e-01
Vnewton: Using errtol_s: 77.691557
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.763969e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.595474e+01
Vprtstp: contraction number = 1.595474e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.123023e-06
Vprtstp: contraction number = 1.848241e-01
Vnewton: Using errtol_s: 14.359276
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.856023e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.158667e+00
Vprtstp: contraction number = 3.158667e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.182856e-07
Vprtstp: contraction number = 1.979766e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.185270e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.229220e-01
Vpmg_setPart:  lower corner = (-56.074, -21.967, -32.37)
Vpmg_setPart:  upper corner = (37.127, 65.885, 60.672)
Vpmg_setPart:  actual minima = (-56.074, -21.967, -32.37)
Vpmg_setPart:  actual maxima = (37.127, 65.885, 60.672)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6905450 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -46.074, -11.967, -22.37
VPMG::focusFillBound -- New mesh maxs = 27.127, 55.885, 50.672
VPMG::focusFillBound -- Old mesh mins = -56.074, -21.967, -32.37
VPMG::focusFillBound -- Old mesh maxs = 37.127, 65.885, 60.672
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.795808
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.171901e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.928700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.540500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.208043e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5843176.710053
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.276370e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.661474e+05
Vprtstp: contraction number = 3.661474e+05
Vnewton: Attempting damping, relres = 0.056826
Vnewton: Attempting damping, relres = 0.524025
Vnewton: Damping accepted, relres = 0.056826
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.682553e-02
Vprtstp: contraction number = 5.682553e-02
Vnewton: Using errtol_s: 332041.616463
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.401572e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.282302e+04
Vprtstp: contraction number = 4.282302e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.597471e-03
Vprtstp: contraction number = 1.161005e-01
Vnewton: Using errtol_s: 38550.190705
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.496257e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.994950e+03
Vprtstp: contraction number = 5.994950e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.234246e-04
Vprtstp: contraction number = 1.399664e-01
Vnewton: Using errtol_s: 5395.733235
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.592512e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.470171e+02
Vprtstp: contraction number = 9.470171e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.458668e-04
Vprtstp: contraction number = 1.579629e-01
Vnewton: Using errtol_s: 852.325607
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.687586e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.659248e+02
Vprtstp: contraction number = 1.659248e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.555675e-05
Vprtstp: contraction number = 1.752060e-01
Vnewton: Using errtol_s: 149.332583
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.783049e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.217641e+01
Vprtstp: contraction number = 3.217641e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.955999e-06
Vprtstp: contraction number = 1.939213e-01
Vnewton: Using errtol_s: 28.958775
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.879853e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.889202e+00
Vprtstp: contraction number = 6.889202e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.061115e-06
Vprtstp: contraction number = 2.141072e-01
Vnewton: Using errtol_s: 6.200282
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.976419e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.613161e+00
Vprtstp: contraction number = 1.613161e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.484684e-07
Vprtstp: contraction number = 2.341579e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 8.381030e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.460240e-01
Vpmg_setPart:  lower corner = (-46.074, -11.967, -22.37)
Vpmg_setPart:  upper corner = (27.127, 55.885, 50.672)
Vpmg_setPart:  actual minima = (-46.074, -11.967, -22.37)
Vpmg_setPart:  actual maxima = (27.127, 55.885, 50.672)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.292443e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:49 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4626 atoms
Valist_getStatistics:  Max atom coordinate:  (17.127, 45.885, 40.672)
Valist_getStatistics:  Min atom coordinate:  (-36.074, -1.967, -12.37)
Valist_getStatistics:  Molecule center:  (-9.4735, 21.959, 14.151)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.970844, 0.915125, 0.969187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.76251, 0.706792, 0.760854
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.78541, 0.772344, 0.785043 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 37.127 65.885 60.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -56.074 -21.967 -32.37
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 27.127 55.885 50.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -46.074 -11.967 -22.37
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 27.127 55.885 50.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -46.074 -11.967 -22.37
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6905450 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.801590
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.084040e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.930600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.847300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.223341e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.117049e-02
Vprtstp: contraction number = 4.117049e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.623375e-03
Vprtstp: contraction number = 1.122983e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.690517e-04
Vprtstp: contraction number = 1.447106e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.080542e-04
Vprtstp: contraction number = 1.615036e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.889592e-05
Vprtstp: contraction number = 1.748744e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.601053e-06
Vprtstp: contraction number = 1.905731e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.102806e-07
Vprtstp: contraction number = 1.972425e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.749760e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.874130e-01
Vpmg_setPart:  lower corner = (-56.074, -21.967, -32.37)
Vpmg_setPart:  upper corner = (37.127, 65.885, 60.672)
Vpmg_setPart:  actual minima = (-56.074, -21.967, -32.37)
Vpmg_setPart:  actual maxima = (37.127, 65.885, 60.672)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6905450 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -46.074, -11.967, -22.37
VPMG::focusFillBound -- New mesh maxs = 27.127, 55.885, 50.672
VPMG::focusFillBound -- Old mesh mins = -56.074, -21.967, -32.37
VPMG::focusFillBound -- Old mesh maxs = 37.127, 65.885, 60.672
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.797165
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.177557e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.938900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.868700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.793059e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.812252e-02
Vprtstp: contraction number = 5.812252e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.841293e-03
Vprtstp: contraction number = 1.177047e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.911876e-04
Vprtstp: contraction number = 1.448831e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.654438e-04
Vprtstp: contraction number = 1.669147e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.428900e-05
Vprtstp: contraction number = 2.072547e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.793147e-06
Vprtstp: contraction number = 2.272783e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.181730e-06
Vprtstp: contraction number = 2.799549e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.480920e-07
Vprtstp: contraction number = 2.512190e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.123060e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.249410e-01
Vpmg_setPart:  lower corner = (-46.074, -11.967, -22.37)
Vpmg_setPart:  upper corner = (27.127, 55.885, 50.672)
Vpmg_setPart:  actual minima = (-46.074, -11.967, -22.37)
Vpmg_setPart:  actual maxima = (27.127, 55.885, 50.672)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.346015e+00
