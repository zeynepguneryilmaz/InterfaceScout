##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:52 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4321 atoms
Valist_getStatistics:  Max atom coordinate:  (-0.95, 50.347, 9.44)
Valist_getStatistics:  Min atom coordinate:  (-60.451, -13.516, -33.387)
Valist_getStatistics:  Molecule center:  (-30.7005, 18.4155, -11.9735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.777352, 0.81143, 0.862781
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.621102, 0.65518, 0.654448
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.798997, 0.807439, 0.758533 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 19.05 70.347 29.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -80.451 -33.516 -53.387
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 9.05 60.347 19.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -70.451 -23.516 -43.387
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 9.05 60.347 19.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -70.451 -23.516 -43.387
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5679564 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.739937
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.119726e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.055800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.349320e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.352348e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.964748e-02
Vprtstp: contraction number = 6.964748e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.205508e-03
Vprtstp: contraction number = 1.321729e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.517171e-03
Vprtstp: contraction number = 1.648112e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.065112e-04
Vprtstp: contraction number = 2.020281e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.885919e-05
Vprtstp: contraction number = 1.920295e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.474690e-05
Vprtstp: contraction number = 2.505454e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.013003e-06
Vprtstp: contraction number = 2.043143e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.419091e-07
Vprtstp: contraction number = 2.794253e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.732190e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.833270e-01
Vpmg_setPart:  lower corner = (-80.451, -33.516, -53.387)
Vpmg_setPart:  upper corner = (19.05, 70.347, 29.44)
Vpmg_setPart:  actual minima = (-80.451, -33.516, -53.387)
Vpmg_setPart:  actual maxima = (19.05, 70.347, 29.44)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5679564 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -70.451, -23.516, -43.387
VPMG::focusFillBound -- New mesh maxs = 9.05, 60.347, 19.44
VPMG::focusFillBound -- Old mesh mins = -80.451, -33.516, -53.387
VPMG::focusFillBound -- Old mesh maxs = 19.05, 70.347, 29.44
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.735814
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.266613e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.163200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.401680e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.417942e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.121089e-02
Vprtstp: contraction number = 9.121089e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.205105e-02
Vprtstp: contraction number = 1.321230e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.942695e-03
Vprtstp: contraction number = 1.612054e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.728984e-04
Vprtstp: contraction number = 1.919490e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.216331e-05
Vprtstp: contraction number = 2.203370e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.071568e-05
Vprtstp: contraction number = 2.521280e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.863131e-06
Vprtstp: contraction number = 2.830287e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.699937e-06
Vprtstp: contraction number = 2.899368e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.540803e-07
Vprtstp: contraction number = 3.259416e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.593670e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.766980e-01
Vpmg_setPart:  lower corner = (-70.451, -23.516, -43.387)
Vpmg_setPart:  upper corner = (9.05, 60.347, 19.44)
Vpmg_setPart:  actual minima = (-70.451, -23.516, -43.387)
Vpmg_setPart:  actual maxima = (9.05, 60.347, 19.44)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.477435e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4321 atoms
Valist_getStatistics:  Max atom coordinate:  (-0.95, 50.347, 9.44)
Valist_getStatistics:  Min atom coordinate:  (-60.451, -13.516, -33.387)
Valist_getStatistics:  Molecule center:  (-30.7005, 18.4155, -11.9735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.777352, 0.81143, 0.862781
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.621102, 0.65518, 0.654448
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.798997, 0.807439, 0.758533 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 19.05 70.347 29.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -80.451 -33.516 -53.387
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 9.05 60.347 19.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -70.451 -23.516 -43.387
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 9.05 60.347 19.44
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -70.451 -23.516 -43.387
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5679564 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.751000
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.137505e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.229400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.113940e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.347408e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5279658.623853
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.466053e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.669498e+05
Vprtstp: contraction number = 3.669498e+05
Vnewton: Attempting damping, relres = 0.067503
Vnewton: Attempting damping, relres = 0.526542
Vnewton: Damping accepted, relres = 0.067503
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.750265e-02
Vprtstp: contraction number = 6.750265e-02
Vnewton: Using errtol_s: 356390.932803
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.699262e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.760522e+04
Vprtstp: contraction number = 4.760522e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.141206e-03
Vprtstp: contraction number = 1.354200e-01
Vnewton: Using errtol_s: 48262.445179
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.864937e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.746747e+03
Vprtstp: contraction number = 7.746747e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.588784e-03
Vprtstp: contraction number = 1.738046e-01
Vnewton: Using errtol_s: 8388.236199
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.029931e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.459617e+03
Vprtstp: contraction number = 1.459617e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.992717e-04
Vprtstp: contraction number = 1.883653e-01
Vnewton: Using errtol_s: 1580.052583
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.197943e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.920771e+02
Vprtstp: contraction number = 2.920771e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.272703e-05
Vprtstp: contraction number = 1.761845e-01
Vnewton: Using errtol_s: 278.380743
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.365755e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.420223e+01
Vprtstp: contraction number = 5.420223e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.254080e-06
Vprtstp: contraction number = 1.755092e-01
Vnewton: Using errtol_s: 48.858384
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.533784e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.008331e+01
Vprtstp: contraction number = 1.008331e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.718883e-06
Vprtstp: contraction number = 1.857433e-01
Vnewton: Using errtol_s: 9.075116
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.704238e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.977401e+00
Vprtstp: contraction number = 1.977401e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.370788e-07
Vprtstp: contraction number = 1.961034e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.480296e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.667458e+00
Vpmg_setPart:  lower corner = (-80.451, -33.516, -53.387)
Vpmg_setPart:  upper corner = (19.05, 70.347, 29.44)
Vpmg_setPart:  actual minima = (-80.451, -33.516, -53.387)
Vpmg_setPart:  actual maxima = (19.05, 70.347, 29.44)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5679564 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -70.451, -23.516, -43.387
VPMG::focusFillBound -- New mesh maxs = 9.05, 60.347, 19.44
VPMG::focusFillBound -- Old mesh mins = -80.451, -33.516, -53.387
VPMG::focusFillBound -- Old mesh maxs = 19.05, 70.347, 29.44
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.739766
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.280777e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.190200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.112020e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.304223e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 6215808.623555
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.423691e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.991693e+05
Vprtstp: contraction number = 5.991693e+05
Vnewton: Attempting damping, relres = 0.091137
Vnewton: Attempting damping, relres = 0.540226
Vnewton: Damping accepted, relres = 0.091137
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.113744e-02
Vprtstp: contraction number = 9.113744e-02
Vnewton: Using errtol_s: 566492.891804
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.643850e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.915254e+04
Vprtstp: contraction number = 7.915254e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.241182e-02
Vprtstp: contraction number = 1.361879e-01
Vnewton: Using errtol_s: 77149.495812
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.810656e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.249495e+04
Vprtstp: contraction number = 1.249495e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.075482e-03
Vprtstp: contraction number = 1.672182e-01
Vnewton: Using errtol_s: 12900.796376
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.977114e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.256198e+03
Vprtstp: contraction number = 2.256198e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.780452e-04
Vprtstp: contraction number = 1.821482e-01
Vnewton: Using errtol_s: 2349.856319
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.145902e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.489934e+02
Vprtstp: contraction number = 4.489934e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.739724e-05
Vprtstp: contraction number = 1.782783e-01
Vnewton: Using errtol_s: 418.928365
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.312949e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.535780e+01
Vprtstp: contraction number = 8.535780e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.236314e-05
Vprtstp: contraction number = 1.834368e-01
Vnewton: Using errtol_s: 76.846893
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.481055e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.616176e+01
Vprtstp: contraction number = 1.616176e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.340100e-06
Vprtstp: contraction number = 1.892804e-01
Vnewton: Using errtol_s: 14.545614
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.649834e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.973267e+00
Vprtstp: contraction number = 2.973267e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.305056e-07
Vprtstp: contraction number = 1.839689e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.469605e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.656618e+00
Vpmg_setPart:  lower corner = (-70.451, -23.516, -43.387)
Vpmg_setPart:  upper corner = (9.05, 60.347, 19.44)
Vpmg_setPart:  actual minima = (-70.451, -23.516, -43.387)
Vpmg_setPart:  actual maxima = (9.05, 60.347, 19.44)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.188198e+00
