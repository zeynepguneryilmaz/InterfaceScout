##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3894 atoms
Valist_getStatistics:  Max atom coordinate:  (70.335, 49.103, 39.403)
Valist_getStatistics:  Min atom coordinate:  (24.289, 3.002, -14.503)
Valist_getStatistics:  Molecule center:  (47.312, 26.0525, 12.45)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.896313, 0.896885, 0.978188
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.687979, 0.688552, 0.769854
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.767566, 0.767715, 0.787021 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 90.335 69.103 59.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 4.289 -16.998 -34.503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 80.335 59.103 49.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 14.289 -6.998 -24.503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 80.335 59.103 49.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 14.289 -6.998 -24.503
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.681747
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.580910e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.920200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.938600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.092324e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.673980e-02
Vprtstp: contraction number = 5.673980e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.022836e-03
Vprtstp: contraction number = 1.237727e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.319351e-03
Vprtstp: contraction number = 1.878659e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.218371e-04
Vprtstp: contraction number = 1.681411e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.109435e-05
Vprtstp: contraction number = 2.303237e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.878856e-06
Vprtstp: contraction number = 1.933453e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.443336e-06
Vprtstp: contraction number = 2.473299e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.059466e-07
Vprtstp: contraction number = 2.070720e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.055830e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.186450e-01
Vpmg_setPart:  lower corner = (4.289, -16.998, -34.503)
Vpmg_setPart:  upper corner = (90.335, 69.103, 59.403)
Vpmg_setPart:  actual minima = (4.289, -16.998, -34.503)
Vpmg_setPart:  actual maxima = (90.335, 69.103, 59.403)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 14.289, -6.998, -24.503
VPMG::focusFillBound -- New mesh maxs = 80.335, 59.103, 49.403
VPMG::focusFillBound -- Old mesh mins = 4.289, -16.998, -34.503
VPMG::focusFillBound -- Old mesh maxs = 90.335, 69.103, 59.403
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.674965
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.068106e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.903800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.922300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.583447e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.335118e-02
Vprtstp: contraction number = 7.335118e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.496647e-03
Vprtstp: contraction number = 1.294682e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.628908e-03
Vprtstp: contraction number = 1.715245e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.163996e-04
Vprtstp: contraction number = 1.942404e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.410398e-05
Vprtstp: contraction number = 2.342101e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.658459e-05
Vprtstp: contraction number = 2.238016e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.362914e-06
Vprtstp: contraction number = 2.630704e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.014578e-06
Vprtstp: contraction number = 2.325460e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.778544e-07
Vprtstp: contraction number = 2.738620e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.504670e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.635330e-01
Vpmg_setPart:  lower corner = (14.289, -6.998, -24.503)
Vpmg_setPart:  upper corner = (80.335, 59.103, 49.403)
Vpmg_setPart:  actual minima = (14.289, -6.998, -24.503)
Vpmg_setPart:  actual maxima = (80.335, 59.103, 49.403)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.166655e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:06 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3894 atoms
Valist_getStatistics:  Max atom coordinate:  (70.335, 49.103, 39.403)
Valist_getStatistics:  Min atom coordinate:  (24.289, 3.002, -14.503)
Valist_getStatistics:  Molecule center:  (47.312, 26.0525, 12.45)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.896313, 0.896885, 0.978188
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.687979, 0.688552, 0.769854
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.767566, 0.767715, 0.787021 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 90.335 69.103 59.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 4.289 -16.998 -34.503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 80.335 59.103 49.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 14.289 -6.998 -24.503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 80.335 59.103 49.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 14.289 -6.998 -24.503
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.682944
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.638900e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.092900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.587300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.096093e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 4197736.482330
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.164729e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.235162e+05
Vprtstp: contraction number = 2.235162e+05
Vnewton: Attempting damping, relres = 0.879455
Vnewton: Attempting damping, relres = 0.523925
Vnewton: Attempting damping, relres = 0.759337
Vnewton: Damping accepted, relres = 0.523925
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.239254e-01
Vprtstp: contraction number = 5.239254e-01
Vnewton: Using errtol_s: 2199300.959990
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.313173e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.236662e+05
Vprtstp: contraction number = 1.236662e+05
Vnewton: Attempting damping, relres = 0.027419
Vnewton: Attempting damping, relres = 0.272897
Vnewton: Damping accepted, relres = 0.027419
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.741873e-02
Vprtstp: contraction number = 5.233326e-02
Vnewton: Using errtol_s: 115096.594781
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.433525e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.583252e+04
Vprtstp: contraction number = 1.583252e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.415025e-03
Vprtstp: contraction number = 1.245508e-01
Vnewton: Using errtol_s: 14335.373512
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.526111e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.491915e+03
Vprtstp: contraction number = 2.491915e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.344772e-04
Vprtstp: contraction number = 1.565076e-01
Vnewton: Using errtol_s: 2243.594301
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.619661e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.454217e+02
Vprtstp: contraction number = 4.454217e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.550204e-05
Vprtstp: contraction number = 1.786831e-01
Vnewton: Using errtol_s: 400.892408
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.711903e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.692080e+01
Vprtstp: contraction number = 8.692080e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.863609e-05
Vprtstp: contraction number = 1.951381e-01
Vnewton: Using errtol_s: 78.229374
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.804290e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.806113e+01
Vprtstp: contraction number = 1.806113e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.872336e-06
Vprtstp: contraction number = 2.077870e-01
Vnewton: Using errtol_s: 16.255046
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.897612e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.932756e+00
Vprtstp: contraction number = 3.932756e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.431882e-07
Vprtstp: contraction number = 2.177466e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 8.693620e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.801410e-01
Vpmg_setPart:  lower corner = (4.289, -16.998, -34.503)
Vpmg_setPart:  upper corner = (90.335, 69.103, 59.403)
Vpmg_setPart:  actual minima = (4.289, -16.998, -34.503)
Vpmg_setPart:  actual maxima = (90.335, 69.103, 59.403)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 14.289, -6.998, -24.503
VPMG::focusFillBound -- New mesh maxs = 80.335, 59.103, 49.403
VPMG::focusFillBound -- Old mesh mins = 4.289, -16.998, -34.503
VPMG::focusFillBound -- Old mesh maxs = 90.335, 69.103, 59.403
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.678045
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.077747e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.035900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.547300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.157262e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 5354107.949111
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.227064e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.124342e+05
Vprtstp: contraction number = 4.124342e+05
Vnewton: Attempting damping, relres = 0.609010
Vnewton: Attempting damping, relres = 0.534760
Vnewton: Attempting damping, relres = 0.765367
Vnewton: Damping accepted, relres = 0.534760
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.347603e-01
Vprtstp: contraction number = 5.347603e-01
Vnewton: Using errtol_s: 2863164.299233
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.377868e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.305342e+05
Vprtstp: contraction number = 2.305342e+05
Vnewton: Attempting damping, relres = 0.039348
Vnewton: Attempting damping, relres = 0.285188
Vnewton: Damping accepted, relres = 0.039348
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 3.934757e-02
Vprtstp: contraction number = 7.357983e-02
Vnewton: Using errtol_s: 210671.137816
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.497215e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.079547e+04
Vprtstp: contraction number = 3.079547e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.188407e-03
Vprtstp: contraction number = 1.318609e-01
Vnewton: Using errtol_s: 27779.289152
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.588616e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.977524e+03
Vprtstp: contraction number = 4.977524e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.367968e-04
Vprtstp: contraction number = 1.612820e-01
Vnewton: Using errtol_s: 4480.300658
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.683363e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.142407e+02
Vprtstp: contraction number = 9.142407e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.536807e-04
Vprtstp: contraction number = 1.836536e-01
Vnewton: Using errtol_s: 822.823268
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.777685e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.824497e+02
Vprtstp: contraction number = 1.824497e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.066897e-05
Vprtstp: contraction number = 1.995629e-01
Vnewton: Using errtol_s: 164.204996
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.871442e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.861269e+01
Vprtstp: contraction number = 3.861269e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.490611e-06
Vprtstp: contraction number = 2.116344e-01
Vnewton: Using errtol_s: 34.751432
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.964468e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.543862e+00
Vprtstp: contraction number = 8.543862e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.436183e-06
Vprtstp: contraction number = 2.212708e-01
Vnewton: Using errtol_s: 7.689477
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.056469e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.950077e+00
Vprtstp: contraction number = 1.950077e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.277987e-07
Vprtstp: contraction number = 2.282430e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.671600e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.076751e+00
Vpmg_setPart:  lower corner = (14.289, -6.998, -24.503)
Vpmg_setPart:  upper corner = (80.335, 59.103, 49.403)
Vpmg_setPart:  actual minima = (14.289, -6.998, -24.503)
Vpmg_setPart:  actual maxima = (80.335, 59.103, 49.403)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.362222e+00
