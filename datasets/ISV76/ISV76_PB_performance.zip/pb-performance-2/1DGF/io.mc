##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 31366 atoms
Valist_getStatistics:  Max atom coordinate:  (64.733, 91.652, 95.334)
Valist_getStatistics:  Min atom coordinate:  (-24.987, -6.35, -11.267)
Valist_getStatistics:  Molecule center:  (19.873, 42.651, 42.0335)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.81075, 0.862513, 0.916256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.68575, 0.737513, 0.791256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.845822, 0.855075, 0.863575 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 84.733 111.652 115.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -44.987 -26.35 -31.267
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 74.733 101.652 105.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -34.987 -16.35 -21.267
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 74.733 101.652 105.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -34.987 -16.35 -21.267
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13022674 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.501815
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.417037e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.032270e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.973530e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.034358e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.971586e-02
Vprtstp: contraction number = 4.971586e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.662567e-03
Vprtstp: contraction number = 1.943558e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.106141e-03
Vprtstp: contraction number = 3.214612e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.617318e-03
Vprtstp: contraction number = 5.206839e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.802734e-04
Vprtstp: contraction number = 5.442799e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.681608e-04
Vprtstp: contraction number = 6.454368e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.144085e-04
Vprtstp: contraction number = 5.533794e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.173645e-04
Vprtstp: contraction number = 6.913442e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.217924e-04
Vprtstp: contraction number = 5.603142e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.859005e-05
Vprtstp: contraction number = 7.273857e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.980238e-05
Vprtstp: contraction number = 5.621667e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.754983e-05
Vprtstp: contraction number = 7.539766e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.110818e-05
Vprtstp: contraction number = 5.621380e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.628939e-05
Vprtstp: contraction number = 7.717098e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 9.132635e-06
Vprtstp: contraction number = 5.606492e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 7.146097e-06
Vprtstp: contraction number = 7.824792e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 3.992415e-06
Vprtstp: contraction number = 5.586846e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.149700e-06
Vprtstp: contraction number = 7.889210e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.753594e-06
Vprtstp: contraction number = 5.567495e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.390936e-06
Vprtstp: contraction number = 7.931918e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 7.721811e-07
Vprtstp: contraction number = 5.551521e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.829978e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.378962e+00
Vpmg_setPart:  lower corner = (-44.987, -26.35, -31.267)
Vpmg_setPart:  upper corner = (84.733, 111.652, 115.334)
Vpmg_setPart:  actual minima = (-44.987, -26.35, -31.267)
Vpmg_setPart:  actual maxima = (84.733, 111.652, 115.334)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13022674 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -34.987, -16.35, -21.267
VPMG::focusFillBound -- New mesh maxs = 74.733, 101.652, 105.334
VPMG::focusFillBound -- Old mesh mins = -44.987, -26.35, -31.267
VPMG::focusFillBound -- Old mesh maxs = 84.733, 111.652, 115.334
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.401695
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.496985e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.053500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.527350e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.585969e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.034363e-02
Vprtstp: contraction number = 6.034363e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.685876e-03
Vprtstp: contraction number = 1.605120e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.581575e-03
Vprtstp: contraction number = 2.665299e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.765275e-04
Vprtstp: contraction number = 3.782681e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.590514e-04
Vprtstp: contraction number = 4.700855e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.770084e-04
Vprtstp: contraction number = 6.034366e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.735785e-04
Vprtstp: contraction number = 6.266180e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.019231e-04
Vprtstp: contraction number = 5.871875e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.547676e-05
Vprtstp: contraction number = 6.424134e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.775936e-05
Vprtstp: contraction number = 5.766834e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.491482e-05
Vprtstp: contraction number = 6.598316e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.419352e-05
Vprtstp: contraction number = 5.696820e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 9.608120e-06
Vprtstp: contraction number = 6.769369e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.419321e-06
Vprtstp: contraction number = 5.640356e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 3.753870e-06
Vprtstp: contraction number = 6.926826e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.099494e-06
Vprtstp: contraction number = 5.592879e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.483473e-06
Vprtstp: contraction number = 7.065858e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 8.239156e-07
Vprtstp: contraction number = 5.553965e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.140359e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.629130e+00
Vpmg_setPart:  lower corner = (-34.987, -16.35, -21.267)
Vpmg_setPart:  upper corner = (74.733, 101.652, 105.334)
Vpmg_setPart:  actual minima = (-34.987, -16.35, -21.267)
Vpmg_setPart:  actual maxima = (74.733, 101.652, 105.334)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.969668e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:32 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 31366 atoms
Valist_getStatistics:  Max atom coordinate:  (64.733, 91.652, 95.334)
Valist_getStatistics:  Min atom coordinate:  (-24.987, -6.35, -11.267)
Valist_getStatistics:  Molecule center:  (19.873, 42.651, 42.0335)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.81075, 0.862513, 0.916256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.68575, 0.737513, 0.791256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.845822, 0.855075, 0.863575 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 84.733 111.652 115.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -44.987 -26.35 -31.267
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 74.733 101.652 105.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -34.987 -16.35 -21.267
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 74.733 101.652 105.334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -34.987 -16.35 -21.267
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13022674 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.470471
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.347051e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.005080e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.353340e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.795581e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 35346514.286879
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.002134e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.777164e+06
Vprtstp: contraction number = 1.777164e+06
Vnewton: Attempting damping, relres = 17551004.813301
Vnewton: Attempting damping, relres = 1.895738
Vnewton: Attempting damping, relres = 0.759071
Vnewton: Attempting damping, relres = 0.879193
Vnewton: Damping accepted, relres = 0.759071
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.590714e-01
Vprtstp: contraction number = 7.590714e-01
Vnewton: Using errtol_s: 26830528.538737
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.593609e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.382565e+06
Vprtstp: contraction number = 1.382565e+06
Vnewton: Attempting damping, relres = 0.243350
Vnewton: Attempting damping, relres = 0.395362
Vnewton: Damping accepted, relres = 0.243350
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.433502e-01
Vprtstp: contraction number = 3.205893e-01
Vnewton: Using errtol_s: 8601580.334745
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.031831e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.853145e+05
Vprtstp: contraction number = 1.853145e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.051780e-02
Vprtstp: contraction number = 3.308722e-01
Vnewton: Using errtol_s: 2846023.643932
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.390466e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.148438e+04
Vprtstp: contraction number = 4.148438e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.860294e-02
Vprtstp: contraction number = 3.552375e-01
Vnewton: Using errtol_s: 1011014.216136
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.740865e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.955063e+04
Vprtstp: contraction number = 1.955063e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.039202e-02
Vprtstp: contraction number = 3.633200e-01
Vnewton: Using errtol_s: 367321.670577
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.066649e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.550077e+04
Vprtstp: contraction number = 1.550077e+04
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.846134e-03
Vprtstp: contraction number = 3.701046e-01
Vnewton: Using errtol_s: 135947.431561
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.392738e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.336043e+04
Vprtstp: contraction number = 1.336043e+04
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.471650e-03
Vprtstp: contraction number = 3.826309e-01
Vnewton: Using errtol_s: 52017.681607
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.717761e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.020775e+04
Vprtstp: contraction number = 1.020775e+04
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.900894e-04
Vprtstp: contraction number = 4.009714e-01
Vnewton: Using errtol_s: 20857.604210
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.040175e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.474266e+03
Vprtstp: contraction number = 6.474266e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.458587e-04
Vprtstp: contraction number = 4.166464e-01
Vnewton: Using errtol_s: 8690.246566
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.363282e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.410322e+03
Vprtstp: contraction number = 3.410322e+03
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.025530e-04
Vprtstp: contraction number = 4.171217e-01
Vnewton: Using errtol_s: 3624.890729
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.684309e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.553809e+03
Vprtstp: contraction number = 1.553809e+03
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.184312e-05
Vprtstp: contraction number = 4.080146e-01
Vnewton: Using errtol_s: 1479.008371
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.000677e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.461952e+02
Vprtstp: contraction number = 6.461952e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.672578e-05
Vprtstp: contraction number = 3.997259e-01
Vnewton: Using errtol_s: 591.197979
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.033123e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.570401e+02
Vprtstp: contraction number = 2.570401e+02
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.575722e-06
Vprtstp: contraction number = 3.931489e-01
Vnewton: Using errtol_s: 232.428858
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.065994e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.006055e+02
Vprtstp: contraction number = 1.006055e+02
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.565218e-06
Vprtstp: contraction number = 3.901044e-01
Vnewton: Using errtol_s: 90.671518
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.098520e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.944848e+01
Vprtstp: contraction number = 3.944848e+01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.004863e-06
Vprtstp: contraction number = 3.917261e-01
Vnewton: Using errtol_s: 35.518399
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.131610e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.570543e+01
Vprtstp: contraction number = 1.570543e+01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.999440e-07
Vprtstp: contraction number = 3.980085e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.775751e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.157505e+00
Vpmg_setPart:  lower corner = (-44.987, -26.35, -31.267)
Vpmg_setPart:  upper corner = (84.733, 111.652, 115.334)
Vpmg_setPart:  actual minima = (-44.987, -26.35, -31.267)
Vpmg_setPart:  actual maxima = (84.733, 111.652, 115.334)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13022674 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -34.987, -16.35, -21.267
VPMG::focusFillBound -- New mesh maxs = 74.733, 101.652, 105.334
VPMG::focusFillBound -- Old mesh mins = -44.987, -26.35, -31.267
VPMG::focusFillBound -- Old mesh maxs = 84.733, 111.652, 115.334
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.441533
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.560734e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 9.152200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.160770e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.749047e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 40436627.958868
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.769894e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.571048e+06
Vprtstp: contraction number = 2.571048e+06
Vnewton: Attempting damping, relres = 14728170.346929
Vnewton: Attempting damping, relres = 1.649325
Vnewton: Attempting damping, relres = 0.762448
Vnewton: Attempting damping, relres = 0.880920
Vnewton: Damping accepted, relres = 0.762448
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.624478e-01
Vprtstp: contraction number = 7.624478e-01
Vnewton: Using errtol_s: 30830816.533413
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.828855e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.002297e+06
Vprtstp: contraction number = 2.002297e+06
Vnewton: Attempting damping, relres = 0.227268
Vnewton: Attempting damping, relres = 0.402219
Vnewton: Damping accepted, relres = 0.227268
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.272676e-01
Vprtstp: contraction number = 2.980763e-01
Vnewton: Using errtol_s: 9189935.406233
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.872577e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.675495e+05
Vprtstp: contraction number = 2.675495e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.248612e-02
Vprtstp: contraction number = 3.189461e-01
Vnewton: Using errtol_s: 2931094.455530
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.907868e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.677207e+04
Vprtstp: contraction number = 5.677207e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.542001e-02
Vprtstp: contraction number = 3.506880e-01
Vnewton: Using errtol_s: 1027899.631868
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.944181e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.548039e+04
Vprtstp: contraction number = 2.548039e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.223594e-03
Vprtstp: contraction number = 3.628477e-01
Vnewton: Using errtol_s: 372971.047794
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.979058e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.970616e+04
Vprtstp: contraction number = 1.970616e+04
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.446846e-03
Vprtstp: contraction number = 3.736988e-01
Vnewton: Using errtol_s: 139378.834639
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.014047e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.651256e+04
Vprtstp: contraction number = 1.651256e+04
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.350322e-03
Vprtstp: contraction number = 3.917558e-01
Vnewton: Using errtol_s: 54602.471239
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.048095e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.228966e+04
Vprtstp: contraction number = 1.228966e+04
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.625897e-04
Vprtstp: contraction number = 4.166337e-01
Vnewton: Using errtol_s: 22749.229425
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.082356e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.672384e+03
Vprtstp: contraction number = 7.672384e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.453365e-04
Vprtstp: contraction number = 4.360842e-01
Vnewton: Using errtol_s: 9920.579238
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.115110e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.063376e+03
Vprtstp: contraction number = 4.063376e+03
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.069641e-04
Vprtstp: contraction number = 4.359893e-01
Vnewton: Using errtol_s: 4325.266107
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.148978e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.903092e+03
Vprtstp: contraction number = 1.903092e+03
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.538633e-05
Vprtstp: contraction number = 4.243138e-01
Vnewton: Using errtol_s: 1835.269967
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.182705e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.226596e+02
Vprtstp: contraction number = 8.226596e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.875501e-05
Vprtstp: contraction number = 4.132303e-01
Vnewton: Using errtol_s: 758.389224
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.215987e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.388260e+02
Vprtstp: contraction number = 3.388260e+02
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.594073e-06
Vprtstp: contraction number = 4.049091e-01
Vnewton: Using errtol_s: 307.078708
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.249895e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.360874e+02
Vprtstp: contraction number = 1.360874e+02
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.034907e-06
Vprtstp: contraction number = 3.996415e-01
Vnewton: Using errtol_s: 122.721402
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.284710e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.423177e+01
Vprtstp: contraction number = 5.423177e+01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.207773e-06
Vprtstp: contraction number = 3.979605e-01
Vnewton: Using errtol_s: 48.838276
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.320166e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.171720e+01
Vprtstp: contraction number = 2.171720e+01
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.834515e-07
Vprtstp: contraction number = 4.002834e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 5.967364e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.316245e+00
Vpmg_setPart:  lower corner = (-34.987, -16.35, -21.267)
Vpmg_setPart:  upper corner = (74.733, 101.652, 105.334)
Vpmg_setPart:  actual minima = (-34.987, -16.35, -21.267)
Vpmg_setPart:  actual maxima = (74.733, 101.652, 105.334)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.413483e+01
