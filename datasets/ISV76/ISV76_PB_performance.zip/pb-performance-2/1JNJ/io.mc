##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1640 atoms
Valist_getStatistics:  Max atom coordinate:  (16.973, 24.748, 14.953)
Valist_getStatistics:  Min atom coordinate:  (-16.529, -26.22, -14.032)
Valist_getStatistics:  Molecule center:  (0.222, -0.736, 0.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.765646, 0.947583, 1.07789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.557312, 0.73925, 0.765391
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.727899, 0.780142, 0.710082 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.973 44.748 34.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -36.529 -46.22 -34.032
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.973 34.748 24.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -26.529 -36.22 -24.032
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.973 34.748 24.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -26.529 -36.22 -24.032
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.181185
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.031250e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.362000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.353500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.652340e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1809018.373423
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.964420e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.390157e+05
Vprtstp: contraction number = 1.390157e+05
Vnewton: Attempting damping, relres = 0.070936
Vnewton: Attempting damping, relres = 0.528948
Vnewton: Damping accepted, relres = 0.070936
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.093562e-02
Vprtstp: contraction number = 7.093562e-02
Vnewton: Using errtol_s: 128323.837915
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.563190e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.107670e+04
Vprtstp: contraction number = 2.107670e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.049664e-02
Vprtstp: contraction number = 1.479741e-01
Vnewton: Using errtol_s: 18988.606557
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.983330e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.946232e+03
Vprtstp: contraction number = 3.946232e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.963471e-03
Vprtstp: contraction number = 1.870572e-01
Vnewton: Using errtol_s: 3551.954918
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.401150e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.099997e+02
Vprtstp: contraction number = 8.099997e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.029880e-04
Vprtstp: contraction number = 2.052427e-01
Vnewton: Using errtol_s: 729.012711
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.833350e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.743893e+02
Vprtstp: contraction number = 1.743893e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.676029e-05
Vprtstp: contraction number = 2.152925e-01
Vnewton: Using errtol_s: 156.950962
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.264140e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.881717e+01
Vprtstp: contraction number = 3.881717e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.931184e-05
Vprtstp: contraction number = 2.225885e-01
Vnewton: Using errtol_s: 34.935476
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.708860e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.884257e+00
Vprtstp: contraction number = 8.884257e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.419984e-06
Vprtstp: contraction number = 2.288743e-01
Vnewton: Using errtol_s: 7.995833
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.155610e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.088558e+00
Vprtstp: contraction number = 2.088558e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.039073e-06
Vprtstp: contraction number = 2.350852e-01
Vnewton: Using errtol_s: 1.879702
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.600560e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.024678e-01
Vprtstp: contraction number = 5.024678e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.499814e-07
Vprtstp: contraction number = 2.405812e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.289070e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.828930e-01
Vpmg_setPart:  lower corner = (-36.529, -46.22, -34.032)
Vpmg_setPart:  upper corner = (36.973, 44.748, 34.953)
Vpmg_setPart:  actual minima = (-36.529, -46.22, -34.032)
Vpmg_setPart:  actual maxima = (36.973, 44.748, 34.953)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -26.529, -36.22, -24.032
VPMG::focusFillBound -- New mesh maxs = 26.973, 34.748, 24.953
VPMG::focusFillBound -- Old mesh mins = -36.529, -46.22, -34.032
VPMG::focusFillBound -- Old mesh maxs = 36.973, 44.748, 34.953
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.178450
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.443460e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.332300e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 3.309200e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.192719e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2338415.631452
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.222246e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.642262e+05
Vprtstp: contraction number = 2.642262e+05
Vnewton: Attempting damping, relres = 0.102854
Vnewton: Attempting damping, relres = 0.546881
Vnewton: Damping accepted, relres = 0.102854
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.028545e-01
Vprtstp: contraction number = 1.028545e-01
Vnewton: Using errtol_s: 240516.469555
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.277772e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.037523e+04
Vprtstp: contraction number = 4.037523e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.554744e-02
Vprtstp: contraction number = 1.511596e-01
Vnewton: Using errtol_s: 36356.385011
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.322340e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.118678e+03
Vprtstp: contraction number = 7.118678e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.739923e-03
Vprtstp: contraction number = 1.762298e-01
Vnewton: Using errtol_s: 6407.078903
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.366843e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.340175e+03
Vprtstp: contraction number = 1.340175e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.158064e-04
Vprtstp: contraction number = 1.882558e-01
Vnewton: Using errtol_s: 1206.169639
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.411323e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.630983e+02
Vprtstp: contraction number = 2.630983e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.012605e-04
Vprtstp: contraction number = 1.963150e-01
Vnewton: Using errtol_s: 236.789140
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.455977e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.347132e+01
Vprtstp: contraction number = 5.347132e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.057984e-05
Vprtstp: contraction number = 2.032366e-01
Vnewton: Using errtol_s: 48.124227
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.501325e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.126998e+01
Vprtstp: contraction number = 1.126998e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.337546e-06
Vprtstp: contraction number = 2.107667e-01
Vnewton: Using errtol_s: 10.142986
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.546518e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.465021e+00
Vprtstp: contraction number = 2.465021e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.487273e-07
Vprtstp: contraction number = 2.187244e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.882700e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.410570e-01
Vpmg_setPart:  lower corner = (-26.529, -36.22, -24.032)
Vpmg_setPart:  upper corner = (26.973, 34.748, 24.953)
Vpmg_setPart:  actual minima = (-26.529, -36.22, -24.032)
Vpmg_setPart:  actual maxima = (26.973, 34.748, 24.953)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.680170e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:58 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 65)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1640 atoms
Valist_getStatistics:  Max atom coordinate:  (16.973, 24.748, 14.953)
Valist_getStatistics:  Min atom coordinate:  (-16.529, -26.22, -14.032)
Valist_getStatistics:  Molecule center:  (0.222, -0.736, 0.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.765646, 0.947583, 1.07789
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.557312, 0.73925, 0.765391
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.727899, 0.780142, 0.710082 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 36.973 44.748 34.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -36.529 -46.22 -34.032
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 26.973 34.748 24.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -26.529 -36.22 -24.032
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 26.973 34.748 24.953
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -26.529 -36.22 -24.032
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.186128
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.021920e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.380800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.762200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.721360e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.308692e-02
Vprtstp: contraction number = 7.308692e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.078952e-02
Vprtstp: contraction number = 1.476258e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.997150e-03
Vprtstp: contraction number = 1.851009e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.109264e-04
Vprtstp: contraction number = 2.057564e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.817017e-05
Vprtstp: contraction number = 2.145644e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.993248e-05
Vprtstp: contraction number = 2.260683e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.543879e-06
Vprtstp: contraction number = 2.279636e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.087261e-06
Vprtstp: contraction number = 2.392805e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.597996e-07
Vprtstp: contraction number = 2.389486e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.876110e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.485350e-01
Vpmg_setPart:  lower corner = (-36.529, -46.22, -34.032)
Vpmg_setPart:  upper corner = (36.973, 44.748, 34.953)
Vpmg_setPart:  actual minima = (-36.529, -46.22, -34.032)
Vpmg_setPart:  actual maxima = (36.973, 44.748, 34.953)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -26.529, -36.22, -24.032
VPMG::focusFillBound -- New mesh maxs = 26.973, 34.748, 24.953
VPMG::focusFillBound -- Old mesh mins = -36.529, -46.22, -34.032
VPMG::focusFillBound -- Old mesh maxs = 36.973, 44.748, 34.953
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.179580
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.498780e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 065)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.338200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.614900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.670830e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.037940e-01
Vprtstp: contraction number = 1.037940e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.567713e-02
Vprtstp: contraction number = 1.510408e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.756036e-03
Vprtstp: contraction number = 1.757997e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.179655e-04
Vprtstp: contraction number = 1.879386e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.017102e-04
Vprtstp: contraction number = 1.963647e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.079465e-05
Vprtstp: contraction number = 2.044500e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.413066e-06
Vprtstp: contraction number = 2.122213e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.762971e-07
Vprtstp: contraction number = 2.212287e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.780440e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.340540e-01
Vpmg_setPart:  lower corner = (-26.529, -36.22, -24.032)
Vpmg_setPart:  upper corner = (26.973, 34.748, 24.953)
Vpmg_setPart:  actual minima = (-26.529, -36.22, -24.032)
Vpmg_setPart:  actual maxima = (26.973, 34.748, 24.953)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.242133e+00
