##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6677 atoms
Valist_getStatistics:  Max atom coordinate:  (18.907, 18.785, -6.611)
Valist_getStatistics:  Min atom coordinate:  (-48.035, -32.888, -70.977)
Valist_getStatistics:  Molecule center:  (-14.564, -7.0515, -38.794)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.835484, 0.954927, 0.815359
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.679234, 0.746594, 0.659109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.812983, 0.781833, 0.808367 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 38.907 38.785 13.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -68.035 -52.888 -90.977
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 28.907 28.785 3.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -58.035 -42.888 -80.977
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 28.907 28.785 3.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -58.035 -42.888 -80.977
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154312 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.869037
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.180212e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.397100e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.638800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.316709e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7460802.966360
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.413710e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.551963e+05
Vprtstp: contraction number = 4.551963e+05
Vnewton: Attempting damping, relres = 0.057322
Vnewton: Attempting damping, relres = 0.522410
Vnewton: Damping accepted, relres = 0.057322
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.732201e-02
Vprtstp: contraction number = 5.732201e-02
Vnewton: Using errtol_s: 427668.228934
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.596632e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.978233e+04
Vprtstp: contraction number = 5.978233e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.302532e-03
Vprtstp: contraction number = 1.273949e-01
Vnewton: Using errtol_s: 54482.752055
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.737697e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.626733e+03
Vprtstp: contraction number = 9.626733e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.163451e-03
Vprtstp: contraction number = 1.593215e-01
Vnewton: Using errtol_s: 8680.275063
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.881005e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.718811e+03
Vprtstp: contraction number = 1.718811e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.073784e-04
Vprtstp: contraction number = 1.782443e-01
Vnewton: Using errtol_s: 1547.209501
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.021575e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.188421e+02
Vprtstp: contraction number = 3.188421e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.846323e-05
Vprtstp: contraction number = 1.854736e-01
Vnewton: Using errtol_s: 286.966566
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.160722e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.938863e+01
Vprtstp: contraction number = 5.938863e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.164121e-06
Vprtstp: contraction number = 1.862590e-01
Vnewton: Using errtol_s: 53.450098
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.302216e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.133708e+01
Vprtstp: contraction number = 1.133708e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.367598e-06
Vprtstp: contraction number = 1.908954e-01
Vnewton: Using errtol_s: 10.203380
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.446719e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.292741e+00
Vprtstp: contraction number = 2.292741e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.765744e-07
Vprtstp: contraction number = 2.022337e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.237154e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.354596e+00
Vpmg_setPart:  lower corner = (-68.035, -52.888, -90.977)
Vpmg_setPart:  upper corner = (38.907, 38.785, 13.389)
Vpmg_setPart:  actual minima = (-68.035, -52.888, -90.977)
Vpmg_setPart:  actual maxima = (38.907, 38.785, 13.389)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154312 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -58.035, -42.888, -80.977
VPMG::focusFillBound -- New mesh maxs = 28.907, 28.785, 3.389
VPMG::focusFillBound -- Old mesh mins = -68.035, -52.888, -90.977
VPMG::focusFillBound -- Old mesh maxs = 38.907, 38.785, 13.389
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.865488
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.283397e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.329900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.700700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.958713e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 8958144.276459
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.056790e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.386155e+05
Vprtstp: contraction number = 7.386155e+05
Vnewton: Attempting damping, relres = 0.076077
Vnewton: Attempting damping, relres = 0.533541
Vnewton: Damping accepted, relres = 0.076077
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.607720e-02
Vprtstp: contraction number = 7.607720e-02
Vnewton: Using errtol_s: 681510.528317
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.248362e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.634015e+04
Vprtstp: contraction number = 9.634015e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.748321e-03
Vprtstp: contraction number = 1.281372e-01
Vnewton: Using errtol_s: 87326.869923
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.392480e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.509083e+04
Vprtstp: contraction number = 1.509083e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.517367e-03
Vprtstp: contraction number = 1.556541e-01
Vnewton: Using errtol_s: 13592.788067
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.537019e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.674140e+03
Vprtstp: contraction number = 2.674140e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.686786e-04
Vprtstp: contraction number = 1.770690e-01
Vnewton: Using errtol_s: 2406.861852
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.680259e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.154644e+02
Vprtstp: contraction number = 5.154644e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.178790e-05
Vprtstp: contraction number = 1.927503e-01
Vnewton: Using errtol_s: 463.923459
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.822930e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.036517e+02
Vprtstp: contraction number = 1.036517e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.041363e-05
Vprtstp: contraction number = 2.010823e-01
Vnewton: Using errtol_s: 93.286789
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.967525e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.122394e+01
Vprtstp: contraction number = 2.122394e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.132312e-06
Vprtstp: contraction number = 2.047617e-01
Vnewton: Using errtol_s: 19.101558
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.112436e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.355075e+00
Vprtstp: contraction number = 4.355075e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.375424e-07
Vprtstp: contraction number = 2.051962e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.265324e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.382519e+00
Vpmg_setPart:  lower corner = (-58.035, -42.888, -80.977)
Vpmg_setPart:  upper corner = (28.907, 28.785, 3.389)
Vpmg_setPart:  actual minima = (-58.035, -42.888, -80.977)
Vpmg_setPart:  actual maxima = (28.907, 28.785, 3.389)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.559304e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6677 atoms
Valist_getStatistics:  Max atom coordinate:  (18.907, 18.785, -6.611)
Valist_getStatistics:  Min atom coordinate:  (-48.035, -32.888, -70.977)
Valist_getStatistics:  Molecule center:  (-14.564, -7.0515, -38.794)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.835484, 0.954927, 0.815359
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.679234, 0.746594, 0.659109
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.812983, 0.781833, 0.808367 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 38.907 38.785 13.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -68.035 -52.888 -90.977
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 28.907 28.785 3.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -58.035 -42.888 -80.977
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 28.907 28.785 3.389
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -58.035 -42.888 -80.977
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154312 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.865164
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.178181e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.336800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.851300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.327927e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.983579e-02
Vprtstp: contraction number = 5.983579e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.244030e-03
Vprtstp: contraction number = 1.377776e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.741505e-03
Vprtstp: contraction number = 2.112444e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.447217e-04
Vprtstp: contraction number = 2.553662e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.272741e-04
Vprtstp: contraction number = 2.861882e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.772958e-05
Vprtstp: contraction number = 2.964435e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.162176e-05
Vprtstp: contraction number = 3.080277e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.653730e-06
Vprtstp: contraction number = 3.143871e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.141661e-06
Vprtstp: contraction number = 3.124647e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.664184e-07
Vprtstp: contraction number = 3.209519e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.232930e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.543430e-01
Vpmg_setPart:  lower corner = (-68.035, -52.888, -90.977)
Vpmg_setPart:  upper corner = (38.907, 38.785, 13.389)
Vpmg_setPart:  actual minima = (-68.035, -52.888, -90.977)
Vpmg_setPart:  actual maxima = (38.907, 38.785, 13.389)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -3.0004
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154312 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -58.035, -42.888, -80.977
VPMG::focusFillBound -- New mesh maxs = 28.907, 28.785, 3.389
VPMG::focusFillBound -- Old mesh mins = -68.035, -52.888, -90.977
VPMG::focusFillBound -- Old mesh maxs = 38.907, 38.785, 13.389
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.858758
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.274886e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.345200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.923100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.362386e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.786114e-02
Vprtstp: contraction number = 7.786114e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.053318e-02
Vprtstp: contraction number = 1.352817e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.978828e-03
Vprtstp: contraction number = 1.878661e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.731527e-04
Vprtstp: contraction number = 2.391075e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.309683e-04
Vprtstp: contraction number = 2.767991e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.309238e-05
Vprtstp: contraction number = 3.290292e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.344880e-05
Vprtstp: contraction number = 3.120923e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.210929e-06
Vprtstp: contraction number = 3.874642e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.654429e-06
Vprtstp: contraction number = 3.174921e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.178507e-07
Vprtstp: contraction number = 4.338964e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.438550e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.762630e-01
Vpmg_setPart:  lower corner = (-58.035, -42.888, -80.977)
Vpmg_setPart:  upper corner = (28.907, 28.785, 3.389)
Vpmg_setPart:  actual minima = (-58.035, -42.888, -80.977)
Vpmg_setPart:  actual maxima = (28.907, 28.785, 3.389)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.344867e+00
