##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 36150 atoms
Valist_getStatistics:  Max atom coordinate:  (65.042, 142.542, 109.818)
Valist_getStatistics:  Min atom coordinate:  (-56.211, 20.968, 42.047)
Valist_getStatistics:  Molecule center:  (4.4155, 81.755, 75.9325)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.839859, 0.841531, 0.841961
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.735693, 0.737365, 0.685711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.875971, 0.876218, 0.814421 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.042 162.542 129.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -76.211 0.968 22.047
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.042 152.542 119.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -66.211 10.968 32.047
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.042 152.542 119.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -66.211 10.968 32.047
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -96.0024
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493981 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.919591
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.944167e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.009510e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.238610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.410112e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.653941e-02
Vprtstp: contraction number = 5.653941e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.907654e-03
Vprtstp: contraction number = 1.221741e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.163208e-03
Vprtstp: contraction number = 1.683940e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.831480e-04
Vprtstp: contraction number = 2.434200e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.874786e-05
Vprtstp: contraction number = 2.781155e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.373989e-05
Vprtstp: contraction number = 3.014671e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.705163e-06
Vprtstp: contraction number = 3.245661e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.446860e-06
Vprtstp: contraction number = 3.175611e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.384675e-07
Vprtstp: contraction number = 3.426708e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.434530e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.819635e+00
Vpmg_setPart:  lower corner = (-76.211, 0.968, 22.047)
Vpmg_setPart:  upper corner = (85.042, 162.542, 129.818)
Vpmg_setPart:  actual minima = (-76.211, 0.968, 22.047)
Vpmg_setPart:  actual maxima = (85.042, 162.542, 129.818)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -96.0024
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493981 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -66.211, 10.968, 32.047
VPMG::focusFillBound -- New mesh maxs = 75.042, 152.542, 119.818
VPMG::focusFillBound -- Old mesh mins = -76.211, 0.968, 22.047
VPMG::focusFillBound -- Old mesh maxs = 85.042, 162.542, 129.818
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.899388
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.190446e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.004480e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.267200e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.744214e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.187319e-02
Vprtstp: contraction number = 6.187319e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.820421e-03
Vprtstp: contraction number = 1.263943e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.439206e-03
Vprtstp: contraction number = 1.840317e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.638102e-04
Vprtstp: contraction number = 2.527854e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.086829e-04
Vprtstp: contraction number = 2.987352e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.553915e-05
Vprtstp: contraction number = 3.269985e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.256544e-05
Vprtstp: contraction number = 3.535663e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.365410e-06
Vprtstp: contraction number = 3.474139e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.634599e-06
Vprtstp: contraction number = 3.744433e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.823970e-07
Vprtstp: contraction number = 3.562936e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.716564e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.107100e+00
Vpmg_setPart:  lower corner = (-66.211, 10.968, 32.047)
Vpmg_setPart:  upper corner = (75.042, 152.542, 119.818)
Vpmg_setPart:  actual minima = (-66.211, 10.968, 32.047)
Vpmg_setPart:  actual maxima = (75.042, 152.542, 119.818)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.118429e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:33 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 36150 atoms
Valist_getStatistics:  Max atom coordinate:  (65.042, 142.542, 109.818)
Valist_getStatistics:  Min atom coordinate:  (-56.211, 20.968, 42.047)
Valist_getStatistics:  Molecule center:  (4.4155, 81.755, 75.9325)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.839859, 0.841531, 0.841961
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.735693, 0.737365, 0.685711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.875971, 0.876218, 0.814421 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 85.042 162.542 129.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -76.211 0.968 22.047
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.042 152.542 119.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -66.211 10.968 32.047
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.042 152.542 119.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -66.211 10.968 32.047
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -96.0024
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493981 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.892500
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.915218e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 9.887600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.232800e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.370481e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 47998325.996736
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.646709e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.932281e+06
Vprtstp: contraction number = 2.932281e+06
Vnewton: Attempting damping, relres = 89811.621711
Vnewton: Attempting damping, relres = 0.649151
Vnewton: Attempting damping, relres = 0.761800
Vnewton: Damping accepted, relres = 0.649151
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.491507e-01
Vprtstp: contraction number = 6.491507e-01
Vnewton: Using errtol_s: 31158148.648159
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.380509e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.602912e+06
Vprtstp: contraction number = 1.602912e+06
Vnewton: Attempting damping, relres = 0.086114
Vnewton: Attempting damping, relres = 0.350699
Vnewton: Damping accepted, relres = 0.086114
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.611400e-02
Vprtstp: contraction number = 1.326564e-01
Vnewton: Using errtol_s: 4133327.730059
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.995718e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.007686e+05
Vprtstp: contraction number = 2.007686e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.274641e-02
Vprtstp: contraction number = 2.641430e-01
Vnewton: Using errtol_s: 1091789.671830
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.477153e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.726957e+04
Vprtstp: contraction number = 3.726957e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.309612e-03
Vprtstp: contraction number = 3.213523e-01
Vnewton: Using errtol_s: 350849.121208
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.956596e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.294893e+04
Vprtstp: contraction number = 1.294893e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.501801e-03
Vprtstp: contraction number = 3.422618e-01
Vnewton: Using errtol_s: 120082.264030
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.044064e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.695820e+03
Vprtstp: contraction number = 8.695820e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.557919e-04
Vprtstp: contraction number = 3.420703e-01
Vnewton: Using errtol_s: 41076.580418
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.092093e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.592454e+03
Vprtstp: contraction number = 6.592454e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.916737e-04
Vprtstp: contraction number = 3.408231e-01
Vnewton: Using errtol_s: 13999.847315
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.140045e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.229424e+03
Vprtstp: contraction number = 4.229424e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.072097e-04
Vprtstp: contraction number = 3.675673e-01
Vnewton: Using errtol_s: 5145.886485
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.188896e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.316136e+03
Vprtstp: contraction number = 2.316136e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.632947e-05
Vprtstp: contraction number = 4.321387e-01
Vnewton: Using errtol_s: 2223.736790
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.237423e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.184550e+03
Vprtstp: contraction number = 1.184550e+03
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.249416e-05
Vprtstp: contraction number = 4.855259e-01
Vnewton: Using errtol_s: 1079.681864
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.286300e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.066332e+02
Vprtstp: contraction number = 6.066332e+02
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.142717e-05
Vprtstp: contraction number = 5.080064e-01
Vnewton: Using errtol_s: 548.485245
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.335126e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.178976e+02
Vprtstp: contraction number = 3.178976e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.974294e-06
Vprtstp: contraction number = 5.228147e-01
Vnewton: Using errtol_s: 286.756133
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.384039e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.709209e+02
Vprtstp: contraction number = 1.709209e+02
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.208823e-06
Vprtstp: contraction number = 5.371050e-01
Vnewton: Using errtol_s: 154.018141
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.433089e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.405402e+01
Vprtstp: contraction number = 9.405402e+01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.764817e-06
Vprtstp: contraction number = 5.499888e-01
Vnewton: Using errtol_s: 84.708251
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.482007e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.278469e+01
Vprtstp: contraction number = 5.278469e+01
Vprtstp: iteration = 15
Vprtstp: relative residual = 9.901580e-07
Vprtstp: contraction number = 5.610543e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 7.826313e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.200620e+00
Vpmg_setPart:  lower corner = (-76.211, 0.968, 22.047)
Vpmg_setPart:  upper corner = (85.042, 162.542, 129.818)
Vpmg_setPart:  actual minima = (-76.211, 0.968, 22.047)
Vpmg_setPart:  actual maxima = (85.042, 162.542, 129.818)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -96.0024
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493981 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -66.211, 10.968, 32.047
VPMG::focusFillBound -- New mesh maxs = 75.042, 152.542, 119.818
VPMG::focusFillBound -- Old mesh mins = -76.211, 0.968, 22.047
VPMG::focusFillBound -- Old mesh maxs = 85.042, 162.542, 129.818
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.865560
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.155823e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.000460e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.267030e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.275049e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 49217206.077598
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.302997e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.271677e+06
Vprtstp: contraction number = 3.271677e+06
Vnewton: Attempting damping, relres = 99287.573036
Vnewton: Attempting damping, relres = 0.642090
Vnewton: Attempting damping, relres = 0.763116
Vnewton: Damping accepted, relres = 0.642090
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.420897e-01
Vprtstp: contraction number = 6.420897e-01
Vnewton: Using errtol_s: 31601861.477619
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.377639e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.810787e+06
Vprtstp: contraction number = 1.810787e+06
Vnewton: Attempting damping, relres = 0.079405
Vnewton: Attempting damping, relres = 0.348299
Vnewton: Damping accepted, relres = 0.079405
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.940502e-02
Vprtstp: contraction number = 1.236665e-01
Vnewton: Using errtol_s: 3908093.125240
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.440279e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.331095e+05
Vprtstp: contraction number = 2.331095e+05
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.063056e-02
Vprtstp: contraction number = 2.598143e-01
Vnewton: Using errtol_s: 1015378.467169
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.489322e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.204932e+04
Vprtstp: contraction number = 4.204932e+04
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.577588e-03
Vprtstp: contraction number = 3.188274e-01
Vnewton: Using errtol_s: 323730.502123
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.538455e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.442668e+04
Vprtstp: contraction number = 1.442668e+04
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.240503e-03
Vprtstp: contraction number = 3.406268e-01
Vnewton: Using errtol_s: 110271.298090
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.587762e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.879604e+03
Vprtstp: contraction number = 8.879604e+03
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.719754e-04
Vprtstp: contraction number = 3.445545e-01
Vnewton: Using errtol_s: 37994.471900
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.636998e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.013887e+03
Vprtstp: contraction number = 6.013887e+03
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.648930e-04
Vprtstp: contraction number = 3.431365e-01
Vnewton: Using errtol_s: 13037.291724
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.685937e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.487698e+03
Vprtstp: contraction number = 3.487698e+03
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.144287e-05
Vprtstp: contraction number = 3.452068e-01
Vnewton: Using errtol_s: 4500.562341
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.735020e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.676336e+03
Vprtstp: contraction number = 1.676336e+03
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.345464e-05
Vprtstp: contraction number = 3.658529e-01
Vnewton: Using errtol_s: 1646.543985
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.783899e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.136103e+02
Vprtstp: contraction number = 7.136103e+02
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.323881e-05
Vprtstp: contraction number = 3.957243e-01
Vnewton: Using errtol_s: 651.577423
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.833332e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.937284e+02
Vprtstp: contraction number = 2.937284e+02
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.390050e-06
Vprtstp: contraction number = 4.071400e-01
Vnewton: Using errtol_s: 265.283212
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.882880e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.218396e+02
Vprtstp: contraction number = 1.218396e+02
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.230578e-06
Vprtstp: contraction number = 4.138324e-01
Vnewton: Using errtol_s: 109.782800
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.932587e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.168692e+01
Vprtstp: contraction number = 5.168692e+01
Vprtstp: iteration = 13
Vprtstp: relative residual = 9.455567e-07
Vprtstp: contraction number = 4.239067e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.957186e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.339821e+00
Vpmg_setPart:  lower corner = (-66.211, 10.968, 32.047)
Vpmg_setPart:  upper corner = (75.042, 152.542, 119.818)
Vpmg_setPart:  actual minima = (-66.211, 10.968, 32.047)
Vpmg_setPart:  actual maxima = (75.042, 152.542, 119.818)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.074092e+01
