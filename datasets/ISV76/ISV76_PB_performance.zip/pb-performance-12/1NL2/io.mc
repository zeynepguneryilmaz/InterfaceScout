##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2065 atoms
Valist_getStatistics:  Max atom coordinate:  (31.545, 62.033, 138.607)
Valist_getStatistics:  Min atom coordinate:  (-9.889, 22.933, 80.851)
Valist_getStatistics:  Molecule center:  (10.828, 42.483, 109.729)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.848271, 0.823958, 0.763719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.639937, 0.615625, 0.607469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.754402, 0.747155, 0.795409 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 51.545 82.033 158.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.889 2.933 60.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 41.545 72.033 148.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.889 12.933 70.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 41.545 72.033 148.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.889 12.933 70.851
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.238745
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.441940e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.578000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.231700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.434470e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2676155.673662
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.138410e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.886929e+05
Vprtstp: contraction number = 1.886929e+05
Vnewton: Attempting damping, relres = 0.069029
Vnewton: Attempting damping, relres = 0.527913
Vnewton: Damping accepted, relres = 0.069029
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.902880e-02
Vprtstp: contraction number = 6.902880e-02
Vnewton: Using errtol_s: 184731.827428
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.485220e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.447081e+04
Vprtstp: contraction number = 2.447081e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.846670e-03
Vprtstp: contraction number = 1.281591e-01
Vnewton: Using errtol_s: 23675.065098
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.527490e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.800691e+03
Vprtstp: contraction number = 3.800691e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.343283e-03
Vprtstp: contraction number = 1.518405e-01
Vnewton: Using errtol_s: 3594.833522
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.575930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.431744e+02
Vprtstp: contraction number = 6.431744e+02
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.182741e-04
Vprtstp: contraction number = 1.624931e-01
Vnewton: Using errtol_s: 584.135596
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.060577e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.133091e+02
Vprtstp: contraction number = 1.133091e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.811427e-05
Vprtstp: contraction number = 1.746165e-01
Vnewton: Using errtol_s: 101.999727
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.165911e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.112036e+01
Vprtstp: contraction number = 2.112036e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.102904e-06
Vprtstp: contraction number = 1.863581e-01
Vnewton: Using errtol_s: 19.008477
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.270984e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.150768e+00
Vprtstp: contraction number = 4.150768e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.395918e-06
Vprtstp: contraction number = 1.965278e-01
Vnewton: Using errtol_s: 3.735693
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.375298e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.537693e-01
Vprtstp: contraction number = 8.537693e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.871254e-07
Vprtstp: contraction number = 2.056894e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.096030e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.000533e+00
Vpmg_setPart:  lower corner = (-29.889, 2.933, 60.851)
Vpmg_setPart:  upper corner = (51.545, 82.033, 158.607)
Vpmg_setPart:  actual minima = (-29.889, 2.933, 60.851)
Vpmg_setPart:  actual maxima = (51.545, 82.033, 158.607)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.889, 12.933, 70.851
VPMG::focusFillBound -- New mesh maxs = 41.545, 72.033, 148.607
VPMG::focusFillBound -- Old mesh mins = -29.889, 2.933, 60.851
VPMG::focusFillBound -- Old mesh maxs = 51.545, 82.033, 158.607
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.239040
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.226950e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 2.584600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 5.159700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.069640e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 3227598.942110
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.142134e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.303992e+05
Vprtstp: contraction number = 3.303992e+05
Vnewton: Attempting damping, relres = 0.096915
Vnewton: Attempting damping, relres = 0.543772
Vnewton: Damping accepted, relres = 0.096915
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.691497e-02
Vprtstp: contraction number = 9.691497e-02
Vnewton: Using errtol_s: 312802.642636
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.285675e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.324974e+04
Vprtstp: contraction number = 4.324974e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.263835e-02
Vprtstp: contraction number = 1.304066e-01
Vnewton: Using errtol_s: 40791.522379
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.413185e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.559483e+03
Vprtstp: contraction number = 6.559483e+03
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.893048e-03
Vprtstp: contraction number = 1.497860e-01
Vnewton: Using errtol_s: 6110.000117
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.518103e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.086479e+03
Vprtstp: contraction number = 1.086479e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.050096e-04
Vprtstp: contraction number = 1.611209e-01
Vnewton: Using errtol_s: 984.448670
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.622303e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.913779e+02
Vprtstp: contraction number = 1.913779e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.336920e-05
Vprtstp: contraction number = 1.749755e-01
Vnewton: Using errtol_s: 172.254360
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.726958e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.606257e+01
Vprtstp: contraction number = 3.606257e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.005588e-05
Vprtstp: contraction number = 1.884210e-01
Vnewton: Using errtol_s: 32.456340
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.830668e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.111159e+00
Vprtstp: contraction number = 7.111159e+00
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.982912e-06
Vprtstp: contraction number = 1.971893e-01
Vnewton: Using errtol_s: 6.400043
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.933972e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.444135e+00
Vprtstp: contraction number = 1.444135e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.026899e-07
Vprtstp: contraction number = 2.030801e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 9.422700e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.033134e+00
Vpmg_setPart:  lower corner = (-19.889, 12.933, 70.851)
Vpmg_setPart:  upper corner = (41.545, 72.033, 148.607)
Vpmg_setPart:  actual minima = (-19.889, 12.933, 70.851)
Vpmg_setPart:  actual maxima = (41.545, 72.033, 148.607)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.264694e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:01 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2065 atoms
Valist_getStatistics:  Max atom coordinate:  (31.545, 62.033, 138.607)
Valist_getStatistics:  Min atom coordinate:  (-9.889, 22.933, 80.851)
Valist_getStatistics:  Molecule center:  (10.828, 42.483, 109.729)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.848271, 0.823958, 0.763719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.639937, 0.615625, 0.607469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.754402, 0.747155, 0.795409 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 51.545 82.033 158.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.889 2.933 60.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 41.545 72.033 148.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.889 12.933 70.851
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 41.545 72.033 148.607
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.889 12.933 70.851
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.237952
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.438880e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.541800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.589700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.484780e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.350483e-02
Vprtstp: contraction number = 7.350483e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.081954e-03
Vprtstp: contraction number = 1.235559e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.532788e-03
Vprtstp: contraction number = 1.687729e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.462007e-04
Vprtstp: contraction number = 1.606228e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.764099e-05
Vprtstp: contraction number = 1.935047e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.900690e-06
Vprtstp: contraction number = 1.868284e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.795013e-06
Vprtstp: contraction number = 2.016712e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.790227e-07
Vprtstp: contraction number = 2.111531e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.596400e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.558770e-01
Vpmg_setPart:  lower corner = (-29.889, 2.933, 60.851)
Vpmg_setPart:  upper corner = (51.545, 82.033, 158.607)
Vpmg_setPart:  actual minima = (-29.889, 2.933, 60.851)
Vpmg_setPart:  actual maxima = (51.545, 82.033, 158.607)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.889, 12.933, 70.851
VPMG::focusFillBound -- New mesh maxs = 41.545, 72.033, 148.607
VPMG::focusFillBound -- Old mesh mins = -29.889, 2.933, 60.851
VPMG::focusFillBound -- Old mesh maxs = 51.545, 82.033, 158.607
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.236448
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.169710e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.612000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.651000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.526113e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.832076e-02
Vprtstp: contraction number = 9.832076e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.264294e-02
Vprtstp: contraction number = 1.285887e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.030292e-03
Vprtstp: contraction number = 1.605871e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.423378e-04
Vprtstp: contraction number = 1.686150e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.725220e-05
Vprtstp: contraction number = 1.964498e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.379466e-05
Vprtstp: contraction number = 2.051183e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.978965e-06
Vprtstp: contraction number = 2.159507e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.859308e-07
Vprtstp: contraction number = 2.302581e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.627340e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.608280e-01
Vpmg_setPart:  lower corner = (-19.889, 12.933, 70.851)
Vpmg_setPart:  upper corner = (41.545, 72.033, 148.607)
Vpmg_setPart:  actual minima = (-19.889, 12.933, 70.851)
Vpmg_setPart:  actual maxima = (41.545, 72.033, 148.607)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.135245e+00
