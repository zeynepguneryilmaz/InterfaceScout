##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:27:45 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11557 atoms
Valist_getStatistics:  Max atom coordinate:  (-33.089, 100.884, 61.594)
Valist_getStatistics:  Min atom coordinate:  (-115.093, 29.302, -32.036)
Valist_getStatistics:  Molecule center:  (-74.091, 65.093, 14.779)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.953156, 0.871734, 0.835187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.796906, 0.715484, 0.710187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.836071, 0.82076, 0.850333 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = -13.089 120.884 81.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -135.093 9.302 -52.036
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -23.089 110.884 71.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -125.093 19.302 -42.036
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -23.089 110.884 71.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -125.093 19.302 -42.036
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.559369
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.079132e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.580700e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.122290e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.307276e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 13016759.700319
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.465974e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.338622e+05
Vprtstp: contraction number = 7.338622e+05
Vnewton: Attempting damping, relres = 0.053127
Vnewton: Attempting damping, relres = 0.520724
Vnewton: Damping accepted, relres = 0.053127
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.312737e-02
Vprtstp: contraction number = 5.312737e-02
Vnewton: Using errtol_s: 691546.251770
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.789264e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.250477e+04
Vprtstp: contraction number = 9.250477e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.698595e-03
Vprtstp: contraction number = 1.260856e-01
Vnewton: Using errtol_s: 87194.001956
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.034309e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.452921e+04
Vprtstp: contraction number = 1.452921e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.033747e-03
Vprtstp: contraction number = 1.543230e-01
Vnewton: Using errtol_s: 13456.040795
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.282025e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.547831e+03
Vprtstp: contraction number = 2.547831e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.763891e-04
Vprtstp: contraction number = 1.706308e-01
Vnewton: Using errtol_s: 2296.014648
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.528470e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.641614e+02
Vprtstp: contraction number = 4.641614e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.209466e-05
Vprtstp: contraction number = 1.819537e-01
Vnewton: Using errtol_s: 417.768416
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.774627e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.877579e+01
Vprtstp: contraction number = 8.877579e+01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.138150e-06
Vprtstp: contraction number = 1.912515e-01
Vnewton: Using errtol_s: 79.898823
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.022454e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.935167e+01
Vprtstp: contraction number = 1.935167e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.338013e-06
Vprtstp: contraction number = 2.179831e-01
Vnewton: Using errtol_s: 17.416590
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.271222e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.740806e+00
Vprtstp: contraction number = 4.740806e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.277874e-07
Vprtstp: contraction number = 2.449808e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.151049e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.350553e+00
Vpmg_setPart:  lower corner = (-135.093, 9.302, -52.036)
Vpmg_setPart:  upper corner = (-13.089, 120.884, 81.594)
Vpmg_setPart:  actual minima = (-135.093, 9.302, -52.036)
Vpmg_setPart:  actual maxima = (-13.089, 120.884, 81.594)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -125.093, 19.302, -42.036
VPMG::focusFillBound -- New mesh maxs = -23.089, 110.884, 71.594
VPMG::focusFillBound -- Old mesh mins = -135.093, 9.302, -52.036
VPMG::focusFillBound -- Old mesh maxs = -13.089, 120.884, 81.594
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.551628
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.211100e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 5.655000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 1.122690e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.873659e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 15159748.594926
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.035309e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.115679e+06
Vprtstp: contraction number = 1.115679e+06
Vnewton: Attempting damping, relres = 0.068242
Vnewton: Attempting damping, relres = 0.529394
Vnewton: Damping accepted, relres = 0.068242
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.824250e-02
Vprtstp: contraction number = 6.824250e-02
Vnewton: Using errtol_s: 1034539.094802
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.357711e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.420196e+05
Vprtstp: contraction number = 1.420196e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.693990e-03
Vprtstp: contraction number = 1.273985e-01
Vnewton: Using errtol_s: 131798.695483
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.603234e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.185830e+04
Vprtstp: contraction number = 2.185830e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.322850e-03
Vprtstp: contraction number = 1.521568e-01
Vnewton: Using errtol_s: 20054.066042
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.849460e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.728480e+03
Vprtstp: contraction number = 3.728480e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.215012e-04
Vprtstp: contraction number = 1.674425e-01
Vnewton: Using errtol_s: 3357.902851
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.097106e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.625462e+02
Vprtstp: contraction number = 6.625462e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.933613e-05
Vprtstp: contraction number = 1.775888e-01
Vnewton: Using errtol_s: 596.325892
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.346181e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.207928e+02
Vprtstp: contraction number = 1.207928e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.171214e-06
Vprtstp: contraction number = 1.823060e-01
Vnewton: Using errtol_s: 108.713798
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.593951e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.592488e+01
Vprtstp: contraction number = 2.592488e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.539131e-06
Vprtstp: contraction number = 2.146263e-01
Vnewton: Using errtol_s: 23.332840
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.842897e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.572795e+00
Vprtstp: contraction number = 6.572795e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.902121e-07
Vprtstp: contraction number = 2.535275e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 2.156096e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.352626e+00
Vpmg_setPart:  lower corner = (-125.093, 19.302, -42.036)
Vpmg_setPart:  upper corner = (-23.089, 110.884, 71.594)
Vpmg_setPart:  actual minima = (-125.093, 19.302, -42.036)
Vpmg_setPart:  actual maxima = (-23.089, 110.884, 71.594)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.617339e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:27:55 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11557 atoms
Valist_getStatistics:  Max atom coordinate:  (-33.089, 100.884, 61.594)
Valist_getStatistics:  Min atom coordinate:  (-115.093, 29.302, -32.036)
Valist_getStatistics:  Molecule center:  (-74.091, 65.093, 14.779)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.953156, 0.871734, 0.835187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.796906, 0.715484, 0.710187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.836071, 0.82076, 0.850333 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = -13.089 120.884 81.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -135.093 9.302 -52.036
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -23.089 110.884 71.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -125.093 19.302 -42.036
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -23.089 110.884 71.594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -125.093 19.302 -42.036
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.557000
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.068526e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.552500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.531610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.337089e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.543101e-02
Vprtstp: contraction number = 5.543101e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 7.224899e-03
Vprtstp: contraction number = 1.303404e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.432758e-03
Vprtstp: contraction number = 1.983083e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.426306e-04
Vprtstp: contraction number = 2.391407e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.141473e-04
Vprtstp: contraction number = 3.331497e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.203051e-05
Vprtstp: contraction number = 2.806068e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.246171e-05
Vprtstp: contraction number = 3.890574e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.756589e-06
Vprtstp: contraction number = 3.014506e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.498529e-06
Vprtstp: contraction number = 3.989069e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.661404e-07
Vprtstp: contraction number = 3.110653e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.127919e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.368159e+00
Vpmg_setPart:  lower corner = (-135.093, 9.302, -52.036)
Vpmg_setPart:  upper corner = (-13.089, 120.884, 81.594)
Vpmg_setPart:  actual minima = (-135.093, 9.302, -52.036)
Vpmg_setPart:  actual maxima = (-13.089, 120.884, 81.594)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -125.093, 19.302, -42.036
VPMG::focusFillBound -- New mesh maxs = -23.089, 110.884, 71.594
VPMG::focusFillBound -- Old mesh mins = -135.093, 9.302, -52.036
VPMG::focusFillBound -- Old mesh maxs = -13.089, 120.884, 81.594
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.549823
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.207383e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.677100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.476560e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.917173e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.013561e-02
Vprtstp: contraction number = 7.013561e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.160336e-03
Vprtstp: contraction number = 1.306089e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.597747e-03
Vprtstp: contraction number = 1.744201e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.520040e-04
Vprtstp: contraction number = 2.203128e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.107777e-04
Vprtstp: contraction number = 3.147057e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.432583e-05
Vprtstp: contraction number = 3.098623e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.435535e-05
Vprtstp: contraction number = 4.182083e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.094795e-06
Vprtstp: contraction number = 3.549057e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.289670e-06
Vprtstp: contraction number = 4.494135e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.408018e-07
Vprtstp: contraction number = 3.672153e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.147510e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.383800e+00
Vpmg_setPart:  lower corner = (-125.093, 19.302, -42.036)
Vpmg_setPart:  upper corner = (-23.089, 110.884, 71.594)
Vpmg_setPart:  actual minima = (-125.093, 19.302, -42.036)
Vpmg_setPart:  actual maxima = (-23.089, 110.884, 71.594)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.631879e+00
