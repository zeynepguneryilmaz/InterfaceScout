##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:25:40 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1672 atoms
Valist_getStatistics:  Max atom coordinate:  (63.579, 38.926, 22.463)
Valist_getStatistics:  Min atom coordinate:  (26.949, 8.407, -13.769)
Valist_getStatistics:  Molecule center:  (45.264, 23.6665, 4.347)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.798229, 1.10186, 0.794083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.589896, 0.789359, 0.58575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.739006, 0.716388, 0.737643 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 83.579 58.926 42.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 6.949 -11.593 -33.769
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 73.579 48.926 32.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 16.949 -1.593 -23.769
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 73.579 48.926 32.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 16.949 -1.593 -23.769
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.189385
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.209950e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.236200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.545400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.739970e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.284853e-02
Vprtstp: contraction number = 9.284853e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.667154e-02
Vprtstp: contraction number = 2.872586e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.181994e-03
Vprtstp: contraction number = 3.442619e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.567014e-03
Vprtstp: contraction number = 3.884792e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.533734e-03
Vprtstp: contraction number = 4.299769e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.180448e-04
Vprtstp: contraction number = 4.029674e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.874389e-04
Vprtstp: contraction number = 4.650778e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.141786e-04
Vprtstp: contraction number = 3.972272e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.462708e-05
Vprtstp: contraction number = 4.784355e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.139352e-05
Vprtstp: contraction number = 3.916285e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.036702e-05
Vprtstp: contraction number = 4.845868e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.023604e-06
Vprtstp: contraction number = 3.881158e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.963817e-06
Vprtstp: contraction number = 4.880740e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.580712e-07
Vprtstp: contraction number = 3.860194e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.707940e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.162350e-01
Vpmg_setPart:  lower corner = (6.949, -11.593, -33.769)
Vpmg_setPart:  upper corner = (83.579, 58.926, 42.463)
Vpmg_setPart:  actual minima = (6.949, -11.593, -33.769)
Vpmg_setPart:  actual maxima = (83.579, 58.926, 42.463)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 16.949, -1.593, -23.769
VPMG::focusFillBound -- New mesh maxs = 73.579, 48.926, 32.463
VPMG::focusFillBound -- Old mesh mins = 6.949, -11.593, -33.769
VPMG::focusFillBound -- Old mesh maxs = 83.579, 58.926, 42.463
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.186886
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.743650e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.235000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.531400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.065395e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.179885e-01
Vprtstp: contraction number = 1.179885e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.270299e-02
Vprtstp: contraction number = 1.924170e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.070192e-03
Vprtstp: contraction number = 2.673741e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.811009e-03
Vprtstp: contraction number = 2.983445e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.860265e-04
Vprtstp: contraction number = 3.788091e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.434700e-04
Vprtstp: contraction number = 3.548988e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.076081e-04
Vprtstp: contraction number = 4.419768e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.007407e-05
Vprtstp: contraction number = 3.724076e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.851872e-05
Vprtstp: contraction number = 4.621121e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.921749e-06
Vprtstp: contraction number = 3.737705e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.231748e-06
Vprtstp: contraction number = 4.668976e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.205251e-06
Vprtstp: contraction number = 3.729409e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.647552e-07
Vprtstp: contraction number = 4.685789e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.529710e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.976730e-01
Vpmg_setPart:  lower corner = (16.949, -1.593, -23.769)
Vpmg_setPart:  upper corner = (73.579, 48.926, 32.463)
Vpmg_setPart:  actual minima = (16.949, -1.593, -23.769)
Vpmg_setPart:  actual maxima = (73.579, 48.926, 32.463)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.436950e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:25:41 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 65, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1672 atoms
Valist_getStatistics:  Max atom coordinate:  (63.579, 38.926, 22.463)
Valist_getStatistics:  Min atom coordinate:  (26.949, 8.407, -13.769)
Valist_getStatistics:  Molecule center:  (45.264, 23.6665, 4.347)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.798229, 1.10186, 0.794083
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.589896, 0.789359, 0.58575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.739006, 0.716388, 0.737643 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 83.579 58.926 42.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 6.949 -11.593 -33.769
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 73.579 48.926 32.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 16.949 -1.593 -23.769
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 73.579 48.926 32.463
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 16.949 -1.593 -23.769
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.188704
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.200520e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.236400e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.403900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.709160e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 1842392.491226
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.017860e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.617200e+05
Vprtstp: contraction number = 1.617200e+05
Vnewton: Attempting damping, relres = 1.573039
Vnewton: Attempting damping, relres = 0.534868
Vnewton: Attempting damping, relres = 0.766405
Vnewton: Damping accepted, relres = 0.534868
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.348677e-01
Vprtstp: contraction number = 5.348677e-01
Vnewton: Using errtol_s: 985436.227188
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.756120e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.127890e+04
Vprtstp: contraction number = 9.127890e+04
Vnewton: Attempting damping, relres = 0.045942
Vnewton: Attempting damping, relres = 0.287280
Vnewton: Damping accepted, relres = 0.045942
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 4.594182e-02
Vprtstp: contraction number = 8.589380e-02
Vnewton: Using errtol_s: 84642.858224
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.318500e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.642326e+04
Vprtstp: contraction number = 1.642326e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.126385e-03
Vprtstp: contraction number = 1.768843e-01
Vnewton: Using errtol_s: 14971.991113
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.748630e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.908641e+03
Vprtstp: contraction number = 3.908641e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.912155e-03
Vprtstp: contraction number = 2.353021e-01
Vnewton: Using errtol_s: 3522.940588
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.177740e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.136229e+03
Vprtstp: contraction number = 1.136229e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.559222e-04
Vprtstp: contraction number = 2.907307e-01
Vnewton: Using errtol_s: 1024.226865
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.605930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.073683e+02
Vprtstp: contraction number = 4.073683e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.991174e-04
Vprtstp: contraction number = 3.581749e-01
Vnewton: Using errtol_s: 366.852385
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.033580e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.748538e+02
Vprtstp: contraction number = 1.748538e+02
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.544841e-05
Vprtstp: contraction number = 4.291359e-01
Vnewton: Using errtol_s: 157.429515
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.462930e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.484686e+01
Vprtstp: contraction number = 8.484686e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.145625e-05
Vprtstp: contraction number = 4.851612e-01
Vnewton: Using errtol_s: 76.378687
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.892110e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.383061e+01
Vprtstp: contraction number = 4.383061e+01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.141353e-05
Vprtstp: contraction number = 5.165333e-01
Vnewton: Using errtol_s: 39.452132
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.319820e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.328544e+01
Vprtstp: contraction number = 2.328544e+01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.137553e-05
Vprtstp: contraction number = 5.312310e-01
Vnewton: Using errtol_s: 20.958196
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.752240e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.250732e+01
Vprtstp: contraction number = 1.250732e+01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.109968e-06
Vprtstp: contraction number = 5.371149e-01
Vnewton: Using errtol_s: 11.256959
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.182670e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.746009e+00
Vprtstp: contraction number = 6.746009e+00
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.295452e-06
Vprtstp: contraction number = 5.393566e-01
Vnewton: Using errtol_s: 6.071515
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.616680e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.644539e+00
Vprtstp: contraction number = 3.644539e+00
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.780357e-06
Vprtstp: contraction number = 5.402467e-01
Vnewton: Using errtol_s: 3.280116
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.004843e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.970280e+00
Vprtstp: contraction number = 1.970280e+00
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.624773e-07
Vprtstp: contraction number = 5.406092e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 6.663000e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.093220e-01
Vpmg_setPart:  lower corner = (6.949, -11.593, -33.769)
Vpmg_setPart:  upper corner = (83.579, 58.926, 42.463)
Vpmg_setPart:  actual minima = (6.949, -11.593, -33.769)
Vpmg_setPart:  actual maxima = (83.579, 58.926, 42.463)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 16.949, -1.593, -23.769
VPMG::focusFillBound -- New mesh maxs = 73.579, 48.926, 32.463
VPMG::focusFillBound -- Old mesh mins = 6.949, -11.593, -33.769
VPMG::focusFillBound -- Old mesh maxs = 83.579, 58.926, 42.463
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.188849
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.745150e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (097, 065, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.263800e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 033, 049)
Vbuildops: Galer: (025, 017, 025)
Vbuildops: Galer: (013, 009, 013)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.415900e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.456435e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 2380649.679413
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.487959e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.949909e+05
Vprtstp: contraction number = 2.949909e+05
Vnewton: Attempting damping, relres = 1.823169
Vnewton: Attempting damping, relres = 0.553047
Vnewton: Attempting damping, relres = 0.775547
Vnewton: Damping accepted, relres = 0.553047
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.530468e-01
Vprtstp: contraction number = 5.530468e-01
Vnewton: Using errtol_s: 1316610.638788
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.557794e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.690314e+05
Vprtstp: contraction number = 1.690314e+05
Vnewton: Attempting damping, relres = 0.064899
Vnewton: Attempting damping, relres = 0.306932
Vnewton: Damping accepted, relres = 0.064899
Vnewton: Damping disabled
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.489861e-02
Vprtstp: contraction number = 1.173474e-01
Vnewton: Using errtol_s: 154500.861696
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.614876e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.951802e+04
Vprtstp: contraction number = 2.951802e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.121770e-02
Vprtstp: contraction number = 1.728496e-01
Vnewton: Using errtol_s: 26705.415858
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.658778e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.102272e+03
Vprtstp: contraction number = 6.102272e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.309285e-03
Vprtstp: contraction number = 2.058608e-01
Vnewton: Using errtol_s: 5497.597911
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.702383e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.387800e+03
Vprtstp: contraction number = 1.387800e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.253162e-04
Vprtstp: contraction number = 2.274800e-01
Vnewton: Using errtol_s: 1250.593764
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.745996e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.369842e+02
Vprtstp: contraction number = 3.369842e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.274851e-04
Vprtstp: contraction number = 2.426827e-01
Vnewton: Using errtol_s: 303.497456
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.789129e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.838789e+01
Vprtstp: contraction number = 8.838789e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.342636e-05
Vprtstp: contraction number = 2.621981e-01
Vnewton: Using errtol_s: 79.576443
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.832605e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.534257e+01
Vprtstp: contraction number = 2.534257e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.582292e-06
Vprtstp: contraction number = 2.866688e-01
Vnewton: Using errtol_s: 22.812080
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.875764e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.842626e+00
Vprtstp: contraction number = 7.842626e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.965106e-06
Vprtstp: contraction number = 3.094360e-01
Vnewton: Using errtol_s: 7.058878
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.919578e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.582264e+00
Vprtstp: contraction number = 2.582264e+00
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.762494e-07
Vprtstp: contraction number = 3.292460e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 4.959420e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.390960e-01
Vpmg_setPart:  lower corner = (16.949, -1.593, -23.769)
Vpmg_setPart:  upper corner = (73.579, 48.926, 32.463)
Vpmg_setPart:  actual minima = (16.949, -1.593, -23.769)
Vpmg_setPart:  actual maxima = (73.579, 48.926, 32.463)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.067732e+00
