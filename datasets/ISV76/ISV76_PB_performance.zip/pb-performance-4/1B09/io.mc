##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:34 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16130 atoms
Valist_getStatistics:  Max atom coordinate:  (170.12, 197.484, 59.506)
Valist_getStatistics:  Min atom coordinate:  (79.608, 105.555, -45.871)
Valist_getStatistics:  Molecule center:  (124.864, 151.519, 6.8175)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.8157, 0.824556, 0.908606
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.6907, 0.699556, 0.783606
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.846757, 0.848403, 0.862427 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 190.12 217.484 79.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 59.608 85.555 -65.871
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 180.12 207.484 69.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 69.608 95.555 -55.871
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 180.12 207.484 69.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 69.608 95.555 -55.871
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6992476 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.680607
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.496435e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.037180e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.092590e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.110059e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.235303e-02
Vprtstp: contraction number = 6.235303e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.357947e-03
Vprtstp: contraction number = 1.340424e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.919970e-03
Vprtstp: contraction number = 2.297179e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.432701e-04
Vprtstp: contraction number = 2.308734e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.559697e-04
Vprtstp: contraction number = 3.518615e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.393333e-05
Vprtstp: contraction number = 2.816787e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.724342e-05
Vprtstp: contraction number = 3.924906e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.354577e-06
Vprtstp: contraction number = 3.105288e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.149473e-06
Vprtstp: contraction number = 4.014273e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.061277e-07
Vprtstp: contraction number = 3.285119e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.163846e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.728457e+00
Vpmg_setPart:  lower corner = (59.608, 85.555, -65.871)
Vpmg_setPart:  upper corner = (190.12, 217.484, 79.506)
Vpmg_setPart:  actual minima = (59.608, 85.555, -65.871)
Vpmg_setPart:  actual maxima = (190.12, 217.484, 79.506)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6992476 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 69.608, 95.555, -55.871
VPMG::focusFillBound -- New mesh maxs = 180.12, 207.484, 69.506
VPMG::focusFillBound -- Old mesh mins = 59.608, 85.555, -65.871
VPMG::focusFillBound -- Old mesh maxs = 190.12, 217.484, 79.506
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.657157
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.708390e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.040610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.071780e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.055902e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.614115e-02
Vprtstp: contraction number = 7.614115e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.037135e-02
Vprtstp: contraction number = 1.362122e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.350423e-03
Vprtstp: contraction number = 2.266265e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.838037e-04
Vprtstp: contraction number = 2.483824e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.363282e-04
Vprtstp: contraction number = 4.048076e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.781027e-05
Vprtstp: contraction number = 3.292467e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.639330e-05
Vprtstp: contraction number = 4.677184e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.312679e-05
Vprtstp: contraction number = 3.606926e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.238285e-06
Vprtstp: contraction number = 4.752329e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.364450e-06
Vprtstp: contraction number = 3.790225e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.123466e-06
Vprtstp: contraction number = 4.751487e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.397269e-07
Vprtstp: contraction number = 3.914022e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.595196e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.158133e+00
Vpmg_setPart:  lower corner = (69.608, 95.555, -55.871)
Vpmg_setPart:  upper corner = (180.12, 207.484, 69.506)
Vpmg_setPart:  actual minima = (69.608, 95.555, -55.871)
Vpmg_setPart:  actual maxima = (180.12, 207.484, 69.506)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.392275e+01
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:20:48 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16130 atoms
Valist_getStatistics:  Max atom coordinate:  (170.12, 197.484, 59.506)
Valist_getStatistics:  Min atom coordinate:  (79.608, 105.555, -45.871)
Valist_getStatistics:  Molecule center:  (124.864, 151.519, 6.8175)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.8157, 0.824556, 0.908606
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.6907, 0.699556, 0.783606
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.846757, 0.848403, 0.862427 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 190.12 217.484 79.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 59.608 85.555 -65.871
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 180.12 207.484 69.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 69.608 95.555 -55.871
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 180.12 207.484 69.506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 69.608 95.555 -55.871
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6992476 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.667011
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.476546e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.036140e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.465560e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.919625e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 18092446.959484
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.173252e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.094011e+06
Vprtstp: contraction number = 1.094011e+06
Vnewton: Attempting damping, relres = 0.062064
Vnewton: Attempting damping, relres = 0.522679
Vnewton: Damping accepted, relres = 0.062064
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.206394e-02
Vprtstp: contraction number = 6.206394e-02
Vnewton: Using errtol_s: 1122888.593289
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.690240e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.415050e+05
Vprtstp: contraction number = 1.415050e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 8.433450e-03
Vprtstp: contraction number = 1.358832e-01
Vnewton: Using errtol_s: 152581.745590
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.101895e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.321883e+04
Vprtstp: contraction number = 2.321883e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.353539e-03
Vprtstp: contraction number = 1.604965e-01
Vnewton: Using errtol_s: 24488.831175
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.518278e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.379915e+03
Vprtstp: contraction number = 4.379915e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.306506e-04
Vprtstp: contraction number = 1.704056e-01
Vnewton: Using errtol_s: 4173.033625
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.931416e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.628710e+02
Vprtstp: contraction number = 8.628710e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.300403e-05
Vprtstp: contraction number = 1.864466e-01
Vnewton: Using errtol_s: 778.048086
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.344945e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.780230e+02
Vprtstp: contraction number = 1.780230e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.856061e-06
Vprtstp: contraction number = 2.059356e-01
Vnewton: Using errtol_s: 160.227807
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.759233e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.290897e+01
Vprtstp: contraction number = 4.290897e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.134487e-06
Vprtstp: contraction number = 2.410199e-01
Vnewton: Using errtol_s: 38.618097
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.171952e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.191201e+01
Vprtstp: contraction number = 1.191201e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.925577e-07
Vprtstp: contraction number = 2.776113e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.565180e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.960257e+00
Vpmg_setPart:  lower corner = (59.608, 85.555, -65.871)
Vpmg_setPart:  upper corner = (190.12, 217.484, 79.506)
Vpmg_setPart:  actual minima = (59.608, 85.555, -65.871)
Vpmg_setPart:  actual maxima = (190.12, 217.484, 79.506)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6992476 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 69.608, 95.555, -55.871
VPMG::focusFillBound -- New mesh maxs = 180.12, 207.484, 69.506
VPMG::focusFillBound -- Old mesh mins = 59.608, 85.555, -65.871
VPMG::focusFillBound -- Old mesh maxs = 190.12, 217.484, 79.506
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.655278
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.704096e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 1.036450e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 2.511010e-01
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.160248e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 20570503.784082
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.185788e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.572562e+06
Vprtstp: contraction number = 1.572562e+06
Vnewton: Attempting damping, relres = 0.075367
Vnewton: Attempting damping, relres = 0.530674
Vnewton: Damping accepted, relres = 0.075367
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.536659e-02
Vprtstp: contraction number = 7.536659e-02
Vnewton: Using errtol_s: 1550328.765248
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.237936e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.046832e+05
Vprtstp: contraction number = 2.046832e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.013069e-02
Vprtstp: contraction number = 1.344188e-01
Vnewton: Using errtol_s: 208393.327162
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.279423e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.276518e+04
Vprtstp: contraction number = 3.276518e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.593825e-03
Vprtstp: contraction number = 1.573264e-01
Vnewton: Using errtol_s: 32785.781826
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.320884e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.963216e+03
Vprtstp: contraction number = 5.963216e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.683951e-04
Vprtstp: contraction number = 1.683968e-01
Vnewton: Using errtol_s: 5521.021932
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.363073e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.148230e+03
Vprtstp: contraction number = 1.148230e+03
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.024315e-05
Vprtstp: contraction number = 1.871985e-01
Vnewton: Using errtol_s: 1033.526894
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.404626e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.226257e+02
Vprtstp: contraction number = 2.226257e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.740530e-06
Vprtstp: contraction number = 1.938678e-01
Vnewton: Using errtol_s: 200.367605
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.445876e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.628244e+01
Vprtstp: contraction number = 5.628244e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.462575e-06
Vprtstp: contraction number = 2.528173e-01
Vnewton: Using errtol_s: 50.656398
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.487256e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.732765e+01
Vprtstp: contraction number = 1.732765e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.581228e-07
Vprtstp: contraction number = 3.078578e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 3.580925e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.980381e+00
Vpmg_setPart:  lower corner = (69.608, 95.555, -55.871)
Vpmg_setPart:  upper corner = (180.12, 207.484, 69.506)
Vpmg_setPart:  actual minima = (69.608, 95.555, -55.871)
Vpmg_setPart:  actual maxima = (180.12, 207.484, 69.506)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.595697e+01
