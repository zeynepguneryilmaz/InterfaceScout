##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing npbe...
PBEparm_parseToken:  trying npbe...
NOsh: parsed npbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7182 atoms
Valist_getStatistics:  Max atom coordinate:  (53.332, 68.956, 64.163)
Valist_getStatistics:  Min atom coordinate:  (-11.345, 12.845, 6.037)
Valist_getStatistics:  Molecule center:  (20.9935, 40.9005, 35.1)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.817789, 1.00116, 0.766609
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.661539, 0.792823, 0.610359
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.808936, 0.791907, 0.79618 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 73.332 88.956 84.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -31.345 -7.155 -13.963
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 63.332 78.956 74.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -21.345 2.845 -3.963
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 63.332 78.956 74.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -21.345 2.845 -3.963
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.942889
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.268889e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.296600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.970500e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.408464e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 7801387.046546
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.505777e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.325963e+05
Vprtstp: contraction number = 5.325963e+05
Vnewton: Attempting damping, relres = 0.063657
Vnewton: Attempting damping, relres = 0.525299
Vnewton: Damping accepted, relres = 0.063657
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.365712e-02
Vprtstp: contraction number = 6.365712e-02
Vnewton: Using errtol_s: 496613.826431
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.709393e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.784363e+04
Vprtstp: contraction number = 7.784363e+04
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.258605e-03
Vprtstp: contraction number = 1.454449e-01
Vnewton: Using errtol_s: 72229.960670
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.857113e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.400294e+04
Vprtstp: contraction number = 1.400294e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.637309e-03
Vprtstp: contraction number = 1.768419e-01
Vnewton: Using errtol_s: 12773.281801
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.004792e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.740333e+03
Vprtstp: contraction number = 2.740333e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.161946e-04
Vprtstp: contraction number = 1.931185e-01
Vnewton: Using errtol_s: 2466.756644
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.153696e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.536627e+02
Vprtstp: contraction number = 5.536627e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.387318e-05
Vprtstp: contraction number = 2.020059e-01
Vnewton: Using errtol_s: 498.299391
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.300581e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.143663e+02
Vprtstp: contraction number = 1.143663e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.319378e-05
Vprtstp: contraction number = 2.065621e-01
Vnewton: Using errtol_s: 102.929765
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.445343e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.446566e+01
Vprtstp: contraction number = 2.446566e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.822460e-06
Vprtstp: contraction number = 2.139236e-01
Vnewton: Using errtol_s: 22.019105
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.589003e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 5.485489e+00
Vprtstp: contraction number = 5.485489e+00
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.328285e-07
Vprtstp: contraction number = 2.242117e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.293466e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.413458e+00
Vpmg_setPart:  lower corner = (-31.345, -7.155, -13.963)
Vpmg_setPart:  upper corner = (73.332, 88.956, 84.163)
Vpmg_setPart:  actual minima = (-31.345, -7.155, -13.963)
Vpmg_setPart:  actual maxima = (73.332, 88.956, 84.163)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 1, mgsolv = 0
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -21.345, 2.845, -3.963
VPMG::focusFillBound -- New mesh maxs = 63.332, 78.956, 74.163
VPMG::focusFillBound -- Old mesh mins = -31.345, -7.155, -13.963
VPMG::focusFillBound -- Old mesh maxs = 73.332, 88.956, 84.163
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.936784
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.375623e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vnewdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vnewdrv2: fine problem setup).  CPU TIME = 3.387600e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vnewdrv2: coarse problem setup).  CPU TIME = 6.741000e-02
Vnm_tstart: starting timer 30 (Vnewdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.201176e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vnewton: Damping enabled
Vnewton: Using errtol_s: 9268114.786757
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.295488e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.703684e+05
Vprtstp: contraction number = 8.703684e+05
Vnewton: Attempting damping, relres = 0.086760
Vnewton: Attempting damping, relres = 0.538283
Vnewton: Damping accepted, relres = 0.086760
Vnewton: Damping disabled
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.676029e-02
Vprtstp: contraction number = 8.676029e-02
Vnewton: Using errtol_s: 804104.282803
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.483532e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.277004e+05
Vprtstp: contraction number = 1.277004e+05
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.278411e-02
Vprtstp: contraction number = 1.473497e-01
Vnewton: Using errtol_s: 118484.564743
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.634485e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 2.258628e+04
Vprtstp: contraction number = 2.258628e+04
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.245863e-03
Vprtstp: contraction number = 1.756762e-01
Vnewton: Using errtol_s: 20814.918194
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.777821e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.291705e+03
Vprtstp: contraction number = 4.291705e+03
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.211535e-04
Vprtstp: contraction number = 1.875241e-01
Vnewton: Using errtol_s: 3903.299347
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.919909e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.470904e+02
Vprtstp: contraction number = 8.470904e+02
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.225277e-05
Vprtstp: contraction number = 1.953035e-01
Vnewton: Using errtol_s: 762.328107
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.059567e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.763989e+02
Vprtstp: contraction number = 1.763989e+02
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.712912e-05
Vprtstp: contraction number = 2.082497e-01
Vnewton: Using errtol_s: 158.754635
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.197791e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 4.140950e+01
Vprtstp: contraction number = 4.140950e+01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.021116e-06
Vprtstp: contraction number = 2.347532e-01
Vnewton: Using errtol_s: 37.268164
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.336897e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.102408e+01
Vprtstp: contraction number = 1.102408e+01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.070513e-06
Vprtstp: contraction number = 2.662228e-01
Vnewton: Using errtol_s: 9.921634
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.481873e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 3.302368e+00
Vprtstp: contraction number = 3.302368e+00
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.206835e-07
Vprtstp: contraction number = 2.995607e-01
Vnm_tstop: stopping timer 30 (Vnewdrv2: solve).  CPU TIME = 1.385095e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.503546e+00
Vpmg_setPart:  lower corner = (-21.345, 2.845, -3.963)
Vpmg_setPart:  upper corner = (63.332, 78.956, 74.163)
Vpmg_setPart:  actual minima = (-21.345, 2.845, -3.963)
Vpmg_setPart:  actual maxima = (63.332, 78.956, 74.163)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.935023e+00
##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Wed Nov 25 17:21:13 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path structure.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7182 atoms
Valist_getStatistics:  Max atom coordinate:  (53.332, 68.956, 64.163)
Valist_getStatistics:  Min atom coordinate:  (-11.345, 12.845, 6.037)
Valist_getStatistics:  Molecule center:  (20.9935, 40.9005, 35.1)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.817789, 1.00116, 0.766609
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.661539, 0.792823, 0.610359
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.808936, 0.791907, 0.79618 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 73.332 88.956 84.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -31.345 -7.155 -13.963
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 63.332 78.956 74.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -21.345 2.845 -3.963
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 63.332 78.956 74.163
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -21.345 2.845 -3.963
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.947927
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.276831e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.288600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.758500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.426373e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.577898e-02
Vprtstp: contraction number = 6.577898e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.849025e-03
Vprtstp: contraction number = 1.497291e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.905170e-03
Vprtstp: contraction number = 1.934374e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.296119e-04
Vprtstp: contraction number = 2.254980e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.150227e-04
Vprtstp: contraction number = 2.677363e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.243338e-05
Vprtstp: contraction number = 2.819737e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.004169e-05
Vprtstp: contraction number = 3.096098e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.066247e-06
Vprtstp: contraction number = 3.053517e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.018646e-06
Vprtstp: contraction number = 3.322128e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.220294e-07
Vprtstp: contraction number = 3.161346e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.208160e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.509510e-01
Vpmg_setPart:  lower corner = (-31.345, -7.155, -13.963)
Vpmg_setPart:  upper corner = (73.332, 88.956, 84.163)
Vpmg_setPart:  actual minima = (-31.345, -7.155, -13.963)
Vpmg_setPart:  actual maxima = (73.332, 88.956, 84.163)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.15
Vpbe_ctor2:  xkappa = 0.127314
Vpbe_ctor2:  Debye length = 7.85462
Vpbe_ctor2:  zkappa2 = 1.27304
Vpbe_ctor2:  zmagic = 7046.53
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -21.345, 2.845, -3.963
VPMG::focusFillBound -- New mesh maxs = 63.332, 78.956, 74.163
VPMG::focusFillBound -- Old mesh mins = -31.345, -7.155, -13.963
VPMG::focusFillBound -- Old mesh maxs = 73.332, 88.956, 84.163
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.937428
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.380019e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.342000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.002900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.565055e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.646123e-02
Vprtstp: contraction number = 8.646123e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.321652e-02
Vprtstp: contraction number = 1.528607e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.587356e-03
Vprtstp: contraction number = 1.957668e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.441189e-04
Vprtstp: contraction number = 2.489486e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.919444e-04
Vprtstp: contraction number = 2.979953e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.889213e-05
Vprtstp: contraction number = 3.589171e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.605757e-05
Vprtstp: contraction number = 3.782373e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.129766e-05
Vprtstp: contraction number = 4.335653e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.548901e-06
Vprtstp: contraction number = 4.026409e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.072569e-06
Vprtstp: contraction number = 4.556198e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.407597e-07
Vprtstp: contraction number = 4.056607e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.144440e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.479670e-01
Vpmg_setPart:  lower corner = (-21.345, 2.845, -3.963)
Vpmg_setPart:  upper corner = (63.332, 78.956, 74.163)
Vpmg_setPart:  actual minima = (-21.345, 2.845, -3.963)
Vpmg_setPart:  actual maxima = (63.332, 78.956, 74.163)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.629986e+00
