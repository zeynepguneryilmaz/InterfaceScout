// get running details
var runDetails = document.getElementById("rundetails");
var timestamp  = runDetails.getAttribute("data-timeStamp");
var rundir     = runDetails.getAttribute("data-rundir");
var runtype    = runDetails.getAttribute("data-runtype");
var pdbName    = runDetails.getAttribute("data-pdbName");

/// get ngl views
var potview, ratview;

function handleResize () {
    potview.handleResize();
    ratview.handleResize();
}

// handle window resize etc
window.addEventListener("orientationchange", handleResize, false);
window.addEventListener("resize", handleResize, false);

// CLASS TO HANDLE CHANGES IN VISUALISATION STATE
class proteinVisualisationClass {
    constructor(view, screenSize, calculation, representation, runtype){
        this.view           = view;
        this.screenSize     = screenSize;
        this.calculation    = calculation;
        if (runtype === "example"){
            this.path           = "/examples/patches/"+timestamp+"/"
        } else {
            this.path           = "/results/patches/"+rundir+"-"+timestamp+"/"
        }
        this.calculationPDB = this.path+calculation + ".pdb"
        this.representation = representation
        this.pdbName        = pdbName
        this.timestamp      = timestamp;
    }

    //method to initialise view to loaded pdb and surface, could be overloaded
    initialise(calculation){
        this.calculation = calculation;
        this.calculationPDB = this.path+calculation + ".pdb"

        this.getColor()

        this.changeView(this)
    } 
        
    //method to change the view
    changeView(fullscreenVisualisation){
        fullscreenVisualisation.view.removeAllComponents();
        fullscreenVisualisation.view.loadFile(fullscreenVisualisation.calculationPDB).then(function (component) {
            component.addRepresentation(fullscreenVisualisation.representation, { color: fullscreenVisualisation.color })
            component.autoView()
        })
    }
 
    //method to change the representation
    changeRepresentation(representation){
        this.representation = representation
        this.changeView(this)
    }

    getColor(){
        //set color depending on type of file loaded
        if (this.calculation === "potlfield"){
            this.color = potlColor
        } else if (this.calculation === "ratio"){
            this.color = ratColor
        }
    }
}


function fullscreenView(fullscreenVisualisation){
    color          = fullscreenVisualisation.color
    timestamp      = fullscreenVisualisation.timestamp
    representation = fullscreenVisualisation.representation
    calculation    = fullscreenVisualisation.calculation
    
    location.href='/cgi-bin/patches/fullscreen.php?timestamp=' + timestamp + '&file=' + calculation + '&pdbColor=' + color + '&representation=' + representation + '&rundir=' + rundir + '&pdbName=' + pdbName + '&runtype=' + runtype;
}

function addFullscreenButtons(){
    function getHeight(vh_val,pix_val){
        sum_val = ($(window).height() * (vh_val/100)) + pix_val;
        return sum_val+"px"
    }

    //Add little overlays
    function addElement( el ){
        Object.assign( el.style, {
            position: "absolute",
            zIndex: 10
        } );
        view.viewer.container.appendChild( el );
    }
    
    //make the representation buttons
    function createElementRep( name, properties, style ){
        var el = document.createElement( name );
        el.className = "rep_buttons inactive_button";
        Object.assign( el, properties );
        Object.assign( el.style, style );
        return el;
    }

    function createElementRepBack( name, properties, style ){
        var el = document.createElement( name );
        el.className = "back_buttons inactive_button";
        Object.assign( el, properties );
        Object.assign( el.style, style );
        return el;
    }
    
    //make the pdb buttons
    function createElementPDB( name, properties, style ){
        var el = document.createElement( name );
        el.className = "pdb_buttons inactive_button";
        Object.assign( el, properties );
        Object.assign( el.style, style );
        return el;
    }
    
    //make a text item
    function createElementTextHeader( name, properties, style ){
        var el = document.createElement( name );
        el.className = "title_header";
        Object.assign( el, properties );
        Object.assign( el.style, style );
        return el;
    }

    function createElementText( name, properties, style ){
        var el = document.createElement( name );
        el.className = "tool_header";
        Object.assign( el, properties );
        Object.assign( el.style, style );
        return el;
    }
    
    // Draw NAME
    //define the text element
    fileStructureText = createElementTextHeader('span', {
      innerText: "PDB: "+ pdbName
    }, { top: getHeight(1,1), left: '1rem', color: 'white' })
    //add the element
    addElement(fileStructureText)
    
    //Calculation
    //write calculations text
    fileStructureText = createElementText('span', {
      innerText: "Calculations"
    }, { top: getHeight(5,0), left: '1rem', color: 'white' })
    
    addElement(fileStructureText)
    
    //buttons for the pbd views
    potl_Button = createElementPDB ("input", {
        type: "button",
        value: "electrostatic potential",
        id: "potlfield_button",
        onclick: function(){
            fullscreenVisualisation.initialise("potlfield")
            updateButtons("calculation")
        }
    }, { top: getHeight(6,15), left: "1rem" } );
    
    ratio_Button = createElementPDB ("input", {
        type: "button",
        value: "NPP ratio",
        id: "ratio_button",
        onclick: function(){
            fullscreenVisualisation.initialise("ratio")
            updateButtons("calculation")
        }
    }, { top: getHeight(6,50), left: "1rem"} );
    
    addElement( potl_Button );
    addElement( ratio_Button );
    
    //Representation buttons
    
    fileStructureText = createElementText('span', {
      innerText: "Representations"
    }, { top: getHeight(23,0), left: '1rem', color: 'white' })
    
    addElement(fileStructureText)
    
    surface_Button = createElementRep ("input", {
        type: "button",
        value: "surface",
        id: "surface_button",
        onclick: function(){
            fullscreenVisualisation.changeRepresentation("surface")
            updateButtons("representation")
        }
    }, { top: getHeight(24,15), left: "1rem" } );
    
    licorice_Button = createElementRep ("input", {
        type: "button",
        value: "licorice",
        id: "licorice_button",
        onclick: function(){
            fullscreenVisualisation.changeRepresentation("licorice")
            updateButtons("representation")
        }
    }, { top: getHeight(24,50), left: "1rem" } );
    
    spacefill_Button = createElementRep ("input", {
        type: "button",
        value: "spacefill",
        id: "spacefill_button",
        onclick: function(){
            fullscreenVisualisation.changeRepresentation("spacefill")
            updateButtons("representation")
        }
    }, { top: getHeight(24,85), left: "1rem" } );
    
    cartoon_Button = createElementRep ("input", {
        type: "button",
        value: "cartoon",
        id: "cartoon_button",
        onclick: function(){
            fullscreenVisualisation.changeRepresentation("cartoon")
            updateButtons("representation")
        }
    }, { top: getHeight(24,120), left: "1rem" } );
    
    addElement( surface_Button );
    addElement( licorice_Button );
    addElement( spacefill_Button );
    addElement( cartoon_Button );
    
    //TOOL BUTTONS
    fileStructureText = createElementText('span', {
      innerText: "Tools"
    }, { top: getHeight(54,0), left: '1rem', color: 'white' })
    
    addElement(fileStructureText)
    
    //screenshot button
    screenshot_Button = createElementRep("input", {
        type: "button",
        id: "download_button",
        value: "Screenshot",
        onclick: function(){
          screenShot(fullscreenVisualisation)
          }
    }, { top: getHeight(55,15), left: "1rem" } );
    addElement( screenshot_Button );
    
    //download zip of results button
    download_Button = createElementRep("input", {
        type: "button",
        value: "Download PDB",
        onclick: function(){
            downloadPDB(fullscreenVisualisation)
        }
    }, { top: getHeight(55,50), left: "1rem" } );
    addElement( download_Button );
    
    //BACK BUTTONS
    backButton = createElementRepBack( "input", {
        type: "button",
        value: "Back",
        onclick: function(){
          if (runtype == "example"){
              location.href = "https://protein-sol.manchester.ac.uk/examples/patches/"+timestamp+"/results.html";
          } else {
              location.href = "https://protein-sol.manchester.ac.uk/results/patches/"+rundir+"-"+timestamp+"/results.html";
          }
        }
    }, { top: getHeight(55,85), left: "1rem" } );
    addElement( backButton );

}

//update the buttons depending on what view is chosen
function updateButtons(buttonChanged){
   //update buttons for calculation
   if (buttonChanged === "calculation"){
       //find the list of all active pdb buttons
       active_pdb_buttons = document.querySelectorAll(".pdb_buttons.active_button");
       //go through the list
       active_pdb_buttons.forEach(function(button){
           //and set the button to be inactive
           button.setAttribute("class","pdb_buttons inactive_button");
       });
       //activate the current pdb buttin
       document.getElementById(fullscreenVisualisation.calculation+"_button").setAttribute("class","pdb_buttons active_button");
       update_scale_text( fullscreenVisualisation.calculation )

   
   //update buttons if representation changed
   } else if (buttonChanged === "representation"){
       // decativate all rep buttons
       // fix me change me add querySelectorAll that ignores fullscreenVisualisation.representation_button match
       active_rep_buttons = document.querySelectorAll(".rep_buttons.active_button");
       active_rep_buttons.forEach(function(button){
           button.setAttribute("class","rep_buttons inactive_button");
       });
       //reactivate current button
       document.getElementById(fullscreenVisualisation.representation+"_button").setAttribute("class","rep_buttons active_button");
   }
}

var downloadInt = 0
function screenShot(currentVisualisation){
          currentVisualisation.view.makeImage( {
            factor: 8,
            antialias: true,
            trim: true,
            transparent: true
          } ).then( function( blob ){
            NGL.download( blob, timestamp+"-protein-sol-screenshot-patches-"+currentVisualisation.calculation+"-"+currentVisualisation.representation+"-screenshot-"+downloadInt+".png" );
            downloadInt = downloadInt + 1;
          } );
}

function downloadPDB(currentVisualisation){
    if (runtype == "example"){
       location.href = "/cgi-bin/utilities/download_example.php?app=patches&timestamp="+timestamp+"&idname="+pdbName+"&file="+currentVisualisation.calculation+".pdb";
    } else {
       location.href = "/cgi-bin/utilities/download_file.php?app=patches&dirname="+rundir+"&timestamp="+timestamp+"&idname="+pdbName+"&file="+currentVisualisation.calculation+".pdb";
    }
}

function matchView( currentVisualisation, matchVisualisation ) {
        viewMatrixRatio = matchVisualisation.view.viewerControls.getOrientation();
        currentVisualisation.view.viewerControls.orient(viewMatrixRatio);
}
