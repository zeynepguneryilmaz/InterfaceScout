##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:57:20 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9021 atoms
Valist_getStatistics:  Max atom coordinate:  (57.168, 63.229, 158.542)
Valist_getStatistics:  Min atom coordinate:  (-21.507, -1.455, 74.004)
Valist_getStatistics:  Molecule center:  (17.8305, 30.887, 116.273)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.717692, 0.720717, 0.665263
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.526339, 0.548951, 0.480617
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.733376, 0.761674, 0.722447 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.8305 30.887 116.273
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 86.7289 88.5444 190.782
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -51.0679 -26.7704 41.7635
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 68.359 74.8031 170.102
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -32.698 -13.0291 62.4439
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 68.359 74.8031 170.102
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -32.698 -13.0291 62.4439
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6241146 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.675537
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.983481e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.905050e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 113)
Vbuildops: Galer: (049, 041, 057)
Vbuildops: Galer: (025, 021, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.022566e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.369988e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.568867e-02
Vprtstp: contraction number = 9.568867e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.959852e-02
Vprtstp: contraction number = 2.048154e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.588220e-03
Vprtstp: contraction number = 4.892319e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.616123e-03
Vprtstp: contraction number = 3.771423e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.332128e-03
Vprtstp: contraction number = 6.449249e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.969620e-04
Vprtstp: contraction number = 4.274903e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.366409e-04
Vprtstp: contraction number = 6.385809e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.849166e-04
Vprtstp: contraction number = 4.475311e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.783135e-04
Vprtstp: contraction number = 6.258444e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.166439e-05
Vprtstp: contraction number = 4.579822e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.040725e-05
Vprtstp: contraction number = 6.172488e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.337927e-05
Vprtstp: contraction number = 4.638076e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.430319e-05
Vprtstp: contraction number = 6.117897e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.682151e-06
Vprtstp: contraction number = 4.671790e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.064723e-06
Vprtstp: contraction number = 6.082955e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.907113e-06
Vprtstp: contraction number = 4.691865e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.155733e-06
Vprtstp: contraction number = 6.060117e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 5.436726e-07
Vprtstp: contraction number = 4.704137e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.886348e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.021940e+01
Vpmg_setPart:  lower corner = (-51.0679, -26.7704, 41.7635)
Vpmg_setPart:  upper corner = (86.7289, 88.5444, 190.782)
Vpmg_setPart:  actual minima = (-51.0679, -26.7704, 41.7635)
Vpmg_setPart:  actual maxima = (86.7289, 88.5444, 190.782)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.263588588450E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.323800e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.8967
Vpbe_ctor2:  solute dimensions = 81.057 x 67.8322 x 87.6582
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.455, 77.464, 97.318)
Vclist_setupGrid:  Grid lower corner = (-27.897, -7.845, 67.614)
Vclist_assignAtoms:  Have 6241146 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -32.698, -13.0291, 62.4439
VPMG::focusFillBound -- New mesh maxs = 68.359, 74.8031, 170.102
VPMG::focusFillBound -- Old mesh mins = -51.0679, -26.7704, 41.7635
VPMG::focusFillBound -- Old mesh maxs = 86.7289, 88.5444, 190.782
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-32.698, -13.0291, 62.4439)
Vpmg_setPart:  upper corner = (68.359, 74.8031, 170.102)
Vpmg_setPart:  actual minima = (-51.0679, -26.7704, 41.7635)
Vpmg_setPart:  actual maxima = (86.7289, 88.5444, 190.782)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-32.698, -13.0291, 62.4439)
VPMG::extEnergy    Disj part upper corner = (68.359, 74.8031, 170.102)
VPMG::extEnergy    Old lower corner = (-51.0679, -26.7704, 41.7635)
VPMG::extEnergy    Old upper corner = (86.7289, 88.5444, 190.782)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.443886 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.322691 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.649865
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.761132e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.912760e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 113)
Vbuildops: Galer: (049, 041, 057)
Vbuildops: Galer: (025, 021, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.013012e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.839310e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.248858e-01
Vprtstp: contraction number = 1.248858e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.900229e-02
Vprtstp: contraction number = 1.521573e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.650091e-03
Vprtstp: contraction number = 3.499627e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.128636e-03
Vprtstp: contraction number = 3.200912e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.425740e-03
Vprtstp: contraction number = 6.697904e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.780416e-04
Vprtstp: contraction number = 4.054328e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.027423e-04
Vprtstp: contraction number = 6.967358e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.782069e-04
Vprtstp: contraction number = 4.424837e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.214282e-04
Vprtstp: contraction number = 6.813889e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.657667e-05
Vprtstp: contraction number = 4.659269e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.771968e-05
Vprtstp: contraction number = 6.667002e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.818905e-05
Vprtstp: contraction number = 4.822164e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.192723e-05
Vprtstp: contraction number = 6.557370e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.892552e-06
Vprtstp: contraction number = 4.940419e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 3.817086e-06
Vprtstp: contraction number = 6.477815e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.919573e-06
Vprtstp: contraction number = 5.028896e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.232183e-06
Vprtstp: contraction number = 6.419046e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 6.279968e-07
Vprtstp: contraction number = 5.096621e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.852440e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.986648e+01
Vpmg_setPart:  lower corner = (-32.698, -13.0291, 62.4439)
Vpmg_setPart:  upper corner = (68.359, 74.8031, 170.102)
Vpmg_setPart:  actual minima = (-32.698, -13.0291, 62.4439)
Vpmg_setPart:  actual maxima = (68.359, 74.8031, 170.102)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.122627901893E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.255500e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.901905e+01
