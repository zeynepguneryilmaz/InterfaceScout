##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 257, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5022 atoms
Valist_getStatistics:  Max atom coordinate:  (178.19, 150.73, 116.286)
Valist_getStatistics:  Min atom coordinate:  (76.358, 47.241, 21.062)
Valist_getStatistics:  Molecule center:  (127.274, 98.9855, 68.674)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.693221, 0.705228, 0.744366
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.485902, 0.492965, 0.527148
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.700934, 0.699015, 0.708184 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 127.274 98.9855 68.674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 216.006 189.255 152.043
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 38.5417 8.71635 -14.695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 189.47 162.085 127.715
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 65.0785 35.886 9.6334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 189.47 162.085 127.715
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 65.0785 35.886 9.6334
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.939677
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.028944e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 257, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.062630e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 129, 113)
Vbuildops: Galer: (065, 065, 057)
Vbuildops: Galer: (033, 033, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.900076e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.067695e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.035003e-01
Vprtstp: contraction number = 1.035003e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.784076e-02
Vprtstp: contraction number = 1.723741e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.799854e-03
Vprtstp: contraction number = 2.129872e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.086649e-03
Vprtstp: contraction number = 2.859712e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.078510e-04
Vprtstp: contraction number = 2.833032e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.123397e-04
Vprtstp: contraction number = 3.649158e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.648157e-05
Vprtstp: contraction number = 3.247434e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.438873e-05
Vprtstp: contraction number = 3.944110e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.938480e-06
Vprtstp: contraction number = 3.432185e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.011609e-06
Vprtstp: contraction number = 4.073336e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.042734e-07
Vprtstp: contraction number = 3.501046e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.347706e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.110691e+01
Vpmg_setPart:  lower corner = (38.5417, 8.71635, -14.695)
Vpmg_setPart:  upper corner = (216.006, 189.255, 152.043)
Vpmg_setPart:  actual minima = (38.5417, 8.71635, -14.695)
Vpmg_setPart:  actual maxima = (216.006, 189.255, 152.043)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.099676805494E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.821800e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.5588
Vpbe_ctor2:  solute dimensions = 104.391 x 106.199 x 98.0812
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (114.612, 116.269, 108.004)
Vclist_setupGrid:  Grid lower corner = (69.968, 40.851, 14.672)
Vclist_assignAtoms:  Have 1992514 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 65.0785, 35.886, 9.6334
VPMG::focusFillBound -- New mesh maxs = 189.47, 162.085, 127.715
VPMG::focusFillBound -- Old mesh mins = 38.5417, 8.71635, -14.695
VPMG::focusFillBound -- Old mesh maxs = 216.006, 189.255, 152.043
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (65.0785, 35.886, 9.6334)
Vpmg_setPart:  upper corner = (189.47, 162.085, 127.715)
Vpmg_setPart:  actual minima = (38.5417, 8.71635, -14.695)
Vpmg_setPart:  actual maxima = (216.006, 189.255, 152.043)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (65.0785, 35.886, 9.6334)
VPMG::extEnergy    Disj part upper corner = (189.47, 162.085, 127.715)
VPMG::extEnergy    Old lower corner = (38.5417, 8.71635, -14.695)
VPMG::extEnergy    Old upper corner = (216.006, 189.255, 152.043)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0432083 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0795144 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.933352
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.130299e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 257, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.081280e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 129, 113)
Vbuildops: Galer: (065, 065, 057)
Vbuildops: Galer: (033, 033, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.102507e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.621745e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.409852e-01
Vprtstp: contraction number = 1.409852e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.270165e-02
Vprtstp: contraction number = 1.610215e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.469234e-03
Vprtstp: contraction number = 1.968682e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.203389e-03
Vprtstp: contraction number = 2.692607e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.628079e-04
Vprtstp: contraction number = 3.014884e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.455503e-04
Vprtstp: contraction number = 4.011774e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.578087e-05
Vprtstp: contraction number = 3.832411e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.635263e-05
Vprtstp: contraction number = 4.724313e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.097225e-05
Vprtstp: contraction number = 4.163628e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.599244e-06
Vprtstp: contraction number = 5.103094e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.417460e-06
Vprtstp: contraction number = 4.317476e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.276350e-06
Vprtstp: contraction number = 5.279715e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.621439e-07
Vprtstp: contraction number = 4.404308e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.752120e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.532299e+01
Vpmg_setPart:  lower corner = (65.0785, 35.886, 9.6334)
Vpmg_setPart:  upper corner = (189.47, 162.085, 127.715)
Vpmg_setPart:  actual minima = (65.0785, 35.886, 9.6334)
Vpmg_setPart:  actual maxima = (189.469, 162.085, 127.715)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.202558522448E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.735100e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.923548e+01
