##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:56:20 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7182 atoms
Valist_getStatistics:  Max atom coordinate:  (53.332, 68.956, 64.163)
Valist_getStatistics:  Min atom coordinate:  (-11.345, 12.845, 6.037)
Valist_getStatistics:  Molecule center:  (20.9935, 40.9005, 35.1)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.712767, 0.625751, 0.646467
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.544275, 0.493089, 0.505275
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763608, 0.787996, 0.781594 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 20.9935 40.9005 35.1
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 78.0149 90.9605 86.8174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -36.0279 -9.15955 -16.6174
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 64.5355 80.3476 75.522
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -22.5485 1.4534 -5.322
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 64.5355 80.3476 75.522
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -22.5485 1.4534 -5.322
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.242349
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.291467e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.137260e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.300320e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.053301e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.935096e-02
Vprtstp: contraction number = 8.935096e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.269195e-02
Vprtstp: contraction number = 1.420460e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.690377e-03
Vprtstp: contraction number = 2.119752e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.584991e-04
Vprtstp: contraction number = 2.819304e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.729192e-04
Vprtstp: contraction number = 3.598147e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.069657e-04
Vprtstp: contraction number = 3.919317e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.598288e-05
Vprtstp: contraction number = 4.298845e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.977075e-05
Vprtstp: contraction number = 4.299590e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.619204e-06
Vprtstp: contraction number = 4.359573e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.808853e-06
Vprtstp: contraction number = 4.419031e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.644832e-06
Vprtstp: contraction number = 4.318444e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.407272e-07
Vprtstp: contraction number = 4.503362e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.727283e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.464078e+00
Vpmg_setPart:  lower corner = (-36.0279, -9.15955, -16.6174)
Vpmg_setPart:  upper corner = (78.0149, 90.9605, 86.8174)
Vpmg_setPart:  actual minima = (-36.0279, -9.15955, -16.6174)
Vpmg_setPart:  actual maxima = (78.0149, 90.9606, 86.8174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.867623594828E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 7.421000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.4717
Vpbe_ctor2:  solute dimensions = 67.084 x 58.8942 x 60.844
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.457, 68.891, 70.906)
Vclist_setupGrid:  Grid lower corner = (-17.735, 6.455, -0.353)
Vclist_assignAtoms:  Have 8001736 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -22.5485, 1.4534, -5.322
VPMG::focusFillBound -- New mesh maxs = 64.5355, 80.3476, 75.522
VPMG::focusFillBound -- Old mesh mins = -36.0279, -9.15955, -16.6174
VPMG::focusFillBound -- Old mesh maxs = 78.0149, 90.9606, 86.8174
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-22.5485, 1.4534, -5.322)
Vpmg_setPart:  upper corner = (64.5355, 80.3476, 75.522)
Vpmg_setPart:  actual minima = (-36.0279, -9.15955, -16.6174)
Vpmg_setPart:  actual maxima = (78.0149, 90.9606, 86.8174)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-22.5485, 1.4534, -5.322)
VPMG::extEnergy    Disj part upper corner = (64.5355, 80.3476, 75.522)
VPMG::extEnergy    Old lower corner = (-36.0279, -9.15955, -16.6174)
VPMG::extEnergy    Old upper corner = (78.0149, 90.9606, 86.8174)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0312702 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0612267 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.239310
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.851582e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.156440e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.362900e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.439533e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.185585e-01
Vprtstp: contraction number = 1.185585e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.663379e-02
Vprtstp: contraction number = 1.403003e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.992296e-03
Vprtstp: contraction number = 1.798926e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.525193e-04
Vprtstp: contraction number = 2.514856e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.554820e-04
Vprtstp: contraction number = 3.395022e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.093534e-04
Vprtstp: contraction number = 4.280280e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.973866e-05
Vprtstp: contraction number = 4.548431e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.466271e-05
Vprtstp: contraction number = 4.958458e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.162219e-05
Vprtstp: contraction number = 4.712456e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.889654e-06
Vprtstp: contraction number = 5.067593e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.775864e-06
Vprtstp: contraction number = 4.713119e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.411082e-06
Vprtstp: contraction number = 5.083397e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.651427e-07
Vprtstp: contraction number = 4.713707e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.465120e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.200737e+00
Vpmg_setPart:  lower corner = (-22.5485, 1.4534, -5.322)
Vpmg_setPart:  upper corner = (64.5355, 80.3476, 75.522)
Vpmg_setPart:  actual minima = (-22.5485, 1.4534, -5.322)
Vpmg_setPart:  actual maxima = (64.5355, 80.3476, 75.522)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.016859962061E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 7.924000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.400784e+01
