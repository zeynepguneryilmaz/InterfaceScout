##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:31 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (52.53, 57.314, 88.942)
Valist_getStatistics:  Min atom coordinate:  (1.051, 21.809, 33.755)
Valist_getStatistics:  Molecule center:  (26.7905, 39.5615, 61.3485)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.578563, 0.49907, 0.619811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.465331, 0.44982, 0.489595
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.804288, 0.901318, 0.78991 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 26.7905 39.5615 61.3485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 73.0755 71.5019 110.933
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.4945 7.62105 11.7636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 64.017 68.35 100.516
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -10.436 10.773 22.1809
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 64.017 68.35 100.516
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -10.436 10.773 22.1809
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.387752
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.121871e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.181100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.053710e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.699545e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.156226e-01
Vprtstp: contraction number = 1.156226e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.670711e-02
Vprtstp: contraction number = 1.444969e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.948944e-03
Vprtstp: contraction number = 1.765083e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.763946e-04
Vprtstp: contraction number = 1.954580e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.278743e-04
Vprtstp: contraction number = 2.218520e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.856230e-05
Vprtstp: contraction number = 2.233623e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.066188e-06
Vprtstp: contraction number = 2.824068e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.897934e-06
Vprtstp: contraction number = 2.352950e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.868878e-07
Vprtstp: contraction number = 3.092246e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.685232e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.253023e+00
Vpmg_setPart:  lower corner = (-19.4945, 7.62105, 11.7636)
Vpmg_setPart:  upper corner = (73.0755, 71.5019, 110.933)
Vpmg_setPart:  actual minima = (-19.4945, 7.62105, 11.7636)
Vpmg_setPart:  actual maxima = (73.0755, 71.5019, 110.933)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 9.846836474715E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.051000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.0204
Vpbe_ctor2:  solute dimensions = 54.453 x 37.577 x 58.3352
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (64.259, 48.285, 67.967)
Vclist_setupGrid:  Grid lower corner = (-5.339, 15.419, 27.365)
Vclist_assignAtoms:  Have 4236814 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -10.436, 10.773, 22.1809
VPMG::focusFillBound -- New mesh maxs = 64.017, 68.35, 100.516
VPMG::focusFillBound -- Old mesh mins = -19.4945, 7.62105, 11.7636
VPMG::focusFillBound -- Old mesh maxs = 73.0755, 71.5019, 110.933
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-10.436, 10.773, 22.1809)
Vpmg_setPart:  upper corner = (64.017, 68.35, 100.516)
Vpmg_setPart:  actual minima = (-19.4945, 7.62105, 11.7636)
Vpmg_setPart:  actual maxima = (73.0755, 71.5019, 110.933)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-10.436, 10.773, 22.1809)
VPMG::extEnergy    Disj part upper corner = (64.017, 68.35, 100.516)
VPMG::extEnergy    Old lower corner = (-19.4945, 7.62105, 11.7636)
VPMG::extEnergy    Old upper corner = (73.0755, 71.5019, 110.933)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0765255 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0785597 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.380194
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.385753e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.012600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.836410e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.333825e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.338148e-01
Vprtstp: contraction number = 1.338148e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.784485e-02
Vprtstp: contraction number = 1.333548e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.844824e-03
Vprtstp: contraction number = 1.594199e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.192576e-04
Vprtstp: contraction number = 1.825272e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.074431e-04
Vprtstp: contraction number = 2.069168e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.463188e-05
Vprtstp: contraction number = 2.292551e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.944964e-06
Vprtstp: contraction number = 2.413524e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.470195e-06
Vprtstp: contraction number = 2.473009e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.012990e-07
Vprtstp: contraction number = 2.729563e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.863620e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.404089e+00
Vpmg_setPart:  lower corner = (-10.436, 10.773, 22.1809)
Vpmg_setPart:  upper corner = (64.017, 68.35, 100.516)
Vpmg_setPart:  actual minima = (-10.436, 10.773, 22.1809)
Vpmg_setPart:  actual maxima = (64.017, 68.35, 100.516)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.376532958756E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.579000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.413718e+01
