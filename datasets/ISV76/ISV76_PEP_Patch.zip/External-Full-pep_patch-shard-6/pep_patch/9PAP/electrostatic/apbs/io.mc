##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3240 atoms
Valist_getStatistics:  Max atom coordinate:  (48.922, 99.072, 37.738)
Valist_getStatistics:  Min atom coordinate:  (13.821, 45.616, -7.69)
Valist_getStatistics:  Molecule center:  (31.3715, 72.344, 15.024)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.498445, 0.594768, 0.6381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.449453, 0.474864, 0.531603
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.90171, 0.798401, 0.833103 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3715 72.344 15.024
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 63.272 119.925 55.8624
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -0.529 24.7625 -25.8144
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 60.1365 110.333 49.0466
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 2.6065 34.3549 -18.9986
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 60.1365 110.333 49.0466
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 2.6065 34.3549 -18.9986
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.545122
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.282387e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.521000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.263380e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.753932e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.060957e-01
Vprtstp: contraction number = 1.060957e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.525114e-02
Vprtstp: contraction number = 1.437489e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.588718e-03
Vprtstp: contraction number = 2.353081e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.068318e-03
Vprtstp: contraction number = 2.976879e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.515922e-04
Vprtstp: contraction number = 4.227133e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.905357e-04
Vprtstp: contraction number = 4.219199e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.787046e-05
Vprtstp: contraction number = 5.136593e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.422531e-05
Vprtstp: contraction number = 4.518760e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.321458e-05
Vprtstp: contraction number = 5.249162e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.059577e-05
Vprtstp: contraction number = 4.564273e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.566398e-06
Vprtstp: contraction number = 5.253416e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.550972e-06
Vprtstp: contraction number = 4.582805e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.339622e-06
Vprtstp: contraction number = 5.251417e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.152456e-07
Vprtstp: contraction number = 4.592682e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.760060e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.217399e+00
Vpmg_setPart:  lower corner = (-0.529, 24.7625, -25.8144)
Vpmg_setPart:  upper corner = (63.272, 119.925, 55.8624)
Vpmg_setPart:  actual minima = (-0.529, 24.7625, -25.8144)
Vpmg_setPart:  actual maxima = (63.272, 119.925, 55.8624)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.167996495308E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.470000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4913
Vpbe_ctor2:  solute dimensions = 37.53 x 55.9782 x 48.0452
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (47.881, 66.236, 58.208)
Vclist_setupGrid:  Grid lower corner = (7.431, 39.226, -14.08)
Vclist_assignAtoms:  Have 6505296 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 2.6065, 34.3549, -18.9986
VPMG::focusFillBound -- New mesh maxs = 60.1365, 110.333, 49.0466
VPMG::focusFillBound -- Old mesh mins = -0.529, 24.7625, -25.8144
VPMG::focusFillBound -- Old mesh maxs = 63.272, 119.925, 55.8624
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (2.6065, 34.3549, -18.9986)
Vpmg_setPart:  upper corner = (60.1365, 110.333, 49.0466)
Vpmg_setPart:  actual minima = (-0.529, 24.7625, -25.8144)
Vpmg_setPart:  actual maxima = (63.272, 119.925, 55.8624)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (2.6065, 34.3549, -18.9986)
VPMG::extEnergy    Disj part upper corner = (60.1365, 110.333, 49.0466)
VPMG::extEnergy    Old lower corner = (-0.529, 24.7625, -25.8144)
VPMG::extEnergy    Old upper corner = (63.272, 119.925, 55.8624)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0642856 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0582485 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.534752
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.519534e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.435700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.156120e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.497857e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.232905e-01
Vprtstp: contraction number = 1.232905e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.682643e-02
Vprtstp: contraction number = 1.364779e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.211757e-03
Vprtstp: contraction number = 1.908757e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.470254e-04
Vprtstp: contraction number = 2.637265e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.030588e-04
Vprtstp: contraction number = 3.577918e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.225810e-04
Vprtstp: contraction number = 4.044794e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.743799e-05
Vprtstp: contraction number = 4.685716e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.553474e-05
Vprtstp: contraction number = 4.445618e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.256881e-05
Vprtstp: contraction number = 4.922241e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.657844e-06
Vprtstp: contraction number = 4.501494e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.817610e-06
Vprtstp: contraction number = 4.980007e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.273847e-06
Vprtstp: contraction number = 4.521019e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.375505e-07
Vprtstp: contraction number = 5.004922e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.448613e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.891787e+00
Vpmg_setPart:  lower corner = (2.6065, 34.3549, -18.9986)
Vpmg_setPart:  upper corner = (60.1365, 110.333, 49.0466)
Vpmg_setPart:  actual minima = (2.6065, 34.3549, -18.9986)
Vpmg_setPart:  actual maxima = (60.1365, 110.333, 49.0466)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.597778553592E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.994000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.567433e+01
