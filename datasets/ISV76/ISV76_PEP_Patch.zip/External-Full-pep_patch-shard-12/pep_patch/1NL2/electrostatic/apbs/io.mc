##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:48:18 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2065 atoms
Valist_getStatistics:  Max atom coordinate:  (31.545, 62.033, 138.607)
Valist_getStatistics:  Min atom coordinate:  (-9.889, 22.933, 80.851)
Valist_getStatistics:  Molecule center:  (10.828, 42.483, 109.729)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.588094, 0.552048, 0.645256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.502188, 0.480984, 0.504563
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.853924, 0.871272, 0.781957 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 10.828 42.483 109.729
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 48.466 77.8141 161.35
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -26.81 7.1519 58.1085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 42.968 73.266 150.094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -21.312 11.7 69.364
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 42.968 73.266 150.094
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -21.312 11.7 69.364
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.252043
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.761230e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.136500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.979380e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.088589e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.109002e-01
Vprtstp: contraction number = 1.109002e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.485194e-02
Vprtstp: contraction number = 1.339217e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.663060e-03
Vprtstp: contraction number = 1.793073e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.726844e-04
Vprtstp: contraction number = 1.774967e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.100228e-04
Vprtstp: contraction number = 2.327616e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.341023e-05
Vprtstp: contraction number = 2.127762e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.142957e-06
Vprtstp: contraction number = 2.624048e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.458253e-06
Vprtstp: contraction number = 2.373862e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.912463e-07
Vprtstp: contraction number = 2.682979e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.889482e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.292619e+00
Vpmg_setPart:  lower corner = (-26.81, 7.1519, 58.1085)
Vpmg_setPart:  upper corner = (48.466, 77.8141, 161.35)
Vpmg_setPart:  actual minima = (-26.81, 7.1519, 58.1085)
Vpmg_setPart:  actual maxima = (48.466, 77.8141, 161.35)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.511662121770E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.656000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.6764
Vpbe_ctor2:  solute dimensions = 44.28 x 41.566 x 60.73
Vpbe_ctor2:  solute charge = 5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (54.214, 51.88, 70.536)
Vclist_setupGrid:  Grid lower corner = (-16.279, 16.543, 74.461)
Vclist_assignAtoms:  Have 3887038 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -21.312, 11.7, 69.364
VPMG::focusFillBound -- New mesh maxs = 42.968, 73.266, 150.094
VPMG::focusFillBound -- Old mesh mins = -26.81, 7.1519, 58.1085
VPMG::focusFillBound -- Old mesh maxs = 48.466, 77.8141, 161.35
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-21.312, 11.7, 69.364)
Vpmg_setPart:  upper corner = (42.968, 73.266, 150.094)
Vpmg_setPart:  actual minima = (-26.81, 7.1519, 58.1085)
Vpmg_setPart:  actual maxima = (48.466, 77.8141, 161.35)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-21.312, 11.7, 69.364)
VPMG::extEnergy    Disj part upper corner = (42.968, 73.266, 150.094)
VPMG::extEnergy    Old lower corner = (-26.81, 7.1519, 58.1085)
VPMG::extEnergy    Old upper corner = (48.466, 77.8141, 161.35)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.12005 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0970351 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.246116
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 8.112350e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.124200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.898860e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.197475e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.288462e-01
Vprtstp: contraction number = 1.288462e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.676141e-02
Vprtstp: contraction number = 1.300886e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.650916e-03
Vprtstp: contraction number = 1.581559e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.488193e-04
Vprtstp: contraction number = 1.693073e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.232000e-05
Vprtstp: contraction number = 2.056952e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.932571e-05
Vprtstp: contraction number = 2.093340e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.676590e-06
Vprtstp: contraction number = 2.419880e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.133770e-06
Vprtstp: contraction number = 2.424351e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.930692e-07
Vprtstp: contraction number = 2.584910e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.779251e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.162229e+00
Vpmg_setPart:  lower corner = (-21.312, 11.7, 69.364)
Vpmg_setPart:  upper corner = (42.968, 73.266, 150.094)
Vpmg_setPart:  actual minima = (-21.312, 11.7, 69.364)
Vpmg_setPart:  actual maxima = (42.968, 73.266, 150.094)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.052141419217E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.658000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.409477e+00
