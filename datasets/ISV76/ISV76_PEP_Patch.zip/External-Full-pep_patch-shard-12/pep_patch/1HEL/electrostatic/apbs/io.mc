##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:48:35 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1960 atoms
Valist_getStatistics:  Max atom coordinate:  (20.054, 38.799, 41.285)
Valist_getStatistics:  Min atom coordinate:  (-18.505, 5.196, -2.53)
Valist_getStatistics:  Molecule center:  (0.7745, 21.9975, 19.3775)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.549753, 0.488102, 0.610898
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.479634, 0.443369, 0.515602
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.872454, 0.908353, 0.844006 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7745 21.9975 19.3775
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 35.9587 53.236 58.4749
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.4097 -9.241 -19.72
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 31.4711 50.3731 52.376
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.9221 -6.3781 -13.621
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 31.4711 50.3731 52.376
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.9221 -6.3781 -13.621
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.249644
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.228200e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.807800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.757330e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.807460e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.062745e-01
Vprtstp: contraction number = 1.062745e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.436664e-02
Vprtstp: contraction number = 1.351843e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.271204e-03
Vprtstp: contraction number = 1.580887e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.933008e-04
Vprtstp: contraction number = 1.731685e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.088609e-05
Vprtstp: contraction number = 1.802338e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.281501e-05
Vprtstp: contraction number = 1.807831e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.390286e-06
Vprtstp: contraction number = 1.865224e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.817946e-07
Vprtstp: contraction number = 2.015636e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.971412e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.220554e+00
Vpmg_setPart:  lower corner = (-34.4097, -9.241, -19.72)
Vpmg_setPart:  upper corner = (35.9587, 53.236, 58.4749)
Vpmg_setPart:  actual minima = (-34.4097, -9.241, -19.72)
Vpmg_setPart:  actual maxima = (35.9587, 53.236, 58.4749)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.296719272086E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.347000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.4182
Vpbe_ctor2:  solute dimensions = 41.3932 x 36.7512 x 45.997
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 73 x 75 table
Vclist_ctor2:  Using 75 x 73 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.339, 46.383, 56.595)
Vclist_setupGrid:  Grid lower corner = (-24.895, -1.194, -8.92)
Vclist_assignAtoms:  Have 4985470 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.9221, -6.3781, -13.621
VPMG::focusFillBound -- New mesh maxs = 31.4711, 50.3731, 52.376
VPMG::focusFillBound -- Old mesh mins = -34.4097, -9.241, -19.72
VPMG::focusFillBound -- Old mesh maxs = 35.9587, 53.236, 58.4749
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-29.9221, -6.3781, -13.621)
Vpmg_setPart:  upper corner = (31.4711, 50.3731, 52.376)
Vpmg_setPart:  actual minima = (-34.4097, -9.241, -19.72)
Vpmg_setPart:  actual maxima = (35.9587, 53.236, 58.4749)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-29.9221, -6.3781, -13.621)
VPMG::extEnergy    Disj part upper corner = (31.4711, 50.3731, 52.376)
VPMG::extEnergy    Old lower corner = (-34.4097, -9.241, -19.72)
VPMG::extEnergy    Old upper corner = (35.9587, 53.236, 58.4749)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0816391 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0486065 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.246371
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.560280e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.791000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.720770e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.880121e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.228002e-01
Vprtstp: contraction number = 1.228002e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.617038e-02
Vprtstp: contraction number = 1.316804e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.421896e-03
Vprtstp: contraction number = 1.497736e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.906711e-04
Vprtstp: contraction number = 1.613080e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.388706e-05
Vprtstp: contraction number = 1.635316e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.522273e-06
Vprtstp: contraction number = 1.490485e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.601225e-06
Vprtstp: contraction number = 1.681557e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.360841e-07
Vprtstp: contraction number = 2.098919e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.928732e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.176533e+00
Vpmg_setPart:  lower corner = (-29.9221, -6.3781, -13.621)
Vpmg_setPart:  upper corner = (31.4711, 50.3731, 52.376)
Vpmg_setPart:  actual minima = (-29.9221, -6.3781, -13.621)
Vpmg_setPart:  actual maxima = (31.4711, 50.3731, 52.376)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.057920224987E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.347000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.175008e+00
