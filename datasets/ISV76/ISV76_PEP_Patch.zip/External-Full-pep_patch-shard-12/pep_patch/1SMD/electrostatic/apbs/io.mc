##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:48:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 193, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7641 atoms
Valist_getStatistics:  Max atom coordinate:  (36.52, 95.782, 47.472)
Valist_getStatistics:  Min atom coordinate:  (-18.739, 23.032, -9.902)
Valist_getStatistics:  Molecule center:  (8.8905, 59.407, 18.785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.611097, 0.67113, 0.636097
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.484469, 0.498949, 0.499175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.792786, 0.743446, 0.784746 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.8905 59.407 18.785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 57.7782 123.835 69.6728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.9972 -5.02145 -32.1028
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 47.648 107.306 58.719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.867 11.5079 -21.149
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 47.648 107.306 58.719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.867 11.5079 -21.149
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7997207 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.933010
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.647104e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.088870e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 081)
Vbuildops: Galer: (041, 049, 041)
Vbuildops: Galer: (021, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.839830e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.417482e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.174249e-02
Vprtstp: contraction number = 8.174249e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.133624e-02
Vprtstp: contraction number = 1.386823e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.525268e-03
Vprtstp: contraction number = 2.227606e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.584524e-04
Vprtstp: contraction number = 3.003453e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.017025e-04
Vprtstp: contraction number = 3.977870e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.137864e-04
Vprtstp: contraction number = 3.771477e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.894098e-05
Vprtstp: contraction number = 4.301127e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.906062e-05
Vprtstp: contraction number = 3.894613e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.195782e-06
Vprtstp: contraction number = 4.299851e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.220051e-06
Vprtstp: contraction number = 3.928913e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.379074e-06
Vprtstp: contraction number = 4.282771e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.438074e-07
Vprtstp: contraction number = 3.943279e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.889190e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.640411e+00
Vpmg_setPart:  lower corner = (-39.9972, -5.02145, -32.1028)
Vpmg_setPart:  upper corner = (57.7782, 123.835, 69.6728)
Vpmg_setPart:  actual minima = (-39.9972, -5.02145, -32.1028)
Vpmg_setPart:  actual maxima = (57.7782, 123.835, 69.6728)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.301573376274E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.016000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 43.6707
Vpbe_ctor2:  solute dimensions = 57.515 x 75.7982 x 59.868
Vpbe_ctor2:  solute charge = -4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.039, 85.53, 70.154)
Vclist_setupGrid:  Grid lower corner = (-25.129, 16.642, -16.292)
Vclist_assignAtoms:  Have 7997207 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.867, 11.5079, -21.149
VPMG::focusFillBound -- New mesh maxs = 47.648, 107.306, 58.719
VPMG::focusFillBound -- Old mesh mins = -39.9972, -5.02145, -32.1028
VPMG::focusFillBound -- Old mesh maxs = 57.7782, 123.835, 69.6728
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-29.867, 11.5079, -21.149)
Vpmg_setPart:  upper corner = (47.648, 107.306, 58.719)
Vpmg_setPart:  actual minima = (-39.9972, -5.02145, -32.1028)
Vpmg_setPart:  actual maxima = (57.7782, 123.835, 69.6728)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-29.867, 11.5079, -21.149)
VPMG::extEnergy    Disj part upper corner = (47.648, 107.306, 58.719)
VPMG::extEnergy    Old lower corner = (-39.9972, -5.02145, -32.1028)
VPMG::extEnergy    Old upper corner = (57.7782, 123.835, 69.6728)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0335196 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0432032 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.908253
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.032408e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.099310e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 081)
Vbuildops: Galer: (041, 049, 041)
Vbuildops: Galer: (021, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.621710e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.110338e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.122091e-01
Vprtstp: contraction number = 1.122091e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.466330e-02
Vprtstp: contraction number = 1.306784e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.697309e-03
Vprtstp: contraction number = 1.839496e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.878136e-04
Vprtstp: contraction number = 2.550000e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.490077e-04
Vprtstp: contraction number = 3.620279e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.871635e-05
Vprtstp: contraction number = 3.964389e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.573207e-05
Vprtstp: contraction number = 4.632674e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.990183e-05
Vprtstp: contraction number = 4.351831e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.664002e-06
Vprtstp: contraction number = 4.855837e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.293821e-06
Vprtstp: contraction number = 4.443109e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.111130e-06
Vprtstp: contraction number = 4.916669e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 9.427284e-07
Vprtstp: contraction number = 4.465516e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.145242e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.886260e+00
Vpmg_setPart:  lower corner = (-29.867, 11.5079, -21.149)
Vpmg_setPart:  upper corner = (47.648, 107.306, 58.719)
Vpmg_setPart:  actual minima = (-29.867, 11.5079, -21.149)
Vpmg_setPart:  actual maxima = (47.648, 107.306, 58.719)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.738516507818E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.991000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.803089e+01
