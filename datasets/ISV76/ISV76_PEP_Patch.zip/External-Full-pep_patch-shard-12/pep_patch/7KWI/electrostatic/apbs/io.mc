##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:28 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2364 atoms
Valist_getStatistics:  Max atom coordinate:  (26.302, 19.88, 28.451)
Valist_getStatistics:  Min atom coordinate:  (-29.368, -16.781, -24.217)
Valist_getStatistics:  Molecule center:  (-1.533, 1.5495, 2.117)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.617419, 0.517477, 0.589158
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.488187, 0.460648, 0.471564
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790691, 0.890181, 0.800403 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.533 1.5495 2.117
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 47.8605 34.6681 49.2497
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -50.9265 -31.569 -45.0156
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 37.522 31.031 39.8421
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -40.588 -27.932 -35.6081
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 37.522 31.031 39.8421
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -40.588 -27.932 -35.6081
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.264514
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.065690e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.498900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.961540e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.224875e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.181743e-01
Vprtstp: contraction number = 1.181743e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.569772e-02
Vprtstp: contraction number = 1.328353e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.881854e-03
Vprtstp: contraction number = 1.835843e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.741053e-04
Vprtstp: contraction number = 1.645140e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.152016e-04
Vprtstp: contraction number = 2.429874e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.209349e-05
Vprtstp: contraction number = 1.917811e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.358027e-06
Vprtstp: contraction number = 2.877782e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.327610e-06
Vprtstp: contraction number = 2.088085e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.111154e-07
Vprtstp: contraction number = 3.096658e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.193631e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.702707e+00
Vpmg_setPart:  lower corner = (-50.9265, -31.569, -45.0156)
Vpmg_setPart:  upper corner = (47.8605, 34.6681, 49.2497)
Vpmg_setPart:  actual minima = (-50.9265, -31.569, -45.0156)
Vpmg_setPart:  actual maxima = (47.8605, 34.6681, 49.2497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.534477966397E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.093000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.689
Vpbe_ctor2:  solute dimensions = 58.11 x 38.963 x 55.4502
Vpbe_ctor2:  solute charge = 11
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.1887, 49.1797, 65.1867)
Vclist_setupGrid:  Grid lower corner = (-35.6274, -23.0404, -30.4764)
Vclist_assignAtoms:  Have 4089281 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -40.588, -27.932, -35.6081
VPMG::focusFillBound -- New mesh maxs = 37.522, 31.031, 39.8421
VPMG::focusFillBound -- Old mesh mins = -50.9265, -31.569, -45.0156
VPMG::focusFillBound -- Old mesh maxs = 47.8605, 34.6681, 49.2497
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-40.588, -27.932, -35.6081)
Vpmg_setPart:  upper corner = (37.522, 31.031, 39.8421)
Vpmg_setPart:  actual minima = (-50.9265, -31.569, -45.0156)
Vpmg_setPart:  actual maxima = (47.8605, 34.6681, 49.2497)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-40.588, -27.932, -35.6081)
VPMG::extEnergy    Disj part upper corner = (37.522, 31.031, 39.8421)
VPMG::extEnergy    Old lower corner = (-50.9265, -31.569, -45.0156)
VPMG::extEnergy    Old upper corner = (47.8605, 34.6681, 49.2497)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.225737 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.106144 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.264337
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.008280e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.463300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.462990e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.805865e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.357001e-01
Vprtstp: contraction number = 1.357001e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.755656e-02
Vprtstp: contraction number = 1.293777e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.970417e-03
Vprtstp: contraction number = 1.691913e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.167762e-04
Vprtstp: contraction number = 1.739743e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.253358e-04
Vprtstp: contraction number = 2.425341e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.738937e-05
Vprtstp: contraction number = 2.185278e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.222736e-06
Vprtstp: contraction number = 3.002163e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.978313e-06
Vprtstp: contraction number = 2.405906e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.410403e-07
Vprtstp: contraction number = 3.240338e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.323824e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.783224e+00
Vpmg_setPart:  lower corner = (-40.588, -27.932, -35.6081)
Vpmg_setPart:  upper corner = (37.522, 31.031, 39.8421)
Vpmg_setPart:  actual minima = (-40.588, -27.932, -35.6081)
Vpmg_setPart:  actual maxima = (37.522, 31.031, 39.8421)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.209472393704E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.972000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.631360e+00
