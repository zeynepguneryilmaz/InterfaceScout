##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:56:08 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6976 atoms
Valist_getStatistics:  Max atom coordinate:  (30.531, 30.518, 24.088)
Valist_getStatistics:  Min atom coordinate:  (-30.453, -30.45, -24.005)
Valist_getStatistics:  Molecule center:  (0.039, 0.034, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.679554, 0.679384, 0.678234
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.524737, 0.524637, 0.555211
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.77218, 0.772226, 0.818613 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.039 0.034 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.4033 54.3847 43.4485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -54.3253 -54.3167 -43.3655
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 42.018 42.005 35.575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -41.94 -41.937 -35.492
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 42.018 42.005 35.575
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -41.94 -41.937 -35.492
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.887550
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.564136e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.996200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 065)
Vbuildops: Galer: (041, 041, 033)
Vbuildops: Galer: (021, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.256050e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.025189e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.488617e-02
Vprtstp: contraction number = 7.488617e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.902256e-03
Vprtstp: contraction number = 1.322308e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.089815e-03
Vprtstp: contraction number = 2.110444e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.595371e-04
Vprtstp: contraction number = 2.677448e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.473272e-04
Vprtstp: contraction number = 4.420211e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.886764e-05
Vprtstp: contraction number = 3.593120e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.680401e-05
Vprtstp: contraction number = 5.266711e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.781169e-05
Vprtstp: contraction number = 3.805590e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.440274e-06
Vprtstp: contraction number = 5.300044e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.643621e-06
Vprtstp: contraction number = 3.859656e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.919744e-06
Vprtstp: contraction number = 5.268780e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.456774e-07
Vprtstp: contraction number = 3.884255e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.576376e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.020163e+00
Vpmg_setPart:  lower corner = (-54.3253, -54.3167, -43.3655)
Vpmg_setPart:  upper corner = (54.4033, 54.3847, 43.4485)
Vpmg_setPart:  actual minima = (-54.3253, -54.3167, -43.3655)
Vpmg_setPart:  actual maxima = (54.4033, 54.3847, 43.4485)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.878080757525E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.295000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.4734
Vpbe_ctor2:  solute dimensions = 63.958 x 63.942 x 51.067
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (73.5027, 73.4867, 60.6117)
Vclist_setupGrid:  Grid lower corner = (-36.7124, -36.7094, -30.2644)
Vclist_assignAtoms:  Have 8691653 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -41.94, -41.937, -35.492
VPMG::focusFillBound -- New mesh maxs = 42.018, 42.005, 35.575
VPMG::focusFillBound -- Old mesh mins = -54.3253, -54.3167, -43.3655
VPMG::focusFillBound -- Old mesh maxs = 54.4033, 54.3847, 43.4485
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-41.94, -41.937, -35.492)
Vpmg_setPart:  upper corner = (42.018, 42.005, 35.575)
Vpmg_setPart:  actual minima = (-54.3253, -54.3167, -43.3655)
Vpmg_setPart:  actual maxima = (54.4033, 54.3847, 43.4485)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-41.94, -41.937, -35.492)
VPMG::extEnergy    Disj part upper corner = (42.018, 42.005, 35.575)
VPMG::extEnergy    Old lower corner = (-54.3253, -54.3167, -43.3655)
VPMG::extEnergy    Old upper corner = (54.4033, 54.3847, 43.4485)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.036167 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0577014 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.894960
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.921632e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.120000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 065)
Vbuildops: Galer: (041, 041, 033)
Vbuildops: Galer: (021, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.149760e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.975726e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.045921e-01
Vprtstp: contraction number = 1.045921e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.336118e-02
Vprtstp: contraction number = 1.277457e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.266312e-03
Vprtstp: contraction number = 1.696191e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.923332e-04
Vprtstp: contraction number = 2.172399e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.619991e-04
Vprtstp: contraction number = 3.290435e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.426192e-05
Vprtstp: contraction number = 3.349520e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.480726e-05
Vprtstp: contraction number = 4.571763e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.394628e-06
Vprtstp: contraction number = 3.787048e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.563151e-06
Vprtstp: contraction number = 4.857192e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.774849e-06
Vprtstp: contraction number = 3.889524e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.682957e-07
Vprtstp: contraction number = 4.892223e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.285742e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.721917e+00
Vpmg_setPart:  lower corner = (-41.94, -41.937, -35.492)
Vpmg_setPart:  upper corner = (42.018, 42.005, 35.575)
Vpmg_setPart:  actual minima = (-41.94, -41.937, -35.492)
Vpmg_setPart:  actual maxima = (42.018, 42.005, 35.575)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.022458356580E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.379000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.400225e+01
