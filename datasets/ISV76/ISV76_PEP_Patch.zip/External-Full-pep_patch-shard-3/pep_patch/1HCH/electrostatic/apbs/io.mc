##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:36 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4694 atoms
Valist_getStatistics:  Max atom coordinate:  (29.917, 37.404, 35.018)
Valist_getStatistics:  Min atom coordinate:  (-19.142, -22.327, -9.237)
Valist_getStatistics:  Molecule center:  (5.3875, 7.5385, 12.8905)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.68842, 0.664626, 0.61515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.561203, 0.515956, 0.518103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.815204, 0.776311, 0.842239 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 5.3875 7.5385 12.8905
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 49.4464 60.7086 52.2601
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.6714 -45.6316 -26.4791
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 41.3045 48.815 46.0491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -30.5295 -33.738 -20.2681
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 41.3045 48.815 46.0491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -30.5295 -33.738 -20.2681
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7181167 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.612701
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.129186e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.564500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.317940e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.467958e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.610570e-02
Vprtstp: contraction number = 7.610570e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.128138e-02
Vprtstp: contraction number = 1.482331e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.652775e-03
Vprtstp: contraction number = 2.351463e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.996568e-04
Vprtstp: contraction number = 3.014416e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.720466e-04
Vprtstp: contraction number = 4.652578e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.529420e-04
Vprtstp: contraction number = 4.110831e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.307461e-05
Vprtstp: contraction number = 5.431771e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.607871e-05
Vprtstp: contraction number = 4.342928e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.046161e-05
Vprtstp: contraction number = 5.671380e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.107981e-06
Vprtstp: contraction number = 4.451254e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.271141e-06
Vprtstp: contraction number = 5.787387e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.376624e-06
Vprtstp: contraction number = 4.508746e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.389487e-06
Vprtstp: contraction number = 5.846474e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.306670e-07
Vprtstp: contraction number = 4.538849e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.259531e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.584814e+00
Vpmg_setPart:  lower corner = (-38.6714, -45.6316, -26.4791)
Vpmg_setPart:  upper corner = (49.4464, 60.7086, 52.2601)
Vpmg_setPart:  actual minima = (-38.6714, -45.6316, -26.4791)
Vpmg_setPart:  actual maxima = (49.4464, 60.7086, 52.2601)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.367917494852E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.343000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2413
Vpbe_ctor2:  solute dimensions = 51.834 x 62.553 x 46.3172
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.839, 72.511, 57.035)
Vclist_setupGrid:  Grid lower corner = (-25.532, -28.717, -15.627)
Vclist_assignAtoms:  Have 7181167 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -30.5295, -33.738, -20.2681
VPMG::focusFillBound -- New mesh maxs = 41.3045, 48.815, 46.0491
VPMG::focusFillBound -- Old mesh mins = -38.6714, -45.6316, -26.4791
VPMG::focusFillBound -- Old mesh maxs = 49.4464, 60.7086, 52.2601
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-30.5295, -33.738, -20.2681)
Vpmg_setPart:  upper corner = (41.3045, 48.815, 46.0491)
Vpmg_setPart:  actual minima = (-38.6714, -45.6316, -26.4791)
Vpmg_setPart:  actual maxima = (49.4464, 60.7086, 52.2601)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-30.5295, -33.738, -20.2681)
VPMG::extEnergy    Disj part upper corner = (41.3045, 48.815, 46.0491)
VPMG::extEnergy    Old lower corner = (-38.6714, -45.6316, -26.4791)
VPMG::extEnergy    Old upper corner = (49.4464, 60.7086, 52.2601)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0152247 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0208909 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.607528
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.364003e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.711000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.343340e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.435353e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.009561e-01
Vprtstp: contraction number = 1.009561e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.334683e-02
Vprtstp: contraction number = 1.322042e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.476042e-03
Vprtstp: contraction number = 1.855154e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.336871e-04
Vprtstp: contraction number = 2.559274e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.072274e-04
Vprtstp: contraction number = 3.270186e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.699830e-05
Vprtstp: contraction number = 3.715642e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.071934e-05
Vprtstp: contraction number = 3.989613e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.259280e-05
Vprtstp: contraction number = 4.099308e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.190039e-06
Vprtstp: contraction number = 4.121433e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.181269e-06
Vprtstp: contraction number = 4.202799e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.918703e-07
Vprtstp: contraction number = 4.088768e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.323516e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.655957e+00
Vpmg_setPart:  lower corner = (-30.5295, -33.738, -20.2681)
Vpmg_setPart:  upper corner = (41.3045, 48.815, 46.0491)
Vpmg_setPart:  actual minima = (-30.5295, -33.738, -20.2681)
Vpmg_setPart:  actual maxima = (41.3045, 48.815, 46.0491)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.070032675657E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.438000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.134796e+01
