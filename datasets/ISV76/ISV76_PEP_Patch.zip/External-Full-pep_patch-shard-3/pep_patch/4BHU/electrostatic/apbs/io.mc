##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:57:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 257, 289)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 18431 atoms
Valist_getStatistics:  Max atom coordinate:  (72.41, 59.598, 163.546)
Valist_getStatistics:  Min atom coordinate:  (-38.903, -46.971, 35.276)
Valist_getStatistics:  Molecule center:  (16.7535, 6.3135, 99.411)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.762045, 0.726969, 0.773826
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.526387, 0.505754, 0.524636
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.690755, 0.695702, 0.677977 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.7535 6.3135 99.411
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 114.295 99.3655 210.842
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -80.7882 -86.7385 -12.0199
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.131 71.05 174.959
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -50.624 -58.423 23.8634
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.131 71.05 174.959
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -50.624 -58.423 23.8634
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.892691
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.381228e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 257, 289)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.023980e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 129, 145)
Vbuildops: Galer: (065, 065, 073)
Vbuildops: Galer: (033, 033, 037)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.807066e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.393204e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.669514e-02
Vprtstp: contraction number = 7.669514e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.411186e-02
Vprtstp: contraction number = 1.839994e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.399947e-03
Vprtstp: contraction number = 3.117908e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.803490e-03
Vprtstp: contraction number = 4.098890e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.004401e-03
Vprtstp: contraction number = 5.569210e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.169861e-04
Vprtstp: contraction number = 5.147205e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.660925e-04
Vprtstp: contraction number = 7.081283e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.115200e-04
Vprtstp: contraction number = 5.777775e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.612894e-04
Vprtstp: contraction number = 7.625257e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.856300e-05
Vprtstp: contraction number = 6.110940e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.583934e-05
Vprtstp: contraction number = 7.694504e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.746014e-05
Vprtstp: contraction number = 6.257984e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.641730e-05
Vprtstp: contraction number = 7.673239e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.303186e-05
Vprtstp: contraction number = 6.324429e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.760627e-05
Vprtstp: contraction number = 7.644310e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.119417e-05
Vprtstp: contraction number = 6.358060e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 8.533849e-06
Vprtstp: contraction number = 7.623475e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 5.441822e-06
Vprtstp: contraction number = 6.376749e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 4.141140e-06
Vprtstp: contraction number = 7.609841e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 2.645166e-06
Vprtstp: contraction number = 6.387533e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 2.010627e-06
Vprtstp: contraction number = 7.601137e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 1.285588e-06
Vprtstp: contraction number = 6.393964e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 9.764946e-07
Vprtstp: contraction number = 7.595705e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.291900e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.142764e+01
Vpmg_setPart:  lower corner = (-80.7882, -86.7385, -12.0199)
Vpmg_setPart:  upper corner = (114.295, 99.3655, 210.842)
Vpmg_setPart:  actual minima = (-80.7882, -86.7385, -12.0199)
Vpmg_setPart:  actual maxima = (114.295, 99.3655, 210.842)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.751306634955E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.598700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.1382
Vpbe_ctor2:  solute dimensions = 114.755 x 109.473 x 131.095
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.832, 119.088, 140.789)
Vclist_setupGrid:  Grid lower corner = (-45.1624, -53.2304, 29.0166)
Vclist_assignAtoms:  Have 5613515 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -50.624, -58.423, 23.8634
VPMG::focusFillBound -- New mesh maxs = 84.131, 71.05, 174.959
VPMG::focusFillBound -- Old mesh mins = -80.7882, -86.7385, -12.0199
VPMG::focusFillBound -- Old mesh maxs = 114.295, 99.3655, 210.842
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-50.624, -58.423, 23.8634)
Vpmg_setPart:  upper corner = (84.131, 71.05, 174.959)
Vpmg_setPart:  actual minima = (-80.7882, -86.7385, -12.0199)
Vpmg_setPart:  actual maxima = (114.295, 99.3655, 210.842)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-50.624, -58.423, 23.8634)
VPMG::extEnergy    Disj part upper corner = (84.131, 71.05, 174.959)
VPMG::extEnergy    Old lower corner = (-80.7882, -86.7385, -12.0199)
VPMG::extEnergy    Old upper corner = (114.295, 99.3655, 210.842)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.00828927 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0224322 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.867320
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.681611e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 257, 289)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.003140e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 129, 145)
Vbuildops: Galer: (065, 065, 073)
Vbuildops: Galer: (033, 033, 037)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.719285e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.205966e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.183146e-01
Vprtstp: contraction number = 1.183146e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.760658e-02
Vprtstp: contraction number = 1.488116e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.107830e-03
Vprtstp: contraction number = 2.333121e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.712901e-03
Vprtstp: contraction number = 4.169844e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.029878e-04
Vprtstp: contraction number = 5.271687e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.428499e-04
Vprtstp: contraction number = 6.011708e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.402590e-04
Vprtstp: contraction number = 6.268012e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.146425e-04
Vprtstp: contraction number = 6.308210e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.393359e-04
Vprtstp: contraction number = 6.491535e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.059263e-05
Vprtstp: contraction number = 6.501742e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.954100e-05
Vprtstp: contraction number = 6.572389e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.970666e-05
Vprtstp: contraction number = 6.668793e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.626409e-05
Vprtstp: contraction number = 6.614531e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.786097e-05
Vprtstp: contraction number = 6.800528e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.187275e-05
Vprtstp: contraction number = 6.647314e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 8.189626e-06
Vprtstp: contraction number = 6.897836e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 5.473749e-06
Vprtstp: contraction number = 6.683760e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.813035e-06
Vprtstp: contraction number = 6.966038e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.565022e-06
Vprtstp: contraction number = 6.726983e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.797669e-06
Vprtstp: contraction number = 7.008394e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.218151e-06
Vprtstp: contraction number = 6.776285e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 8.564063e-07
Vprtstp: contraction number = 7.030376e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.053628e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.893229e+01
Vpmg_setPart:  lower corner = (-50.624, -58.423, 23.8634)
Vpmg_setPart:  upper corner = (84.131, 71.05, 174.959)
Vpmg_setPart:  actual minima = (-50.624, -58.423, 23.8634)
Vpmg_setPart:  actual maxima = (84.131, 71.05, 174.959)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.142432519054E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.583700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.376464e+02
