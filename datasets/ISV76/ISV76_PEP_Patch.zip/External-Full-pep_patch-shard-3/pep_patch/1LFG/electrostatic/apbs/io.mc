##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10528 atoms
Valist_getStatistics:  Max atom coordinate:  (36.822, 58.816, 41.541)
Valist_getStatistics:  Min atom coordinate:  (-54.508, -4.849, -26.513)
Valist_getStatistics:  Molecule center:  (-8.843, 26.9835, 7.514)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.717022, 0.704129, 0.630764
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.511063, 0.539194, 0.475204
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.712758, 0.765759, 0.753379 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -8.843 26.9835 7.514
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 71.4634 83.3139 68.0673
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -89.1495 -29.3469 -53.0393
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 48.3961 70.119 53.1336
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -66.0821 -16.152 -38.1056
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 48.3961 70.119 53.1336
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -66.0821 -16.152 -38.1056
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.479060
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.569572e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.446460e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 081, 097)
Vbuildops: Galer: (057, 041, 049)
Vbuildops: Galer: (029, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.113610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.750075e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.206569e-02
Vprtstp: contraction number = 8.206569e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.192718e-02
Vprtstp: contraction number = 1.453370e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.906871e-03
Vprtstp: contraction number = 2.437183e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.170510e-03
Vprtstp: contraction number = 4.026699e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.578301e-04
Vprtstp: contraction number = 4.765703e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.545054e-04
Vprtstp: contraction number = 6.355078e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.875105e-04
Vprtstp: contraction number = 5.289356e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.265131e-04
Vprtstp: contraction number = 6.746988e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.738454e-05
Vprtstp: contraction number = 5.326289e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.589217e-05
Vprtstp: contraction number = 6.810489e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.446921e-05
Vprtstp: contraction number = 5.331891e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.670622e-05
Vprtstp: contraction number = 6.827446e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.910289e-06
Vprtstp: contraction number = 5.333516e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.089253e-06
Vprtstp: contraction number = 6.833956e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 3.247741e-06
Vprtstp: contraction number = 5.333562e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.220298e-06
Vprtstp: contraction number = 6.836438e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.184120e-06
Vprtstp: contraction number = 5.333158e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 8.096993e-07
Vprtstp: contraction number = 6.837984e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.506545e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.622077e+01
Vpmg_setPart:  lower corner = (-89.1495, -29.3469, -53.0393)
Vpmg_setPart:  upper corner = (71.4634, 83.3139, 68.0673)
Vpmg_setPart:  actual minima = (-89.1495, -29.3469, -53.0393)
Vpmg_setPart:  actual maxima = (71.4634, 83.3139, 68.0673)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.758609270911E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.994000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.8931
Vpbe_ctor2:  solute dimensions = 94.4782 x 66.271 x 71.2392
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (104.11, 76.445, 80.834)
Vclist_setupGrid:  Grid lower corner = (-60.898, -11.239, -32.903)
Vclist_assignAtoms:  Have 7669266 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -66.0821, -16.152, -38.1056
VPMG::focusFillBound -- New mesh maxs = 48.3961, 70.119, 53.1336
VPMG::focusFillBound -- Old mesh mins = -89.1495, -29.3469, -53.0393
VPMG::focusFillBound -- Old mesh maxs = 71.4634, 83.3139, 68.0673
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-66.0821, -16.152, -38.1056)
Vpmg_setPart:  upper corner = (48.3961, 70.119, 53.1336)
Vpmg_setPart:  actual minima = (-89.1495, -29.3469, -53.0393)
Vpmg_setPart:  actual maxima = (71.4634, 83.3139, 68.0673)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-66.0821, -16.152, -38.1056)
VPMG::extEnergy    Disj part upper corner = (48.3961, 70.119, 53.1336)
VPMG::extEnergy    Old lower corner = (-89.1495, -29.3469, -53.0393)
VPMG::extEnergy    Old upper corner = (71.4634, 83.3139, 68.0673)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.221121 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.215392 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.464499
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.258301e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.461680e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 081, 097)
Vbuildops: Galer: (057, 041, 049)
Vbuildops: Galer: (029, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.070610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.325807e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.180005e-01
Vprtstp: contraction number = 1.180005e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.618611e-02
Vprtstp: contraction number = 1.371698e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.034091e-03
Vprtstp: contraction number = 1.874503e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.266384e-04
Vprtstp: contraction number = 2.724501e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.184567e-04
Vprtstp: contraction number = 3.852431e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.617061e-04
Vprtstp: contraction number = 5.077804e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.026950e-05
Vprtstp: contraction number = 4.963913e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.697011e-05
Vprtstp: contraction number = 5.851552e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.396381e-05
Vprtstp: contraction number = 5.101928e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.442413e-05
Vprtstp: contraction number = 6.019129e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.380469e-06
Vprtstp: contraction number = 5.116752e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.486518e-06
Vprtstp: contraction number = 6.078907e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.298165e-06
Vprtstp: contraction number = 5.122381e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.404460e-06
Vprtstp: contraction number = 6.111221e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 7.203678e-07
Vprtstp: contraction number = 5.129145e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.245719e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.360964e+01
Vpmg_setPart:  lower corner = (-66.0821, -16.152, -38.1056)
Vpmg_setPart:  upper corner = (48.3961, 70.119, 53.1336)
Vpmg_setPart:  actual minima = (-66.0821, -16.152, -38.1056)
Vpmg_setPart:  actual maxima = (48.3961, 70.119, 53.1336)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.937516370655E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.946000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.726707e+01
