##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:58:01 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4624 atoms
Valist_getStatistics:  Max atom coordinate:  (17.127, 45.885, 40.672)
Valist_getStatistics:  Min atom coordinate:  (-36.074, -1.967, -12.37)
Valist_getStatistics:  Molecule center:  (-9.4735, 21.959, 14.151)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.593247, 0.677346, 0.585002
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.473969, 0.554689, 0.469119
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.79894, 0.818915, 0.80191 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -9.4735 21.959 14.151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 37.9862 65.3092 60.9511
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -56.9333 -21.3911 -32.6492
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 28.444 57.4591 51.6805
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -47.391 -13.5411 -23.3785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 28.444 57.4591 51.6805
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -47.391 -13.5411 -23.3785
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6904299 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.681829
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.356658e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.671090e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.183570e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.383715e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.652400e-02
Vprtstp: contraction number = 8.652400e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.152688e-02
Vprtstp: contraction number = 1.332218e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.527361e-03
Vprtstp: contraction number = 2.192580e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.157270e-04
Vprtstp: contraction number = 2.436245e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.416520e-04
Vprtstp: contraction number = 3.924661e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.166418e-05
Vprtstp: contraction number = 2.965595e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.253517e-05
Vprtstp: contraction number = 4.539949e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.007395e-05
Vprtstp: contraction number = 3.096326e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.633479e-06
Vprtstp: contraction number = 4.599467e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.457588e-06
Vprtstp: contraction number = 3.145774e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.678563e-07
Vprtstp: contraction number = 4.581928e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.937904e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.942288e+00
Vpmg_setPart:  lower corner = (-56.9333, -21.3911, -32.6492)
Vpmg_setPart:  upper corner = (37.9862, 65.3092, 60.9511)
Vpmg_setPart:  actual minima = (-56.9333, -21.3911, -32.6492)
Vpmg_setPart:  actual maxima = (37.9862, 65.3092, 60.9511)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.395793063679E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 7.083000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 33.2253
Vpbe_ctor2:  solute dimensions = 55.835 x 51.0002 x 55.059
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.981, 60.632, 65.822)
Vclist_setupGrid:  Grid lower corner = (-42.464, -8.357, -18.76)
Vclist_assignAtoms:  Have 6904299 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -47.391, -13.5411, -23.3785
VPMG::focusFillBound -- New mesh maxs = 28.444, 57.4591, 51.6805
VPMG::focusFillBound -- Old mesh mins = -56.9333, -21.3911, -32.6492
VPMG::focusFillBound -- Old mesh maxs = 37.9862, 65.3092, 60.9511
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-47.391, -13.5411, -23.3785)
Vpmg_setPart:  upper corner = (28.444, 57.4591, 51.6805)
Vpmg_setPart:  actual minima = (-56.9333, -21.3911, -32.6492)
Vpmg_setPart:  actual maxima = (37.9862, 65.3092, 60.9511)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-47.391, -13.5411, -23.3785)
VPMG::extEnergy    Disj part upper corner = (28.444, 57.4591, 51.6805)
VPMG::extEnergy    Old lower corner = (-56.9333, -21.3911, -32.6492)
VPMG::extEnergy    Old upper corner = (37.9862, 65.3092, 60.9511)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0235757 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.046369 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.764447
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.702904e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.905400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 081)
Vbuildops: Galer: (041, 033, 041)
Vbuildops: Galer: (021, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.919740e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.195616e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.151095e-01
Vprtstp: contraction number = 1.151095e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.555681e-02
Vprtstp: contraction number = 1.351479e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.806450e-03
Vprtstp: contraction number = 1.804001e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.042528e-04
Vprtstp: contraction number = 2.153086e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.825861e-04
Vprtstp: contraction number = 3.021685e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.474023e-05
Vprtstp: contraction number = 2.998050e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.179557e-05
Vprtstp: contraction number = 3.981637e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.405790e-06
Vprtstp: contraction number = 3.397842e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.109508e-06
Vprtstp: contraction number = 4.198753e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.096167e-06
Vprtstp: contraction number = 3.525212e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.616403e-07
Vprtstp: contraction number = 4.211403e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.679834e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.592860e+00
Vpmg_setPart:  lower corner = (-47.391, -13.5411, -23.3785)
Vpmg_setPart:  upper corner = (28.444, 57.4591, 51.6805)
Vpmg_setPart:  actual minima = (-47.391, -13.5411, -23.3785)
Vpmg_setPart:  actual maxima = (28.444, 57.4591, 51.6805)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.086577826184E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.182000e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.978815e+01
