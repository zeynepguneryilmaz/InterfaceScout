##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (385, 353, 449)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 81285 atoms
Valist_getStatistics:  Max atom coordinate:  (146.872, 185.854, 168.776)
Valist_getStatistics:  Min atom coordinate:  (-14.542, 39.991, -24.762)
Valist_getStatistics:  Molecule center:  (66.165, 112.923, 72.007)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.728407, 0.719319, 0.7449
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.480558, 0.479947, 0.482819
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.659738, 0.667224, 0.648167 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 66.165 112.923 72.007
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 206.019 239.523 238.865
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -73.689 -13.6777 -94.8505
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 158.432 197.393 180.159
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -26.1021 28.4518 -36.1445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 158.432 197.393 180.159
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -26.1021 28.4518 -36.1445
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -71
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12670908 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.788429
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.691317e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (385, 353, 449)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.265755e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (193, 177, 225)
Vbuildops: Galer: (097, 089, 113)
Vbuildops: Galer: (049, 045, 057)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.018421e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.196463e+02
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.754627e-02
Vprtstp: contraction number = 8.754627e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.603631e-02
Vprtstp: contraction number = 1.831752e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.197343e-03
Vprtstp: contraction number = 3.864569e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.277968e-03
Vprtstp: contraction number = 3.675717e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.391124e-03
Vprtstp: contraction number = 6.106864e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.308676e-04
Vprtstp: contraction number = 4.534949e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.973182e-04
Vprtstp: contraction number = 6.297965e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.938879e-04
Vprtstp: contraction number = 4.879914e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.212564e-04
Vprtstp: contraction number = 6.253941e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.146088e-05
Vprtstp: contraction number = 5.068673e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.841427e-05
Vprtstp: contraction number = 6.250198e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.983046e-05
Vprtstp: contraction number = 5.162264e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.247146e-05
Vprtstp: contraction number = 6.289043e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.482595e-06
Vprtstp: contraction number = 5.197944e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.117461e-06
Vprtstp: contraction number = 6.351562e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.142538e-06
Vprtstp: contraction number = 5.203543e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.376248e-06
Vprtstp: contraction number = 6.423445e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 7.151228e-07
Vprtstp: contraction number = 5.196178e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.298638e+02
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.224299e+02
Vpmg_setPart:  lower corner = (-73.689, -13.6777, -94.8505)
Vpmg_setPart:  upper corner = (206.019, 239.523, 238.865)
Vpmg_setPart:  actual minima = (-73.689, -13.6777, -94.8505)
Vpmg_setPart:  actual maxima = (206.019, 239.523, 238.865)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.784687537834E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.233320e-01
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 121.266
Vpbe_ctor2:  solute dimensions = 164.534 x 148.941 x 196.303
Vpbe_ctor2:  solute charge = -71
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (174.194, 158.643, 206.318)
Vclist_setupGrid:  Grid lower corner = (-20.932, 33.601, -31.152)
Vclist_assignAtoms:  Have 12670908 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -26.1021, 28.4518, -36.1445
VPMG::focusFillBound -- New mesh maxs = 158.432, 197.393, 180.159
VPMG::focusFillBound -- Old mesh mins = -73.689, -13.6777, -94.8505
VPMG::focusFillBound -- Old mesh maxs = 206.019, 239.523, 238.865
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-26.1021, 28.4518, -36.1445)
Vpmg_setPart:  upper corner = (158.432, 197.393, 180.159)
Vpmg_setPart:  actual minima = (-73.689, -13.6777, -94.8505)
Vpmg_setPart:  actual maxima = (206.019, 239.523, 238.865)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-26.1021, 28.4518, -36.1445)
VPMG::extEnergy    Disj part upper corner = (158.432, 197.393, 180.159)
VPMG::extEnergy    Old lower corner = (-73.689, -13.6777, -94.8505)
VPMG::extEnergy    Old upper corner = (206.019, 239.523, 238.865)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.113979 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.163811 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 16.759848
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.554316e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (385, 353, 449)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.251377e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (193, 177, 225)
Vbuildops: Galer: (097, 089, 113)
Vbuildops: Galer: (049, 045, 057)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.210875e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.798175e+02
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.348244e-01
Vprtstp: contraction number = 1.348244e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.072644e-02
Vprtstp: contraction number = 1.537292e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.439916e-03
Vprtstp: contraction number = 2.624626e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.091295e-03
Vprtstp: contraction number = 3.844351e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.254952e-03
Vprtstp: contraction number = 6.000836e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.431528e-04
Vprtstp: contraction number = 5.921765e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.065969e-04
Vprtstp: contraction number = 6.816860e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.300781e-04
Vprtstp: contraction number = 6.515596e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.286872e-04
Vprtstp: contraction number = 6.928275e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.555013e-04
Vprtstp: contraction number = 6.799739e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.086578e-04
Vprtstp: contraction number = 6.987579e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.544941e-05
Vprtstp: contraction number = 6.943766e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.327968e-05
Vprtstp: contraction number = 7.061643e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.729350e-05
Vprtstp: contraction number = 6.999573e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.668852e-05
Vprtstp: contraction number = 7.156346e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.868129e-05
Vprtstp: contraction number = 6.999748e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.357270e-05
Vprtstp: contraction number = 7.265397e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 9.457651e-06
Vprtstp: contraction number = 6.968142e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 6.981078e-06
Vprtstp: contraction number = 7.381407e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 4.831484e-06
Vprtstp: contraction number = 6.920829e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 3.622317e-06
Vprtstp: contraction number = 7.497318e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 2.487957e-06
Vprtstp: contraction number = 6.868413e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 1.893035e-06
Vprtstp: contraction number = 7.608792e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 1.290517e-06
Vprtstp: contraction number = 6.817184e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 9.954297e-07
Vprtstp: contraction number = 7.713420e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.624394e+02
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.567153e+02
Vpmg_setPart:  lower corner = (-26.1021, 28.4518, -36.1445)
Vpmg_setPart:  upper corner = (158.432, 197.393, 180.159)
Vpmg_setPart:  actual minima = (-26.1021, 28.4518, -36.1445)
Vpmg_setPart:  actual maxima = (158.432, 197.393, 180.159)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.026353151219E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.176040e-01
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
