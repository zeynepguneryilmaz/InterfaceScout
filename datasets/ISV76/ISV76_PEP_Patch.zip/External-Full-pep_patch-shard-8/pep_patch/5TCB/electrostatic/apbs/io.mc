##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:59:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3894 atoms
Valist_getStatistics:  Max atom coordinate:  (70.335, 49.103, 39.403)
Valist_getStatistics:  Min atom coordinate:  (24.289, 3.002, -14.503)
Valist_getStatistics:  Molecule center:  (47.312, 26.0525, 12.45)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.640714, 0.65255, 0.597754
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.533141, 0.540103, 0.47662
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.832104, 0.827681, 0.797352 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 47.312 26.0525 12.45
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 88.3177 67.8157 60.2703
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 6.3063 -15.7107 -35.3703
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 81.433 60.6191 50.5796
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 13.191 -8.5141 -25.6796
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 81.433 60.6191 50.5796
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 13.191 -8.5141 -25.6796
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.556306
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.075692e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.303700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.748220e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.530673e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.390698e-02
Vprtstp: contraction number = 9.390698e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.241174e-02
Vprtstp: contraction number = 1.321705e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.527010e-03
Vprtstp: contraction number = 2.035984e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.952707e-04
Vprtstp: contraction number = 1.959908e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.544287e-04
Vprtstp: contraction number = 3.118066e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.530409e-05
Vprtstp: contraction number = 2.286110e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.265526e-05
Vprtstp: contraction number = 3.584644e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.030120e-06
Vprtstp: contraction number = 2.394356e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.114661e-06
Vprtstp: contraction number = 3.678603e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.727009e-07
Vprtstp: contraction number = 2.446492e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.164222e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.606822e+00
Vpmg_setPart:  lower corner = (6.3063, -15.7107, -35.3703)
Vpmg_setPart:  upper corner = (88.3177, 67.8157, 60.2703)
Vpmg_setPart:  actual minima = (6.3063, -15.7107, -35.3703)
Vpmg_setPart:  actual maxima = (88.3177, 67.8157, 60.2703)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.217166383402E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.404000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 30.8072
Vpbe_ctor2:  solute dimensions = 48.242 x 49.1332 x 56.2592
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.826, 58.881, 66.686)
Vclist_setupGrid:  Grid lower corner = (17.899, -3.388, -20.893)
Vclist_assignAtoms:  Have 6499616 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 13.191, -8.5141, -25.6796
VPMG::focusFillBound -- New mesh maxs = 81.433, 60.6191, 50.5796
VPMG::focusFillBound -- Old mesh mins = 6.3063, -15.7107, -35.3703
VPMG::focusFillBound -- Old mesh maxs = 88.3177, 67.8157, 60.2703
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (13.191, -8.5141, -25.6796)
Vpmg_setPart:  upper corner = (81.433, 60.6191, 50.5796)
Vpmg_setPart:  actual minima = (6.3063, -15.7107, -35.3703)
Vpmg_setPart:  actual maxima = (88.3177, 67.8157, 60.2703)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (13.191, -8.5141, -25.6796)
VPMG::extEnergy    Disj part upper corner = (81.433, 60.6191, 50.5796)
VPMG::extEnergy    Old lower corner = (6.3063, -15.7107, -35.3703)
VPMG::extEnergy    Old upper corner = (88.3177, 67.8157, 60.2703)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0964685 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.118061 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.515337
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.311171e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.114900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.869710e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.477163e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.180226e-01
Vprtstp: contraction number = 1.180226e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.556266e-02
Vprtstp: contraction number = 1.318617e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.569963e-03
Vprtstp: contraction number = 1.651365e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.846136e-04
Vprtstp: contraction number = 1.885683e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.210249e-04
Vprtstp: contraction number = 2.497349e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.974285e-05
Vprtstp: contraction number = 2.457580e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.343626e-06
Vprtstp: contraction number = 3.141470e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.557136e-06
Vprtstp: contraction number = 2.736770e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.781432e-07
Vprtstp: contraction number = 3.434089e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.890542e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.344083e+00
Vpmg_setPart:  lower corner = (13.191, -8.5141, -25.6796)
Vpmg_setPart:  upper corner = (81.433, 60.6191, 50.5796)
Vpmg_setPart:  actual minima = (13.191, -8.5141, -25.6796)
Vpmg_setPart:  actual maxima = (81.433, 60.6191, 50.5796)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.782457545134E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.985000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.197913e+01
