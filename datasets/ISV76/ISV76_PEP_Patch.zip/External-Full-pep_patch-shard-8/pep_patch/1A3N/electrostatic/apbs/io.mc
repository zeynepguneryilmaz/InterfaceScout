##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:57:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8734 atoms
Valist_getStatistics:  Max atom coordinate:  (47.471, 30.722, 43.241)
Valist_getStatistics:  Min atom coordinate:  (-19.459, -25.892, -16.428)
Valist_getStatistics:  Molecule center:  (14.006, 2.415, 13.4065)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.613408, 0.634973, 0.656264
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.464995, 0.498514, 0.511038
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.758052, 0.785094, 0.778707 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 14.006 2.415 13.4065
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 72.8931 53.2128 65.9076
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -44.8811 -48.3828 -39.0946
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.6455 42.2961 54.2895
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -30.6335 -37.4661 -27.4765
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.6455 42.2961 54.2895
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -30.6335 -37.4661 -27.4765
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9290964 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.176687
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.196032e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.271360e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 081)
Vbuildops: Galer: (049, 041, 041)
Vbuildops: Galer: (025, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.912220e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.084238e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.384659e-02
Vprtstp: contraction number = 8.384659e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.151059e-02
Vprtstp: contraction number = 1.372815e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.940628e-03
Vprtstp: contraction number = 1.685950e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.676592e-04
Vprtstp: contraction number = 2.409835e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.239896e-04
Vprtstp: contraction number = 2.651281e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.634656e-05
Vprtstp: contraction number = 3.737940e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.769566e-05
Vprtstp: contraction number = 3.818118e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.100091e-06
Vprtstp: contraction number = 4.577444e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.558238e-06
Vprtstp: contraction number = 4.392837e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.705857e-06
Vprtstp: contraction number = 4.794107e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.772809e-07
Vprtstp: contraction number = 4.556541e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.436120e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.301405e+00
Vpmg_setPart:  lower corner = (-44.8811, -48.3828, -39.0946)
Vpmg_setPart:  upper corner = (72.8931, 53.2128, 65.9076)
Vpmg_setPart:  actual minima = (-44.8811, -48.3828, -39.0946)
Vpmg_setPart:  actual maxima = (72.8931, 53.2128, 65.9076)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.433465545873E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.334000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 37.3093
Vpbe_ctor2:  solute dimensions = 69.279 x 59.7622 x 61.766
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.71, 69.394, 72.449)
Vclist_setupGrid:  Grid lower corner = (-25.849, -32.282, -22.818)
Vclist_assignAtoms:  Have 9290964 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -30.6335, -37.4661, -27.4765
VPMG::focusFillBound -- New mesh maxs = 58.6455, 42.2961, 54.2895
VPMG::focusFillBound -- Old mesh mins = -44.8811, -48.3828, -39.0946
VPMG::focusFillBound -- Old mesh maxs = 72.8931, 53.2128, 65.9076
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-30.6335, -37.4661, -27.4765)
Vpmg_setPart:  upper corner = (58.6455, 42.2961, 54.2895)
Vpmg_setPart:  actual minima = (-44.8811, -48.3828, -39.0946)
Vpmg_setPart:  actual maxima = (72.8931, 53.2128, 65.9076)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-30.6335, -37.4661, -27.4765)
VPMG::extEnergy    Disj part upper corner = (58.6455, 42.2961, 54.2895)
VPMG::extEnergy    Old lower corner = (-44.8811, -48.3828, -39.0946)
VPMG::extEnergy    Old upper corner = (72.8931, 53.2128, 65.9076)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0345188 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0919766 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.177460
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.775814e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.089180e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 081)
Vbuildops: Galer: (049, 041, 041)
Vbuildops: Galer: (025, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.074660e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.517270e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.184256e-01
Vprtstp: contraction number = 1.184256e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.558262e-02
Vprtstp: contraction number = 1.315816e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.447659e-03
Vprtstp: contraction number = 1.570762e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.888449e-04
Vprtstp: contraction number = 1.997194e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.147692e-04
Vprtstp: contraction number = 2.347764e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.563811e-05
Vprtstp: contraction number = 3.105197e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.140982e-05
Vprtstp: contraction number = 3.201578e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.533957e-06
Vprtstp: contraction number = 3.973733e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.666232e-06
Vprtstp: contraction number = 3.675006e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.115190e-07
Vprtstp: contraction number = 4.270228e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.690506e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.544917e+00
Vpmg_setPart:  lower corner = (-30.6335, -37.4661, -27.4765)
Vpmg_setPart:  upper corner = (58.6455, 42.2961, 54.2895)
Vpmg_setPart:  actual minima = (-30.6335, -37.4661, -27.4765)
Vpmg_setPart:  actual maxima = (58.6455, 42.2961, 54.2895)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.918909073325E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.347000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.401794e+01
