##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:58:45 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 4318 atoms
Valist_getStatistics:  Max atom coordinate:  (-0.95, 50.347, 9.44)
Valist_getStatistics:  Min atom coordinate:  (-60.451, -13.516, -33.387)
Valist_getStatistics:  Molecule center:  (-30.7005, 18.4155, -11.9735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.655361, 0.710143, 0.600552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.510506, 0.542731, 0.509516
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.77897, 0.764256, 0.848413 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -30.7005 18.4155 -11.9735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 21.7283 75.227 26.4618
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -83.1294 -38.3959 -50.4088
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 10.14 61.834 20.6355
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -71.541 -25.003 -44.5825
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 10.14 61.834 20.6355
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -71.541 -25.003 -44.5825
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5677667 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.576709
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.283902e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.006390e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 065)
Vbuildops: Galer: (041, 041, 033)
Vbuildops: Galer: (021, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.549040e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.285003e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.989126e-02
Vprtstp: contraction number = 9.989126e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.385496e-02
Vprtstp: contraction number = 1.387004e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.706881e-03
Vprtstp: contraction number = 1.953727e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.707070e-04
Vprtstp: contraction number = 2.108357e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.600846e-04
Vprtstp: contraction number = 2.805023e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.056911e-05
Vprtstp: contraction number = 2.534228e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.366375e-05
Vprtstp: contraction number = 3.368019e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.779124e-06
Vprtstp: contraction number = 2.765803e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.356626e-06
Vprtstp: contraction number = 3.589790e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.899082e-07
Vprtstp: contraction number = 2.874102e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.762810e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.750457e+00
Vpmg_setPart:  lower corner = (-83.1294, -38.3959, -50.4088)
Vpmg_setPart:  upper corner = (21.7283, 75.227, 26.4618)
Vpmg_setPart:  actual minima = (-83.1294, -38.3959, -50.4088)
Vpmg_setPart:  actual maxima = (21.7283, 75.227, 26.4618)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.257177003206E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.996000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.4403
Vpbe_ctor2:  solute dimensions = 61.681 x 66.837 x 45.218
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (72.281, 76.643, 55.607)
Vclist_setupGrid:  Grid lower corner = (-66.841, -19.906, -39.777)
Vclist_assignAtoms:  Have 5677667 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -71.541, -25.003, -44.5825
VPMG::focusFillBound -- New mesh maxs = 10.14, 61.834, 20.6355
VPMG::focusFillBound -- Old mesh mins = -83.1294, -38.3959, -50.4088
VPMG::focusFillBound -- Old mesh maxs = 21.7283, 75.227, 26.4618
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-71.541, -25.003, -44.5825)
Vpmg_setPart:  upper corner = (10.14, 61.834, 20.6355)
Vpmg_setPart:  actual minima = (-83.1294, -38.3959, -50.4088)
Vpmg_setPart:  actual maxima = (21.7283, 75.227, 26.4618)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-71.541, -25.003, -44.5825)
VPMG::extEnergy    Disj part upper corner = (10.14, 61.834, 20.6355)
VPMG::extEnergy    Old lower corner = (-83.1294, -38.3959, -50.4088)
VPMG::extEnergy    Old upper corner = (21.7283, 75.227, 26.4618)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.114971 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0716444 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.802196
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.796850e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.178990e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 065)
Vbuildops: Galer: (041, 041, 033)
Vbuildops: Galer: (021, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.876440e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.069812e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.228924e-01
Vprtstp: contraction number = 1.228924e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.683773e-02
Vprtstp: contraction number = 1.370120e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.943623e-03
Vprtstp: contraction number = 1.748230e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.199014e-04
Vprtstp: contraction number = 2.105913e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.731362e-04
Vprtstp: contraction number = 2.792964e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.994292e-05
Vprtstp: contraction number = 2.884603e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.843272e-05
Vprtstp: contraction number = 3.690757e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.166023e-06
Vprtstp: contraction number = 3.345152e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.472346e-06
Vprtstp: contraction number = 4.009629e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.681910e-07
Vprtstp: contraction number = 3.511607e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.194516e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.028661e+00
Vpmg_setPart:  lower corner = (-71.541, -25.003, -44.5825)
Vpmg_setPart:  upper corner = (10.14, 61.834, 20.6355)
Vpmg_setPart:  actual minima = (-71.541, -25.003, -44.5825)
Vpmg_setPart:  actual maxima = (10.14, 61.834, 20.6355)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.945306006523E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.100000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.801896e+01
