##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:50:31 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11769 atoms
Valist_getStatistics:  Max atom coordinate:  (46.965, 62.976, 76.535)
Valist_getStatistics:  Min atom coordinate:  (-32.976, -0.079, 1.65)
Valist_getStatistics:  Molecule center:  (6.9945, 31.4485, 39.0925)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.733364, 0.702217, 0.686455
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.535557, 0.538069, 0.507964
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.730275, 0.766243, 0.739981 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 6.9945 31.4485 39.0925
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 77.3975 87.6258 104.992
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -63.4085 -24.7288 -26.8071
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.408 74.494 87.857
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -44.419 -11.597 -9.672
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.408 74.494 87.857
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -44.419 -11.597 -9.672
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -22
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880362 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.657275
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.673681e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.236790e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.591240e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.568589e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.066452e-02
Vprtstp: contraction number = 8.066452e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.087631e-02
Vprtstp: contraction number = 1.348339e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.709049e-03
Vprtstp: contraction number = 2.490779e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.392697e-04
Vprtstp: contraction number = 2.728890e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.848496e-04
Vprtstp: contraction number = 3.853121e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.177047e-04
Vprtstp: contraction number = 4.132171e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.005322e-05
Vprtstp: contraction number = 5.102024e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.220664e-05
Vprtstp: contraction number = 5.363017e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.054528e-05
Vprtstp: contraction number = 6.379205e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.220424e-05
Vprtstp: contraction number = 5.940167e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.463160e-06
Vprtstp: contraction number = 6.934607e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.136972e-06
Vprtstp: contraction number = 6.069804e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.658543e-06
Vprtstp: contraction number = 7.121983e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.227965e-06
Vprtstp: contraction number = 6.089760e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.600495e-06
Vprtstp: contraction number = 7.183662e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 9.740171e-07
Vprtstp: contraction number = 6.085725e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.156361e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.243127e+01
Vpmg_setPart:  lower corner = (-63.4085, -24.7288, -26.8071)
Vpmg_setPart:  upper corner = (77.3975, 87.6258, 104.992)
Vpmg_setPart:  actual minima = (-63.4085, -24.7288, -26.8071)
Vpmg_setPart:  actual maxima = (77.3975, 87.6258, 104.992)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.735571185564E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.006000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 47.7925
Vpbe_ctor2:  solute dimensions = 82.827 x 66.091 x 77.529
Vpbe_ctor2:  solute charge = -22
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (92.721, 75.835, 87.665)
Vclist_setupGrid:  Grid lower corner = (-39.366, -6.469, -4.74)
Vclist_assignAtoms:  Have 8880362 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -44.419, -11.597, -9.672
VPMG::focusFillBound -- New mesh maxs = 58.408, 74.494, 87.857
VPMG::focusFillBound -- Old mesh mins = -63.4085, -24.7288, -26.8071
VPMG::focusFillBound -- Old mesh maxs = 77.3975, 87.6258, 104.992
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-44.419, -11.597, -9.672)
Vpmg_setPart:  upper corner = (58.408, 74.494, 87.857)
Vpmg_setPart:  actual minima = (-63.4085, -24.7288, -26.8071)
Vpmg_setPart:  actual maxima = (77.3975, 87.6258, 104.992)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-44.419, -11.597, -9.672)
VPMG::extEnergy    Disj part upper corner = (58.408, 74.494, 87.857)
VPMG::extEnergy    Old lower corner = (-63.4085, -24.7288, -26.8071)
VPMG::extEnergy    Old upper corner = (77.3975, 87.6258, 104.992)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.131219 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.133498 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.650305
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.288553e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.240090e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.600350e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.931925e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.131853e-01
Vprtstp: contraction number = 1.131853e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.502228e-02
Vprtstp: contraction number = 1.327229e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.891428e-03
Vprtstp: contraction number = 1.924760e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.512041e-04
Vprtstp: contraction number = 2.598038e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.032640e-04
Vprtstp: contraction number = 4.037039e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.360884e-04
Vprtstp: contraction number = 4.487454e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.543068e-05
Vprtstp: contraction number = 5.542773e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.011544e-05
Vprtstp: contraction number = 5.318186e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.455503e-05
Vprtstp: contraction number = 6.121094e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.392568e-05
Vprtstp: contraction number = 5.671212e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.952554e-06
Vprtstp: contraction number = 6.428810e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.220797e-06
Vprtstp: contraction number = 5.831628e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.439759e-06
Vprtstp: contraction number = 6.588570e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.030707e-06
Vprtstp: contraction number = 5.903632e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.354432e-06
Vprtstp: contraction number = 6.669754e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 8.042102e-07
Vprtstp: contraction number = 5.937621e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.161666e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.248396e+01
Vpmg_setPart:  lower corner = (-44.419, -11.597, -9.672)
Vpmg_setPart:  upper corner = (58.408, 74.494, 87.857)
Vpmg_setPart:  actual minima = (-44.419, -11.597, -9.672)
Vpmg_setPart:  actual maxima = (58.408, 74.494, 87.857)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.922268699780E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.074000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.225181e+01
