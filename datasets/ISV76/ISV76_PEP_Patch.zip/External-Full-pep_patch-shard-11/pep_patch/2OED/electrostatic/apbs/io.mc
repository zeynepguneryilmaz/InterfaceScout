##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:10 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (65, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 862 atoms
Valist_getStatistics:  Max atom coordinate:  (10.788, 17.71, 14.851)
Valist_getStatistics:  Min atom coordinate:  (-9.347, -16.577, -14.694)
Valist_getStatistics:  Molecule center:  (0.7205, 0.5665, 0.0785)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.618459, 0.485204, 0.564843
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.618459, 0.441664, 0.540594
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 1, 0.910265, 0.95707 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.7205 0.5665 0.0785
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 20.5112 31.6195 27.191
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.0702 -30.4866 -27.0339
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 20.5112 28.833 26.027
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.0702 -27.7 -25.87
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 20.5112 28.833 26.027
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.0702 -27.7 -25.87
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.113527
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.228460e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.706500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 065, 049)
Vbuildops: Galer: (017, 033, 025)
Vbuildops: Galer: (009, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.528800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.220940e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.340812e-01
Vprtstp: contraction number = 1.340812e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.087889e-02
Vprtstp: contraction number = 1.557183e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.703199e-03
Vprtstp: contraction number = 1.773657e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.050320e-04
Vprtstp: contraction number = 1.903846e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.421745e-04
Vprtstp: contraction number = 2.016568e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.005596e-05
Vprtstp: contraction number = 2.114019e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.688811e-06
Vprtstp: contraction number = 2.225452e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.521046e-06
Vprtstp: contraction number = 2.274016e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.627200e-07
Vprtstp: contraction number = 2.384674e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.426610e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.360360e-01
Vpmg_setPart:  lower corner = (-19.0702, -30.4866, -27.0339)
Vpmg_setPart:  upper corner = (20.5112, 31.6195, 27.191)
Vpmg_setPart:  actual minima = (-19.0702, -30.4866, -27.0339)
Vpmg_setPart:  actual maxima = (20.5112, 31.6195, 27.1909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.445441835660E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.823000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 19.7585
Vpbe_ctor2:  solute dimensions = 23.2832 x 36.533 x 31.897
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 46 x 73 x 63 table
Vclist_ctor2:  Using 46 x 73 x 63 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (32.915, 47.067, 42.325)
Vclist_setupGrid:  Grid lower corner = (-15.737, -22.967, -21.084)
Vclist_assignAtoms:  Have 2282168 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.0702, -27.7, -25.87
VPMG::focusFillBound -- New mesh maxs = 20.5112, 28.833, 26.027
VPMG::focusFillBound -- Old mesh mins = -19.0702, -30.4866, -27.0339
VPMG::focusFillBound -- Old mesh maxs = 20.5112, 31.6195, 27.1909
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-19.0702, -27.7, -25.87)
Vpmg_setPart:  upper corner = (20.5112, 28.833, 26.027)
Vpmg_setPart:  actual minima = (-19.0702, -30.4866, -27.0339)
Vpmg_setPart:  actual maxima = (20.5112, 31.6195, 27.1909)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-19.0702, -27.7, -25.87)
VPMG::extEnergy    Disj part upper corner = (20.5112, 28.833, 26.027)
VPMG::extEnergy    Old lower corner = (-19.0702, -30.4866, -27.0339)
VPMG::extEnergy    Old upper corner = (20.5112, 31.6195, 27.1909)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.00518572 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0164395 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.112980
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.590030e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (065, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.700900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (033, 065, 049)
Vbuildops: Galer: (017, 033, 025)
Vbuildops: Galer: (009, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.644500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.629719e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.470989e-01
Vprtstp: contraction number = 1.470989e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.507949e-02
Vprtstp: contraction number = 1.704940e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.896345e-03
Vprtstp: contraction number = 1.952331e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.017193e-03
Vprtstp: contraction number = 2.077454e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.194420e-04
Vprtstp: contraction number = 2.157328e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.872974e-05
Vprtstp: contraction number = 2.220621e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.117406e-05
Vprtstp: contraction number = 2.293069e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.612727e-06
Vprtstp: contraction number = 2.338207e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.314390e-07
Vprtstp: contraction number = 2.416781e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.275830e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.221740e-01
Vpmg_setPart:  lower corner = (-19.0702, -27.7, -25.87)
Vpmg_setPart:  upper corner = (20.5112, 28.833, 26.027)
Vpmg_setPart:  actual minima = (-19.0702, -27.7, -25.87)
Vpmg_setPart:  actual maxima = (20.5112, 28.833, 26.027)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.706846443141E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.191000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.525853e+00
