##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:26 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5405 atoms
Valist_getStatistics:  Max atom coordinate:  (37.4, 43.251, 66.222)
Valist_getStatistics:  Min atom coordinate:  (-17.645, -16.456, -2.766)
Valist_getStatistics:  Molecule center:  (9.8775, 13.3975, 31.728)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.616994, 0.671417, 0.637164
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.487937, 0.519951, 0.478969
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.790831, 0.774409, 0.75172 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 9.8775 13.3975 31.728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 59.237 67.1108 92.8957
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.482 -40.3158 -29.4397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 48.9125 54.9936 77.709
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -29.1575 -28.1986 -14.253
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 48.9125 54.9936 77.709
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -29.1575 -28.1986 -14.253
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.745200
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.453542e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.030030e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 097)
Vbuildops: Galer: (041, 041, 049)
Vbuildops: Galer: (021, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.620190e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.102354e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.841025e-02
Vprtstp: contraction number = 8.841025e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.207298e-02
Vprtstp: contraction number = 1.365564e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.129089e-03
Vprtstp: contraction number = 1.763515e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.609072e-04
Vprtstp: contraction number = 2.164810e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.100976e-04
Vprtstp: contraction number = 2.388714e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.719520e-05
Vprtstp: contraction number = 3.378386e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.318161e-05
Vprtstp: contraction number = 3.543901e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.797340e-06
Vprtstp: contraction number = 4.398051e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.377669e-06
Vprtstp: contraction number = 4.101311e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.126151e-06
Vprtstp: contraction number = 4.736366e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.720963e-07
Vprtstp: contraction number = 4.192122e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.502314e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.136470e+00
Vpmg_setPart:  lower corner = (-39.482, -40.3158, -29.4397)
Vpmg_setPart:  upper corner = (59.237, 67.1108, 92.8957)
Vpmg_setPart:  actual minima = (-39.482, -40.3159, -29.4397)
Vpmg_setPart:  actual maxima = (59.237, 67.1108, 92.8957)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.648141105869E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.359000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.9114
Vpbe_ctor2:  solute dimensions = 58.07 x 63.1922 x 71.962
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (67.825, 72.487, 81.768)
Vclist_setupGrid:  Grid lower corner = (-24.035, -22.846, -9.156)
Vclist_assignAtoms:  Have 5695360 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -29.1575, -28.1986, -14.253
VPMG::focusFillBound -- New mesh maxs = 48.9125, 54.9936, 77.709
VPMG::focusFillBound -- Old mesh mins = -39.482, -40.3159, -29.4397
VPMG::focusFillBound -- Old mesh maxs = 59.237, 67.1108, 92.8957
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-29.1575, -28.1986, -14.253)
Vpmg_setPart:  upper corner = (48.9125, 54.9936, 77.709)
Vpmg_setPart:  actual minima = (-39.482, -40.3159, -29.4397)
Vpmg_setPart:  actual maxima = (59.237, 67.1108, 92.8957)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-29.1575, -28.1986, -14.253)
VPMG::extEnergy    Disj part upper corner = (48.9125, 54.9936, 77.709)
VPMG::extEnergy    Old lower corner = (-39.482, -40.3159, -29.4397)
VPMG::extEnergy    Old upper corner = (59.237, 67.1108, 92.8957)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0525782 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.091604 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.743416
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.803071e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.039780e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 097)
Vbuildops: Galer: (041, 041, 049)
Vbuildops: Galer: (021, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.603670e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.106740e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.195968e-01
Vprtstp: contraction number = 1.195968e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.593607e-02
Vprtstp: contraction number = 1.332482e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.732819e-03
Vprtstp: contraction number = 1.714864e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.713862e-04
Vprtstp: contraction number = 2.090831e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.529397e-04
Vprtstp: contraction number = 2.676643e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.215802e-05
Vprtstp: contraction number = 3.410365e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.109381e-05
Vprtstp: contraction number = 4.044212e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.740116e-06
Vprtstp: contraction number = 4.617524e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.533226e-06
Vprtstp: contraction number = 4.654181e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.302108e-06
Vprtstp: contraction number = 5.078299e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.094156e-06
Vprtstp: contraction number = 4.752844e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.668627e-07
Vprtstp: contraction number = 5.180821e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.081111e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.715232e+00
Vpmg_setPart:  lower corner = (-29.1575, -28.1986, -14.253)
Vpmg_setPart:  upper corner = (48.9125, 54.9936, 77.709)
Vpmg_setPart:  actual minima = (-29.1575, -28.1986, -14.253)
Vpmg_setPart:  actual maxima = (48.9125, 54.9936, 77.709)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.695877470225E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.386000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.923472e+01
