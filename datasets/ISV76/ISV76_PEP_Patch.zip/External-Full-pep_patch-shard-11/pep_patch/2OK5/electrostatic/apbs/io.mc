##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:24 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11094 atoms
Valist_getStatistics:  Max atom coordinate:  (-3.331, 72.827, 39.722)
Valist_getStatistics:  Min atom coordinate:  (-82.399, -8.218, -29.691)
Valist_getStatistics:  Molecule center:  (-42.865, 32.3045, 5.0155)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.72321, 0.743564, 0.637307
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.529584, 0.541557, 0.479053
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.732269, 0.728326, 0.751684 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -42.865 32.3045 5.0155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 26.5632 103.687 66.197
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -112.293 -39.0776 -56.1659
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 7.9751 84.294 51.0046
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -93.7051 -19.685 -40.9736
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 7.9751 84.294 51.0046
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -93.7051 -19.685 -40.9736
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479018 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.553973
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.675378e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.479210e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.738410e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.424122e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.508282e-02
Vprtstp: contraction number = 7.508282e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.922577e-03
Vprtstp: contraction number = 1.321551e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.577022e-03
Vprtstp: contraction number = 1.589327e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.885455e-04
Vprtstp: contraction number = 1.829685e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.103369e-05
Vprtstp: contraction number = 2.115219e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.694414e-05
Vprtstp: contraction number = 2.776194e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.310394e-06
Vprtstp: contraction number = 3.724234e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.693537e-06
Vprtstp: contraction number = 4.268414e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.102713e-06
Vprtstp: contraction number = 4.093921e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.543248e-07
Vprtstp: contraction number = 4.120064e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.587156e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.309143e+00
Vpmg_setPart:  lower corner = (-112.293, -39.0776, -56.1659)
Vpmg_setPart:  upper corner = (26.5632, 103.687, 66.197)
Vpmg_setPart:  actual minima = (-112.293, -39.0776, -56.1659)
Vpmg_setPart:  actual maxima = (26.5632, 103.687, 66.197)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.709067839092E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 9.734000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.1595
Vpbe_ctor2:  solute dimensions = 81.6802 x 83.979 x 71.9782
Vpbe_ctor2:  solute charge = 2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.848, 93.825, 82.193)
Vclist_setupGrid:  Grid lower corner = (-88.789, -14.608, -36.081)
Vclist_assignAtoms:  Have 7479018 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -93.7051, -19.685, -40.9736
VPMG::focusFillBound -- New mesh maxs = 7.9751, 84.294, 51.0046
VPMG::focusFillBound -- Old mesh mins = -112.293, -39.0776, -56.1659
VPMG::focusFillBound -- Old mesh maxs = 26.5632, 103.687, 66.197
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-93.7051, -19.685, -40.9736)
Vpmg_setPart:  upper corner = (7.9751, 84.294, 51.0046)
Vpmg_setPart:  actual minima = (-112.293, -39.0776, -56.1659)
Vpmg_setPart:  actual maxima = (26.5632, 103.687, 66.197)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-93.7051, -19.685, -40.9736)
VPMG::extEnergy    Disj part upper corner = (7.9751, 84.294, 51.0046)
VPMG::extEnergy    Old lower corner = (-112.293, -39.0776, -56.1659)
VPMG::extEnergy    Old upper corner = (26.5632, 103.687, 66.197)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0296823 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0487929 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.540621
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.427419e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.479500e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 097)
Vbuildops: Galer: (049, 049, 049)
Vbuildops: Galer: (025, 025, 025)
Vbuildops: Galer: (013, 013, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.702980e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.620677e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.158796e-01
Vprtstp: contraction number = 1.158796e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.559450e-02
Vprtstp: contraction number = 1.345750e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.426394e-03
Vprtstp: contraction number = 1.555929e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.257787e-04
Vprtstp: contraction number = 1.754780e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.697426e-05
Vprtstp: contraction number = 2.042710e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.409949e-05
Vprtstp: contraction number = 2.770876e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.544504e-06
Vprtstp: contraction number = 3.130565e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.889281e-06
Vprtstp: contraction number = 3.829651e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.101058e-06
Vprtstp: contraction number = 3.810838e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.441202e-07
Vprtstp: contraction number = 4.033575e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.595891e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.321362e+00
Vpmg_setPart:  lower corner = (-93.7051, -19.685, -40.9736)
Vpmg_setPart:  upper corner = (7.9751, 84.294, 51.0046)
Vpmg_setPart:  actual minima = (-93.7051, -19.685, -40.9736)
Vpmg_setPart:  actual maxima = (7.9751, 84.294, 51.0046)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.985152486406E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 9.447000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.638313e+01
