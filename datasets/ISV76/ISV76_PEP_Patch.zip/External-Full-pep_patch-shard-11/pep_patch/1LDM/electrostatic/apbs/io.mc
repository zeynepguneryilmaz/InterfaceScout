##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:51:49 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 193, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20624 atoms
Valist_getStatistics:  Max atom coordinate:  (43.286, 37.912, 33.174)
Valist_getStatistics:  Min atom coordinate:  (-43.286, -37.987, -33.091)
Valist_getStatistics:  Molecule center:  (0, -0.0375, 0.0415)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.67959, 0.692892, 0.609468
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.489045, 0.51175, 0.462677
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.719617, 0.738571, 0.759149 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 -0.0375 0.0415
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 76.1141 66.4801 58.5504
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -76.1141 -66.5551 -58.4674
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 54.773 49.0905 44.4585
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -54.773 -49.1655 -44.3755
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 54.773 49.0905 44.4585
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -54.773 -49.1655 -44.3755
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 16
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14133352 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.954187
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.540869e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.772690e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 097)
Vbuildops: Galer: (057, 049, 049)
Vbuildops: Galer: (029, 025, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.485778e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.370438e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.335974e-02
Vprtstp: contraction number = 8.335974e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.359932e-02
Vprtstp: contraction number = 1.631401e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.445620e-03
Vprtstp: contraction number = 3.269002e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.840757e-03
Vprtstp: contraction number = 4.140608e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.100401e-03
Vprtstp: contraction number = 5.977980e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.065364e-04
Vprtstp: contraction number = 5.511959e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.804468e-04
Vprtstp: contraction number = 6.272447e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.234656e-04
Vprtstp: contraction number = 5.873768e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.378448e-04
Vprtstp: contraction number = 6.168502e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.357164e-05
Vprtstp: contraction number = 6.062735e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.069126e-05
Vprtstp: contraction number = 6.065606e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.136353e-05
Vprtstp: contraction number = 6.187166e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.879461e-05
Vprtstp: contraction number = 5.992506e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.178807e-05
Vprtstp: contraction number = 6.272046e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 7.004879e-06
Vprtstp: contraction number = 5.942347e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.433829e-06
Vprtstp: contraction number = 6.329629e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.619528e-06
Vprtstp: contraction number = 5.908049e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.668257e-06
Vprtstp: contraction number = 6.368540e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 9.817090e-07
Vprtstp: contraction number = 5.884640e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.958680e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.137039e+01
Vpmg_setPart:  lower corner = (-76.1141, -66.5551, -58.4674)
Vpmg_setPart:  upper corner = (76.1141, 66.4801, 58.5504)
Vpmg_setPart:  actual minima = (-76.1141, -66.5551, -58.4674)
Vpmg_setPart:  actual maxima = (76.1141, 66.4801, 58.5504)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.404280102524E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.175100e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0228
Vpbe_ctor2:  solute dimensions = 89.546 x 78.256 x 68.834
Vpbe_ctor2:  solute charge = 16
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (99.352, 88.679, 79.045)
Vclist_setupGrid:  Grid lower corner = (-49.676, -44.377, -39.481)
Vclist_assignAtoms:  Have 14133352 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -54.773, -49.1655, -44.3755
VPMG::focusFillBound -- New mesh maxs = 54.773, 49.0905, 44.4585
VPMG::focusFillBound -- Old mesh mins = -76.1141, -66.5551, -58.4674
VPMG::focusFillBound -- Old mesh maxs = 76.1141, 66.4801, 58.5504
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-54.773, -49.1655, -44.3755)
Vpmg_setPart:  upper corner = (54.773, 49.0905, 44.4585)
Vpmg_setPart:  actual minima = (-76.1141, -66.5551, -58.4674)
Vpmg_setPart:  actual maxima = (76.1141, 66.4801, 58.5504)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-54.773, -49.1655, -44.3755)
VPMG::extEnergy    Disj part upper corner = (54.773, 49.0905, 44.4585)
VPMG::extEnergy    Old lower corner = (-76.1141, -66.5551, -58.4674)
VPMG::extEnergy    Old upper corner = (76.1141, 66.4801, 58.5504)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.283449 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.53653 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.937945
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.699190e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.757550e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 097)
Vbuildops: Galer: (057, 049, 049)
Vbuildops: Galer: (029, 025, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.484560e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.348813e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.166266e-01
Vprtstp: contraction number = 1.166266e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.564604e-02
Vprtstp: contraction number = 1.341550e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.947434e-03
Vprtstp: contraction number = 1.883821e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.137944e-04
Vprtstp: contraction number = 2.761026e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.138603e-04
Vprtstp: contraction number = 3.856752e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.526016e-04
Vprtstp: contraction number = 4.862088e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.995451e-05
Vprtstp: contraction number = 5.239426e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.589418e-05
Vprtstp: contraction number = 5.740036e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.575185e-05
Vprtstp: contraction number = 5.611136e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.532255e-05
Vprtstp: contraction number = 5.950078e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.754974e-06
Vprtstp: contraction number = 5.713784e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.267956e-06
Vprtstp: contraction number = 6.017100e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.028222e-06
Vprtstp: contraction number = 5.748383e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.830149e-06
Vprtstp: contraction number = 6.043643e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.054316e-06
Vprtstp: contraction number = 5.760818e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 6.385810e-07
Vprtstp: contraction number = 6.056828e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.665469e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.843614e+01
Vpmg_setPart:  lower corner = (-54.773, -49.1655, -44.3755)
Vpmg_setPart:  upper corner = (54.773, 49.0905, 44.4585)
Vpmg_setPart:  actual minima = (-54.773, -49.1655, -44.3755)
Vpmg_setPart:  actual maxima = (54.773, 49.0905, 44.4585)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 9.585716088337E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.170200e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.221413e+01
