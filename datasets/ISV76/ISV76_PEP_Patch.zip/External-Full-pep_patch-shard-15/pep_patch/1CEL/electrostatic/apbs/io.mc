##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:50:20 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6131 atoms
Valist_getStatistics:  Max atom coordinate:  (55.695, 86.664, 91.68)
Valist_getStatistics:  Min atom coordinate:  (4.658, 40.155, 25.691)
Valist_getStatistics:  Molecule center:  (30.1765, 63.4095, 58.6855)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.572008, 0.6579, 0.612152
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.461475, 0.54325, 0.464256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.806764, 0.825733, 0.7584 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.1765 63.4095 58.6855
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 75.9371 105.515 117.452
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -15.5841 21.3039 -0.0811
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 67.0945 98.1775 103.254
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -6.7415 28.6415 14.1169
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 67.0945 98.1775 103.254
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -6.7415 28.6415 14.1169
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -23
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8278659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.803467
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.543809e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.297800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 097)
Vbuildops: Galer: (041, 033, 049)
Vbuildops: Galer: (021, 017, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.343110e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.033436e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.093402e-01
Vprtstp: contraction number = 1.093402e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.909976e-02
Vprtstp: contraction number = 1.746820e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.517816e-03
Vprtstp: contraction number = 3.936079e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.499451e-03
Vprtstp: contraction number = 3.324703e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.484671e-03
Vprtstp: contraction number = 5.939990e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.217816e-04
Vprtstp: contraction number = 4.188009e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.771271e-04
Vprtstp: contraction number = 6.065266e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.847585e-04
Vprtstp: contraction number = 4.899105e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.104230e-04
Vprtstp: contraction number = 5.976612e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.078266e-05
Vprtstp: contraction number = 5.504530e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.551398e-05
Vprtstp: contraction number = 5.842781e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.097654e-05
Vprtstp: contraction number = 5.906559e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.199321e-05
Vprtstp: contraction number = 5.717438e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.368364e-06
Vprtstp: contraction number = 6.143780e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.145904e-06
Vprtstp: contraction number = 5.626628e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.602856e-06
Vprtstp: contraction number = 6.278140e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.449476e-06
Vprtstp: contraction number = 5.568791e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 9.207440e-07
Vprtstp: contraction number = 6.352253e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.748740e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.222166e+00
Vpmg_setPart:  lower corner = (-15.5841, 21.3039, -0.0811)
Vpmg_setPart:  upper corner = (75.9371, 105.515, 117.452)
Vpmg_setPart:  actual minima = (-15.5841, 21.3039, -0.0811)
Vpmg_setPart:  actual maxima = (75.9371, 105.515, 117.452)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.082586258155E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.298000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.7815
Vpbe_ctor2:  solute dimensions = 53.836 x 49.536 x 69.1372
Vpbe_ctor2:  solute charge = -23
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.817, 59.289, 78.769)
Vclist_setupGrid:  Grid lower corner = (-1.732, 33.765, 19.301)
Vclist_assignAtoms:  Have 8278659 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -6.7415, 28.6415, 14.1169
VPMG::focusFillBound -- New mesh maxs = 67.0945, 98.1775, 103.254
VPMG::focusFillBound -- Old mesh mins = -15.5841, 21.3039, -0.0811
VPMG::focusFillBound -- Old mesh maxs = 75.9371, 105.515, 117.452
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-6.7415, 28.6415, 14.1169)
Vpmg_setPart:  upper corner = (67.0945, 98.1775, 103.254)
Vpmg_setPart:  actual minima = (-15.5841, 21.3039, -0.0811)
Vpmg_setPart:  actual maxima = (75.9371, 105.515, 117.452)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-6.7415, 28.6415, 14.1169)
VPMG::extEnergy    Disj part upper corner = (67.0945, 98.1775, 103.254)
VPMG::extEnergy    Old lower corner = (-15.5841, 21.3039, -0.0811)
VPMG::extEnergy    Old upper corner = (75.9371, 105.515, 117.452)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.392543 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.251159 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.803806
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.916824e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.714500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 097)
Vbuildops: Galer: (041, 033, 049)
Vbuildops: Galer: (021, 017, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.444040e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.320620e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.316099e-01
Vprtstp: contraction number = 1.316099e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.018032e-02
Vprtstp: contraction number = 1.533344e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.904150e-03
Vprtstp: contraction number = 2.430164e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.447649e-03
Vprtstp: contraction number = 2.951886e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.407895e-04
Vprtstp: contraction number = 4.426415e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.880975e-04
Vprtstp: contraction number = 4.495977e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.500991e-04
Vprtstp: contraction number = 5.210010e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.734756e-05
Vprtstp: contraction number = 5.153101e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.095575e-05
Vprtstp: contraction number = 5.295028e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.221137e-05
Vprtstp: contraction number = 5.423261e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.171553e-05
Vprtstp: contraction number = 5.274563e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.507202e-06
Vprtstp: contraction number = 5.554339e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 3.411481e-06
Vprtstp: contraction number = 5.242623e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.919838e-06
Vprtstp: contraction number = 5.627580e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.001351e-06
Vprtstp: contraction number = 5.215810e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 5.680308e-07
Vprtstp: contraction number = 5.672645e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.765890e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.255928e+00
Vpmg_setPart:  lower corner = (-6.7415, 28.6415, 14.1169)
Vpmg_setPart:  upper corner = (67.0945, 98.1775, 103.254)
Vpmg_setPart:  actual minima = (-6.7415, 28.6415, 14.1169)
Vpmg_setPart:  actual maxima = (67.0945, 98.1775, 103.254)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.152358277176E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.087000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.193474e+01
