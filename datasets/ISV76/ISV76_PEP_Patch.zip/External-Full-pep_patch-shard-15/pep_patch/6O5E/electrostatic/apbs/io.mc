##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:32 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3014 atoms
Valist_getStatistics:  Max atom coordinate:  (37.807, 63.708, 66.754)
Valist_getStatistics:  Min atom coordinate:  (-6.801, 28.577, 17.075)
Valist_getStatistics:  Molecule center:  (15.503, 46.1425, 41.9145)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.62782, 0.492695, 0.561289
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.525556, 0.44607, 0.45517
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.837113, 0.905369, 0.810937 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 15.503 46.1425 41.9145
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 55.6835 77.6749 86.8176
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -24.6775 14.61 -2.9886
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 49.1386 74.691 78.3281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -18.1326 17.594 5.5009
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 49.1386 74.691 78.3281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -18.1326 17.594 5.5009
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6380823 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.402882
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.422200e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.587700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.155880e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.261506e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.163324e-01
Vprtstp: contraction number = 1.163324e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.697868e-02
Vprtstp: contraction number = 1.459497e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.176390e-03
Vprtstp: contraction number = 1.870811e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.225429e-04
Vprtstp: contraction number = 2.274730e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.024496e-04
Vprtstp: contraction number = 2.801904e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.540121e-05
Vprtstp: contraction number = 3.230494e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.323624e-05
Vprtstp: contraction number = 3.552876e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.575800e-06
Vprtstp: contraction number = 3.690701e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.098495e-06
Vprtstp: contraction number = 3.613068e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.191597e-06
Vprtstp: contraction number = 3.845727e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.320058e-07
Vprtstp: contraction number = 3.625436e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.339860e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.648626e+00
Vpmg_setPart:  lower corner = (-24.6775, 14.61, -2.9886)
Vpmg_setPart:  upper corner = (55.6835, 77.6749, 86.8176)
Vpmg_setPart:  actual minima = (-24.6775, 14.61, -2.9886)
Vpmg_setPart:  actual maxima = (55.6835, 77.6749, 86.8176)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.150801343689E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.472000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.7806
Vpbe_ctor2:  solute dimensions = 47.2712 x 37.097 x 52.8272
Vpbe_ctor2:  solute charge = -1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.388, 47.911, 62.459)
Vclist_setupGrid:  Grid lower corner = (-13.191, 22.187, 10.685)
Vclist_assignAtoms:  Have 6380823 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -18.1326, 17.594, 5.5009
VPMG::focusFillBound -- New mesh maxs = 49.1386, 74.691, 78.3281
VPMG::focusFillBound -- Old mesh mins = -24.6775, 14.61, -2.9886
VPMG::focusFillBound -- Old mesh maxs = 55.6835, 77.6749, 86.8176
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-18.1326, 17.594, 5.5009)
Vpmg_setPart:  upper corner = (49.1386, 74.691, 78.3281)
Vpmg_setPart:  actual minima = (-24.6775, 14.61, -2.9886)
Vpmg_setPart:  actual maxima = (55.6835, 77.6749, 86.8176)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-18.1326, 17.594, 5.5009)
VPMG::extEnergy    Disj part upper corner = (49.1386, 74.691, 78.3281)
VPMG::extEnergy    Old lower corner = (-24.6775, 14.61, -2.9886)
VPMG::extEnergy    Old upper corner = (55.6835, 77.6749, 86.8176)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0450694 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0828053 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.395919
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.142331e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.645000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 081)
Vbuildops: Galer: (033, 033, 041)
Vbuildops: Galer: (017, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.239880e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.080982e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.346844e-01
Vprtstp: contraction number = 1.346844e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.908429e-02
Vprtstp: contraction number = 1.416964e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.287425e-03
Vprtstp: contraction number = 1.722582e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.229913e-04
Vprtstp: contraction number = 2.199263e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.077968e-04
Vprtstp: contraction number = 2.874127e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.516655e-05
Vprtstp: contraction number = 3.136070e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.439693e-05
Vprtstp: contraction number = 3.743782e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.006013e-06
Vprtstp: contraction number = 3.691453e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.701108e-06
Vprtstp: contraction number = 4.109597e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.469070e-06
Vprtstp: contraction number = 3.969272e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.500685e-07
Vprtstp: contraction number = 4.425033e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.260026e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.581095e+00
Vpmg_setPart:  lower corner = (-18.1326, 17.594, 5.5009)
Vpmg_setPart:  upper corner = (49.1386, 74.691, 78.3281)
Vpmg_setPart:  actual minima = (-18.1326, 17.594, 5.5009)
Vpmg_setPart:  actual maxima = (49.1386, 74.691, 78.3281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.536803495721E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.505000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 9.945063e+00
