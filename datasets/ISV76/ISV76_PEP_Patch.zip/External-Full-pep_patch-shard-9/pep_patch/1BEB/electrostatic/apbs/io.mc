##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:48 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2486 atoms
Valist_getStatistics:  Max atom coordinate:  (9.194, 36.011, 10.98)
Valist_getStatistics:  Min atom coordinate:  (-35.21, -3.962, -29.901)
Valist_getStatistics:  Molecule center:  (-13.008, 16.0245, -9.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.623331, 0.566833, 0.57949
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.522916, 0.489681, 0.497127
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.838905, 0.86389, 0.857869 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -13.008 16.0245 -9.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 26.8852 52.3018 27.6269
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -52.9012 -20.2528 -46.5478
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 20.4586 47.3641 22.3556
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -46.4746 -15.3151 -41.2766
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 20.4586 47.3641 22.3556
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -46.4746 -15.3151 -41.2766
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.451380
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.038210e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 7.048500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.107600e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.373541e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.023279e-01
Vprtstp: contraction number = 1.023279e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.378581e-02
Vprtstp: contraction number = 1.347219e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.181898e-03
Vprtstp: contraction number = 1.582713e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.844094e-04
Vprtstp: contraction number = 1.761812e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.356222e-05
Vprtstp: contraction number = 1.913643e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.486931e-05
Vprtstp: contraction number = 2.021324e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.069391e-06
Vprtstp: contraction number = 2.064247e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.325074e-07
Vprtstp: contraction number = 2.060693e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.514692e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.838063e+00
Vpmg_setPart:  lower corner = (-52.9012, -20.2528, -46.5478)
Vpmg_setPart:  upper corner = (26.8852, 52.3018, 27.6269)
Vpmg_setPart:  actual minima = (-52.9012, -20.2528, -46.5478)
Vpmg_setPart:  actual maxima = (26.8852, 52.3018, 27.6269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.554973973106E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.271000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.0648
Vpbe_ctor2:  solute dimensions = 46.9332 x 42.6792 x 43.6322
Vpbe_ctor2:  solute charge = -8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (57.184, 52.753, 53.661)
Vclist_setupGrid:  Grid lower corner = (-41.6, -10.352, -36.291)
Vclist_assignAtoms:  Have 5583342 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -46.4746, -15.3151, -41.2766
VPMG::focusFillBound -- New mesh maxs = 20.4586, 47.3641, 22.3556
VPMG::focusFillBound -- Old mesh mins = -52.9012, -20.2528, -46.5478
VPMG::focusFillBound -- Old mesh maxs = 26.8852, 52.3018, 27.6269
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-46.4746, -15.3151, -41.2766)
Vpmg_setPart:  upper corner = (20.4586, 47.3641, 22.3556)
Vpmg_setPart:  actual minima = (-52.9012, -20.2528, -46.5478)
Vpmg_setPart:  actual maxima = (26.8852, 52.3018, 27.6269)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-46.4746, -15.3151, -41.2766)
VPMG::extEnergy    Disj part upper corner = (20.4586, 47.3641, 22.3556)
VPMG::extEnergy    Old lower corner = (-52.9012, -20.2528, -46.5478)
VPMG::extEnergy    Old upper corner = (26.8852, 52.3018, 27.6269)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.127025 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.178945 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.445387
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.245107e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.965400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.248470e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.492824e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.226814e-01
Vprtstp: contraction number = 1.226814e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.654009e-02
Vprtstp: contraction number = 1.348215e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.553209e-03
Vprtstp: contraction number = 1.543649e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.371930e-04
Vprtstp: contraction number = 1.712327e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.091865e-05
Vprtstp: contraction number = 1.850868e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.538178e-05
Vprtstp: contraction number = 1.900895e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.868405e-06
Vprtstp: contraction number = 1.864807e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.173341e-07
Vprtstp: contraction number = 1.803560e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.435685e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.767269e+00
Vpmg_setPart:  lower corner = (-46.4746, -15.3151, -41.2766)
Vpmg_setPart:  upper corner = (20.4586, 47.3641, 22.3556)
Vpmg_setPart:  actual minima = (-46.4746, -15.3151, -41.2766)
Vpmg_setPart:  actual maxima = (20.4586, 47.3641, 22.3556)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.139852155773E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.252000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 8.498666e+00
