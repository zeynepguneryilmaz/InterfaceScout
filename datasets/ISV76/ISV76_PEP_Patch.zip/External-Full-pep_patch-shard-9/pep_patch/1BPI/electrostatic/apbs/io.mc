##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:57:25 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 892 atoms
Valist_getStatistics:  Max atom coordinate:  (43.79, 24.093, 17.248)
Valist_getStatistics:  Min atom coordinate:  (16.941, -3.835, -16.916)
Valist_getStatistics:  Molecule center:  (30.3655, 10.129, 0.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.521581, 0.53017, 0.493239
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.515146, 0.520198, 0.446391
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.987662, 0.981191, 0.905019 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3655 10.129 0.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 55.4014 35.5771 31.7333
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 5.3296 -15.3191 -31.4013
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 55.0925 35.0985 28.735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 5.6385 -14.8405 -28.403
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 55.0925 35.0985 28.735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 5.6385 -14.8405 -28.403
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.169902
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.364980e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.889800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.746320e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.785380e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.270689e-01
Vprtstp: contraction number = 1.270689e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.614870e-02
Vprtstp: contraction number = 1.270861e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.402512e-03
Vprtstp: contraction number = 1.487743e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.773127e-04
Vprtstp: contraction number = 1.570493e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.506976e-05
Vprtstp: contraction number = 1.724558e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.161557e-05
Vprtstp: contraction number = 1.785094e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.242219e-06
Vprtstp: contraction number = 1.930357e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.389223e-07
Vprtstp: contraction number = 1.957535e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.395733e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.628393e+00
Vpmg_setPart:  lower corner = (5.3296, -15.3191, -31.4013)
Vpmg_setPart:  upper corner = (55.4014, 35.5771, 31.7333)
Vpmg_setPart:  actual minima = (5.3296, -15.3191, -31.4013)
Vpmg_setPart:  actual maxima = (55.4014, 35.5771, 31.7333)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.008694789402E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.336000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 21.8681
Vpbe_ctor2:  solute dimensions = 29.454 x 29.939 x 37.138
Vpbe_ctor2:  solute charge = 6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 58 x 59 x 74 table
Vclist_ctor2:  Using 58 x 59 x 74 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (39.629, 40.708, 46.944)
Vclist_setupGrid:  Grid lower corner = (10.551, -10.225, -23.306)
Vclist_assignAtoms:  Have 2442566 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 5.6385, -14.8405, -28.403
VPMG::focusFillBound -- New mesh maxs = 55.0925, 35.0985, 28.735
VPMG::focusFillBound -- Old mesh mins = 5.3296, -15.3191, -31.4013
VPMG::focusFillBound -- Old mesh maxs = 55.4014, 35.5771, 31.7333
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (5.6385, -14.8405, -28.403)
Vpmg_setPart:  upper corner = (55.0925, 35.0985, 28.735)
Vpmg_setPart:  actual minima = (5.3296, -15.3191, -31.4013)
Vpmg_setPart:  actual maxima = (55.4014, 35.5771, 31.7333)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (5.6385, -14.8405, -28.403)
VPMG::extEnergy    Disj part upper corner = (55.0925, 35.0985, 28.735)
VPMG::extEnergy    Old lower corner = (5.3296, -15.3191, -31.4013)
VPMG::extEnergy    Old upper corner = (55.4014, 35.5771, 31.7333)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0288345 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0207709 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.169046
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.097910e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.894200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.679390e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.038325e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.365097e-01
Vprtstp: contraction number = 1.365097e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.832017e-02
Vprtstp: contraction number = 1.342041e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.808486e-03
Vprtstp: contraction number = 1.533002e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.564610e-04
Vprtstp: contraction number = 1.625292e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.978665e-05
Vprtstp: contraction number = 1.747940e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.454373e-05
Vprtstp: contraction number = 1.822828e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.811894e-06
Vprtstp: contraction number = 1.933406e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.627114e-07
Vprtstp: contraction number = 2.001183e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.397592e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.626035e+00
Vpmg_setPart:  lower corner = (5.6385, -14.8405, -28.403)
Vpmg_setPart:  upper corner = (55.0925, 35.0985, 28.735)
Vpmg_setPart:  actual minima = (5.6385, -14.8405, -28.403)
Vpmg_setPart:  actual maxima = (55.0925, 35.0985, 28.735)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.289666699358E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.293000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.754741e+00
