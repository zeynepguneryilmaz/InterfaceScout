##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:57:56 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 193, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6622 atoms
Valist_getStatistics:  Max atom coordinate:  (-8.74, 32.263, 13.414)
Valist_getStatistics:  Min atom coordinate:  (-64.121, -43.559, -33.761)
Valist_getStatistics:  Molecule center:  (-36.4305, -5.648, -10.1735)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.610098, 0.698967, 0.667212
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.483881, 0.515324, 0.548728
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.79312, 0.737265, 0.822419 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -36.4305 -5.648 -10.1735
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 12.3774 61.4528 32.5281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -85.2383 -72.7488 -52.8751
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 2.28 43.8231 24.9451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -75.141 -55.1191 -45.2921
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 2.28 43.8231 24.9451
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -75.141 -55.1191 -45.2921
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.190570
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.153634e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.281320e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 065)
Vbuildops: Galer: (041, 049, 033)
Vbuildops: Galer: (021, 025, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.830450e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.066834e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.179511e-02
Vprtstp: contraction number = 8.179511e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.062796e-02
Vprtstp: contraction number = 1.299339e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.108899e-03
Vprtstp: contraction number = 1.984293e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.609210e-04
Vprtstp: contraction number = 2.185601e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.698725e-04
Vprtstp: contraction number = 3.685502e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.957301e-05
Vprtstp: contraction number = 2.918247e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.255878e-05
Vprtstp: contraction number = 4.550618e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.395012e-06
Vprtstp: contraction number = 3.278108e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.461604e-06
Vprtstp: contraction number = 4.680998e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.204424e-06
Vprtstp: contraction number = 3.479382e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.610367e-07
Vprtstp: contraction number = 4.658132e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.689979e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.573279e+00
Vpmg_setPart:  lower corner = (-85.2383, -72.7488, -52.8751)
Vpmg_setPart:  upper corner = (12.3774, 61.4528, 32.5281)
Vpmg_setPart:  actual minima = (-85.2383, -72.7488, -52.8751)
Vpmg_setPart:  actual maxima = (12.3774, 61.4528, 32.5281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.816085437958E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.262000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 44.4471
Vpbe_ctor2:  solute dimensions = 57.421 x 78.9422 x 50.2372
Vpbe_ctor2:  solute charge = -7
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (68.161, 88.602, 59.955)
Vclist_setupGrid:  Grid lower corner = (-70.511, -49.949, -40.151)
Vclist_assignAtoms:  Have 7690695 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -75.141, -55.1191, -45.2921
VPMG::focusFillBound -- New mesh maxs = 2.28, 43.8231, 24.9451
VPMG::focusFillBound -- Old mesh mins = -85.2383, -72.7488, -52.8751
VPMG::focusFillBound -- Old mesh maxs = 12.3774, 61.4528, 32.5281
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-75.141, -55.1191, -45.2921)
Vpmg_setPart:  upper corner = (2.28, 43.8231, 24.9451)
Vpmg_setPart:  actual minima = (-85.2383, -72.7488, -52.8751)
Vpmg_setPart:  actual maxima = (12.3774, 61.4528, 32.5281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-75.141, -55.1191, -45.2921)
VPMG::extEnergy    Disj part upper corner = (2.28, 43.8231, 24.9451)
VPMG::extEnergy    Old lower corner = (-85.2383, -72.7488, -52.8751)
VPMG::extEnergy    Old upper corner = (12.3774, 61.4528, 32.5281)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.077293 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0604453 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.178462
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.693461e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.264510e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 065)
Vbuildops: Galer: (041, 049, 033)
Vbuildops: Galer: (021, 025, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.726620e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.233880e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.103261e-01
Vprtstp: contraction number = 1.103261e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.431935e-02
Vprtstp: contraction number = 1.297911e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.333022e-03
Vprtstp: contraction number = 1.629280e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.730334e-04
Vprtstp: contraction number = 2.027556e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.453678e-04
Vprtstp: contraction number = 3.073099e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.993558e-05
Vprtstp: contraction number = 3.435119e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.214081e-05
Vprtstp: contraction number = 4.433875e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.520133e-06
Vprtstp: contraction number = 4.299812e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.537386e-06
Vprtstp: contraction number = 4.766095e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.049681e-06
Vprtstp: contraction number = 4.517317e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.875814e-07
Vprtstp: contraction number = 4.818220e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.702097e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.568895e+00
Vpmg_setPart:  lower corner = (-75.141, -55.1191, -45.2921)
Vpmg_setPart:  upper corner = (2.28, 43.8231, 24.9451)
Vpmg_setPart:  actual minima = (-75.141, -55.1191, -45.2921)
Vpmg_setPart:  actual maxima = (2.28, 43.8231, 24.9451)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.914997559441E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.250000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.909954e+01
