##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:56:31 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (193, 193, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 8699 atoms
Valist_getStatistics:  Max atom coordinate:  (74.16, 40.994, 76.405)
Valist_getStatistics:  Min atom coordinate:  (3.877, -27.049, 28.812)
Valist_getStatistics:  Molecule center:  (39.0185, 6.9725, 52.6085)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.649951, 0.630454, 0.67622
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.486491, 0.475022, 0.554027
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.748504, 0.75346, 0.819299 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 39.0185 6.9725 52.6085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 101.414 67.496 95.8866
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -23.3768 -53.5511 9.3304
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 85.7216 52.5746 88.0662
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -7.6846 -38.6296 17.1508
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 85.7216 52.5746 88.0662
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -7.6846 -38.6296 17.1508
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -29
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9199176 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.616078
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.780792e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.513200e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.503360e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.519726e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.814707e-02
Vprtstp: contraction number = 7.814707e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.047007e-02
Vprtstp: contraction number = 1.339791e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.215436e-03
Vprtstp: contraction number = 2.115970e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.516153e-04
Vprtstp: contraction number = 2.941251e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.308985e-04
Vprtstp: contraction number = 3.543479e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.732639e-05
Vprtstp: contraction number = 3.782025e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.613702e-05
Vprtstp: contraction number = 4.138155e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.406503e-05
Vprtstp: contraction number = 3.892140e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.031682e-06
Vprtstp: contraction number = 4.288424e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.350814e-06
Vprtstp: contraction number = 3.897443e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.020177e-06
Vprtstp: contraction number = 4.339674e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.968811e-07
Vprtstp: contraction number = 3.890318e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.546512e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.248239e+00
Vpmg_setPart:  lower corner = (-23.3768, -53.5511, 9.3304)
Vpmg_setPart:  upper corner = (101.414, 67.496, 95.8866)
Vpmg_setPart:  actual minima = (-23.3767, -53.5511, 9.3304)
Vpmg_setPart:  actual maxima = (101.414, 67.496, 95.8866)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.516987610879E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.065000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 42.3691
Vpbe_ctor2:  solute dimensions = 73.4062 x 71.2042 x 50.9154
Vpbe_ctor2:  solute charge = -29
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (83.063, 80.823, 60.373)
Vclist_setupGrid:  Grid lower corner = (-2.513, -33.439, 22.422)
Vclist_assignAtoms:  Have 9199176 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -7.6846, -38.6296, 17.1508
VPMG::focusFillBound -- New mesh maxs = 85.7216, 52.5746, 88.0662
VPMG::focusFillBound -- Old mesh mins = -23.3767, -53.5511, 9.3304
VPMG::focusFillBound -- Old mesh maxs = 101.414, 67.496, 95.8866
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-7.6846, -38.6296, 17.1508)
Vpmg_setPart:  upper corner = (85.7216, 52.5746, 88.0662)
Vpmg_setPart:  actual minima = (-23.3767, -53.5511, 9.3304)
Vpmg_setPart:  actual maxima = (101.414, 67.496, 95.8866)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-7.6846, -38.6296, 17.1508)
VPMG::extEnergy    Disj part upper corner = (85.7216, 52.5746, 88.0662)
VPMG::extEnergy    Old lower corner = (-23.3767, -53.5511, 9.3304)
VPMG::extEnergy    Old upper corner = (101.414, 67.496, 95.8866)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.743862 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.314066 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.601315
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.475072e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.548120e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 097, 065)
Vbuildops: Galer: (049, 049, 033)
Vbuildops: Galer: (025, 025, 017)
Vbuildops: Galer: (013, 013, 009)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.393940e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.524602e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.139998e-01
Vprtstp: contraction number = 1.139998e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.565646e-02
Vprtstp: contraction number = 1.373375e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.900503e-03
Vprtstp: contraction number = 1.852592e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.242101e-04
Vprtstp: contraction number = 2.496843e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.363791e-04
Vprtstp: contraction number = 3.263958e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.673936e-05
Vprtstp: contraction number = 3.669501e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.748006e-05
Vprtstp: contraction number = 4.320998e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.492848e-05
Vprtstp: contraction number = 3.983044e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.862141e-06
Vprtstp: contraction number = 4.596679e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.756510e-06
Vprtstp: contraction number = 4.016982e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.289427e-06
Vprtstp: contraction number = 4.677753e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.175469e-07
Vprtstp: contraction number = 4.013774e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.362707e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.040247e+00
Vpmg_setPart:  lower corner = (-7.6846, -38.6296, 17.1508)
Vpmg_setPart:  upper corner = (85.7216, 52.5746, 88.0662)
Vpmg_setPart:  actual minima = (-7.6846, -38.6296, 17.1508)
Vpmg_setPart:  actual maxima = (85.7216, 52.5746, 88.0662)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.103143964489E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.063000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.404628e+01
