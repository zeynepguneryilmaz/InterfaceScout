##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1397 atoms
Valist_getStatistics:  Max atom coordinate:  (45.852, 73.289, 20.559)
Valist_getStatistics:  Min atom coordinate:  (13.03, 27.999, -2.577)
Valist_getStatistics:  Molecule center:  (29.441, 50.644, 8.991)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.633392, 0.639109, 0.465449
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.580917, 0.532197, 0.465449
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.917152, 0.832716, 1 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 29.441 50.644 8.991
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 59.8438 91.547 31.3326
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -0.9618 9.741 -13.3506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.325 84.7046 31.3326
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 1.557 16.5834 -13.3506
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.325 84.7046 31.3326
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 1.557 16.5834 -13.3506
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.174834
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.421630e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.448800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.568600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.852190e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.225310e-01
Vprtstp: contraction number = 1.225310e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.890256e-02
Vprtstp: contraction number = 1.542676e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.653116e-03
Vprtstp: contraction number = 1.932604e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.918464e-04
Vprtstp: contraction number = 2.167592e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.015965e-04
Vprtstp: contraction number = 2.545904e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.548151e-05
Vprtstp: contraction number = 2.752107e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.815206e-05
Vprtstp: contraction number = 3.271731e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.077141e-06
Vprtstp: contraction number = 3.347907e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.312865e-06
Vprtstp: contraction number = 3.805843e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.503433e-07
Vprtstp: contraction number = 3.676580e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.213959e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.350502e+00
Vpmg_setPart:  lower corner = (-0.9618, 9.741, -13.3506)
Vpmg_setPart:  upper corner = (59.8438, 91.547, 31.3326)
Vpmg_setPart:  actual minima = (-0.9618, 9.741, -13.3506)
Vpmg_setPart:  actual maxima = (59.8438, 91.547, 31.3326)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.405999998642E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.607000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.5155
Vpbe_ctor2:  solute dimensions = 35.768 x 48.1212 x 26.2842
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 71 x 75 x 52 table
Vclist_ctor2:  Using 71 x 75 x 52 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.602, 58.07, 35.916)
Vclist_setupGrid:  Grid lower corner = (6.64, 21.609, -8.967)
Vclist_assignAtoms:  Have 3420580 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 1.557, 16.5834, -13.3506
VPMG::focusFillBound -- New mesh maxs = 57.325, 84.7046, 31.3326
VPMG::focusFillBound -- Old mesh mins = -0.9618, 9.741, -13.3506
VPMG::focusFillBound -- Old mesh maxs = 59.8438, 91.547, 31.3326
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (1.557, 16.5834, -13.3506)
Vpmg_setPart:  upper corner = (57.325, 84.7046, 31.3326)
Vpmg_setPart:  actual minima = (-0.9618, 9.741, -13.3506)
Vpmg_setPart:  actual maxima = (59.8438, 91.547, 31.3326)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (1.557, 16.5834, -13.3506)
VPMG::extEnergy    Disj part upper corner = (57.325, 84.7046, 31.3326)
VPMG::extEnergy    Old lower corner = (-0.9618, 9.741, -13.3506)
VPMG::extEnergy    Old upper corner = (59.8438, 91.547, 31.3326)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0546609 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.057981 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.175038
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.052280e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.534000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 049)
Vbuildops: Galer: (025, 033, 025)
Vbuildops: Galer: (013, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.598700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.457825e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.256966e-01
Vprtstp: contraction number = 1.256966e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.782697e-02
Vprtstp: contraction number = 1.418253e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.104363e-03
Vprtstp: contraction number = 1.741386e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.489553e-04
Vprtstp: contraction number = 2.090462e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.891598e-04
Vprtstp: contraction number = 2.914836e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.076502e-05
Vprtstp: contraction number = 3.212364e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.103413e-05
Vprtstp: contraction number = 3.461552e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.872274e-06
Vprtstp: contraction number = 3.742620e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.006115e-06
Vprtstp: contraction number = 3.818611e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.142917e-06
Vprtstp: contraction number = 3.801973e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.474366e-07
Vprtstp: contraction number = 3.914866e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.371479e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.509210e+00
Vpmg_setPart:  lower corner = (1.557, 16.5834, -13.3506)
Vpmg_setPart:  upper corner = (57.325, 84.7046, 31.3326)
Vpmg_setPart:  actual minima = (1.557, 16.5834, -13.3506)
Vpmg_setPart:  actual maxima = (57.325, 84.7046, 31.3326)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.460082100273E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.507000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.071857e+00
