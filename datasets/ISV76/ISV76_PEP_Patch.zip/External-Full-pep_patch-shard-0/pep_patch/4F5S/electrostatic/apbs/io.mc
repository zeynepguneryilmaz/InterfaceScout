##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9219 atoms
Valist_getStatistics:  Max atom coordinate:  (55.518, 54.313, 140.028)
Valist_getStatistics:  Min atom coordinate:  (-37.618, -8.602, 64.109)
Valist_getStatistics:  Molecule center:  (8.95, 22.8555, 102.069)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.728201, 0.696671, 0.699383
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.517639, 0.534806, 0.515569
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.710847, 0.76766, 0.737176 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.95 22.8555 102.069
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 90.5085 78.5891 169.209
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -72.6085 -32.8781 34.9277
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 66.9256 65.64 151.563
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -49.0256 -19.929 52.5739
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 66.9256 65.64 151.563
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -49.0256 -19.929 52.5739
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -17
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6233876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.293781
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.298115e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.443840e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 081, 097)
Vbuildops: Galer: (057, 041, 049)
Vbuildops: Galer: (029, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.308010e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.500181e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.622873e-02
Vprtstp: contraction number = 9.622873e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.942339e-02
Vprtstp: contraction number = 2.018460e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.125900e-03
Vprtstp: contraction number = 4.183565e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.631692e-03
Vprtstp: contraction number = 4.469280e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.946011e-03
Vprtstp: contraction number = 5.358414e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.087196e-03
Vprtstp: contraction number = 5.586793e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.542483e-04
Vprtstp: contraction number = 5.097962e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.343452e-04
Vprtstp: contraction number = 6.032408e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.635481e-04
Vprtstp: contraction number = 4.891594e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.025419e-04
Vprtstp: contraction number = 6.269835e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.903918e-05
Vprtstp: contraction number = 4.782354e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.138971e-05
Vprtstp: contraction number = 6.400944e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.484284e-05
Vprtstp: contraction number = 4.728569e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.601595e-06
Vprtstp: contraction number = 6.468839e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.515755e-06
Vprtstp: contraction number = 4.703130e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.935475e-06
Vprtstp: contraction number = 6.500519e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.377834e-06
Vprtstp: contraction number = 4.693734e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 8.973527e-07
Vprtstp: contraction number = 6.512778e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.437618e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.555561e+01
Vpmg_setPart:  lower corner = (-72.6085, -32.8781, 34.9277)
Vpmg_setPart:  upper corner = (90.5085, 78.5891, 169.209)
Vpmg_setPart:  actual minima = (-72.6085, -32.8781, 34.9277)
Vpmg_setPart:  actual maxima = (90.5085, 78.5891, 169.209)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.216708510716E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 9.307000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.0452
Vpbe_ctor2:  solute dimensions = 95.9512 x 65.569 x 78.9892
Vpbe_ctor2:  solute charge = -17
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.916, 75.695, 88.699)
Vclist_setupGrid:  Grid lower corner = (-44.008, -14.992, 57.719)
Vclist_assignAtoms:  Have 6233876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -49.0256, -19.929, 52.5739
VPMG::focusFillBound -- New mesh maxs = 66.9256, 65.64, 151.563
VPMG::focusFillBound -- Old mesh mins = -72.6085, -32.8781, 34.9277
VPMG::focusFillBound -- Old mesh maxs = 90.5085, 78.5891, 169.209
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-49.0256, -19.929, 52.5739)
Vpmg_setPart:  upper corner = (66.9256, 65.64, 151.563)
Vpmg_setPart:  actual minima = (-72.6085, -32.8781, 34.9277)
Vpmg_setPart:  actual maxima = (90.5085, 78.5891, 169.209)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-49.0256, -19.929, 52.5739)
VPMG::extEnergy    Disj part upper corner = (66.9256, 65.64, 151.563)
VPMG::extEnergy    Old lower corner = (-72.6085, -32.8781, 34.9277)
VPMG::extEnergy    Old upper corner = (90.5085, 78.5891, 169.209)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0818203 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0836343 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.283113
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.928597e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.436420e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 081, 097)
Vbuildops: Galer: (057, 041, 049)
Vbuildops: Galer: (029, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.850120e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.196848e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.258461e-01
Vprtstp: contraction number = 1.258461e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.915396e-02
Vprtstp: contraction number = 1.522015e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.059728e-03
Vprtstp: contraction number = 2.641610e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.736099e-03
Vprtstp: contraction number = 3.431210e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.529860e-04
Vprtstp: contraction number = 4.913233e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.204759e-04
Vprtstp: contraction number = 4.929459e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.218144e-04
Vprtstp: contraction number = 5.275318e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.201478e-04
Vprtstp: contraction number = 5.416593e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.241925e-05
Vprtstp: contraction number = 5.195204e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.546169e-05
Vprtstp: contraction number = 5.681211e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.824988e-05
Vprtstp: contraction number = 5.146363e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.070282e-05
Vprtstp: contraction number = 5.864596e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.498930e-06
Vprtstp: contraction number = 5.137835e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.295329e-06
Vprtstp: contraction number = 5.992674e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.699255e-06
Vprtstp: contraction number = 5.156555e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.033092e-06
Vprtstp: contraction number = 6.079675e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 5.362149e-07
Vprtstp: contraction number = 5.190391e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.360318e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.473516e+01
Vpmg_setPart:  lower corner = (-49.0256, -19.929, 52.5739)
Vpmg_setPart:  upper corner = (66.9256, 65.64, 151.563)
Vpmg_setPart:  actual minima = (-49.0256, -19.929, 52.5739)
Vpmg_setPart:  actual maxima = (66.9256, 65.64, 151.563)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.047037962413E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.808000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.706288e+01
