##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:50:28 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7461 atoms
Valist_getStatistics:  Max atom coordinate:  (51.081, 33.625, 68.431)
Valist_getStatistics:  Min atom coordinate:  (-13.925, -22.048, 7.855)
Valist_getStatistics:  Molecule center:  (18.578, 5.7885, 38.143)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.718579, 0.61894, 0.677694
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.547694, 0.489083, 0.523644
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.76219, 0.790194, 0.772684 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 18.578 5.7885 38.143
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 76.0644 55.3037 92.3586
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.9083 -43.7267 -16.0725
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 62.3935 44.9151 80.0345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -25.2375 -33.3381 -3.7485
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 62.3935 44.9151 80.0345
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -25.2375 -33.3381 -3.7485
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -12
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8115402 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.019916
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.724828e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.573500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.739380e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.260210e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.757466e-02
Vprtstp: contraction number = 8.757466e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.489209e-02
Vprtstp: contraction number = 1.700503e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.898253e-03
Vprtstp: contraction number = 3.960661e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.789057e-03
Vprtstp: contraction number = 3.033198e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.962553e-04
Vprtstp: contraction number = 5.568606e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.539626e-04
Vprtstp: contraction number = 3.552930e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.922369e-04
Vprtstp: contraction number = 5.430996e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.248488e-05
Vprtstp: contraction number = 3.770601e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.810319e-05
Vprtstp: contraction number = 5.256709e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.480366e-05
Vprtstp: contraction number = 3.885149e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.636640e-06
Vprtstp: contraction number = 5.158617e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.012351e-06
Vprtstp: contraction number = 3.944602e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.538465e-06
Vprtstp: contraction number = 5.107190e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.115485e-07
Vprtstp: contraction number = 3.975057e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.444972e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.961781e+00
Vpmg_setPart:  lower corner = (-38.9083, -43.7267, -16.0725)
Vpmg_setPart:  upper corner = (76.0644, 55.3037, 92.3586)
Vpmg_setPart:  actual minima = (-38.9083, -43.7267, -16.0725)
Vpmg_setPart:  actual maxima = (76.0644, 55.3037, 92.3585)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.906263138920E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.329000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 40.5448
Vpbe_ctor2:  solute dimensions = 67.631 x 58.2532 x 63.783
Vpbe_ctor2:  solute charge = -12
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (77.786, 68.453, 73.356)
Vclist_setupGrid:  Grid lower corner = (-20.315, -28.438, 1.465)
Vclist_assignAtoms:  Have 8115402 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -25.2375, -33.3381, -3.7485
VPMG::focusFillBound -- New mesh maxs = 62.3935, 44.9151, 80.0345
VPMG::focusFillBound -- Old mesh mins = -38.9083, -43.7267, -16.0725
VPMG::focusFillBound -- Old mesh maxs = 76.0644, 55.3037, 92.3585
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-25.2375, -33.3381, -3.7485)
Vpmg_setPart:  upper corner = (62.3935, 44.9151, 80.0345)
Vpmg_setPart:  actual minima = (-38.9083, -43.7267, -16.0725)
Vpmg_setPart:  actual maxima = (76.0644, 55.3037, 92.3585)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-25.2375, -33.3381, -3.7485)
VPMG::extEnergy    Disj part upper corner = (62.3935, 44.9151, 80.0345)
VPMG::extEnergy    Old lower corner = (-38.9083, -43.7267, -16.0725)
VPMG::extEnergy    Old upper corner = (76.0644, 55.3037, 92.3585)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0747634 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0569329 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.014520
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.093776e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.597600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.985350e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.135775e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.098396e-01
Vprtstp: contraction number = 1.098396e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.555530e-02
Vprtstp: contraction number = 1.416184e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.105914e-03
Vprtstp: contraction number = 2.639559e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.227310e-03
Vprtstp: contraction number = 2.989128e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.970045e-04
Vprtstp: contraction number = 4.864332e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.317418e-04
Vprtstp: contraction number = 3.881743e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.189059e-04
Vprtstp: contraction number = 5.130966e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.939457e-05
Vprtstp: contraction number = 4.154088e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.498536e-05
Vprtstp: contraction number = 5.058320e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.071376e-05
Vprtstp: contraction number = 4.288018e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.360318e-06
Vprtstp: contraction number = 5.003207e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.336525e-06
Vprtstp: contraction number = 4.358931e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.162004e-06
Vprtstp: contraction number = 4.973212e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.110317e-07
Vprtstp: contraction number = 4.397850e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.492385e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.032611e+00
Vpmg_setPart:  lower corner = (-25.2375, -33.3381, -3.7485)
Vpmg_setPart:  upper corner = (62.3935, 44.9151, 80.0345)
Vpmg_setPart:  actual minima = (-25.2375, -33.3381, -3.7485)
Vpmg_setPart:  actual maxima = (62.3935, 44.9151, 80.0345)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.138364743092E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.284000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.874287e+01
