##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:51:00 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1416 atoms
Valist_getStatistics:  Max atom coordinate:  (16.918, 20.221, 12.444)
Valist_getStatistics:  Min atom coordinate:  (-23.639, -20.226, -15.753)
Valist_getStatistics:  Molecule center:  (-3.3605, -0.0025, -1.6545)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.571612, 0.57767, 0.538546
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.492492, 0.496056, 0.525125
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.861585, 0.858719, 0.975079 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -3.3605 -0.0025 -1.6545
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 33.2227 36.9684 24.1957
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -39.9437 -36.9734 -27.5047
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 28.159 31.7451 23.5515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -34.88 -31.7501 -26.8605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 28.159 31.7451 23.5515
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -34.88 -31.7501 -26.8605
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.180319
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.948830e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.363300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.281250e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.837060e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.196310e-01
Vprtstp: contraction number = 1.196310e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.620023e-02
Vprtstp: contraction number = 1.354183e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.023937e-03
Vprtstp: contraction number = 1.866601e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.038160e-04
Vprtstp: contraction number = 2.658177e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.670309e-04
Vprtstp: contraction number = 3.322041e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.067702e-04
Vprtstp: contraction number = 3.998421e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.373816e-05
Vprtstp: contraction number = 4.096476e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.979845e-05
Vprtstp: contraction number = 4.526584e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.368432e-06
Vprtstp: contraction number = 4.226812e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.875191e-06
Vprtstp: contraction number = 4.630725e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.636384e-06
Vprtstp: contraction number = 4.222717e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.619979e-07
Vprtstp: contraction number = 4.656597e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.120645e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.302677e+00
Vpmg_setPart:  lower corner = (-39.9437, -36.9734, -27.5047)
Vpmg_setPart:  upper corner = (33.2227, 36.9684, 24.1957)
Vpmg_setPart:  actual minima = (-39.9437, -36.9734, -27.5047)
Vpmg_setPart:  actual maxima = (33.2227, 36.9684, 24.1957)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.436272192460E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.943000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 26.3633
Vpbe_ctor2:  solute dimensions = 43.039 x 43.4952 x 30.412
Vpbe_ctor2:  solute charge = -9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 60 table
Vclist_ctor2:  Using 75 x 75 x 60 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.337, 53.227, 40.977)
Vclist_setupGrid:  Grid lower corner = (-30.029, -26.616, -22.143)
Vclist_assignAtoms:  Have 3482706 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -34.88, -31.7501, -26.8605
VPMG::focusFillBound -- New mesh maxs = 28.159, 31.7451, 23.5515
VPMG::focusFillBound -- Old mesh mins = -39.9437, -36.9734, -27.5047
VPMG::focusFillBound -- Old mesh maxs = 33.2227, 36.9684, 24.1957
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-34.88, -31.7501, -26.8605)
Vpmg_setPart:  upper corner = (28.159, 31.7451, 23.5515)
Vpmg_setPart:  actual minima = (-39.9437, -36.9734, -27.5047)
Vpmg_setPart:  actual maxima = (33.2227, 36.9684, 24.1957)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-34.88, -31.7501, -26.8605)
VPMG::extEnergy    Disj part upper corner = (28.159, 31.7451, 23.5515)
VPMG::extEnergy    Old lower corner = (-39.9437, -36.9734, -27.5047)
VPMG::extEnergy    Old upper corner = (33.2227, 36.9684, 24.1957)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.101093 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0803956 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.178830
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.814850e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.427800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 049)
Vbuildops: Galer: (033, 033, 025)
Vbuildops: Galer: (017, 017, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.280770e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.582780e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.309756e-01
Vprtstp: contraction number = 1.309756e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.779714e-02
Vprtstp: contraction number = 1.358813e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.111564e-03
Vprtstp: contraction number = 1.748351e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.026213e-04
Vprtstp: contraction number = 2.258097e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.983791e-04
Vprtstp: contraction number = 2.823414e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.616837e-05
Vprtstp: contraction number = 3.335451e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.400333e-05
Vprtstp: contraction number = 3.627615e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.568052e-06
Vprtstp: contraction number = 3.986134e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.732491e-06
Vprtstp: contraction number = 3.900994e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.570331e-06
Vprtstp: contraction number = 4.207193e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.210771e-07
Vprtstp: contraction number = 3.955071e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.949263e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.131622e+00
Vpmg_setPart:  lower corner = (-34.88, -31.7501, -26.8605)
Vpmg_setPart:  upper corner = (28.159, 31.7451, 23.5515)
Vpmg_setPart:  actual minima = (-34.88, -31.7501, -26.8605)
Vpmg_setPart:  actual maxima = (28.159, 31.7451, 23.5515)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.600239408819E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.948000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.858609e+00
