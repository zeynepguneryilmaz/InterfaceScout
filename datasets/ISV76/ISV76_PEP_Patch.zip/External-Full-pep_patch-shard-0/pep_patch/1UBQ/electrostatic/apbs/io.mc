##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:50:09 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1231 atoms
Valist_getStatistics:  Max atom coordinate:  (46.124, 45.268, 36.251)
Valist_getStatistics:  Min atom coordinate:  (15.44, 12.896, -0.366)
Valist_getStatistics:  Molecule center:  (30.782, 29.082, 17.9425)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.593622, 0.620149, 0.530445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.557523, 0.573127, 0.468277
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.939189, 0.924176, 0.882799 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.782 29.082 17.9425
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 59.2758 58.8492 51.891
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 2.28815 -0.68515 -16.006
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 57.5431 56.5921 47.9122
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 4.0209 1.5719 -12.0272
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 57.5431 56.5921 47.9122
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 4.0209 1.5719 -12.0272
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.157195
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.275790e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.484600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.172100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.660940e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.150241e-01
Vprtstp: contraction number = 1.150241e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.595925e-02
Vprtstp: contraction number = 1.387470e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.536262e-03
Vprtstp: contraction number = 1.589212e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.294065e-04
Vprtstp: contraction number = 1.693069e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.239065e-05
Vprtstp: contraction number = 1.918710e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.598243e-05
Vprtstp: contraction number = 1.939836e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.571619e-06
Vprtstp: contraction number = 2.234715e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.542974e-07
Vprtstp: contraction number = 2.111920e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.234600e-01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.055524e+00
Vpmg_setPart:  lower corner = (2.28815, -0.68515, -16.006)
Vpmg_setPart:  upper corner = (59.2758, 58.8492, 51.891)
Vpmg_setPart:  actual minima = (2.28815, -0.68515, -16.006)
Vpmg_setPart:  actual maxima = (59.2758, 58.8492, 51.891)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.498298683888E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.193000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.0473
Vpbe_ctor2:  solute dimensions = 33.5222 x 35.0202 x 39.9394
Vpbe_ctor2:  solute charge = 9.27036e-15
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 67 x 70 x 75 table
Vclist_ctor2:  Using 67 x 70 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (43.464, 45.152, 49.397)
Vclist_setupGrid:  Grid lower corner = (9.05, 6.506, -6.756)
Vclist_assignAtoms:  Have 3629725 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 4.0209, 1.5719, -12.0272
VPMG::focusFillBound -- New mesh maxs = 57.5431, 56.5921, 47.9122
VPMG::focusFillBound -- Old mesh mins = 2.28815, -0.68515, -16.006
VPMG::focusFillBound -- Old mesh maxs = 59.2758, 58.8492, 51.891
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (4.0209, 1.5719, -12.0272)
Vpmg_setPart:  upper corner = (57.5431, 56.5921, 47.9122)
Vpmg_setPart:  actual minima = (2.28815, -0.68515, -16.006)
Vpmg_setPart:  actual maxima = (59.2758, 58.8492, 51.891)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (4.0209, 1.5719, -12.0272)
VPMG::extEnergy    Disj part upper corner = (57.5431, 56.5921, 47.9122)
VPMG::extEnergy    Old lower corner = (2.28815, -0.68515, -16.006)
VPMG::extEnergy    Old upper corner = (59.2758, 58.8492, 51.891)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0104251 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0143343 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.157190
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.863120e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.564000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.588100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.126432e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.312717e-01
Vprtstp: contraction number = 1.312717e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.934824e-02
Vprtstp: contraction number = 1.473908e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.213772e-03
Vprtstp: contraction number = 1.661016e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.656287e-04
Vprtstp: contraction number = 1.760015e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.079889e-04
Vprtstp: contraction number = 1.909183e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.145886e-05
Vprtstp: contraction number = 1.987136e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.735401e-06
Vprtstp: contraction number = 2.206734e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.037809e-06
Vprtstp: contraction number = 2.191597e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.552944e-07
Vprtstp: contraction number = 2.459936e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.070844e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.207178e+00
Vpmg_setPart:  lower corner = (4.0209, 1.5719, -12.0272)
Vpmg_setPart:  upper corner = (57.5431, 56.5921, 47.9122)
Vpmg_setPart:  actual minima = (4.0209, 1.5719, -12.0272)
Vpmg_setPart:  actual maxima = (57.5431, 56.5921, 47.9122)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.317083767700E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.627000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.453354e+00
