##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1653 atoms
Valist_getStatistics:  Max atom coordinate:  (47.533, 48.811, 16.711)
Valist_getStatistics:  Min atom coordinate:  (17.81, 13.783, -17.993)
Valist_getStatistics:  Molecule center:  (32.6715, 31.297, -0.641)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.572245, 0.500623, 0.499112
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.544948, 0.450734, 0.449845
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.952299, 0.900346, 0.901292 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 32.6715 31.297 -0.641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 60.1393 63.3369 31.3021
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 5.20375 -0.7429 -32.5842
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.829 60.144 28.1491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 6.514 2.45 -29.4311
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.829 60.144 28.1491
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 6.514 2.45 -29.4311
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.225768
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.008000e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.464000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.322710e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.998100e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.279499e-01
Vprtstp: contraction number = 1.279499e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.802066e-02
Vprtstp: contraction number = 1.408415e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.136434e-03
Vprtstp: contraction number = 1.740466e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.314392e-04
Vprtstp: contraction number = 2.013239e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.818796e-04
Vprtstp: contraction number = 2.880398e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.790984e-05
Vprtstp: contraction number = 3.733780e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.904628e-05
Vprtstp: contraction number = 4.277182e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.286774e-05
Vprtstp: contraction number = 4.430082e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.156267e-06
Vprtstp: contraction number = 4.784265e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.799376e-06
Vprtstp: contraction number = 4.547197e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.360775e-06
Vprtstp: contraction number = 4.860993e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 6.207073e-07
Vprtstp: contraction number = 4.561427e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.154933e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.346252e+00
Vpmg_setPart:  lower corner = (5.20375, -0.7429, -32.5842)
Vpmg_setPart:  upper corner = (60.1393, 63.3369, 31.3021)
Vpmg_setPart:  actual minima = (5.20375, -0.7429, -32.5842)
Vpmg_setPart:  actual maxima = (60.1393, 63.3369, 31.3021)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.822952097131E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.253000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.3058
Vpbe_ctor2:  solute dimensions = 32.315 x 37.694 x 37.5802
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 64 x 75 x 75 table
Vclist_ctor2:  Using 64 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (42.503, 47.808, 47.484)
Vclist_setupGrid:  Grid lower corner = (11.42, 7.393, -24.383)
Vclist_assignAtoms:  Have 5044982 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 6.514, 2.45, -29.4311
VPMG::focusFillBound -- New mesh maxs = 58.829, 60.144, 28.1491
VPMG::focusFillBound -- Old mesh mins = 5.20375, -0.7429, -32.5842
VPMG::focusFillBound -- Old mesh maxs = 60.1393, 63.3369, 31.3021
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (6.514, 2.45, -29.4311)
Vpmg_setPart:  upper corner = (58.829, 60.144, 28.1491)
Vpmg_setPart:  actual minima = (5.20375, -0.7429, -32.5842)
Vpmg_setPart:  actual maxima = (60.1393, 63.3369, 31.3021)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (6.514, 2.45, -29.4311)
VPMG::extEnergy    Disj part upper corner = (58.829, 60.144, 28.1491)
VPMG::extEnergy    Old lower corner = (5.20375, -0.7429, -32.5842)
VPMG::extEnergy    Old upper corner = (60.1393, 63.3369, 31.3021)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0349405 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0376149 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.222713
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.826970e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.538000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 065, 065)
Vbuildops: Galer: (025, 033, 033)
Vbuildops: Galer: (013, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.338230e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.844725e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.416009e-01
Vprtstp: contraction number = 1.416009e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.117080e-02
Vprtstp: contraction number = 1.495104e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.804965e-03
Vprtstp: contraction number = 1.797270e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.866629e-04
Vprtstp: contraction number = 2.067464e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.179997e-04
Vprtstp: contraction number = 2.771195e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.469086e-05
Vprtstp: contraction number = 3.426192e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.891675e-05
Vprtstp: contraction number = 3.871525e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.241538e-05
Vprtstp: contraction number = 4.293491e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.547693e-06
Vprtstp: contraction number = 4.468403e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.458200e-06
Vprtstp: contraction number = 4.431030e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.133023e-06
Vprtstp: contraction number = 4.609159e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.012019e-07
Vprtstp: contraction number = 4.423580e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.198052e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.390556e+00
Vpmg_setPart:  lower corner = (6.514, 2.45, -29.4311)
Vpmg_setPart:  upper corner = (58.829, 60.144, 28.1491)
Vpmg_setPart:  actual minima = (6.514, 2.45, -29.4311)
Vpmg_setPart:  actual maxima = (58.829, 60.144, 28.1491)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.875079341883E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.002000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.391843e+00
