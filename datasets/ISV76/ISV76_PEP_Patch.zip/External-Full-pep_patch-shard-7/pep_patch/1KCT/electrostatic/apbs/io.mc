##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:52:37 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 129, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5968 atoms
Valist_getStatistics:  Max atom coordinate:  (65.368, 24.495, 51.41)
Valist_getStatistics:  Min atom coordinate:  (-1.991, -23.12, -7.811)
Valist_getStatistics:  Molecule center:  (31.6885, 0.6875, 21.7995)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.624282, 0.670185, 0.660822
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.471392, 0.550477, 0.513719
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.755094, 0.82138, 0.777394 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.6885 0.6875 21.7995
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 91.6196 43.5793 74.6653
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -28.2426 -42.2043 -31.0663
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 76.9421 35.918 62.897
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -13.5651 -34.543 -19.298
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 76.9421 35.918 62.897
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -13.5651 -34.543 -19.298
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107214 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.784998
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.471669e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.286500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 065, 081)
Vbuildops: Galer: (049, 033, 041)
Vbuildops: Galer: (025, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.670060e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.993610e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.548794e-02
Vprtstp: contraction number = 9.548794e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.379665e-02
Vprtstp: contraction number = 1.444858e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.396277e-03
Vprtstp: contraction number = 2.461668e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.210512e-03
Vprtstp: contraction number = 3.564232e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.774662e-04
Vprtstp: contraction number = 4.770429e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.129581e-04
Vprtstp: contraction number = 5.419505e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.689678e-04
Vprtstp: contraction number = 5.399054e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.963904e-05
Vprtstp: contraction number = 5.896926e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.370668e-05
Vprtstp: contraction number = 5.390124e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.251588e-05
Vprtstp: contraction number = 6.054347e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.738144e-05
Vprtstp: contraction number = 5.345522e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.064707e-05
Vprtstp: contraction number = 6.125542e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.657858e-06
Vprtstp: contraction number = 5.314004e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.486684e-06
Vprtstp: contraction number = 6.162550e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.846116e-06
Vprtstp: contraction number = 5.294763e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.141405e-06
Vprtstp: contraction number = 6.182734e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 6.030256e-07
Vprtstp: contraction number = 5.283188e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.242831e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.748307e+00
Vpmg_setPart:  lower corner = (-28.2426, -42.2043, -31.0663)
Vpmg_setPart:  upper corner = (91.6196, 43.5793, 74.6653)
Vpmg_setPart:  actual minima = (-28.2426, -42.2043, -31.0663)
Vpmg_setPart:  actual maxima = (91.6196, 43.5793, 74.6653)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.674412544239E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.104000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8916
Vpbe_ctor2:  solute dimensions = 70.5072 x 50.461 x 62.195
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (80.139, 60.395, 72.001)
Vclist_setupGrid:  Grid lower corner = (-8.381, -29.51, -14.201)
Vclist_assignAtoms:  Have 7107214 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -13.5651, -34.543, -19.298
VPMG::focusFillBound -- New mesh maxs = 76.9421, 35.918, 62.897
VPMG::focusFillBound -- Old mesh mins = -28.2426, -42.2043, -31.0663
VPMG::focusFillBound -- Old mesh maxs = 91.6196, 43.5793, 74.6653
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-13.5651, -34.543, -19.298)
Vpmg_setPart:  upper corner = (76.9421, 35.918, 62.897)
Vpmg_setPart:  actual minima = (-28.2426, -42.2043, -31.0663)
Vpmg_setPart:  actual maxima = (91.6196, 43.5793, 74.6653)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-13.5651, -34.543, -19.298)
VPMG::extEnergy    Disj part upper corner = (76.9421, 35.918, 62.897)
VPMG::extEnergy    Old lower corner = (-28.2426, -42.2043, -31.0663)
VPMG::extEnergy    Old upper corner = (91.6196, 43.5793, 74.6653)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.114872 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.198305 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.796272
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.854672e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 129, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.340600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 065, 081)
Vbuildops: Galer: (049, 033, 041)
Vbuildops: Galer: (025, 017, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.640670e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.261129e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.243298e-01
Vprtstp: contraction number = 1.243298e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.798715e-02
Vprtstp: contraction number = 1.446729e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.454611e-03
Vprtstp: contraction number = 1.920599e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.340380e-04
Vprtstp: contraction number = 2.703743e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.241701e-04
Vprtstp: contraction number = 3.470631e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.458237e-04
Vprtstp: contraction number = 4.498370e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.629744e-05
Vprtstp: contraction number = 4.546410e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.464600e-05
Vprtstp: contraction number = 5.225843e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.655354e-05
Vprtstp: contraction number = 4.777907e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.991255e-06
Vprtstp: contraction number = 5.431621e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.363027e-06
Vprtstp: contraction number = 4.852522e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.410823e-06
Vprtstp: contraction number = 5.525574e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.180591e-06
Vprtstp: contraction number = 4.897045e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.585410e-07
Vprtstp: contraction number = 5.578063e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.771954e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.276857e+00
Vpmg_setPart:  lower corner = (-13.5651, -34.543, -19.298)
Vpmg_setPart:  upper corner = (76.9421, 35.918, 62.897)
Vpmg_setPart:  actual minima = (-13.5651, -34.543, -19.298)
Vpmg_setPart:  actual maxima = (76.9421, 35.918, 62.897)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.618360510871E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.202000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.026480e+01
