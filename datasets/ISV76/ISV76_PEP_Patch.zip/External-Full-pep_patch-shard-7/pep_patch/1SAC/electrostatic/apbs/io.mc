##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:31 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 193, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16373 atoms
Valist_getStatistics:  Max atom coordinate:  (59.251, 70.957, 67.909)
Valist_getStatistics:  Min atom coordinate:  (-33.283, -0.428, -32.929)
Valist_getStatistics:  Molecule center:  (12.984, 35.2645, 17.49)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.725622, 0.655722, 0.69058
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.516122, 0.489885, 0.484348
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.711282, 0.747093, 0.701365 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.984 35.2645 17.49
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 94.2537 98.2138 105.884
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -68.2857 -27.6848 -70.9042
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 70.7897 82.2935 79.4866
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -44.8217 -11.7645 -44.5066
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 70.7897 82.2935 79.4866
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -44.8217 -11.7645 -44.5066
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8516294 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.447712
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.029769e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.338810e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 129)
Vbuildops: Galer: (057, 049, 065)
Vbuildops: Galer: (029, 025, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.976138e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.467632e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.694729e-02
Vprtstp: contraction number = 7.694729e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.146774e-02
Vprtstp: contraction number = 1.490337e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.480749e-03
Vprtstp: contraction number = 3.035252e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.034456e-04
Vprtstp: contraction number = 2.595550e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.416657e-04
Vprtstp: contraction number = 4.888681e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.355793e-04
Vprtstp: contraction number = 3.069727e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.402831e-05
Vprtstp: contraction number = 5.460147e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.466721e-05
Vprtstp: contraction number = 3.332131e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.403685e-05
Vprtstp: contraction number = 5.690492e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.043478e-06
Vprtstp: contraction number = 3.593026e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.927435e-06
Vprtstp: contraction number = 5.804397e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.113784e-06
Vprtstp: contraction number = 3.804640e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.507351e-07
Vprtstp: contraction number = 5.842563e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.770474e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.010507e+01
Vpmg_setPart:  lower corner = (-68.2857, -27.6848, -70.9042)
Vpmg_setPart:  upper corner = (94.2537, 98.2138, 105.884)
Vpmg_setPart:  actual minima = (-68.2857, -27.6848, -70.9042)
Vpmg_setPart:  actual maxima = (94.2537, 98.2138, 105.884)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.942646213084E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.530100e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.8579
Vpbe_ctor2:  solute dimensions = 95.6114 x 74.058 x 103.993
Vpbe_ctor2:  solute charge = -10
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (105.314, 84.165, 113.618)
Vclist_setupGrid:  Grid lower corner = (-39.673, -6.818, -39.319)
Vclist_assignAtoms:  Have 8516294 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -44.8217, -11.7645, -44.5066
VPMG::focusFillBound -- New mesh maxs = 70.7897, 82.2935, 79.4866
VPMG::focusFillBound -- Old mesh mins = -68.2857, -27.6848, -70.9042
VPMG::focusFillBound -- Old mesh maxs = 94.2537, 98.2138, 105.884
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-44.8217, -11.7645, -44.5066)
Vpmg_setPart:  upper corner = (70.7897, 82.2935, 79.4866)
Vpmg_setPart:  actual minima = (-68.2857, -27.6848, -70.9042)
Vpmg_setPart:  actual maxima = (94.2537, 98.2138, 105.884)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-44.8217, -11.7645, -44.5066)
VPMG::extEnergy    Disj part upper corner = (70.7897, 82.2935, 79.4866)
VPMG::extEnergy    Old lower corner = (-68.2857, -27.6848, -70.9042)
VPMG::extEnergy    Old upper corner = (94.2537, 98.2138, 105.884)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0850273 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0884712 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.437832
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.135735e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.327480e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 129)
Vbuildops: Galer: (057, 049, 065)
Vbuildops: Galer: (029, 025, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.965661e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.173921e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.154614e-01
Vprtstp: contraction number = 1.154614e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.503880e-02
Vprtstp: contraction number = 1.302495e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.456517e-03
Vprtstp: contraction number = 2.298400e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.413078e-04
Vprtstp: contraction number = 2.723284e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.288123e-04
Vprtstp: contraction number = 5.617847e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.006996e-04
Vprtstp: contraction number = 3.795291e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.274849e-04
Vprtstp: contraction number = 6.352027e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.170444e-05
Vprtstp: contraction number = 4.055729e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.291769e-05
Vprtstp: contraction number = 6.366510e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.377156e-05
Vprtstp: contraction number = 4.183635e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.787406e-06
Vprtstp: contraction number = 6.380837e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.741298e-06
Vprtstp: contraction number = 4.257568e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 2.408915e-06
Vprtstp: contraction number = 6.438714e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.037398e-06
Vprtstp: contraction number = 4.306495e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.770880e-07
Vprtstp: contraction number = 6.526792e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.030062e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.266219e+01
Vpmg_setPart:  lower corner = (-44.8217, -11.7645, -44.5066)
Vpmg_setPart:  upper corner = (70.7897, 82.2935, 79.4866)
Vpmg_setPart:  actual minima = (-44.8217, -11.7645, -44.5066)
Vpmg_setPart:  actual maxima = (70.7897, 82.2935, 79.4866)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.486950880305E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.558700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.487388e+01
