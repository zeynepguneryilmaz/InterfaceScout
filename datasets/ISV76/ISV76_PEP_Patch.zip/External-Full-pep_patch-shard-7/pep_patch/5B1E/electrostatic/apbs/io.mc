##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:50 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3966 atoms
Valist_getStatistics:  Max atom coordinate:  (34.368, 40.014, 50.659)
Valist_getStatistics:  Min atom coordinate:  (-8.341, -6.715, 5.821)
Valist_getStatistics:  Molecule center:  (13.0135, 16.6495, 28.24)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.60507, 0.659374, 0.633837
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.512173, 0.544117, 0.529095
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.84647, 0.825202, 0.83475 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 13.0135 16.6495 28.24
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 51.7379 58.8495 68.8055
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -25.7109 -25.5504 -12.3256
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 45.7926 51.473 62.1021
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -19.7656 -18.174 -5.6221
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 45.7926 51.473 62.1021
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -19.7656 -18.174 -5.6221
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7713453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.524223
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.978620e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.627300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.440720e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.234049e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.565479e-02
Vprtstp: contraction number = 7.565479e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.010688e-03
Vprtstp: contraction number = 1.191027e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.274763e-03
Vprtstp: contraction number = 1.414723e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.081888e-04
Vprtstp: contraction number = 1.633157e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.155853e-05
Vprtstp: contraction number = 1.996194e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.127768e-05
Vprtstp: contraction number = 2.713687e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.952241e-06
Vprtstp: contraction number = 3.504480e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.593688e-06
Vprtstp: contraction number = 4.032366e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.838325e-07
Vprtstp: contraction number = 4.290880e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.169226e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.393198e+00
Vpmg_setPart:  lower corner = (-25.7109, -25.5504, -12.3256)
Vpmg_setPart:  upper corner = (51.7379, 58.8495, 68.8055)
Vpmg_setPart:  actual minima = (-25.7109, -25.5504, -12.3256)
Vpmg_setPart:  actual maxima = (51.7379, 58.8495, 68.8055)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.223053487773E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.699000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.7686
Vpbe_ctor2:  solute dimensions = 45.5582 x 49.647 x 47.7242
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (55.489, 59.509, 57.618)
Vclist_setupGrid:  Grid lower corner = (-14.731, -13.105, -0.569)
Vclist_assignAtoms:  Have 7713453 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -19.7656, -18.174, -5.6221
VPMG::focusFillBound -- New mesh maxs = 45.7926, 51.473, 62.1021
VPMG::focusFillBound -- Old mesh mins = -25.7109, -25.5504, -12.3256
VPMG::focusFillBound -- Old mesh maxs = 51.7379, 58.8495, 68.8055
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-19.7656, -18.174, -5.6221)
Vpmg_setPart:  upper corner = (45.7926, 51.473, 62.1021)
Vpmg_setPart:  actual minima = (-25.7109, -25.5504, -12.3256)
Vpmg_setPart:  actual maxima = (51.7379, 58.8495, 68.8055)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-19.7656, -18.174, -5.6221)
VPMG::extEnergy    Disj part upper corner = (45.7926, 51.473, 62.1021)
VPMG::extEnergy    Old lower corner = (-25.7109, -25.5504, -12.3256)
VPMG::extEnergy    Old upper corner = (51.7379, 58.8495, 68.8055)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0117018 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0392844 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.513450
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.173110e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.640400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.497280e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.817427e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.003668e-01
Vprtstp: contraction number = 1.003668e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.215031e-02
Vprtstp: contraction number = 1.210590e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.701160e-03
Vprtstp: contraction number = 1.400096e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.611598e-04
Vprtstp: contraction number = 1.535187e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.322140e-05
Vprtstp: contraction number = 1.654979e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.240524e-06
Vprtstp: contraction number = 1.906585e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.133350e-06
Vprtstp: contraction number = 2.588852e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.589691e-07
Vprtstp: contraction number = 3.088894e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.934457e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.163482e+00
Vpmg_setPart:  lower corner = (-19.7656, -18.174, -5.6221)
Vpmg_setPart:  upper corner = (45.7926, 51.473, 62.1021)
Vpmg_setPart:  actual minima = (-19.7656, -18.174, -5.6221)
Vpmg_setPart:  actual maxima = (45.7926, 51.473, 62.1021)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.738878092041E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.822000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.236602e+00
