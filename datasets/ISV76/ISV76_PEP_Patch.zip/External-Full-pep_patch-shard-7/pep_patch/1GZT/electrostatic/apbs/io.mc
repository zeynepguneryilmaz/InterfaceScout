##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:33 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6508 atoms
Valist_getStatistics:  Max atom coordinate:  (46.765, 59.843, 65.515)
Valist_getStatistics:  Min atom coordinate:  (-11.498, 2.215, 13.555)
Valist_getStatistics:  Molecule center:  (17.6335, 31.029, 39.535)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.652237, 0.645747, 0.58643
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.508669, 0.504851, 0.469959
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.779883, 0.78181, 0.801389 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 17.6335 31.029 39.535
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 69.8124 82.6887 86.4494
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -34.5455 -20.6307 -7.3794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 58.327 71.4171 77.1317
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -23.06 -9.3591 1.9383
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 58.327 71.4171 77.1317
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -23.06 -9.3591 1.9383
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8257027 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.825032
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.552311e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.640700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.011250e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.119010e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.733501e-02
Vprtstp: contraction number = 9.733501e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.314976e-02
Vprtstp: contraction number = 1.350980e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.597589e-03
Vprtstp: contraction number = 2.735858e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.351225e-04
Vprtstp: contraction number = 2.599303e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.164266e-04
Vprtstp: contraction number = 4.453176e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.392158e-04
Vprtstp: contraction number = 3.343107e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.066065e-05
Vprtstp: contraction number = 5.075618e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.665580e-05
Vprtstp: contraction number = 3.772368e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.403196e-05
Vprtstp: contraction number = 5.264131e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.709034e-06
Vprtstp: contraction number = 4.068594e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.025173e-06
Vprtstp: contraction number = 5.298922e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.286031e-06
Vprtstp: contraction number = 4.251098e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.783511e-07
Vprtstp: contraction number = 5.274767e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.657854e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.207126e+00
Vpmg_setPart:  lower corner = (-34.5455, -20.6307, -7.3794)
Vpmg_setPart:  upper corner = (69.8124, 82.6887, 86.4494)
Vpmg_setPart:  actual minima = (-34.5455, -20.6307, -7.3794)
Vpmg_setPart:  actual maxima = (69.8124, 82.6887, 86.4494)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.163292474983E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.355000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 35.791
Vpbe_ctor2:  solute dimensions = 61.387 x 60.7762 x 55.1934
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (70.7817, 70.1467, 64.4787)
Vclist_setupGrid:  Grid lower corner = (-17.7574, -4.04436, 7.29564)
Vclist_assignAtoms:  Have 8257027 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 244.17
Vacc_storeParms:  Using 2466-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -23.06, -9.3591, 1.9383
VPMG::focusFillBound -- New mesh maxs = 58.327, 71.4171, 77.1317
VPMG::focusFillBound -- Old mesh mins = -34.5455, -20.6307, -7.3794
VPMG::focusFillBound -- Old mesh maxs = 69.8124, 82.6887, 86.4494
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-23.06, -9.3591, 1.9383)
Vpmg_setPart:  upper corner = (58.327, 71.4171, 77.1317)
Vpmg_setPart:  actual minima = (-34.5455, -20.6307, -7.3794)
Vpmg_setPart:  actual maxima = (69.8124, 82.6887, 86.4494)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-23.06, -9.3591, 1.9383)
VPMG::extEnergy    Disj part upper corner = (58.327, 71.4171, 77.1317)
VPMG::extEnergy    Old lower corner = (-34.5455, -20.6307, -7.3794)
VPMG::extEnergy    Old upper corner = (69.8124, 82.6887, 86.4494)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.173503 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.170356 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.823461
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.927326e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.693000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.960140e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.126913e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.195034e-01
Vprtstp: contraction number = 1.195034e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.585176e-02
Vprtstp: contraction number = 1.326470e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.304494e-03
Vprtstp: contraction number = 2.084622e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.664427e-04
Vprtstp: contraction number = 2.319395e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.771059e-04
Vprtstp: contraction number = 3.615481e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.771702e-05
Vprtstp: contraction number = 3.165469e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.766388e-05
Vprtstp: contraction number = 4.293794e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.376076e-05
Vprtstp: contraction number = 3.653571e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.337337e-06
Vprtstp: contraction number = 4.605367e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.582463e-06
Vprtstp: contraction number = 4.074997e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.253574e-06
Vprtstp: contraction number = 4.854181e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.532778e-07
Vprtstp: contraction number = 4.413602e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.103199e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.649512e+00
Vpmg_setPart:  lower corner = (-23.06, -9.3591, 1.9383)
Vpmg_setPart:  upper corner = (58.327, 71.4171, 77.1317)
Vpmg_setPart:  actual minima = (-23.06, -9.3591, 1.9383)
Vpmg_setPart:  actual maxima = (58.327, 71.4171, 77.1317)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.372741368600E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.500000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.829696e+01
