##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:49 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 193, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7048 atoms
Valist_getStatistics:  Max atom coordinate:  (44.437, 77.704, 74.629)
Valist_getStatistics:  Min atom coordinate:  (-1.437, 7.666, 19.933)
Valist_getStatistics:  Molecule center:  (21.5, 42.685, 47.281)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.646106, 0.64646, 0.616446
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.536312, 0.484438, 0.487615
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.830069, 0.749369, 0.791011 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 21.5 42.685 47.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 62.8508 104.745 96.5967
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -19.8508 -19.3752 -2.03465
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 55.824 89.191 86.2902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -12.824 -3.821 8.2718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 55.824 89.191 86.2902
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -12.824 -3.821 8.2718
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8826458 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.951536
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.726128e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.333800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 097, 081)
Vbuildops: Galer: (033, 049, 041)
Vbuildops: Galer: (017, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.589390e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.251144e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.525878e-02
Vprtstp: contraction number = 9.525878e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.383927e-02
Vprtstp: contraction number = 1.452808e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.645434e-03
Vprtstp: contraction number = 3.356703e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.876546e-03
Vprtstp: contraction number = 4.039550e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.138559e-03
Vprtstp: contraction number = 6.067313e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.925565e-04
Vprtstp: contraction number = 5.204441e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.816974e-04
Vprtstp: contraction number = 6.441536e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.083076e-04
Vprtstp: contraction number = 5.457402e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.335859e-04
Vprtstp: contraction number = 6.412914e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.419710e-05
Vprtstp: contraction number = 5.554262e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.730977e-05
Vprtstp: contraction number = 6.376229e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.650320e-05
Vprtstp: contraction number = 5.602057e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.682863e-05
Vprtstp: contraction number = 6.349660e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.470457e-06
Vprtstp: contraction number = 5.627586e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 5.996890e-06
Vprtstp: contraction number = 6.332207e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.383362e-06
Vprtstp: contraction number = 5.641861e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.138724e-06
Vprtstp: contraction number = 6.321297e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.208386e-06
Vprtstp: contraction number = 5.650033e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 7.630507e-07
Vprtstp: contraction number = 6.314629e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.042607e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.548303e+00
Vpmg_setPart:  lower corner = (-19.8508, -19.3752, -2.03465)
Vpmg_setPart:  upper corner = (62.8508, 104.745, 96.5967)
Vpmg_setPart:  actual minima = (-19.8508, -19.3752, -2.03465)
Vpmg_setPart:  actual maxima = (62.8508, 104.745, 96.5967)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.050101138630E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.087000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 38.9089
Vpbe_ctor2:  solute dimensions = 48.648 x 73.012 x 58.0184
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.654, 82.818, 67.476)
Vclist_setupGrid:  Grid lower corner = (-7.827, 1.276, 13.543)
Vclist_assignAtoms:  Have 8826458 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -12.824, -3.821, 8.2718
VPMG::focusFillBound -- New mesh maxs = 55.824, 89.191, 86.2902
VPMG::focusFillBound -- Old mesh mins = -19.8508, -19.3752, -2.03465
VPMG::focusFillBound -- Old mesh maxs = 62.8508, 104.745, 96.5967
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-12.824, -3.821, 8.2718)
Vpmg_setPart:  upper corner = (55.824, 89.191, 86.2902)
Vpmg_setPart:  actual minima = (-19.8508, -19.3752, -2.03465)
Vpmg_setPart:  actual maxima = (62.8508, 104.745, 96.5967)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-12.824, -3.821, 8.2718)
VPMG::extEnergy    Disj part upper corner = (55.824, 89.191, 86.2902)
VPMG::extEnergy    Old lower corner = (-19.8508, -19.3752, -2.03465)
VPMG::extEnergy    Old upper corner = (62.8508, 104.745, 96.5967)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.202921 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.24564 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.941093
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.138376e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 193, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.355500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 097, 081)
Vbuildops: Galer: (033, 049, 041)
Vbuildops: Galer: (017, 025, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.510130e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.394274e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.236358e-01
Vprtstp: contraction number = 1.236358e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.809517e-02
Vprtstp: contraction number = 1.463586e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.403707e-03
Vprtstp: contraction number = 2.433638e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.677987e-03
Vprtstp: contraction number = 3.810396e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.655723e-04
Vprtstp: contraction number = 5.158397e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.746379e-04
Vprtstp: contraction number = 5.483516e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.767730e-04
Vprtstp: contraction number = 5.831244e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.577582e-04
Vprtstp: contraction number = 5.699914e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.283245e-05
Vprtstp: contraction number = 5.884477e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.322607e-05
Vprtstp: contraction number = 5.733563e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.137394e-05
Vprtstp: contraction number = 5.894469e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.801094e-05
Vprtstp: contraction number = 5.740732e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.062365e-05
Vprtstp: contraction number = 5.898444e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.100629e-06
Vprtstp: contraction number = 5.742498e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 3.599806e-06
Vprtstp: contraction number = 5.900712e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.067341e-06
Vprtstp: contraction number = 5.742925e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.220176e-06
Vprtstp: contraction number = 5.902148e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 7.007430e-07
Vprtstp: contraction number = 5.742969e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.470047e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.961703e+00
Vpmg_setPart:  lower corner = (-12.824, -3.821, 8.2718)
Vpmg_setPart:  upper corner = (55.824, 89.191, 86.2902)
Vpmg_setPart:  actual minima = (-12.824, -3.821, 8.2718)
Vpmg_setPart:  actual maxima = (55.824, 89.191, 86.2902)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.185995794390E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.111000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.332408e+01
