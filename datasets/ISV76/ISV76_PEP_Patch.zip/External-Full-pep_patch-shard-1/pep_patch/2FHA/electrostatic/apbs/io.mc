##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:58:08 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (289, 289, 289)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 66456 atoms
Valist_getStatistics:  Max atom coordinate:  (61.573, 61.573, 61.573)
Valist_getStatistics:  Min atom coordinate:  (-61.573, -61.573, -61.573)
Valist_getStatistics:  Molecule center:  (0, 0, 0)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0 0 0
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.744458, 0.744458, 0.744458
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.507361, 0.507361, 0.507361
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.681517, 0.681517, 0.681517 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0 0 0
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 107.202 107.202 107.202
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -107.202 -107.202 -107.202
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 73.06 73.06 73.06
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -73.06 -73.06 -73.06
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 73.06 73.06 73.06
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -73.06 -73.06 -73.06
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -216
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17707991 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 11.766840
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.598445e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (289, 289, 289)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.056170e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (145, 145, 145)
Vbuildops: Galer: (073, 073, 073)
Vbuildops: Galer: (037, 037, 037)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.441478e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.144498e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.375336e-02
Vprtstp: contraction number = 7.375336e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.267213e-02
Vprtstp: contraction number = 1.718177e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.108686e-03
Vprtstp: contraction number = 4.031433e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.733149e-03
Vprtstp: contraction number = 3.392552e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.092098e-03
Vprtstp: contraction number = 6.301235e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.150742e-04
Vprtstp: contraction number = 3.800706e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.781598e-04
Vprtstp: contraction number = 6.701446e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.067035e-04
Vprtstp: contraction number = 3.836052e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.595259e-05
Vprtstp: contraction number = 7.118096e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.899507e-05
Vprtstp: contraction number = 3.817522e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.234418e-05
Vprtstp: contraction number = 7.706202e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 8.521704e-06
Vprtstp: contraction number = 3.813835e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.053459e-06
Vprtstp: contraction number = 8.277052e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.760251e-06
Vprtstp: contraction number = 3.913330e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.348937e-06
Vprtstp: contraction number = 8.509866e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 9.599055e-07
Vprtstp: contraction number = 4.086553e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.616026e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.148357e+01
Vpmg_setPart:  lower corner = (-107.202, -107.202, -107.202)
Vpmg_setPart:  upper corner = (107.202, 107.202, 107.202)
Vpmg_setPart:  actual minima = (-107.202, -107.202, -107.202)
Vpmg_setPart:  actual maxima = (107.202, 107.202, 107.202)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.493257225936E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.395800e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 70.1195
Vpbe_ctor2:  solute dimensions = 126.12 x 126.12 x 126.12
Vpbe_ctor2:  solute charge = -216
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (135.926, 135.926, 135.926)
Vclist_setupGrid:  Grid lower corner = (-67.963, -67.963, -67.963)
Vclist_assignAtoms:  Have 17707991 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -73.06, -73.06, -73.06
VPMG::focusFillBound -- New mesh maxs = 73.06, 73.06, 73.06
VPMG::focusFillBound -- Old mesh mins = -107.202, -107.202, -107.202
VPMG::focusFillBound -- Old mesh maxs = 107.202, 107.202, 107.202
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-73.06, -73.06, -73.06)
Vpmg_setPart:  upper corner = (73.06, 73.06, 73.06)
Vpmg_setPart:  actual minima = (-107.202, -107.202, -107.202)
Vpmg_setPart:  actual maxima = (107.202, 107.202, 107.202)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-73.06, -73.06, -73.06)
VPMG::extEnergy    Disj part upper corner = (73.06, 73.06, 73.06)
VPMG::extEnergy    Old lower corner = (-107.202, -107.202, -107.202)
VPMG::extEnergy    Old upper corner = (107.202, 107.202, 107.202)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 1.34745 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 1.84204 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 11.701053
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.967049e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (289, 289, 289)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.003110e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (145, 145, 145)
Vbuildops: Galer: (073, 073, 073)
Vbuildops: Galer: (037, 037, 037)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.442547e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.126943e+02
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.206111e-01
Vprtstp: contraction number = 1.206111e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.039728e-02
Vprtstp: contraction number = 1.691162e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.432780e-03
Vprtstp: contraction number = 4.134266e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.094186e-03
Vprtstp: contraction number = 4.855084e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.144388e-03
Vprtstp: contraction number = 7.680130e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.785054e-03
Vprtstp: contraction number = 5.676952e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.411730e-03
Vprtstp: contraction number = 7.908614e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.219429e-04
Vprtstp: contraction number = 5.822237e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.595772e-04
Vprtstp: contraction number = 8.024610e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.861524e-04
Vprtstp: contraction number = 5.854544e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.165763e-04
Vprtstp: contraction number = 8.198223e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.855243e-04
Vprtstp: contraction number = 5.860334e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.559044e-04
Vprtstp: contraction number = 8.403449e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.185946e-05
Vprtstp: contraction number = 5.892039e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 7.882051e-05
Vprtstp: contraction number = 8.580554e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.716028e-05
Vprtstp: contraction number = 5.983249e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 4.091985e-05
Vprtstp: contraction number = 8.676763e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 2.490894e-05
Vprtstp: contraction number = 6.087250e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.181177e-05
Vprtstp: contraction number = 8.756604e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.348213e-05
Vprtstp: contraction number = 6.181125e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.192604e-05
Vprtstp: contraction number = 8.845815e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 7.471971e-06
Vprtstp: contraction number = 6.265256e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 6.676116e-06
Vprtstp: contraction number = 8.934879e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 4.231791e-06
Vprtstp: contraction number = 6.338702e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 3.816131e-06
Vprtstp: contraction number = 9.017768e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 2.442334e-06
Vprtstp: contraction number = 6.400027e-01
Vprtstp: iteration = 27
Vprtstp: relative residual = 2.220712e-06
Vprtstp: contraction number = 9.092579e-01
Vprtstp: iteration = 28
Vprtstp: relative residual = 1.431878e-06
Vprtstp: contraction number = 6.447833e-01
Vprtstp: iteration = 29
Vprtstp: relative residual = 1.311568e-06
Vprtstp: contraction number = 9.159774e-01
Vprtstp: iteration = 30
Vprtstp: relative residual = 8.501464e-07
Vprtstp: contraction number = 6.481910e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.516353e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.004394e+02
Vpmg_setPart:  lower corner = (-73.06, -73.06, -73.06)
Vpmg_setPart:  upper corner = (73.06, 73.06, 73.06)
Vpmg_setPart:  actual minima = (-73.06, -73.06, -73.06)
Vpmg_setPart:  actual maxima = (73.06, 73.06, 73.06)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.244129191591E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.283500e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.034934e+02
