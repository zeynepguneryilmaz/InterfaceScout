##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 18:04:03 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (321, 289, 321)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 60408 atoms
Valist_getStatistics:  Max atom coordinate:  (62.66, 90.146, 152.086)
Valist_getStatistics:  Min atom coordinate:  (-67.575, -24.394, 13.491)
Valist_getStatistics:  Molecule center:  (-2.4575, 32.876, 82.7885)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.708598, 0.695716, 0.751023
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.479322, 0.478689, 0.504278
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.676438, 0.688053, 0.671455 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -2.4575 32.876 82.7885
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 110.918 133.059 202.952
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -115.833 -67.307 -37.3752
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 74.2341 101.807 163.473
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -79.1491 -36.0552 2.104
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 74.2341 101.807 163.473
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -79.1491 -36.0552 2.104
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -216
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15198279 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.912759
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.562822e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (321, 289, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.299380e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (161, 145, 161)
Vbuildops: Galer: (081, 073, 081)
Vbuildops: Galer: (041, 037, 041)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.154907e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.838946e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.016562e-01
Vprtstp: contraction number = 1.016562e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.485562e-02
Vprtstp: contraction number = 2.445068e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.665615e-02
Vprtstp: contraction number = 6.701158e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.183243e-03
Vprtstp: contraction number = 4.913047e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.188790e-03
Vprtstp: contraction number = 8.784769e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.872171e-03
Vprtstp: contraction number = 5.386402e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.436419e-03
Vprtstp: contraction number = 8.874655e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.924821e-03
Vprtstp: contraction number = 5.601242e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.701695e-03
Vprtstp: contraction number = 8.840797e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.753091e-04
Vprtstp: contraction number = 5.731396e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 8.572471e-04
Vprtstp: contraction number = 8.789492e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.984855e-04
Vprtstp: contraction number = 5.814957e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 4.357680e-04
Vprtstp: contraction number = 8.741839e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.558451e-04
Vprtstp: contraction number = 5.871131e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.226310e-04
Vprtstp: contraction number = 8.701792e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.316024e-04
Vprtstp: contraction number = 5.911234e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.140790e-04
Vprtstp: contraction number = 8.668454e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 6.777637e-05
Vprtstp: contraction number = 5.941181e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 5.856839e-05
Vprtstp: contraction number = 8.641417e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 3.492783e-05
Vprtstp: contraction number = 5.963597e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 3.010665e-05
Vprtstp: contraction number = 8.619673e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 1.800602e-05
Vprtstp: contraction number = 5.980745e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 1.548805e-05
Vprtstp: contraction number = 8.601596e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 9.283508e-06
Vprtstp: contraction number = 5.993982e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 7.971922e-06
Vprtstp: contraction number = 8.587187e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 4.786726e-06
Vprtstp: contraction number = 6.004482e-01
Vprtstp: iteration = 27
Vprtstp: relative residual = 4.105005e-06
Vprtstp: contraction number = 8.575811e-01
Vprtstp: iteration = 28
Vprtstp: relative residual = 2.468355e-06
Vprtstp: contraction number = 6.013038e-01
Vprtstp: iteration = 29
Vprtstp: relative residual = 2.114555e-06
Vprtstp: contraction number = 8.566657e-01
Vprtstp: iteration = 30
Vprtstp: relative residual = 1.273008e-06
Vprtstp: contraction number = 6.020214e-01
Vprtstp: iteration = 31
Vprtstp: relative residual = 1.089580e-06
Vprtstp: contraction number = 8.559102e-01
Vprtstp: iteration = 32
Vprtstp: relative residual = 6.566257e-07
Vprtstp: contraction number = 6.026410e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.139301e+02
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.365664e+02
Vpmg_setPart:  lower corner = (-115.833, -67.307, -37.3752)
Vpmg_setPart:  upper corner = (110.918, 133.059, 202.952)
Vpmg_setPart:  actual minima = (-115.833, -67.307, -37.3752)
Vpmg_setPart:  actual maxima = (110.918, 133.059, 202.952)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.437162050073E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.983000e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 80.9226
Vpbe_ctor2:  solute dimensions = 133.383 x 117.862 x 141.369
Vpbe_ctor2:  solute charge = -216
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (143.015, 127.32, 151.375)
Vclist_setupGrid:  Grid lower corner = (-73.965, -30.784, 7.101)
Vclist_assignAtoms:  Have 15198279 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -79.1491, -36.0552, 2.104
VPMG::focusFillBound -- New mesh maxs = 74.2341, 101.807, 163.473
VPMG::focusFillBound -- Old mesh mins = -115.833, -67.307, -37.3752
VPMG::focusFillBound -- Old mesh maxs = 110.918, 133.059, 202.952
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-79.1491, -36.0552, 2.104)
Vpmg_setPart:  upper corner = (74.2341, 101.807, 163.473)
Vpmg_setPart:  actual minima = (-115.833, -67.307, -37.3752)
Vpmg_setPart:  actual maxima = (110.918, 133.059, 202.952)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-79.1491, -36.0552, 2.104)
VPMG::extEnergy    Disj part upper corner = (74.2341, 101.807, 163.473)
VPMG::extEnergy    Old lower corner = (-115.833, -67.307, -37.3752)
VPMG::extEnergy    Old upper corner = (110.918, 133.059, 202.952)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.666797 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.662275 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.827562
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.966368e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (321, 289, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.255790e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (161, 145, 161)
Vbuildops: Galer: (081, 073, 081)
Vbuildops: Galer: (041, 037, 041)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.147570e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.946796e+02
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.308259e-01
Vprtstp: contraction number = 1.308259e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.190188e-02
Vprtstp: contraction number = 1.674125e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 8.537577e-03
Vprtstp: contraction number = 3.898101e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.739311e-03
Vprtstp: contraction number = 4.379827e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.950123e-03
Vprtstp: contraction number = 7.889484e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.531513e-03
Vprtstp: contraction number = 5.191354e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.295088e-03
Vprtstp: contraction number = 8.456265e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.030889e-04
Vprtstp: contraction number = 5.428888e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.027452e-04
Vprtstp: contraction number = 8.572817e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.370118e-04
Vprtstp: contraction number = 5.591282e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.894982e-04
Vprtstp: contraction number = 8.590148e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.653269e-04
Vprtstp: contraction number = 5.710810e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.416868e-04
Vprtstp: contraction number = 8.570098e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 8.222370e-05
Vprtstp: contraction number = 5.803203e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 7.022506e-05
Vprtstp: contraction number = 8.540732e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.128279e-05
Vprtstp: contraction number = 5.878640e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 3.513239e-05
Vprtstp: contraction number = 8.510179e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 2.088084e-05
Vprtstp: contraction number = 5.943472e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.770775e-05
Vprtstp: contraction number = 8.480384e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.062754e-05
Vprtstp: contraction number = 6.001629e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 8.981908e-06
Vprtstp: contraction number = 8.451544e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 5.438921e-06
Vprtstp: contraction number = 6.055418e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 4.581190e-06
Vprtstp: contraction number = 8.422976e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 2.797446e-06
Vprtstp: contraction number = 6.106373e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 2.348167e-06
Vprtstp: contraction number = 8.393967e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 1.445385e-06
Vprtstp: contraction number = 6.155375e-01
Vprtstp: iteration = 27
Vprtstp: relative residual = 1.208956e-06
Vprtstp: contraction number = 8.364255e-01
Vprtstp: iteration = 28
Vprtstp: relative residual = 7.498948e-07
Vprtstp: contraction number = 6.202828e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 9.908797e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.216137e+02
Vpmg_setPart:  lower corner = (-79.1491, -36.0552, 2.104)
Vpmg_setPart:  upper corner = (74.2341, 101.807, 163.473)
Vpmg_setPart:  actual minima = (-79.1491, -36.0552, 2.104)
Vpmg_setPart:  actual maxima = (74.2341, 101.807, 163.473)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.053106616541E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 4.295300e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.009113e+02
