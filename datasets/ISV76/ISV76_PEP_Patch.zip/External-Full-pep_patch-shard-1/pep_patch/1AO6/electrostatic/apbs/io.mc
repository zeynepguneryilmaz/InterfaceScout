##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:52 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 9121 atoms
Valist_getStatistics:  Max atom coordinate:  (68.089, 61.673, 62.62)
Valist_getStatistics:  Min atom coordinate:  (-5.47, 0.123, -18.22)
Valist_getStatistics:  Molecule center:  (31.3095, 30.898, 22.2)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.679178, 0.689269, 0.73573
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.503683, 0.530452, 0.536949
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.741607, 0.769587, 0.729818 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 31.3095 30.898 22.2
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 96.5106 86.0396 92.83
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -33.8916 -24.2436 -48.43
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 79.6631 73.3342 73.7471
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -17.0441 -11.5382 -29.3471
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 79.6631 73.3342 73.7471
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -17.0441 -11.5382 -29.3471
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7025743 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.207290
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.185346e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.231570e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 7.314830e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.154527e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.089693e-02
Vprtstp: contraction number = 9.089693e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.725930e-02
Vprtstp: contraction number = 1.898777e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.563625e-03
Vprtstp: contraction number = 3.802951e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.067970e-03
Vprtstp: contraction number = 4.674200e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.643881e-03
Vprtstp: contraction number = 5.358206e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.541671e-04
Vprtstp: contraction number = 5.804355e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.985349e-04
Vprtstp: contraction number = 5.224817e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.056847e-04
Vprtstp: contraction number = 6.131662e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.552938e-04
Vprtstp: contraction number = 5.080196e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.758700e-05
Vprtstp: contraction number = 6.284024e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.881511e-05
Vprtstp: contraction number = 5.002215e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.103541e-05
Vprtstp: contraction number = 6.357746e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.540386e-05
Vprtstp: contraction number = 4.963317e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.841880e-06
Vprtstp: contraction number = 6.389230e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.867779e-06
Vprtstp: contraction number = 4.945985e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.114451e-06
Vprtstp: contraction number = 6.398094e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.538654e-06
Vprtstp: contraction number = 4.940369e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 9.839763e-07
Vprtstp: contraction number = 6.395048e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.286169e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.380861e+01
Vpmg_setPart:  lower corner = (-33.8916, -24.2436, -48.43)
Vpmg_setPart:  upper corner = (96.5106, 86.0396, 92.83)
Vpmg_setPart:  actual minima = (-33.8916, -24.2436, -48.43)
Vpmg_setPart:  actual maxima = (96.5106, 86.0396, 92.83)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.232475126630E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 7.610000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 52.8634
Vpbe_ctor2:  solute dimensions = 76.7072 x 64.8724 x 83.0942
Vpbe_ctor2:  solute charge = -15
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (86.339, 74.33, 93.62)
Vclist_setupGrid:  Grid lower corner = (-11.86, -6.267, -24.61)
Vclist_assignAtoms:  Have 7025743 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -17.0441, -11.5382, -29.3471
VPMG::focusFillBound -- New mesh maxs = 79.6631, 73.3342, 73.7471
VPMG::focusFillBound -- Old mesh mins = -33.8916, -24.2436, -48.43
VPMG::focusFillBound -- Old mesh maxs = 96.5106, 86.0396, 92.83
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-17.0441, -11.5382, -29.3471)
Vpmg_setPart:  upper corner = (79.6631, 73.3342, 73.7471)
Vpmg_setPart:  actual minima = (-33.8916, -24.2436, -48.43)
Vpmg_setPart:  actual maxima = (96.5106, 86.0396, 92.83)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-17.0441, -11.5382, -29.3471)
VPMG::extEnergy    Disj part upper corner = (79.6631, 73.3342, 73.7471)
VPMG::extEnergy    Old lower corner = (-33.8916, -24.2436, -48.43)
VPMG::extEnergy    Old upper corner = (96.5106, 86.0396, 92.83)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.153779 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.122842 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.213677
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.799455e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.251530e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 097)
Vbuildops: Galer: (049, 041, 049)
Vbuildops: Galer: (025, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.573830e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.971258e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.225090e-01
Vprtstp: contraction number = 1.225090e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.832685e-02
Vprtstp: contraction number = 1.495959e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.386404e-03
Vprtstp: contraction number = 2.393430e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.596923e-03
Vprtstp: contraction number = 3.640620e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.096283e-04
Vprtstp: contraction number = 5.069928e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.544300e-04
Vprtstp: contraction number = 5.612822e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.630908e-04
Vprtstp: contraction number = 5.789469e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.586754e-04
Vprtstp: contraction number = 6.031200e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 9.225139e-05
Vprtstp: contraction number = 5.813845e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.696820e-05
Vprtstp: contraction number = 6.175321e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.301662e-05
Vprtstp: contraction number = 5.795623e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.064454e-05
Vprtstp: contraction number = 6.252774e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.192804e-05
Vprtstp: contraction number = 5.777817e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.513280e-06
Vprtstp: contraction number = 6.298839e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.330718e-06
Vprtstp: contraction number = 5.764085e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.740051e-06
Vprtstp: contraction number = 6.327012e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.576723e-06
Vprtstp: contraction number = 5.754357e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.000342e-06
Vprtstp: contraction number = 6.344437e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 5.749602e-07
Vprtstp: contraction number = 5.747636e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.377271e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.464169e+01
Vpmg_setPart:  lower corner = (-17.0441, -11.5382, -29.3471)
Vpmg_setPart:  upper corner = (79.6631, 73.3342, 73.7471)
Vpmg_setPart:  actual minima = (-17.0441, -11.5382, -29.3471)
Vpmg_setPart:  actual maxima = (79.6631, 73.3342, 73.7471)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.996658399582E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 7.877000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.481078e+01
