##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:18 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 225, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13112 atoms
Valist_getStatistics:  Max atom coordinate:  (102.02, 72.619, 60.598)
Valist_getStatistics:  Min atom coordinate:  (23.733, -9.382, -5.922)
Valist_getStatistics:  Molecule center:  (62.8765, 31.6185, 27.338)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.716153, 0.644946, 0.613294
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.525433, 0.468666, 0.464928
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.733689, 0.726674, 0.758083 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 62.8765 31.6185 27.338
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 131.627 103.852 86.2142
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -5.8742 -40.6155 -31.5382
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 113.318 84.1091 71.9711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 12.4349 -20.8721 -17.2951
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 113.318 84.1091 71.9711
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 12.4349 -20.8721 -17.2951
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9089137 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.843920
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.117943e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.758100e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 097)
Vbuildops: Galer: (049, 057, 049)
Vbuildops: Galer: (025, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.509354e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.958199e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.678889e-02
Vprtstp: contraction number = 9.678889e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.757315e-02
Vprtstp: contraction number = 1.815616e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.733778e-03
Vprtstp: contraction number = 5.539007e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.755644e-03
Vprtstp: contraction number = 3.858362e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.287316e-03
Vprtstp: contraction number = 8.753003e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.564105e-03
Vprtstp: contraction number = 4.758001e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.313103e-03
Vprtstp: contraction number = 8.395234e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.897586e-04
Vprtstp: contraction number = 5.252891e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.498432e-04
Vprtstp: contraction number = 7.971531e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.060599e-04
Vprtstp: contraction number = 5.566312e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.352702e-04
Vprtstp: contraction number = 7.687064e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.356447e-04
Vprtstp: contraction number = 5.765485e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.018033e-04
Vprtstp: contraction number = 7.505142e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.997951e-05
Vprtstp: contraction number = 5.891708e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 4.432456e-05
Vprtstp: contraction number = 7.389951e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 2.646852e-05
Vprtstp: contraction number = 5.971524e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 1.936783e-05
Vprtstp: contraction number = 7.317310e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.166310e-05
Vprtstp: contraction number = 6.021889e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 8.480905e-06
Vprtstp: contraction number = 7.271573e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 5.134032e-06
Vprtstp: contraction number = 6.053637e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 3.718470e-06
Vprtstp: contraction number = 7.242788e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 2.258462e-06
Vprtstp: contraction number = 6.073631e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 1.631665e-06
Vprtstp: contraction number = 7.224674e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 9.930665e-07
Vprtstp: contraction number = 6.086216e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.620179e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.801092e+01
Vpmg_setPart:  lower corner = (-5.8742, -40.6155, -31.5382)
Vpmg_setPart:  upper corner = (131.627, 103.852, 86.2142)
Vpmg_setPart:  actual minima = (-5.8742, -40.6155, -31.5382)
Vpmg_setPart:  actual maxima = (131.627, 103.852, 86.2142)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.772605915687E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.182500e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 54.5168
Vpbe_ctor2:  solute dimensions = 80.8832 x 84.9812 x 69.2662
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (91.067, 94.781, 79.3)
Vclist_setupGrid:  Grid lower corner = (17.343, -15.772, -12.312)
Vclist_assignAtoms:  Have 9089137 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 12.4349, -20.8721, -17.2951
VPMG::focusFillBound -- New mesh maxs = 113.318, 84.1091, 71.9711
VPMG::focusFillBound -- Old mesh mins = -5.8742, -40.6155, -31.5382
VPMG::focusFillBound -- Old mesh maxs = 131.627, 103.852, 86.2142
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (12.4349, -20.8721, -17.2951)
Vpmg_setPart:  upper corner = (113.318, 84.1091, 71.9711)
Vpmg_setPart:  actual minima = (-5.8742, -40.6155, -31.5382)
Vpmg_setPart:  actual maxima = (131.627, 103.852, 86.2142)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (12.4349, -20.8721, -17.2951)
VPMG::extEnergy    Disj part upper corner = (113.318, 84.1091, 71.9711)
VPMG::extEnergy    Old lower corner = (-5.8742, -40.6155, -31.5382)
VPMG::extEnergy    Old upper corner = (131.627, 103.852, 86.2142)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.20959 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.191457 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.849761
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.981441e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.763900e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 097)
Vbuildops: Galer: (049, 057, 049)
Vbuildops: Galer: (025, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.486182e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.699082e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.217481e-01
Vprtstp: contraction number = 1.217481e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.820103e-02
Vprtstp: contraction number = 1.494975e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.050511e-03
Vprtstp: contraction number = 2.774849e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.566151e-03
Vprtstp: contraction number = 3.100976e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.308133e-04
Vprtstp: contraction number = 5.943318e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.749431e-04
Vprtstp: contraction number = 4.028123e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.482779e-04
Vprtstp: contraction number = 6.621748e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.072343e-04
Vprtstp: contraction number = 4.319123e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.104733e-05
Vprtstp: contraction number = 6.625432e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.207535e-05
Vprtstp: contraction number = 4.514645e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.105714e-05
Vprtstp: contraction number = 6.564899e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 9.814260e-06
Vprtstp: contraction number = 4.660776e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 6.379021e-06
Vprtstp: contraction number = 6.499747e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 3.044067e-06
Vprtstp: contraction number = 4.771997e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.960938e-06
Vprtstp: contraction number = 6.441836e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 9.525165e-07
Vprtstp: contraction number = 4.857454e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.757980e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.937680e+01
Vpmg_setPart:  lower corner = (12.4349, -20.8721, -17.2951)
Vpmg_setPart:  upper corner = (113.318, 84.1091, 71.9711)
Vpmg_setPart:  actual minima = (12.4349, -20.8721, -17.2951)
Vpmg_setPart:  actual maxima = (113.318, 84.1091, 71.9711)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.654220876143E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.218600e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.729178e+01
