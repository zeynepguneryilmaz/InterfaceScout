##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:55 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 513)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 14499 atoms
Valist_getStatistics:  Max atom coordinate:  (132.861, 123.476, 224.969)
Valist_getStatistics:  Min atom coordinate:  (89.64, 98.67, -2.701)
Valist_getStatistics:  Molecule center:  (111.25, 111.073, 111.134)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.612199, 0.488396, 0.764469
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.516367, 0.488396, 0.48875
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.843463, 1, 0.639333 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 111.25 111.073 111.134
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 150.431 134.516 306.838
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 72.0697 87.63 -84.57
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 144.298 134.516 236.254
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 78.203 87.63 -13.986
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 144.298 134.516 236.254
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 78.203 87.63 -13.986
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.176483
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.713198e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 513)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.344770e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 257)
Vbuildops: Galer: (033, 025, 129)
Vbuildops: Galer: (017, 013, 065)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.431860e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.415739e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.926333e-02
Vprtstp: contraction number = 7.926333e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 6.831542e-03
Vprtstp: contraction number = 8.618792e-02
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.567384e-04
Vprtstp: contraction number = 9.613326e-02
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.469862e-05
Vprtstp: contraction number = 1.137418e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.088968e-05
Vprtstp: contraction number = 1.457816e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.990357e-06
Vprtstp: contraction number = 1.827746e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.868810e-07
Vprtstp: contraction number = 2.446199e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.570706e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.239729e+00
Vpmg_setPart:  lower corner = (72.0697, 87.63, -84.57)
Vpmg_setPart:  upper corner = (150.431, 134.516, 306.838)
Vpmg_setPart:  actual minima = (72.0697, 87.63, -84.57)
Vpmg_setPart:  actual maxima = (150.431, 134.516, 306.838)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.176615008857E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.451000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 116.577
Vpbe_ctor2:  solute dimensions = 46.095 x 27.58 x 230.24
Vpbe_ctor2:  solute charge = -219
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 55 x 75 table
Vclist_ctor2:  Using 75 x 55 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (56.001, 37.586, 240.45)
Vclist_setupGrid:  Grid lower corner = (83.25, 92.28, -9.091)
Vclist_assignAtoms:  Have 11490875 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 78.203, 87.63, -13.986
VPMG::focusFillBound -- New mesh maxs = 144.298, 134.516, 236.254
VPMG::focusFillBound -- Old mesh mins = 72.0697, 87.63, -84.57
VPMG::focusFillBound -- Old mesh maxs = 150.431, 134.516, 306.838
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (78.203, 87.63, -13.986)
Vpmg_setPart:  upper corner = (144.298, 134.516, 236.254)
Vpmg_setPart:  actual minima = (72.0697, 87.63, -84.57)
Vpmg_setPart:  actual maxima = (150.431, 134.516, 306.838)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (78.203, 87.63, -13.986)
VPMG::extEnergy    Disj part upper corner = (144.298, 134.516, 236.254)
VPMG::extEnergy    Old lower corner = (72.0697, 87.63, -84.57)
VPMG::extEnergy    Old upper corner = (150.431, 134.516, 306.838)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 8.61778e+06 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 6.24669e+06 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.173083
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.426998e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 513)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.343210e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 257)
Vbuildops: Galer: (033, 025, 129)
Vbuildops: Galer: (017, 013, 065)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 4.411220e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.512290e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.149264e-01
Vprtstp: contraction number = 1.149264e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.192673e-02
Vprtstp: contraction number = 1.037771e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.261456e-03
Vprtstp: contraction number = 1.057671e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.393771e-04
Vprtstp: contraction number = 1.104891e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.621740e-05
Vprtstp: contraction number = 1.163563e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.418804e-06
Vprtstp: contraction number = 1.491487e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.636716e-07
Vprtstp: contraction number = 1.916946e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.485906e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.155553e+00
Vpmg_setPart:  lower corner = (78.203, 87.63, -13.986)
Vpmg_setPart:  upper corner = (144.298, 134.516, 236.254)
Vpmg_setPart:  actual minima = (78.203, 87.63, -13.986)
Vpmg_setPart:  actual maxima = (144.298, 134.516, 236.254)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.121092864349E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 8.695000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.275828e+01
