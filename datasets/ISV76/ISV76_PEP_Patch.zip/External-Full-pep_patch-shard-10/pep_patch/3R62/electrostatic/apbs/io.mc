##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:28 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1988 atoms
Valist_getStatistics:  Max atom coordinate:  (28.914, 8.392, 14.489)
Valist_getStatistics:  Min atom coordinate:  (-3.551, -23.367, -59.228)
Valist_getStatistics:  Molecule center:  (12.6815, -7.4875, -22.3695)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.608193, 0.615064, 0.671085
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.566094, 0.570135, 0.498923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.93078, 0.926954, 0.743457 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.6815 -7.4875 -22.3695
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 41.8747 22.0356 42.0547
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -16.5117 -37.0106 -86.7937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 39.854 19.879 25.5271
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -14.491 -34.854 -70.2661
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 39.854 19.879 25.5271
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -14.491 -34.854 -70.2661
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.252535
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.441210e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.892700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 097)
Vbuildops: Galer: (025, 025, 049)
Vbuildops: Galer: (013, 013, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.391210e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.561850e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.026582e-01
Vprtstp: contraction number = 1.026582e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.282685e-02
Vprtstp: contraction number = 1.249472e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.937099e-03
Vprtstp: contraction number = 1.510191e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.244187e-04
Vprtstp: contraction number = 1.674766e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.871635e-05
Vprtstp: contraction number = 1.809894e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.184188e-05
Vprtstp: contraction number = 2.016794e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.283580e-06
Vprtstp: contraction number = 1.928393e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.984370e-07
Vprtstp: contraction number = 2.182700e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.630541e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.837110e+00
Vpmg_setPart:  lower corner = (-16.5117, -37.0106, -86.7937)
Vpmg_setPart:  upper corner = (41.8747, 22.0356, 42.0547)
Vpmg_setPart:  actual minima = (-16.5117, -37.0105, -86.7937)
Vpmg_setPart:  actual maxima = (41.8747, 22.0356, 42.0547)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.095737021873E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.399000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.961
Vpbe_ctor2:  solute dimensions = 34.345 x 34.733 x 75.7932
Vpbe_ctor2:  solute charge = 8
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 68 x 69 x 75 table
Vclist_ctor2:  Using 68 x 69 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (45.245, 44.539, 86.497)
Vclist_setupGrid:  Grid lower corner = (-9.941, -29.757, -65.618)
Vclist_assignAtoms:  Have 3612730 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -14.491, -34.854, -70.2661
VPMG::focusFillBound -- New mesh maxs = 39.854, 19.879, 25.5271
VPMG::focusFillBound -- Old mesh mins = -16.5117, -37.0105, -86.7937
VPMG::focusFillBound -- Old mesh maxs = 41.8747, 22.0355, 42.0547
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-14.491, -34.854, -70.2661)
Vpmg_setPart:  upper corner = (39.854, 19.879, 25.5271)
Vpmg_setPart:  actual minima = (-16.5117, -37.0105, -86.7937)
Vpmg_setPart:  actual maxima = (41.8747, 22.0356, 42.0547)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-14.491, -34.854, -70.2661)
VPMG::extEnergy    Disj part upper corner = (39.854, 19.879, 25.5271)
VPMG::extEnergy    Old lower corner = (-16.5117, -37.0105, -86.7937)
VPMG::extEnergy    Old upper corner = (41.8747, 22.0356, 42.0547)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.321771 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.580168 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.253852
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.676170e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.896500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 097)
Vbuildops: Galer: (025, 025, 049)
Vbuildops: Galer: (013, 013, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.394930e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.474563e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.252273e-01
Vprtstp: contraction number = 1.252273e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.702520e-02
Vprtstp: contraction number = 1.359543e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.650096e-03
Vprtstp: contraction number = 1.556573e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.544885e-04
Vprtstp: contraction number = 1.714989e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.401400e-05
Vprtstp: contraction number = 1.848540e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.746634e-05
Vprtstp: contraction number = 2.078980e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.670373e-06
Vprtstp: contraction number = 2.101398e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.493510e-07
Vprtstp: contraction number = 2.314073e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.652750e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.858533e+00
Vpmg_setPart:  lower corner = (-14.491, -34.854, -70.2661)
Vpmg_setPart:  upper corner = (39.854, 19.879, 25.5271)
Vpmg_setPart:  actual minima = (-14.491, -34.854, -70.2661)
Vpmg_setPart:  actual maxima = (39.854, 19.879, 25.5271)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.141025918378E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.290000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.520762e+00
