##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:23 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1563 atoms
Valist_getStatistics:  Max atom coordinate:  (32.283, 8.323, 33.714)
Valist_getStatistics:  Min atom coordinate:  (0.26, -22.512, -11.34)
Valist_getStatistics:  Molecule center:  (16.2715, -7.0945, 11.187)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.605416, 0.600085, 0.629385
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.56446, 0.561325, 0.526477
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.932352, 0.935409, 0.836493 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 16.2715 -7.0945 11.187
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 45.3315 21.7096 51.4676
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -12.7885 -35.8986 -29.0937
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 43.3656 19.8491 44.8815
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -10.8226 -34.0381 -22.5075
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 43.3656 19.8491 44.8815
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -10.8226 -34.0381 -22.5075
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.204703
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.966880e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.553500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.969300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.451130e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.011005e-01
Vprtstp: contraction number = 1.011005e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.287563e-02
Vprtstp: contraction number = 1.273547e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.077989e-03
Vprtstp: contraction number = 1.613894e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.895776e-04
Vprtstp: contraction number = 1.874782e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.238920e-05
Vprtstp: contraction number = 2.114834e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.813741e-05
Vprtstp: contraction number = 2.201430e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.143755e-06
Vprtstp: contraction number = 2.284646e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.537727e-07
Vprtstp: contraction number = 2.301711e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.118505e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.259478e+00
Vpmg_setPart:  lower corner = (-12.7885, -35.8986, -29.0937)
Vpmg_setPart:  upper corner = (45.3315, 21.7096, 51.4676)
Vpmg_setPart:  actual minima = (-12.7885, -35.8986, -29.0937)
Vpmg_setPart:  actual maxima = (45.3315, 21.7096, 51.4676)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.017297189592E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.538000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 25.2812
Vpbe_ctor2:  solute dimensions = 34.1882 x 33.8872 x 47.389
Vpbe_ctor2:  solute charge = 1
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 68 x 67 x 75 table
Vclist_ctor2:  Using 68 x 67 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (44.803, 43.615, 57.834)
Vclist_setupGrid:  Grid lower corner = (-6.13, -28.902, -17.73)
Vclist_assignAtoms:  Have 3953257 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -10.8226, -34.0381, -22.5075
VPMG::focusFillBound -- New mesh maxs = 43.3656, 19.8491, 44.8815
VPMG::focusFillBound -- Old mesh mins = -12.7885, -35.8986, -29.0937
VPMG::focusFillBound -- Old mesh maxs = 45.3315, 21.7096, 51.4676
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-10.8226, -34.0381, -22.5075)
Vpmg_setPart:  upper corner = (43.3656, 19.8491, 44.8815)
Vpmg_setPart:  actual minima = (-12.7885, -35.8986, -29.0937)
Vpmg_setPart:  actual maxima = (45.3315, 21.7096, 51.4676)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-10.8226, -34.0381, -22.5075)
VPMG::extEnergy    Disj part upper corner = (43.3656, 19.8491, 44.8815)
VPMG::extEnergy    Old lower corner = (-12.7885, -35.8986, -29.0937)
VPMG::extEnergy    Old upper corner = (45.3315, 21.7096, 51.4676)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0255199 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0442052 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.203180
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.657520e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.839200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 049, 065)
Vbuildops: Galer: (025, 025, 033)
Vbuildops: Galer: (013, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.138730e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.503187e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.170590e-01
Vprtstp: contraction number = 1.170590e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.569247e-02
Vprtstp: contraction number = 1.340561e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.571048e-03
Vprtstp: contraction number = 1.638396e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.830719e-04
Vprtstp: contraction number = 1.878891e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.025347e-04
Vprtstp: contraction number = 2.122557e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.245629e-05
Vprtstp: contraction number = 2.190115e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.466020e-06
Vprtstp: contraction number = 2.434071e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.279169e-06
Vprtstp: contraction number = 2.340220e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.412310e-07
Vprtstp: contraction number = 2.667599e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.333489e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.493493e+00
Vpmg_setPart:  lower corner = (-10.8226, -34.0381, -22.5075)
Vpmg_setPart:  upper corner = (43.3656, 19.8491, 44.8815)
Vpmg_setPart:  actual minima = (-10.8226, -34.0381, -22.5075)
Vpmg_setPart:  actual maxima = (43.3656, 19.8491, 44.8815)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.161120347777E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.862000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 4.110028e+00
