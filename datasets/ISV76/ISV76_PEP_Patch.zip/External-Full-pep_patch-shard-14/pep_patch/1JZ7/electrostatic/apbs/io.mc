##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:56:41 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (257, 321, 385)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 63336 atoms
Valist_getStatistics:  Max atom coordinate:  (55.811, 65.715, 83.528)
Valist_getStatistics:  Min atom coordinate:  (-55.284, -72.582, -90.009)
Valist_getStatistics:  Molecule center:  (0.2635, -3.4335, -3.2405)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.758646, 0.750502, 0.780362
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.524388, 0.503972, 0.51112
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.691215, 0.671513, 0.654978 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.2635 -3.4335 -3.2405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 97.3702 116.647 146.589
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -96.8432 -123.514 -153.07
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 67.3851 77.202 94.8945
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -66.8581 -84.069 -101.376
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 67.3851 77.202 94.8945
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -66.8581 -84.069 -101.376
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -156
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13693372 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.549077
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.437835e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 321, 385)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.917590e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 161, 193)
Vbuildops: Galer: (065, 081, 097)
Vbuildops: Galer: (033, 041, 049)
Vbuildops: Galer: (017, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.167592e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.775602e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 6.228918e-02
Vprtstp: contraction number = 6.228918e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 9.050742e-03
Vprtstp: contraction number = 1.453020e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.128086e-03
Vprtstp: contraction number = 2.351284e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.701695e-04
Vprtstp: contraction number = 2.679260e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.843827e-04
Vprtstp: contraction number = 3.233822e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.840675e-05
Vprtstp: contraction number = 3.167692e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.032649e-05
Vprtstp: contraction number = 3.480161e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 6.788777e-06
Vprtstp: contraction number = 3.339867e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.408300e-06
Vprtstp: contraction number = 3.547472e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.174525e-07
Vprtstp: contraction number = 3.394313e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.200860e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.526404e+01
Vpmg_setPart:  lower corner = (-96.8432, -123.514, -153.07)
Vpmg_setPart:  upper corner = (97.3702, 116.647, 146.589)
Vpmg_setPart:  actual minima = (-96.8432, -123.514, -153.07)
Vpmg_setPart:  actual maxima = (97.3702, 116.647, 146.589)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.291050193381E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.821700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 94.1284
Vpbe_ctor2:  solute dimensions = 114.243 x 141.271 x 176.27
Vpbe_ctor2:  solute charge = -156
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (123.875, 151.077, 186.317)
Vclist_setupGrid:  Grid lower corner = (-61.674, -78.972, -96.399)
Vclist_assignAtoms:  Have 13693372 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -66.8581, -84.069, -101.375
VPMG::focusFillBound -- New mesh maxs = 67.3851, 77.202, 94.8945
VPMG::focusFillBound -- Old mesh mins = -96.8432, -123.514, -153.07
VPMG::focusFillBound -- Old mesh maxs = 97.3702, 116.647, 146.589
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-66.8581, -84.069, -101.375)
Vpmg_setPart:  upper corner = (67.3851, 77.202, 94.8945)
Vpmg_setPart:  actual minima = (-96.8432, -123.514, -153.07)
Vpmg_setPart:  actual maxima = (97.3702, 116.647, 146.589)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-66.8581, -84.069, -101.376)
VPMG::extEnergy    Disj part upper corner = (67.3851, 77.202, 94.8945)
VPMG::extEnergy    Old lower corner = (-96.8432, -123.514, -153.07)
VPMG::extEnergy    Old upper corner = (97.3702, 116.647, 146.589)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.942522 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.861656 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 10.464993
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.749037e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 321, 385)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 6.850750e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 161, 193)
Vbuildops: Galer: (065, 081, 097)
Vbuildops: Galer: (033, 041, 049)
Vbuildops: Galer: (017, 021, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.234854e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.062527e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.081504e-01
Vprtstp: contraction number = 1.081504e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.487011e-02
Vprtstp: contraction number = 1.374947e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.497787e-03
Vprtstp: contraction number = 2.352227e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.015150e-03
Vprtstp: contraction number = 2.902265e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.603932e-04
Vprtstp: contraction number = 4.535221e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.771499e-04
Vprtstp: contraction number = 3.847796e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 8.959478e-05
Vprtstp: contraction number = 5.057568e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.671768e-05
Vprtstp: contraction number = 4.098194e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.877553e-05
Vprtstp: contraction number = 5.113486e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.902037e-06
Vprtstp: contraction number = 4.208689e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.034059e-06
Vprtstp: contraction number = 5.105088e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.722327e-06
Vprtstp: contraction number = 4.269463e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.751432e-07
Vprtstp: contraction number = 5.081168e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.103688e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.432257e+01
Vpmg_setPart:  lower corner = (-66.8581, -84.069, -101.376)
Vpmg_setPart:  upper corner = (67.3851, 77.202, 94.8945)
Vpmg_setPart:  actual minima = (-66.8581, -84.069, -101.375)
Vpmg_setPart:  actual maxima = (67.3851, 77.202, 94.8945)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.940953647319E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.806400e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.164845e+02
