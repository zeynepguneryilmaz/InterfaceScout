##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:59:52 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 161, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2201 atoms
Valist_getStatistics:  Max atom coordinate:  (34.909, 53.916, 32.497)
Valist_getStatistics:  Min atom coordinate:  (-10.775, -8.638, -9.997)
Valist_getStatistics:  Molecule center:  (12.067, 22.639, 11.25)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.642655, 0.690009, 0.604448
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.534283, 0.530887, 0.511808
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.831367, 0.769392, 0.846735 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 12.067 22.639 11.25
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 53.197 77.8397 49.9347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.063 -32.5617 -27.4347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 46.2611 65.11 44.0057
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -22.1271 -19.832 -21.5057
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 46.2611 65.11 44.0057
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -22.1271 -19.832 -21.5057
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.242812
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.090180e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.867000e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.824690e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.895750e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.277775e-01
Vprtstp: contraction number = 1.277775e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.770711e-02
Vprtstp: contraction number = 1.385776e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.020178e-03
Vprtstp: contraction number = 2.270375e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.145588e-04
Vprtstp: contraction number = 1.777431e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.067884e-04
Vprtstp: contraction number = 2.893931e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.996480e-05
Vprtstp: contraction number = 1.932643e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.287619e-05
Vprtstp: contraction number = 3.221882e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.561754e-06
Vprtstp: contraction number = 1.989528e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.716286e-07
Vprtstp: contraction number = 3.402468e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.595817e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.967523e+00
Vpmg_setPart:  lower corner = (-29.063, -32.5617, -27.4347)
Vpmg_setPart:  upper corner = (53.197, 77.8397, 49.9347)
Vpmg_setPart:  actual minima = (-29.063, -32.5617, -27.4347)
Vpmg_setPart:  actual maxima = (53.197, 77.8397, 49.9347)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.348999205652E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.636000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 36.2513
Vpbe_ctor2:  solute dimensions = 48.3882 x 64.942 x 45.5114
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (58.464, 75.334, 55.274)
Vclist_setupGrid:  Grid lower corner = (-17.165, -15.028, -16.387)
Vclist_assignAtoms:  Have 3534101 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -22.1271, -19.832, -21.5057
VPMG::focusFillBound -- New mesh maxs = 46.2611, 65.11, 44.0057
VPMG::focusFillBound -- Old mesh mins = -29.063, -32.5617, -27.4347
VPMG::focusFillBound -- Old mesh maxs = 53.197, 77.8397, 49.9347
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-22.1271, -19.832, -21.5057)
Vpmg_setPart:  upper corner = (46.2611, 65.11, 44.0057)
Vpmg_setPart:  actual minima = (-29.063, -32.5617, -27.4347)
Vpmg_setPart:  actual maxima = (53.197, 77.8397, 49.9347)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-22.1271, -19.832, -21.5057)
VPMG::extEnergy    Disj part upper corner = (46.2611, 65.11, 44.0057)
VPMG::extEnergy    Old lower corner = (-29.063, -32.5617, -27.4347)
VPMG::extEnergy    Old upper corner = (53.197, 77.8397, 49.9347)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.713187 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.377477 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.247080
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 8.014600e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 161, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.761500e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 081, 065)
Vbuildops: Galer: (033, 041, 033)
Vbuildops: Galer: (017, 021, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.913050e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.789305e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.459461e-01
Vprtstp: contraction number = 1.459461e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.030430e-02
Vprtstp: contraction number = 1.391219e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.052755e-03
Vprtstp: contraction number = 1.996008e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.568584e-04
Vprtstp: contraction number = 1.867516e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.944142e-04
Vprtstp: contraction number = 2.568700e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.048130e-05
Vprtstp: contraction number = 2.082219e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.168049e-05
Vprtstp: contraction number = 2.885404e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.522230e-06
Vprtstp: contraction number = 2.159353e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.760132e-07
Vprtstp: contraction number = 3.076695e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.566568e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.949213e+00
Vpmg_setPart:  lower corner = (-22.1271, -19.832, -21.5057)
Vpmg_setPart:  upper corner = (46.2611, 65.11, 44.0057)
Vpmg_setPart:  actual minima = (-22.1271, -19.832, -21.5057)
Vpmg_setPart:  actual maxima = (46.2611, 65.11, 44.0057)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.079269300307E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.589000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 7.780196e+00
