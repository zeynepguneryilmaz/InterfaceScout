##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:53:50 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 193, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 11557 atoms
Valist_getStatistics:  Max atom coordinate:  (-33.089, 100.884, 61.594)
Valist_getStatistics:  Min atom coordinate:  (-115.093, 29.302, -32.036)
Valist_getStatistics:  Molecule center:  (-74.091, 65.093, 14.779)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.642236, 0.653641, 0.732495
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.467071, 0.488661, 0.520165
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.727259, 0.747599, 0.710128 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -74.091 65.093 14.779
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = -2.1606 127.843 96.8184
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -146.021 2.34345 -67.2605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -21.779 112.005 73.0375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -126.403 18.1815 -43.4795
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -21.779 112.005 73.0375
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -126.403 18.1815 -43.4795
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.417480
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.699139e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.175960e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 113)
Vbuildops: Galer: (057, 049, 057)
Vbuildops: Galer: (029, 025, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.699463e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.763148e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.523856e-02
Vprtstp: contraction number = 8.523856e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.271852e-02
Vprtstp: contraction number = 1.492108e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.477807e-03
Vprtstp: contraction number = 1.948189e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.973956e-04
Vprtstp: contraction number = 2.814568e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.646112e-04
Vprtstp: contraction number = 3.794278e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.025249e-04
Vprtstp: contraction number = 3.874549e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.440023e-05
Vprtstp: contraction number = 5.306049e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.250477e-05
Vprtstp: contraction number = 4.136889e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.315988e-05
Vprtstp: contraction number = 5.847594e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.448189e-06
Vprtstp: contraction number = 4.140000e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.284414e-06
Vprtstp: contraction number = 6.028450e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.355810e-06
Vprtstp: contraction number = 4.128013e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.269268e-07
Vprtstp: contraction number = 6.099133e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.341299e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.545050e+01
Vpmg_setPart:  lower corner = (-146.021, 2.34345, -67.2605)
Vpmg_setPart:  upper corner = (-2.1606, 127.843, 96.8184)
Vpmg_setPart:  actual minima = (-146.021, 2.34345, -67.2605)
Vpmg_setPart:  actual maxima = (-2.1606, 127.843, 96.8184)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.119653475137E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.845000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 55.8265
Vpbe_ctor2:  solute dimensions = 84.624 x 73.823 x 96.517
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (94.784, 84.362, 106.41)
Vclist_setupGrid:  Grid lower corner = (-121.483, 22.912, -38.426)
Vclist_assignAtoms:  Have 6792183 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -126.403, 18.1815, -43.4795
VPMG::focusFillBound -- New mesh maxs = -21.779, 112.005, 73.0375
VPMG::focusFillBound -- Old mesh mins = -146.021, 2.34345, -67.2605
VPMG::focusFillBound -- Old mesh maxs = -2.1606, 127.843, 96.8184
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-126.403, 18.1815, -43.4795)
Vpmg_setPart:  upper corner = (-21.779, 112.005, 73.0375)
Vpmg_setPart:  actual minima = (-146.021, 2.34345, -67.2605)
Vpmg_setPart:  actual maxima = (-2.1606, 127.843, 96.8184)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-126.403, 18.1815, -43.4795)
VPMG::extEnergy    Disj part upper corner = (-21.779, 112.005, 73.0375)
VPMG::extEnergy    Old lower corner = (-146.021, 2.34345, -67.2605)
VPMG::extEnergy    Old upper corner = (-2.1606, 127.843, 96.8184)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0248156 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0472229 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.410170
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.508189e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 193, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.104520e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 097, 113)
Vbuildops: Galer: (057, 049, 057)
Vbuildops: Galer: (029, 025, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.689812e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.372742e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.264328e-01
Vprtstp: contraction number = 1.264328e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.767713e-02
Vprtstp: contraction number = 1.398145e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.221330e-03
Vprtstp: contraction number = 1.822315e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.167983e-04
Vprtstp: contraction number = 2.535593e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.911130e-04
Vprtstp: contraction number = 3.564074e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.223688e-04
Vprtstp: contraction number = 4.203483e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.025270e-05
Vprtstp: contraction number = 4.923859e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.959932e-05
Vprtstp: contraction number = 4.912530e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.602228e-05
Vprtstp: contraction number = 5.413058e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.282806e-06
Vprtstp: contraction number = 5.169554e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.669881e-06
Vprtstp: contraction number = 5.638042e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.479008e-06
Vprtstp: contraction number = 5.308503e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.423224e-06
Vprtstp: contraction number = 5.741102e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.668752e-07
Vprtstp: contraction number = 5.388297e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.450804e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.652482e+01
Vpmg_setPart:  lower corner = (-126.403, 18.1815, -43.4795)
Vpmg_setPart:  upper corner = (-21.779, 112.005, 73.0375)
Vpmg_setPart:  actual minima = (-126.403, 18.1815, -43.4795)
Vpmg_setPart:  actual maxima = (-21.779, 112.005, 73.0375)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.742085103230E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.032000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 3.975831e+01
