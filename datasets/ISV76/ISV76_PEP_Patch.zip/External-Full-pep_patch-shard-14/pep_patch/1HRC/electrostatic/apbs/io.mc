##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:48 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 97, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1672 atoms
Valist_getStatistics:  Max atom coordinate:  (63.579, 38.926, 22.463)
Valist_getStatistics:  Min atom coordinate:  (26.949, 8.407, -13.769)
Valist_getStatistics:  Molecule center:  (45.264, 23.6665, 4.347)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.524479, 0.579877, 0.51166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.464767, 0.549438, 0.457227
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.88615, 0.947507, 0.893614 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 45.264 23.6665 4.347
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 78.8307 51.5006 37.0933
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 11.6974 -4.1676 -28.3993
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 75.0091 50.0395 33.6095
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 15.5189 -2.7065 -24.9155
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 75.0091 50.0395 33.6095
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 15.5189 -2.7065 -24.9155
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.208979
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.415730e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.565400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.734450e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.773730e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.363445e-01
Vprtstp: contraction number = 1.363445e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.356515e-02
Vprtstp: contraction number = 1.728353e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.294148e-03
Vprtstp: contraction number = 2.670956e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.072519e-03
Vprtstp: contraction number = 3.292771e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.169761e-04
Vprtstp: contraction number = 4.424452e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.677040e-04
Vprtstp: contraction number = 4.009963e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.784428e-04
Vprtstp: contraction number = 4.852893e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.248083e-05
Vprtstp: contraction number = 4.061851e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.558083e-05
Vprtstp: contraction number = 4.908999e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.442302e-05
Vprtstp: contraction number = 4.053591e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.106516e-06
Vprtstp: contraction number = 4.927205e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.874277e-06
Vprtstp: contraction number = 4.044566e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.419613e-06
Vprtstp: contraction number = 4.939025e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.731370e-07
Vprtstp: contraction number = 4.037277e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.610344e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.838054e+00
Vpmg_setPart:  lower corner = (11.6974, -4.1676, -28.3993)
Vpmg_setPart:  upper corner = (78.8307, 51.5006, 37.0933)
Vpmg_setPart:  actual minima = (11.6974, -4.1676, -28.3993)
Vpmg_setPart:  actual maxima = (78.8307, 51.5006, 37.0933)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.515266666948E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.254000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 23.2743
Vpbe_ctor2:  solute dimensions = 39.4902 x 32.746 x 38.525
Vpbe_ctor2:  solute charge = 9
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 65 x 75 table
Vclist_ctor2:  Using 75 x 65 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (49.41, 43.299, 49.012)
Vclist_setupGrid:  Grid lower corner = (20.559, 2.017, -20.159)
Vclist_assignAtoms:  Have 4760898 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 15.5189, -2.7065, -24.9155
VPMG::focusFillBound -- New mesh maxs = 75.0091, 50.0395, 33.6095
VPMG::focusFillBound -- Old mesh mins = 11.6974, -4.1676, -28.3993
VPMG::focusFillBound -- Old mesh maxs = 78.8307, 51.5006, 37.0933
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (15.5189, -2.7065, -24.9155)
Vpmg_setPart:  upper corner = (75.0091, 50.0395, 33.6095)
Vpmg_setPart:  actual minima = (11.6974, -4.1676, -28.3993)
Vpmg_setPart:  actual maxima = (78.8307, 51.5006, 37.0933)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (15.5189, -2.7065, -24.9155)
VPMG::extEnergy    Disj part upper corner = (75.0091, 50.0395, 33.6095)
VPMG::extEnergy    Old lower corner = (11.6974, -4.1676, -28.3993)
VPMG::extEnergy    Old upper corner = (78.8307, 51.5006, 37.0933)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0767288 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0838073 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.207866
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.438920e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 097, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.691900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 049, 065)
Vbuildops: Galer: (033, 025, 033)
Vbuildops: Galer: (017, 013, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.894440e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.304227e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.491033e-01
Vprtstp: contraction number = 1.491033e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.481491e-02
Vprtstp: contraction number = 1.664276e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.571513e-03
Vprtstp: contraction number = 2.245228e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.474945e-03
Vprtstp: contraction number = 2.647298e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 5.175286e-04
Vprtstp: contraction number = 3.508798e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.768710e-04
Vprtstp: contraction number = 3.417609e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.459056e-05
Vprtstp: contraction number = 4.217229e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.714249e-05
Vprtstp: contraction number = 3.638864e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.186444e-05
Vprtstp: contraction number = 4.371167e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.350531e-06
Vprtstp: contraction number = 3.666867e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.913706e-06
Vprtstp: contraction number = 4.398787e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.021717e-07
Vprtstp: contraction number = 3.669172e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.356894e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.607483e+00
Vpmg_setPart:  lower corner = (15.5189, -2.7065, -24.9155)
Vpmg_setPart:  upper corner = (75.0091, 50.0395, 33.6095)
Vpmg_setPart:  actual minima = (15.5189, -2.7065, -24.9155)
Vpmg_setPart:  actual maxima = (75.0091, 50.0395, 33.6095)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.645040891328E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.156000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.933802e+00
