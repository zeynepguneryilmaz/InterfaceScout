##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:15 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 353, 321)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 20148 atoms
Valist_getStatistics:  Max atom coordinate:  (51.224, 57.144, 74.381)
Valist_getStatistics:  Min atom coordinate:  (-54.335, -90.406, -56.357)
Valist_getStatistics:  Molecule center:  (-1.5555, -16.631, 9.012)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.721311, 0.723191, 0.708709
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.502426, 0.482224, 0.479387
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.696545, 0.666801, 0.676424 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -1.5555 -16.631 9.012
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 90.7723 110.651 122.405
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -93.8834 -143.913 -104.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 62.755 68.2405 85.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -65.866 -101.502 -67.69
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 62.755 68.2405 85.714
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -65.866 -101.502 -67.69
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 7.13873e-14
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105702 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.715818
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 8.951325e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 353, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.177830e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 177, 161)
Vbuildops: Galer: (065, 089, 081)
Vbuildops: Galer: (033, 045, 041)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.086712e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.134104e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.194877e-02
Vprtstp: contraction number = 8.194877e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.442120e-02
Vprtstp: contraction number = 1.759783e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.865296e-03
Vprtstp: contraction number = 1.986863e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.074872e-03
Vprtstp: contraction number = 3.751347e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.707864e-04
Vprtstp: contraction number = 3.449587e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.796848e-04
Vprtstp: contraction number = 4.846046e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.881042e-05
Vprtstp: contraction number = 4.386036e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.991359e-05
Vprtstp: contraction number = 5.064507e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.851493e-05
Vprtstp: contraction number = 4.638753e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 9.591181e-06
Vprtstp: contraction number = 5.180242e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.490859e-06
Vprtstp: contraction number = 4.682279e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.372628e-06
Vprtstp: contraction number = 5.283238e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.109698e-06
Vprtstp: contraction number = 4.677086e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 5.961706e-07
Vprtstp: contraction number = 5.372366e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.555378e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.786658e+01
Vpmg_setPart:  lower corner = (-93.8834, -143.913, -104.381)
Vpmg_setPart:  upper corner = (90.7723, 110.651, 122.405)
Vpmg_setPart:  actual minima = (-93.8834, -143.913, -104.381)
Vpmg_setPart:  actual maxima = (90.7723, 110.651, 122.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.557838573481E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.437000e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 90.6594
Vpbe_ctor2:  solute dimensions = 108.621 x 149.743 x 133.404
Vpbe_ctor2:  solute charge = 7.13873e-14
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (118.339, 160.33, 143.518)
Vclist_setupGrid:  Grid lower corner = (-60.725, -96.796, -62.747)
Vclist_assignAtoms:  Have 5105702 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -65.866, -101.502, -67.69
VPMG::focusFillBound -- New mesh maxs = 62.755, 68.2405, 85.714
VPMG::focusFillBound -- Old mesh mins = -93.8834, -143.913, -104.381
VPMG::focusFillBound -- Old mesh maxs = 90.7723, 110.651, 122.405
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-65.866, -101.502, -67.69)
Vpmg_setPart:  upper corner = (62.755, 68.2405, 85.714)
Vpmg_setPart:  actual minima = (-93.8834, -143.913, -104.381)
Vpmg_setPart:  actual maxima = (90.7723, 110.651, 122.405)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-65.866, -101.502, -67.69)
VPMG::extEnergy    Disj part upper corner = (62.755, 68.2405, 85.714)
VPMG::extEnergy    Old lower corner = (-93.8834, -143.913, -104.381)
VPMG::extEnergy    Old upper corner = (90.7723, 110.651, 122.405)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0313255 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0640953 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 4.703677
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.190470e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 353, 321)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.153470e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 177, 161)
Vbuildops: Galer: (065, 089, 081)
Vbuildops: Galer: (033, 045, 041)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.093904e+01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.113163e+02
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.315534e-01
Vprtstp: contraction number = 1.315534e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.070476e-02
Vprtstp: contraction number = 1.573868e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.117572e-03
Vprtstp: contraction number = 1.988708e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.455863e-03
Vprtstp: contraction number = 3.535732e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.024240e-04
Vprtstp: contraction number = 4.137916e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.488145e-04
Vprtstp: contraction number = 5.790183e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.888739e-04
Vprtstp: contraction number = 5.414737e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.240601e-04
Vprtstp: contraction number = 6.568411e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.256262e-05
Vprtstp: contraction number = 5.848988e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.054150e-05
Vprtstp: contraction number = 6.965225e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.060280e-05
Vprtstp: contraction number = 6.054985e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.191977e-05
Vprtstp: contraction number = 7.162666e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.349556e-05
Vprtstp: contraction number = 6.156801e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.776815e-06
Vprtstp: contraction number = 7.244466e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.066684e-06
Vprtstp: contraction number = 6.205174e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 4.414691e-06
Vprtstp: contraction number = 7.276942e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.749803e-06
Vprtstp: contraction number = 6.228754e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 2.004675e-06
Vprtstp: contraction number = 7.290250e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.251208e-06
Vprtstp: contraction number = 6.241451e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 9.129011e-07
Vprtstp: contraction number = 7.296157e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.429722e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.663353e+01
Vpmg_setPart:  lower corner = (-65.866, -101.502, -67.69)
Vpmg_setPart:  upper corner = (62.755, 68.2405, 85.714)
Vpmg_setPart:  actual minima = (-65.866, -101.502, -67.69)
Vpmg_setPart:  actual maxima = (62.755, 68.2405, 85.714)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 9.702953236069E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.150700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.830250e+02
