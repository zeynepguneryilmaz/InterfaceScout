##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:59:57 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 225, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16125 atoms
Valist_getStatistics:  Max atom coordinate:  (170.12, 197.484, 59.506)
Valist_getStatistics:  Min atom coordinate:  (79.608, 105.555, -45.871)
Valist_getStatistics:  Molecule center:  (124.864, 151.519, 6.8175)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.703414, 0.713628, 0.713263
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.503059, 0.509067, 0.497691
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.715167, 0.71335, 0.697767 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 124.864 151.519 6.8175
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 203.646 231.446 98.1151
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 46.0816 71.5931 -84.4802
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 181.207 208.535 70.522
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 68.5214 94.504 -56.887
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 181.207 208.535 70.522
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 68.5214 94.504 -56.887
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6991473 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.378033
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.661661e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.109400e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 113, 129)
Vbuildops: Galer: (057, 057, 065)
Vbuildops: Galer: (029, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.667725e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.005697e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.643168e-02
Vprtstp: contraction number = 8.643168e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.405933e-02
Vprtstp: contraction number = 1.626641e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.404137e-03
Vprtstp: contraction number = 3.132537e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.175310e-03
Vprtstp: contraction number = 2.668651e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 6.228996e-04
Vprtstp: contraction number = 5.299873e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.929079e-04
Vprtstp: contraction number = 3.096934e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.107602e-04
Vprtstp: contraction number = 5.741609e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.572938e-05
Vprtstp: contraction number = 3.225833e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.052885e-05
Vprtstp: contraction number = 5.745650e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.790418e-06
Vprtstp: contraction number = 3.307744e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.861451e-06
Vprtstp: contraction number = 5.686618e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.300137e-06
Vprtstp: contraction number = 3.366965e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.315907e-07
Vprtstp: contraction number = 5.627027e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.908944e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.342056e+01
Vpmg_setPart:  lower corner = (46.0816, 71.5931, -84.4802)
Vpmg_setPart:  upper corner = (203.646, 231.446, 98.1151)
Vpmg_setPart:  actual minima = (46.0816, 71.5931, -84.4802)
Vpmg_setPart:  actual maxima = (203.646, 231.446, 98.1151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.658109691467E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.357700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 58.2482
Vpbe_ctor2:  solute dimensions = 92.6852 x 94.031 x 107.409
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (103.292, 104.709, 118.157)
Vclist_setupGrid:  Grid lower corner = (73.218, 99.165, -52.261)
Vclist_assignAtoms:  Have 6991473 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 68.5214, 94.504, -56.887
VPMG::focusFillBound -- New mesh maxs = 181.207, 208.535, 70.522
VPMG::focusFillBound -- Old mesh mins = 46.0816, 71.5931, -84.4802
VPMG::focusFillBound -- Old mesh maxs = 203.646, 231.446, 98.1151
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (68.5214, 94.504, -56.887)
Vpmg_setPart:  upper corner = (181.207, 208.535, 70.522)
Vpmg_setPart:  actual minima = (46.0816, 71.5931, -84.4802)
Vpmg_setPart:  actual maxima = (203.646, 231.446, 98.1151)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (68.5214, 94.504, -56.887)
VPMG::extEnergy    Disj part upper corner = (181.207, 208.535, 70.522)
VPMG::extEnergy    Old lower corner = (46.0816, 71.5931, -84.4802)
VPMG::extEnergy    Old upper corner = (203.646, 231.446, 98.1151)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0872182 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.162857 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 3.312097
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.260192e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 225, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.078520e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 113, 129)
Vbuildops: Galer: (057, 057, 065)
Vbuildops: Galer: (029, 029, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.639192e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.074073e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.265135e-01
Vprtstp: contraction number = 1.265135e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.815322e-02
Vprtstp: contraction number = 1.434884e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 4.813258e-03
Vprtstp: contraction number = 2.651463e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.340852e-03
Vprtstp: contraction number = 2.785747e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.477087e-04
Vprtstp: contraction number = 6.322166e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 3.337661e-04
Vprtstp: contraction number = 3.937274e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.407769e-04
Vprtstp: contraction number = 7.213941e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.062410e-04
Vprtstp: contraction number = 4.412425e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.499237e-05
Vprtstp: contraction number = 7.058703e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.522100e-05
Vprtstp: contraction number = 4.696611e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.429219e-05
Vprtstp: contraction number = 6.897076e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.187182e-05
Vprtstp: contraction number = 4.887091e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.051043e-06
Vprtstp: contraction number = 6.781644e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 4.037893e-06
Vprtstp: contraction number = 5.015366e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.706344e-06
Vprtstp: contraction number = 6.702368e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.380919e-06
Vprtstp: contraction number = 5.102524e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 9.180037e-07
Vprtstp: contraction number = 6.647776e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.460636e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.886675e+01
Vpmg_setPart:  lower corner = (68.5214, 94.504, -56.887)
Vpmg_setPart:  upper corner = (181.207, 208.535, 70.522)
Vpmg_setPart:  actual minima = (68.5214, 94.504, -56.887)
Vpmg_setPart:  actual maxima = (181.207, 208.535, 70.522)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.170844981822E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.342900e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.857703e+01
