##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 18:03:12 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 5, dime = (129, 129, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 2946 atoms
Valist_getStatistics:  Max atom coordinate:  (9.444, 13.862, 14.228)
Valist_getStatistics:  Min atom coordinate:  (-31.035, -21.111, -56.717)
Valist_getStatistics:  Molecule center:  (-10.7955, -3.6245, -21.2445)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.578534, 0.497967, 0.645734
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.496564, 0.449172, 0.48401
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.858315, 0.902011, 0.74955 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -10.7955 -3.6245 -21.2445
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 26.2307 28.2454 40.746
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -47.8217 -35.4944 -83.235
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 20.9846 25.1225 25.2205
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -42.5756 -32.3715 -67.7095
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 20.9846 25.1225 25.2205
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -42.5756 -32.3715 -67.7095
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.523769
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.313013e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.032760e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 097)
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.060620e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.798715e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.132468e-01
Vprtstp: contraction number = 1.132468e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.635221e-02
Vprtstp: contraction number = 1.443945e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.764380e-03
Vprtstp: contraction number = 1.690524e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.129833e-04
Vprtstp: contraction number = 1.855690e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.025682e-04
Vprtstp: contraction number = 1.999444e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.159464e-05
Vprtstp: contraction number = 2.105394e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.833225e-06
Vprtstp: contraction number = 2.238160e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.162731e-06
Vprtstp: contraction number = 2.405704e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.054756e-07
Vprtstp: contraction number = 2.627225e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.857880e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.326970e+00
Vpmg_setPart:  lower corner = (-47.8217, -35.4944, -83.235)
Vpmg_setPart:  upper corner = (26.2307, 28.2454, 40.746)
Vpmg_setPart:  actual minima = (-47.8217, -35.4944, -83.235)
Vpmg_setPart:  actual maxima = (26.2306, 28.2454, 40.746)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.085636492868E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.397000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 2.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.4325
Vpbe_ctor2:  solute dimensions = 43.5602 x 37.494 x 72.93
Vpbe_ctor2:  solute charge = -5
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 74 x 75 table
Vclist_ctor2:  Using 75 x 74 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (53.259, 47.753, 83.725)
Vclist_setupGrid:  Grid lower corner = (-37.425, -27.501, -63.107)
Vclist_assignAtoms:  Have 5232876 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -42.5756, -32.3715, -67.7095
VPMG::focusFillBound -- New mesh maxs = 20.9846, 25.1225, 25.2205
VPMG::focusFillBound -- Old mesh mins = -47.8217, -35.4944, -83.235
VPMG::focusFillBound -- Old mesh maxs = 26.2307, 28.2454, 40.746
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-42.5756, -32.3715, -67.7095)
Vpmg_setPart:  upper corner = (20.9846, 25.1225, 25.2205)
Vpmg_setPart:  actual minima = (-47.8217, -35.4944, -83.235)
Vpmg_setPart:  actual maxima = (26.2306, 28.2454, 40.746)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-42.5756, -32.3715, -67.7095)
VPMG::extEnergy    Disj part upper corner = (20.9846, 25.1225, 25.2205)
VPMG::extEnergy    Old lower corner = (-47.8217, -35.4944, -83.235)
VPMG::extEnergy    Old upper corner = (26.2306, 28.2454, 40.746)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.145696 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0923098 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.514374
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.622795e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.047700e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 097)
Vbuildops: Galer: (033, 033, 049)
Vbuildops: Galer: (017, 017, 025)
Vbuildops: Galer: (009, 009, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.043930e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.767641e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.325529e-01
Vprtstp: contraction number = 1.325529e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.807886e-02
Vprtstp: contraction number = 1.363898e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.817414e-03
Vprtstp: contraction number = 1.558403e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.863986e-04
Vprtstp: contraction number = 1.726401e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.294485e-05
Vprtstp: contraction number = 1.910878e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.904473e-05
Vprtstp: contraction number = 2.049035e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.346686e-06
Vprtstp: contraction number = 2.282357e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.199918e-06
Vprtstp: contraction number = 2.760535e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.045923e-07
Vprtstp: contraction number = 3.371833e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.824721e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.289099e+00
Vpmg_setPart:  lower corner = (-42.5756, -32.3715, -67.7095)
Vpmg_setPart:  upper corner = (20.9846, 25.1225, 25.2205)
Vpmg_setPart:  actual minima = (-42.5756, -32.3715, -67.7095)
Vpmg_setPart:  actual maxima = (20.9846, 25.1225, 25.2205)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.510362872987E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.359000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.241422e+01
