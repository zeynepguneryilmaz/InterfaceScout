##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 18:02:33 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3606 atoms
Valist_getStatistics:  Max atom coordinate:  (34.682, 90.446, 8.189)
Valist_getStatistics:  Min atom coordinate:  (-17.88, 48.793, -28.523)
Valist_getStatistics:  Molecule center:  (8.401, 69.6195, -10.167)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.580943, 0.589042, 0.529393
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.466731, 0.502745, 0.467658
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.803403, 0.853496, 0.883385 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 8.401 69.6195 -10.167
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 54.8765 107.318 23.7141
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -38.0744 31.9208 -44.0481
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 45.7395 101.795 19.7631
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -28.9375 37.4438 -40.0971
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 45.7395 101.795 19.7631
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -28.9375 37.4438 -40.0971
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.658807
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.409937e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.486600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.612990e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.922225e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.066561e-01
Vprtstp: contraction number = 1.066561e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.416409e-02
Vprtstp: contraction number = 1.328015e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.562362e-03
Vprtstp: contraction number = 1.809055e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.149751e-04
Vprtstp: contraction number = 2.400032e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.043477e-04
Vprtstp: contraction number = 3.322862e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.943229e-05
Vprtstp: contraction number = 3.397753e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.775890e-05
Vprtstp: contraction number = 3.997982e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.063466e-05
Vprtstp: contraction number = 3.831080e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.337519e-06
Vprtstp: contraction number = 4.078664e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.703113e-06
Vprtstp: contraction number = 3.926467e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.920653e-07
Vprtstp: contraction number = 4.063532e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.064025e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.557254e+00
Vpmg_setPart:  lower corner = (-38.0744, 31.9208, -44.0481)
Vpmg_setPart:  upper corner = (54.8765, 107.318, 23.7141)
Vpmg_setPart:  actual minima = (-38.0744, 31.9208, -44.0481)
Vpmg_setPart:  actual maxima = (54.8765, 107.318, 23.7141)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.353575170907E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.842000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 31.3367
Vpbe_ctor2:  solute dimensions = 54.677 x 44.3514 x 39.8602
Vpbe_ctor2:  solute charge = -6
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (65.342, 54.433, 49.492)
Vclist_setupGrid:  Grid lower corner = (-24.27, 42.403, -34.913)
Vclist_assignAtoms:  Have 7551497 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -28.9375, 37.4438, -40.0971
VPMG::focusFillBound -- New mesh maxs = 45.7395, 101.795, 19.7631
VPMG::focusFillBound -- Old mesh mins = -38.0744, 31.9208, -44.0481
VPMG::focusFillBound -- Old mesh maxs = 54.8765, 107.318, 23.7141
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-28.9375, 37.4438, -40.0971)
Vpmg_setPart:  upper corner = (45.7395, 101.795, 19.7631)
Vpmg_setPart:  actual minima = (-38.0744, 31.9208, -44.0481)
Vpmg_setPart:  actual maxima = (54.8765, 107.318, 23.7141)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-28.9375, 37.4438, -40.0971)
VPMG::extEnergy    Disj part upper corner = (45.7395, 101.795, 19.7631)
VPMG::extEnergy    Old lower corner = (-38.0744, 31.9208, -44.0481)
VPMG::extEnergy    Old upper corner = (54.8765, 107.318, 23.7141)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0790165 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.102998 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.649206
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.722721e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.641200e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.678720e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.232175e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.268994e-01
Vprtstp: contraction number = 1.268994e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.682144e-02
Vprtstp: contraction number = 1.325573e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.811615e-03
Vprtstp: contraction number = 1.671447e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.284922e-04
Vprtstp: contraction number = 2.235342e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.099066e-04
Vprtstp: contraction number = 3.339844e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 7.357031e-05
Vprtstp: contraction number = 3.504907e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.267054e-05
Vprtstp: contraction number = 4.440724e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.326696e-05
Vprtstp: contraction number = 4.060831e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.039407e-06
Vprtstp: contraction number = 4.552218e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.527009e-06
Vprtstp: contraction number = 4.184201e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.146349e-06
Vprtstp: contraction number = 4.536387e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 4.841763e-07
Vprtstp: contraction number = 4.223637e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.422558e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.922594e+00
Vpmg_setPart:  lower corner = (-28.9375, 37.4438, -40.0971)
Vpmg_setPart:  upper corner = (45.7395, 101.795, 19.7631)
Vpmg_setPart:  actual minima = (-28.9375, 37.4438, -40.0971)
Vpmg_setPart:  actual maxima = (45.7395, 101.795, 19.7631)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.825404600475E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.873000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.334654e+01
