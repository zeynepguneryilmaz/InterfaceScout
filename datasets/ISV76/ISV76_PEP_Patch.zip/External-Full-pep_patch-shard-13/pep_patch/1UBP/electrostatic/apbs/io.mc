##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:48:59 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (289, 289, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 36144 atoms
Valist_getStatistics:  Max atom coordinate:  (65.042, 142.542, 109.818)
Valist_getStatistics:  Min atom coordinate:  (-56.211, 20.968, 42.047)
Valist_getStatistics:  Molecule center:  (4.4155, 81.755, 75.9325)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.735075, 0.734985, 0.62863
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.501842, 0.501789, 0.473949
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.682708, 0.68272, 0.75394 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 4.4155 81.755 75.9325
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 110.266 187.593 136.281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -101.435 -24.0829 15.5841
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 76.6807 154.013 121.432
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -67.8497 9.4974 30.4334
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 76.6807 154.013 121.432
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -67.8497 9.4974 30.4334
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -102
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493351 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.925355
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 8.343500e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (289, 289, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.372300e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (145, 145, 097)
Vbuildops: Galer: (073, 073, 049)
Vbuildops: Galer: (037, 037, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.873383e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.889082e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.941328e-02
Vprtstp: contraction number = 8.941328e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.821529e-02
Vprtstp: contraction number = 2.037202e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.111474e-02
Vprtstp: contraction number = 6.101870e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.842200e-03
Vprtstp: contraction number = 4.356559e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.000254e-03
Vprtstp: contraction number = 8.261232e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.954725e-03
Vprtstp: contraction number = 4.886502e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.602754e-03
Vprtstp: contraction number = 8.199385e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.269717e-04
Vprtstp: contraction number = 5.159692e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.696886e-04
Vprtstp: contraction number = 8.098083e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.579578e-04
Vprtstp: contraction number = 5.345139e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.870245e-04
Vprtstp: contraction number = 8.018387e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.573545e-04
Vprtstp: contraction number = 5.482269e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.251414e-04
Vprtstp: contraction number = 7.952831e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.992371e-05
Vprtstp: contraction number = 5.587576e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 5.520821e-05
Vprtstp: contraction number = 7.895492e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.130332e-05
Vprtstp: contraction number = 5.670048e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.455505e-05
Vprtstp: contraction number = 7.844230e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.408318e-05
Vprtstp: contraction number = 5.735351e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.098284e-05
Vprtstp: contraction number = 7.798551e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 6.356297e-06
Vprtstp: contraction number = 5.787481e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 4.931404e-06
Vprtstp: contraction number = 7.758298e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 2.874693e-06
Vprtstp: contraction number = 5.829359e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 2.220224e-06
Vprtstp: contraction number = 7.723344e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 1.301763e-06
Vprtstp: contraction number = 5.863207e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 1.001495e-06
Vprtstp: contraction number = 7.693371e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 5.899550e-07
Vprtstp: contraction number = 5.890744e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.206945e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.254006e+01
Vpmg_setPart:  lower corner = (-101.435, -24.0829, 15.5841)
Vpmg_setPart:  upper corner = (110.266, 187.593, 136.281)
Vpmg_setPart:  actual minima = (-101.435, -24.0829, 15.5841)
Vpmg_setPart:  actual maxima = (110.266, 187.593, 136.281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 8.928605255453E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.291700e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 78.2432
Vpbe_ctor2:  solute dimensions = 124.53 x 124.515 x 70.9982
Vpbe_ctor2:  solute charge = -102
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (134.033, 134.354, 80.551)
Vclist_setupGrid:  Grid lower corner = (-62.601, 14.578, 35.657)
Vclist_assignAtoms:  Have 14493351 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -67.8497, 9.4974, 30.4334
VPMG::focusFillBound -- New mesh maxs = 76.6807, 154.013, 121.432
VPMG::focusFillBound -- Old mesh mins = -101.435, -24.0829, 15.5841
VPMG::focusFillBound -- Old mesh maxs = 110.266, 187.593, 136.281
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-67.8497, 9.4974, 30.4334)
Vpmg_setPart:  upper corner = (76.6807, 154.013, 121.432)
Vpmg_setPart:  actual minima = (-101.435, -24.0829, 15.5841)
Vpmg_setPart:  actual maxima = (110.266, 187.593, 136.281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-67.8497, 9.4974, 30.4334)
VPMG::extEnergy    Disj part upper corner = (76.6807, 154.013, 121.432)
VPMG::extEnergy    Old lower corner = (-101.435, -24.0829, 15.5841)
VPMG::extEnergy    Old upper corner = (110.266, 187.593, 136.281)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 16.9197 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 13.6573 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 5.915204
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.027454e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (289, 289, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.388960e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (145, 145, 097)
Vbuildops: Galer: (073, 073, 049)
Vbuildops: Galer: (037, 037, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 9.611386e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.152160e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.182071e-01
Vprtstp: contraction number = 1.182071e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.635427e-02
Vprtstp: contraction number = 1.383527e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 5.291439e-03
Vprtstp: contraction number = 3.235509e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.735111e-03
Vprtstp: contraction number = 3.279092e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.210790e-03
Vprtstp: contraction number = 6.978168e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.307040e-04
Vprtstp: contraction number = 4.383122e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.897810e-04
Vprtstp: contraction number = 7.344603e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.883873e-04
Vprtstp: contraction number = 4.833158e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.368657e-04
Vprtstp: contraction number = 7.265123e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.973934e-05
Vprtstp: contraction number = 5.095458e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.988279e-05
Vprtstp: contraction number = 7.152749e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.622519e-05
Vprtstp: contraction number = 5.257362e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.852641e-05
Vprtstp: contraction number = 7.064359e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.937613e-06
Vprtstp: contraction number = 5.364024e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.958766e-06
Vprtstp: contraction number = 7.002452e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.783895e-06
Vprtstp: contraction number = 5.437595e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.633872e-06
Vprtstp: contraction number = 6.960743e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.446067e-06
Vprtstp: contraction number = 5.490270e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.002594e-06
Vprtstp: contraction number = 6.933250e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 5.543646e-07
Vprtstp: contraction number = 5.529303e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.023977e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.042711e+01
Vpmg_setPart:  lower corner = (-67.8497, 9.4974, 30.4334)
Vpmg_setPart:  upper corner = (76.6807, 154.013, 121.432)
Vpmg_setPart:  actual minima = (-67.8497, 9.4974, 30.4334)
Vpmg_setPart:  actual maxima = (76.6807, 154.013, 121.432)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.764614757653E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.189200e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.357408e+02
