##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:47:55 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 6, dime = (129, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1856 atoms
Valist_getStatistics:  Max atom coordinate:  (49.597, 39.954, 28.944)
Valist_getStatistics:  Min atom coordinate:  (11.11, -6.742, -4.612)
Valist_getStatistics:  Molecule center:  (30.3535, 16.606, 12.166)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.542127, 0.654887, 0.481737
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.475148, 0.541478, 0.439625
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.876452, 0.826826, 0.912582 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 30.3535 16.606 12.166
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 65.0496 58.5188 42.9972
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -4.34265 -25.3068 -18.6652
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 60.763 51.2606 40.302
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -0.056 -18.0486 -15.97
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 60.763 51.2606 40.302
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -0.056 -18.0486 -15.97
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.236062
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 6.459260e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.542400e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.390530e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 8.702830e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.175629e-01
Vprtstp: contraction number = 1.175629e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.790237e-02
Vprtstp: contraction number = 1.522791e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.229806e-03
Vprtstp: contraction number = 1.804122e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.343875e-04
Vprtstp: contraction number = 1.964166e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.314277e-04
Vprtstp: contraction number = 2.071725e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.838531e-05
Vprtstp: contraction number = 2.159766e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.373539e-06
Vprtstp: contraction number = 2.245366e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.493554e-06
Vprtstp: contraction number = 2.343367e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.668674e-07
Vprtstp: contraction number = 2.456339e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.140552e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.360183e+00
Vpmg_setPart:  lower corner = (-4.34265, -25.3068, -18.6652)
Vpmg_setPart:  upper corner = (65.0496, 58.5188, 42.9972)
Vpmg_setPart:  actual minima = (-4.34265, -25.3068, -18.6652)
Vpmg_setPart:  actual maxima = (65.0496, 58.5188, 42.9972)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.475448745926E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.884000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.7099
Vpbe_ctor2:  solute dimensions = 40.819 x 49.3092 x 36.272
Vpbe_ctor2:  solute charge = 4
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 72 table
Vclist_ctor2:  Using 75 x 75 x 72 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (51.267, 59.476, 46.336)
Vclist_setupGrid:  Grid lower corner = (4.72, -13.132, -11.002)
Vclist_assignAtoms:  Have 4479268 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -0.056, -18.0486, -15.97
VPMG::focusFillBound -- New mesh maxs = 60.763, 51.2606, 40.302
VPMG::focusFillBound -- Old mesh mins = -4.34265, -25.3068, -18.6652
VPMG::focusFillBound -- Old mesh maxs = 65.0496, 58.5188, 42.9972
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-0.056, -18.0486, -15.97)
Vpmg_setPart:  upper corner = (60.763, 51.2606, 40.302)
Vpmg_setPart:  actual minima = (-4.34265, -25.3068, -18.6652)
Vpmg_setPart:  actual maxima = (65.0496, 58.5188, 42.9972)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-0.056, -18.0486, -15.97)
VPMG::extEnergy    Disj part upper corner = (60.763, 51.2606, 40.302)
VPMG::extEnergy    Old lower corner = (-4.34265, -25.3068, -18.6652)
VPMG::extEnergy    Old upper corner = (65.0496, 58.5188, 42.9972)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0573075 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0483631 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.231869
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.726120e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.601300e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 065)
Vbuildops: Galer: (033, 033, 033)
Vbuildops: Galer: (017, 017, 017)
Vbuildops: Galer: (009, 009, 009)
Vbuildops: Galer: (005, 005, 005)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.351610e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.009767e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.313710e-01
Vprtstp: contraction number = 1.313710e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.859352e-02
Vprtstp: contraction number = 1.415344e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.998507e-03
Vprtstp: contraction number = 1.612663e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.255803e-04
Vprtstp: contraction number = 1.752807e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 9.755092e-05
Vprtstp: contraction number = 1.856061e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.884766e-05
Vprtstp: contraction number = 1.932084e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.768921e-06
Vprtstp: contraction number = 1.999676e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.789638e-07
Vprtstp: contraction number = 2.066808e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.876711e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.092122e+00
Vpmg_setPart:  lower corner = (-0.056, -18.0486, -15.97)
Vpmg_setPart:  upper corner = (60.763, 51.2606, 40.302)
Vpmg_setPart:  actual minima = (-0.056, -18.0486, -15.97)
Vpmg_setPart:  actual maxima = (60.763, 51.2606, 40.302)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 9.604884581376E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.833000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.352375e+00
