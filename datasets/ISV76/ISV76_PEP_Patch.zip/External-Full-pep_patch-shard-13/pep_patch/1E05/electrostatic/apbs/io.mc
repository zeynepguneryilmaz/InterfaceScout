##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:47:19 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 6678 atoms
Valist_getStatistics:  Max atom coordinate:  (18.907, 18.785, -6.611)
Valist_getStatistics:  Min atom coordinate:  (-48.035, -32.888, -70.977)
Valist_getStatistics:  Molecule center:  (-14.564, -7.0515, -38.794)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.616924, 0.580735, 0.713364
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.467064, 0.466609, 0.544626
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.757084, 0.80348, 0.763462 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -14.564 -7.0515 -38.794
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 44.6608 39.4073 18.2751
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -73.7887 -53.5103 -95.8632
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 30.2741 30.2772 4.7761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -59.4021 -44.3802 -82.3641
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 30.2741 30.2772 4.7761
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -59.4021 -44.3802 -82.3641
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154912 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.888288
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.725774e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.044150e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 081)
Vbuildops: Galer: (049, 041, 041)
Vbuildops: Galer: (025, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.393720e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.461248e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.583491e-02
Vprtstp: contraction number = 9.583491e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.445105e-02
Vprtstp: contraction number = 1.507911e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.116516e-03
Vprtstp: contraction number = 2.156601e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.283390e-04
Vprtstp: contraction number = 2.657901e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.619055e-04
Vprtstp: contraction number = 3.161815e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 9.505425e-05
Vprtstp: contraction number = 3.629334e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.465025e-05
Vprtstp: contraction number = 3.645313e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.404434e-05
Vprtstp: contraction number = 4.053173e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 5.215993e-06
Vprtstp: contraction number = 3.713946e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.318599e-06
Vprtstp: contraction number = 4.445173e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 9.999903e-07
Vprtstp: contraction number = 4.312907e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.637148e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.354458e+00
Vpmg_setPart:  lower corner = (-73.7887, -53.5103, -95.8632)
Vpmg_setPart:  upper corner = (44.6608, 39.4073, 18.2751)
Vpmg_setPart:  actual minima = (-73.7887, -53.5103, -95.8632)
Vpmg_setPart:  actual maxima = (44.6608, 39.4073, 18.2751)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.983810416340E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.620000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.8164
Vpbe_ctor2:  solute dimensions = 69.6762 x 54.6574 x 67.1402
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.722, 64.453, 77.146)
Vclist_setupGrid:  Grid lower corner = (-54.425, -39.278, -77.367)
Vclist_assignAtoms:  Have 7154912 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -59.4021, -44.3802, -82.3641
VPMG::focusFillBound -- New mesh maxs = 30.2741, 30.2772, 4.7761
VPMG::focusFillBound -- Old mesh mins = -73.7887, -53.5103, -95.8632
VPMG::focusFillBound -- Old mesh maxs = 44.6608, 39.4073, 18.2752
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-59.4021, -44.3802, -82.3641)
Vpmg_setPart:  upper corner = (30.2741, 30.2772, 4.7761)
Vpmg_setPart:  actual minima = (-73.7887, -53.5103, -95.8632)
Vpmg_setPart:  actual maxima = (44.6608, 39.4073, 18.2751)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-59.4021, -44.3802, -82.3641)
VPMG::extEnergy    Disj part upper corner = (30.2741, 30.2772, 4.7761)
VPMG::extEnergy    Old lower corner = (-73.7887, -53.5103, -95.8632)
VPMG::extEnergy    Old upper corner = (44.6608, 39.4073, 18.2751)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0746057 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0987912 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.878901
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.150864e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.034710e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 081, 081)
Vbuildops: Galer: (049, 041, 041)
Vbuildops: Galer: (025, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.453870e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.198955e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.279446e-01
Vprtstp: contraction number = 1.279446e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.822437e-02
Vprtstp: contraction number = 1.424396e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.341699e-03
Vprtstp: contraction number = 1.833643e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.857981e-04
Vprtstp: contraction number = 2.351492e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.329714e-04
Vprtstp: contraction number = 2.964774e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 8.709385e-05
Vprtstp: contraction number = 3.738393e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.610663e-05
Vprtstp: contraction number = 4.145715e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.686919e-05
Vprtstp: contraction number = 4.672046e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 8.206797e-06
Vprtstp: contraction number = 4.864963e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.977734e-06
Vprtstp: contraction number = 4.846877e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.988499e-06
Vprtstp: contraction number = 4.999076e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 9.564751e-07
Vprtstp: contraction number = 4.810035e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.203661e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.923236e+00
Vpmg_setPart:  lower corner = (-59.4021, -44.3802, -82.3641)
Vpmg_setPart:  upper corner = (30.2741, 30.2772, 4.7761)
Vpmg_setPart:  actual minima = (-59.4021, -44.3802, -82.3641)
Vpmg_setPart:  actual maxima = (30.2741, 30.2772, 4.7761)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.226771154896E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.671000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.026673e+01
