##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:55:47 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 193, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7708 atoms
Valist_getStatistics:  Max atom coordinate:  (72.743, 37.919, 53.636)
Valist_getStatistics:  Min atom coordinate:  (7.407, -37.919, 5.056)
Valist_getStatistics:  Molecule center:  (40.075, 0, 29.346)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.722016, 0.693334, 0.685687
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.549715, 0.51201, 0.559595
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.761362, 0.738475, 0.816109 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.075 0 29.346
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 97.8362 66.5601 73.23
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -17.6863 -66.5601 -14.5379
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 84.0522 49.153 65.1601
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -3.9022 -49.153 -6.4681
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 84.0522 49.153 65.1601
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -3.9022 -49.153 -6.4681
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.285902
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.265728e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.074720e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 065)
Vbuildops: Galer: (041, 049, 033)
Vbuildops: Galer: (021, 025, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.800110e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.055081e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.964156e-02
Vprtstp: contraction number = 7.964156e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.048886e-02
Vprtstp: contraction number = 1.317008e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.929781e-03
Vprtstp: contraction number = 2.793231e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.954860e-04
Vprtstp: contraction number = 3.056494e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.838452e-04
Vprtstp: contraction number = 5.403157e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.948937e-04
Vprtstp: contraction number = 4.028018e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.158069e-04
Vprtstp: contraction number = 5.942057e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.868391e-05
Vprtstp: contraction number = 4.203885e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.885397e-05
Vprtstp: contraction number = 5.926799e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.231997e-05
Vprtstp: contraction number = 4.269765e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 7.266639e-06
Vprtstp: contraction number = 5.898261e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.128163e-06
Vprtstp: contraction number = 4.304828e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.840187e-06
Vprtstp: contraction number = 5.882644e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.958800e-07
Vprtstp: contraction number = 4.324996e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 8.259451e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 9.022474e+00
Vpmg_setPart:  lower corner = (-17.6863, -66.5601, -14.5379)
Vpmg_setPart:  upper corner = (97.8362, 66.5601, 73.23)
Vpmg_setPart:  actual minima = (-17.6863, -66.5601, -14.5379)
Vpmg_setPart:  actual maxima = (97.8362, 66.5601, 73.23)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.926014420482E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.589000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 39.2478
Vpbe_ctor2:  solute dimensions = 67.9544 x 78.306 x 51.6282
Vpbe_ctor2:  solute charge = 18
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (78.116, 88.618, 61.36)
Vclist_setupGrid:  Grid lower corner = (1.017, -44.309, -1.334)
Vclist_assignAtoms:  Have 7760195 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -3.9022, -49.153, -6.4681
VPMG::focusFillBound -- New mesh maxs = 84.0522, 49.153, 65.1601
VPMG::focusFillBound -- Old mesh mins = -17.6863, -66.5601, -14.5379
VPMG::focusFillBound -- Old mesh maxs = 97.8362, 66.5601, 73.23
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-3.9022, -49.153, -6.4681)
Vpmg_setPart:  upper corner = (84.0522, 49.153, 65.1601)
Vpmg_setPart:  actual minima = (-17.6863, -66.5601, -14.5379)
Vpmg_setPart:  actual maxima = (97.8362, 66.5601, 73.23)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-3.9022, -49.153, -6.4681)
VPMG::extEnergy    Disj part upper corner = (84.0522, 49.153, 65.1601)
VPMG::extEnergy    Old lower corner = (-17.6863, -66.5601, -14.5379)
VPMG::extEnergy    Old upper corner = (97.8362, 66.5601, 73.23)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.146756 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.190273 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.271425
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.781704e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 193, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.074970e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 097, 065)
Vbuildops: Galer: (041, 049, 033)
Vbuildops: Galer: (021, 025, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.687020e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.487483e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.076404e-01
Vprtstp: contraction number = 1.076404e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.412925e-02
Vprtstp: contraction number = 1.312634e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.852774e-03
Vprtstp: contraction number = 2.019055e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 7.334248e-04
Vprtstp: contraction number = 2.570918e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.077860e-04
Vprtstp: contraction number = 4.196558e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.204425e-04
Vprtstp: contraction number = 3.913191e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.395010e-05
Vprtstp: contraction number = 5.309594e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.688619e-05
Vprtstp: contraction number = 4.204246e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.459135e-05
Vprtstp: contraction number = 5.427079e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.257971e-06
Vprtstp: contraction number = 4.288822e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.408163e-06
Vprtstp: contraction number = 5.446115e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.479764e-06
Vprtstp: contraction number = 4.341822e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 8.067229e-07
Vprtstp: contraction number = 5.451702e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.682662e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.435868e+00
Vpmg_setPart:  lower corner = (-3.9022, -49.153, -6.4681)
Vpmg_setPart:  upper corner = (84.0522, 49.153, 65.1601)
Vpmg_setPart:  actual minima = (-3.9022, -49.153, -6.4681)
Vpmg_setPart:  actual maxima = (84.0522, 49.153, 65.1601)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.267953271406E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.973000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 2.358999e+01
