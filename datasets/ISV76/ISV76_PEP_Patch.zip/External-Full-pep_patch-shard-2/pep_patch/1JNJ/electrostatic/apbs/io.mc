##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:51:11 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (97, 161, 97)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 1640 atoms
Valist_getStatistics:  Max atom coordinate:  (16.973, 24.748, 14.953)
Valist_getStatistics:  Min atom coordinate:  (-16.529, -26.22, -14.032)
Valist_getStatistics:  Molecule center:  (0.222, -0.736, 0.4605)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.627654, 0.573922, 0.567931
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.577542, 0.462601, 0.54241
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.920159, 0.806035, 0.955064 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 0.222 -0.736 0.4605
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 30.3494 45.1778 27.7212
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -29.9054 -46.6497 -26.8002
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 27.944 36.2721 26.4962
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.5 -37.7441 -25.5752
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 27.944 36.2721 26.4962
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.5 -37.7441 -25.5752
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.266019
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 7.034420e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 161, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.034100e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 081, 049)
Vbuildops: Galer: (025, 041, 025)
Vbuildops: Galer: (013, 021, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.565850e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.376210e-01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.145542e-01
Vprtstp: contraction number = 1.145542e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.525307e-02
Vprtstp: contraction number = 1.331516e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.411884e-03
Vprtstp: contraction number = 1.581245e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.100414e-04
Vprtstp: contraction number = 1.700087e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 7.770044e-05
Vprtstp: contraction number = 1.894941e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.547110e-05
Vprtstp: contraction number = 1.991121e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.438117e-06
Vprtstp: contraction number = 2.222283e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 7.670403e-07
Vprtstp: contraction number = 2.230990e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.646605e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.874120e+00
Vpmg_setPart:  lower corner = (-29.9054, -46.6497, -26.8002)
Vpmg_setPart:  upper corner = (30.3494, 45.1778, 27.7212)
Vpmg_setPart:  actual minima = (-29.9054, -46.6497, -26.8002)
Vpmg_setPart:  actual maxima = (30.3494, 45.1778, 27.7212)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.827880612798E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.502000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 28.2522
Vpbe_ctor2:  solute dimensions = 35.444 x 54.0162 x 32.0714
Vpbe_ctor2:  solute charge = -2
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 70 x 75 x 64 table
Vclist_ctor2:  Using 70 x 75 x 64 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (46.282, 63.748, 41.765)
Vclist_setupGrid:  Grid lower corner = (-22.919, -32.61, -20.422)
Vclist_assignAtoms:  Have 3824415 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.5, -37.7441, -25.5752
VPMG::focusFillBound -- New mesh maxs = 27.944, 36.2721, 26.4962
VPMG::focusFillBound -- Old mesh mins = -29.9054, -46.6497, -26.8002
VPMG::focusFillBound -- Old mesh maxs = 30.3494, 45.1778, 27.7212
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-27.5, -37.7441, -25.5752)
Vpmg_setPart:  upper corner = (27.944, 36.2721, 26.4962)
Vpmg_setPart:  actual minima = (-29.9054, -46.6497, -26.8002)
Vpmg_setPart:  actual maxima = (30.3494, 45.1778, 27.7212)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-27.5, -37.7441, -25.5752)
VPMG::extEnergy    Disj part upper corner = (27.944, 36.2721, 26.4962)
VPMG::extEnergy    Old lower corner = (-29.9054, -46.6497, -26.8002)
VPMG::extEnergy    Old upper corner = (30.3494, 45.1778, 27.7212)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0323904 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0413009 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.262860
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 8.239250e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (097, 161, 097)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.912800e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (049, 081, 049)
Vbuildops: Galer: (025, 041, 025)
Vbuildops: Galer: (013, 021, 013)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.632530e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.658249e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.361779e-01
Vprtstp: contraction number = 1.361779e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.983263e-02
Vprtstp: contraction number = 1.456376e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.298681e-03
Vprtstp: contraction number = 1.663260e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.874124e-04
Vprtstp: contraction number = 1.780749e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.116176e-04
Vprtstp: contraction number = 1.900158e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.247084e-05
Vprtstp: contraction number = 2.013198e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.928373e-06
Vprtstp: contraction number = 2.193230e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.115514e-06
Vprtstp: contraction number = 2.263453e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.733985e-07
Vprtstp: contraction number = 2.450874e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.803068e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.033369e+00
Vpmg_setPart:  lower corner = (-27.5, -37.7441, -25.5752)
Vpmg_setPart:  upper corner = (27.944, 36.2721, 26.4962)
Vpmg_setPart:  actual minima = (-27.5, -37.7441, -25.5752)
Vpmg_setPart:  actual maxima = (27.944, 36.2721, 26.4962)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.113586937683E+04 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.452000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.850363e+00
