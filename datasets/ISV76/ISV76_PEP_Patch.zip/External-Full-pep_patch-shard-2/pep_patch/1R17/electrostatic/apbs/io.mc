##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:56:39 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (129, 129, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 5124 atoms
Valist_getStatistics:  Max atom coordinate:  (77.878, 40.675, 140.763)
Valist_getStatistics:  Min atom coordinate:  (29.157, -1.775, 46.873)
Valist_getStatistics:  Molecule center:  (53.5175, 19.45, 93.818)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.683336, 0.605601, 0.736238
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.558213, 0.512486, 0.522367
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.816893, 0.846244, 0.709508 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 53.5175 19.45 93.818
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 97.251 58.2084 176.277
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 9.784 -19.3085 11.3593
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 89.2431 52.2491 152.323
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 17.7919 -13.3491 35.3129
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 89.2431 52.2491 152.323
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 17.7919 -13.3491 35.3129
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.850403
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.695998e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.023180e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 113)
Vbuildops: Galer: (033, 033, 057)
Vbuildops: Galer: (017, 017, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.593010e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.245197e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.362103e-02
Vprtstp: contraction number = 9.362103e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.256103e-02
Vprtstp: contraction number = 1.341689e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.278433e-03
Vprtstp: contraction number = 1.813890e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.185583e-04
Vprtstp: contraction number = 1.837045e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.138920e-04
Vprtstp: contraction number = 2.721054e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.700069e-05
Vprtstp: contraction number = 2.370728e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.502756e-06
Vprtstp: contraction number = 3.519449e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.692211e-06
Vprtstp: contraction number = 2.833084e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.052031e-06
Vprtstp: contraction number = 3.907686e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.344946e-07
Vprtstp: contraction number = 3.179511e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.450166e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.981415e+00
Vpmg_setPart:  lower corner = (9.784, -19.3085, 11.3593)
Vpmg_setPart:  upper corner = (97.251, 58.2084, 176.277)
Vpmg_setPart:  actual minima = (9.784, -19.3085, 11.3593)
Vpmg_setPart:  actual maxima = (97.251, 58.2084, 176.277)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.451437398480E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.323000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.6745
Vpbe_ctor2:  solute dimensions = 51.4512 x 45.5982 x 97.0102
Vpbe_ctor2:  solute charge = -20
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (61.501, 55.23, 106.67)
Vclist_setupGrid:  Grid lower corner = (22.767, -8.165, 40.483)
Vclist_assignAtoms:  Have 5983958 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 17.7919, -13.3491, 35.3129
VPMG::focusFillBound -- New mesh maxs = 89.2431, 52.2491, 152.323
VPMG::focusFillBound -- Old mesh mins = 9.784, -19.3085, 11.3593
VPMG::focusFillBound -- Old mesh maxs = 97.251, 58.2084, 176.277
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (17.7919, -13.3491, 35.3129)
Vpmg_setPart:  upper corner = (89.2431, 52.2491, 152.323)
Vpmg_setPart:  actual minima = (9.784, -19.3085, 11.3593)
Vpmg_setPart:  actual maxima = (97.251, 58.2084, 176.277)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (17.7919, -13.3491, 35.3129)
VPMG::extEnergy    Disj part upper corner = (89.2431, 52.2491, 152.323)
VPMG::extEnergy    Old lower corner = (9.784, -19.3085, 11.3593)
VPMG::extEnergy    Old upper corner = (97.251, 58.2084, 176.277)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 2.80175 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 1.75423 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.853731
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.118522e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (129, 129, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 1.022080e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (065, 065, 113)
Vbuildops: Galer: (033, 033, 057)
Vbuildops: Galer: (017, 017, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.630580e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.037750e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.169461e-01
Vprtstp: contraction number = 1.169461e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.540492e-02
Vprtstp: contraction number = 1.317266e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.545182e-03
Vprtstp: contraction number = 1.652188e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.583370e-04
Vprtstp: contraction number = 1.800802e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.105427e-04
Vprtstp: contraction number = 2.411822e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.492366e-05
Vprtstp: contraction number = 2.254663e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 7.752818e-06
Vprtstp: contraction number = 3.110626e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.004065e-06
Vprtstp: contraction number = 2.584950e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 7.394698e-07
Vprtstp: contraction number = 3.689849e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.901421e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.440950e+00
Vpmg_setPart:  lower corner = (17.7919, -13.3491, 35.3129)
Vpmg_setPart:  upper corner = (89.2431, 52.2491, 152.323)
Vpmg_setPart:  actual minima = (17.7919, -13.3491, 35.3129)
Vpmg_setPart:  actual maxima = (89.2431, 52.2491, 152.323)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.330662751821E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 6.249000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.629716e+01
