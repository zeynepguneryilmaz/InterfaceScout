##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:49:53 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 225, 193)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 10277 atoms
Valist_getStatistics:  Max atom coordinate:  (-19.812, 57.208, 7.965)
Valist_getStatistics:  Min atom coordinate:  (-86.855, -27.454, -62.759)
Valist_getStatistics:  Molecule center:  (-53.3335, 14.877, -27.397)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.611858, 0.660222, 0.647992
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.464083, 0.477652, 0.485339
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.758482, 0.723471, 0.748988 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = -53.3335 14.877 -27.397
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 5.4049 88.8219 34.8103
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -112.072 -59.0679 -89.6043
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = -8.7815 68.374 19.1955
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -97.8855 -38.62 -73.9895
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = -8.7815 68.374 19.1955
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -97.8855 -38.62 -73.9895
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433990 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.743714
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.365389e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.221720e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 097)
Vbuildops: Galer: (049, 057, 049)
Vbuildops: Galer: (025, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.764191e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 5.542662e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 8.895261e-02
Vprtstp: contraction number = 8.895261e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.271006e-02
Vprtstp: contraction number = 1.428858e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.669386e-03
Vprtstp: contraction number = 2.100215e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.524300e-04
Vprtstp: contraction number = 3.567974e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.113713e-04
Vprtstp: contraction number = 4.319176e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.508246e-04
Vprtstp: contraction number = 6.097280e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.360186e-04
Vprtstp: contraction number = 5.422856e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.907614e-05
Vprtstp: contraction number = 6.548822e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.994645e-05
Vprtstp: contraction number = 5.607164e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.296569e-05
Vprtstp: contraction number = 6.600207e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.866910e-05
Vprtstp: contraction number = 5.663192e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.234645e-05
Vprtstp: contraction number = 6.613308e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 7.019736e-06
Vprtstp: contraction number = 5.685629e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 4.646278e-06
Vprtstp: contraction number = 6.618879e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 2.646029e-06
Vprtstp: contraction number = 5.694943e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.752274e-06
Vprtstp: contraction number = 6.622280e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 9.985488e-07
Vprtstp: contraction number = 5.698587e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.991038e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.205491e+01
Vpmg_setPart:  lower corner = (-112.072, -59.0679, -89.6043)
Vpmg_setPart:  upper corner = (5.4049, 88.8219, 34.8103)
Vpmg_setPart:  actual minima = (-112.072, -59.0679, -89.6043)
Vpmg_setPart:  actual maxima = (5.4049, 88.8219, 34.8102)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.035938800300E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.443100e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 51.2678
Vpbe_ctor2:  solute dimensions = 69.104 x 86.994 x 73.185
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (79.823, 97.442, 83.504)
Vclist_setupGrid:  Grid lower corner = (-93.245, -33.844, -69.149)
Vclist_assignAtoms:  Have 7433990 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -97.8855, -38.62, -73.9895
VPMG::focusFillBound -- New mesh maxs = -8.7815, 68.374, 19.1955
VPMG::focusFillBound -- Old mesh mins = -112.072, -59.0679, -89.6043
VPMG::focusFillBound -- Old mesh maxs = 5.4049, 88.8219, 34.8103
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-97.8855, -38.62, -73.9895)
Vpmg_setPart:  upper corner = (-8.7815, 68.374, 19.1955)
Vpmg_setPart:  actual minima = (-112.072, -59.0679, -89.6043)
Vpmg_setPart:  actual maxima = (5.4049, 88.8219, 34.8102)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-97.8855, -38.62, -73.9895)
VPMG::extEnergy    Disj part upper corner = (-8.7815, 68.374, 19.1955)
VPMG::extEnergy    Old lower corner = (-112.072, -59.0679, -89.6043)
VPMG::extEnergy    Old upper corner = (5.4049, 88.8219, 34.8102)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0254738 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0578714 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 1.707302
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.429356e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 193)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.202910e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 097)
Vbuildops: Galer: (049, 057, 049)
Vbuildops: Galer: (025, 029, 025)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.758816e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 3.208420e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.261163e-01
Vprtstp: contraction number = 1.261163e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.742873e-02
Vprtstp: contraction number = 1.381957e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.071436e-03
Vprtstp: contraction number = 1.762283e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 8.164400e-04
Vprtstp: contraction number = 2.658170e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.696289e-04
Vprtstp: contraction number = 3.302495e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.299061e-04
Vprtstp: contraction number = 4.817958e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.612494e-05
Vprtstp: contraction number = 4.320425e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 3.154206e-05
Vprtstp: contraction number = 5.619972e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.455324e-05
Vprtstp: contraction number = 4.613915e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 8.501486e-06
Vprtstp: contraction number = 5.841646e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.079625e-06
Vprtstp: contraction number = 4.798720e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.428197e-06
Vprtstp: contraction number = 5.952009e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.199046e-06
Vprtstp: contraction number = 4.938008e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 7.203257e-07
Vprtstp: contraction number = 6.007492e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 1.645190e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 1.858473e+01
Vpmg_setPart:  lower corner = (-97.8855, -38.62, -73.9895)
Vpmg_setPart:  upper corner = (-8.7815, 68.374, 19.1955)
Vpmg_setPart:  actual minima = (-97.8855, -38.62, -73.9895)
Vpmg_setPart:  actual maxima = (-8.7815, 68.374, 19.1955)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 5.254908836748E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.449300e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 5.119811e+01
