##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:52:34 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (225, 257, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 31356 atoms
Valist_getStatistics:  Max atom coordinate:  (64.733, 91.652, 95.334)
Valist_getStatistics:  Min atom coordinate:  (-24.987, -6.35, -11.267)
Valist_getStatistics:  Molecule center:  (19.873, 42.651, 42.0335)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.703481, 0.668498, 0.725503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.503098, 0.471359, 0.504891
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.715155, 0.705102, 0.695919 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 19.873 42.651 42.0335
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 98.6629 128.219 134.898
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -58.9169 -42.9168 -50.8308
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 76.22 102.985 106.66
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -36.474 -17.683 -22.5926
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 76.22 102.985 106.66
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -36.474 -17.683 -22.5926
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -12
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13020786 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 6.266716
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.447007e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 257, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.974400e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 129, 129)
Vbuildops: Galer: (057, 065, 065)
Vbuildops: Galer: (029, 033, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 5.667174e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.591616e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 7.371830e-02
Vprtstp: contraction number = 7.371830e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.485283e-02
Vprtstp: contraction number = 2.014809e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.588262e-03
Vprtstp: contraction number = 5.108966e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.627618e-03
Vprtstp: contraction number = 4.780566e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.000076e-03
Vprtstp: contraction number = 8.270098e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.656745e-03
Vprtstp: contraction number = 5.522345e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.384535e-03
Vprtstp: contraction number = 8.356959e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.003600e-04
Vprtstp: contraction number = 5.780713e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.697385e-04
Vprtstp: contraction number = 8.367966e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.969538e-04
Vprtstp: contraction number = 5.926996e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.352675e-04
Vprtstp: contraction number = 8.446009e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.023604e-04
Vprtstp: contraction number = 6.035790e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.729558e-04
Vprtstp: contraction number = 8.546918e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.057801e-04
Vprtstp: contraction number = 6.116021e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 9.142641e-05
Vprtstp: contraction number = 8.643060e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 5.651210e-05
Vprtstp: contraction number = 6.181157e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 4.927666e-05
Vprtstp: contraction number = 8.719666e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.070247e-05
Vprtstp: contraction number = 6.230632e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.693973e-05
Vprtstp: contraction number = 8.774448e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.688901e-05
Vprtstp: contraction number = 6.269183e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.488471e-05
Vprtstp: contraction number = 8.813251e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 9.377131e-06
Vprtstp: contraction number = 6.299843e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 8.289197e-06
Vprtstp: contraction number = 8.839801e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 5.242314e-06
Vprtstp: contraction number = 6.324273e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 4.643203e-06
Vprtstp: contraction number = 8.857162e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 2.945546e-06
Vprtstp: contraction number = 6.343781e-01
Vprtstp: iteration = 27
Vprtstp: relative residual = 2.612124e-06
Vprtstp: contraction number = 8.868047e-01
Vprtstp: iteration = 28
Vprtstp: relative residual = 1.661173e-06
Vprtstp: contraction number = 6.359472e-01
Vprtstp: iteration = 29
Vprtstp: relative residual = 1.474213e-06
Vprtstp: contraction number = 8.874530e-01
Vprtstp: iteration = 30
Vprtstp: relative residual = 9.393988e-07
Vprtstp: contraction number = 6.372205e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.363375e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 7.001512e+01
Vpmg_setPart:  lower corner = (-58.9169, -42.9168, -50.8308)
Vpmg_setPart:  upper corner = (98.6629, 128.219, 134.898)
Vpmg_setPart:  actual minima = (-58.9169, -42.9168, -50.8308)
Vpmg_setPart:  actual maxima = (98.6629, 128.219, 134.898)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.706146468562E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.934400e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 59.7694
Vpbe_ctor2:  solute dimensions = 92.694 x 100.668 x 109.252
Vpbe_ctor2:  solute charge = -12
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (102.5, 110.782, 119.381)
Vclist_setupGrid:  Grid lower corner = (-31.377, -12.74, -17.657)
Vclist_assignAtoms:  Have 13020786 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -36.474, -17.683, -22.5926
VPMG::focusFillBound -- New mesh maxs = 76.22, 102.985, 106.66
VPMG::focusFillBound -- Old mesh mins = -58.9169, -42.9168, -50.8308
VPMG::focusFillBound -- Old mesh maxs = 98.6629, 128.219, 134.898
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-36.474, -17.683, -22.5926)
Vpmg_setPart:  upper corner = (76.22, 102.985, 106.66)
Vpmg_setPart:  actual minima = (-58.9169, -42.9168, -50.8308)
Vpmg_setPart:  actual maxima = (98.6629, 128.219, 134.898)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-36.474, -17.683, -22.5926)
VPMG::extEnergy    Disj part upper corner = (76.22, 102.985, 106.66)
VPMG::extEnergy    Old lower corner = (-58.9169, -42.9168, -50.8308)
VPMG::extEnergy    Old upper corner = (98.6629, 128.219, 134.898)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0434623 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0874883 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 6.328974
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.259933e+01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (225, 257, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 4.250950e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (113, 129, 129)
Vbuildops: Galer: (057, 065, 065)
Vbuildops: Galer: (029, 033, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 6.150125e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 9.915952e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.104309e-01
Vprtstp: contraction number = 1.104309e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.578130e-02
Vprtstp: contraction number = 1.429066e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.831989e-03
Vprtstp: contraction number = 2.428183e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 1.560233e-03
Vprtstp: contraction number = 4.071600e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 8.800575e-04
Vprtstp: contraction number = 5.640553e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 4.941670e-04
Vprtstp: contraction number = 5.615167e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 3.124706e-04
Vprtstp: contraction number = 6.323179e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 1.801017e-04
Vprtstp: contraction number = 5.763795e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.165941e-04
Vprtstp: contraction number = 6.473793e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 6.747507e-05
Vprtstp: contraction number = 5.787178e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 4.431413e-05
Vprtstp: contraction number = 6.567481e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.566214e-05
Vprtstp: contraction number = 5.790961e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.703907e-05
Vprtstp: contraction number = 6.639770e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 9.863905e-06
Vprtstp: contraction number = 5.788992e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.606706e-06
Vprtstp: contraction number = 6.697860e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.821841e-06
Vprtstp: contraction number = 5.784790e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.578164e-06
Vprtstp: contraction number = 6.745869e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.490157e-06
Vprtstp: contraction number = 5.779915e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.011292e-06
Vprtstp: contraction number = 6.786481e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 5.840395e-07
Vprtstp: contraction number = 5.775182e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.240821e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.929850e+01
Vpmg_setPart:  lower corner = (-36.474, -17.683, -22.5926)
Vpmg_setPart:  upper corner = (76.22, 102.985, 106.66)
Vpmg_setPart:  actual minima = (-36.474, -17.683, -22.5926)
Vpmg_setPart:  actual maxima = (76.22, 102.985, 106.66)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.526314670961E+06 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.695600e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.470028e+02
