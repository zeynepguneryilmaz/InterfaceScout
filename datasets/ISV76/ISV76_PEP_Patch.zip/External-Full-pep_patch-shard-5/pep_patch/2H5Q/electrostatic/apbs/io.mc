##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:07 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 129, 129)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 3431 atoms
Valist_getStatistics:  Max atom coordinate:  (65.857, 41, 36.694)
Valist_getStatistics:  Min atom coordinate:  (14.654, -4.125, -7.327)
Valist_getStatistics:  Molecule center:  (40.2555, 18.4375, 14.6835)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.576259, 0.643442, 0.62878
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.463976, 0.534745, 0.52612
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.805152, 0.83107, 0.836732 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.2555 18.4375 14.6835
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 86.3562 59.6178 54.9254
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -5.84525 -22.7428 -25.5584
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 77.3736 52.6612 48.3552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 3.1374 -15.7862 -18.9882
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 77.3736 52.6612 48.3552
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 3.1374 -15.7862 -18.9882
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.439242
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 9.294810e-01
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.675900e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.284810e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.261652e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.685398e-02
Vprtstp: contraction number = 9.685398e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.307943e-02
Vprtstp: contraction number = 1.350427e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.436640e-03
Vprtstp: contraction number = 1.862956e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.957794e-04
Vprtstp: contraction number = 2.855488e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.630385e-04
Vprtstp: contraction number = 3.780486e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.362859e-04
Vprtstp: contraction number = 5.181216e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 6.762458e-05
Vprtstp: contraction number = 4.961964e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 4.025707e-05
Vprtstp: contraction number = 5.953024e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 2.051915e-05
Vprtstp: contraction number = 5.097029e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.243016e-05
Vprtstp: contraction number = 6.057835e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.367135e-06
Vprtstp: contraction number = 5.122326e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 3.879660e-06
Vprtstp: contraction number = 6.093258e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.994211e-06
Vprtstp: contraction number = 5.140169e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.218759e-06
Vprtstp: contraction number = 6.111486e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.278397e-07
Vprtstp: contraction number = 5.151467e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.436921e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 4.758949e+00
Vpmg_setPart:  lower corner = (-5.84525, -22.7428, -25.5584)
Vpmg_setPart:  upper corner = (86.3562, 59.6178, 54.9254)
Vpmg_setPart:  actual minima = (-5.84525, -22.7428, -25.5584)
Vpmg_setPart:  actual maxima = (86.3563, 59.6178, 54.9254)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.083160778352E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.514000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 29.5622
Vpbe_ctor2:  solute dimensions = 54.2362 x 48.4474 x 47.3434
Vpbe_ctor2:  solute charge = -3
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (63.983, 57.905, 56.801)
Vclist_setupGrid:  Grid lower corner = (8.264, -10.515, -13.717)
Vclist_assignAtoms:  Have 6173784 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 3.1374, -15.7862, -18.9882
VPMG::focusFillBound -- New mesh maxs = 77.3736, 52.6612, 48.3552
VPMG::focusFillBound -- Old mesh mins = -5.84525, -22.7428, -25.5584
VPMG::focusFillBound -- Old mesh maxs = 86.3563, 59.6178, 54.9254
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (3.1374, -15.7862, -18.9882)
Vpmg_setPart:  upper corner = (77.3736, 52.6612, 48.3552)
Vpmg_setPart:  actual minima = (-5.84525, -22.7428, -25.5584)
Vpmg_setPart:  actual maxima = (86.3563, 59.6178, 54.9254)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (3.1374, -15.7862, -18.9882)
VPMG::extEnergy    Disj part upper corner = (77.3736, 52.6612, 48.3552)
VPMG::extEnergy    Old lower corner = (-5.84525, -22.7428, -25.5584)
VPMG::extEnergy    Old upper corner = (86.3563, 59.6178, 54.9254)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0281776 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0631792 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.438610
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.140542e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 129, 129)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 5.856700e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 065, 065)
Vbuildops: Galer: (041, 033, 033)
Vbuildops: Galer: (021, 017, 017)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 2.314960e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.180341e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.230708e-01
Vprtstp: contraction number = 1.230708e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.669732e-02
Vprtstp: contraction number = 1.356725e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 2.708948e-03
Vprtstp: contraction number = 1.622385e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.417897e-04
Vprtstp: contraction number = 2.000000e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.443436e-04
Vprtstp: contraction number = 2.664199e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.000923e-05
Vprtstp: contraction number = 3.464597e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.019549e-05
Vprtstp: contraction number = 4.038353e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 9.753910e-06
Vprtstp: contraction number = 4.829746e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 4.483289e-06
Vprtstp: contraction number = 4.596402e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.331836e-06
Vprtstp: contraction number = 5.201174e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.086131e-06
Vprtstp: contraction number = 4.657834e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 5.716281e-07
Vprtstp: contraction number = 5.262978e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 3.564145e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.894851e+00
Vpmg_setPart:  lower corner = (3.1374, -15.7862, -18.9882)
Vpmg_setPart:  upper corner = (77.3736, 52.6612, 48.3552)
Vpmg_setPart:  actual minima = (3.1374, -15.7862, -18.9882)
Vpmg_setPart:  actual maxima = (77.3736, 52.6612, 48.3552)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 1.550287994252E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 3.376000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.133662e+01
