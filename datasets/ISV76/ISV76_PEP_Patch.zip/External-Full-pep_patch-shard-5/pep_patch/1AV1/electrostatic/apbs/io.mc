##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:50:00 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (257, 289, 257)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 13204 atoms
Valist_getStatistics:  Max atom coordinate:  (96.299, 79.336, 79.835)
Valist_getStatistics:  Min atom coordinate:  (-15.857, -37.771, -28.399)
Valist_getStatistics:  Molecule center:  (40.221, 20.7825, 25.718)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.764153, 0.707785, 0.731784
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.527627, 0.485789, 0.508586
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.690473, 0.686351, 0.694995 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 40.221 20.7825 25.718
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 138.033 122.704 119.386
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = -57.5905 -81.1386 -67.9503
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 107.757 90.7361 90.817
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = -27.3152 -49.1711 -39.381
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 107.757 90.7361 90.817
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = -27.3152 -49.1711 -39.381
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.057756
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.223467e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 289, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.963740e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 145, 129)
Vbuildops: Galer: (065, 073, 065)
Vbuildops: Galer: (033, 037, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.934886e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.389067e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.796141e-02
Vprtstp: contraction number = 9.796141e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.936544e-02
Vprtstp: contraction number = 1.976844e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 9.617948e-03
Vprtstp: contraction number = 4.966551e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 4.372897e-03
Vprtstp: contraction number = 4.546601e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.814175e-03
Vprtstp: contraction number = 6.435493e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.574001e-03
Vprtstp: contraction number = 5.593117e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 9.755989e-04
Vprtstp: contraction number = 6.198210e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 5.813250e-04
Vprtstp: contraction number = 5.958648e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.480122e-04
Vprtstp: contraction number = 5.986534e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 2.147948e-04
Vprtstp: contraction number = 6.172048e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 1.258055e-04
Vprtstp: contraction number = 5.857010e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 7.936725e-05
Vprtstp: contraction number = 6.308726e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 4.585923e-05
Vprtstp: contraction number = 5.778105e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 2.934294e-05
Vprtstp: contraction number = 6.398480e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 1.681466e-05
Vprtstp: contraction number = 5.730393e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 1.085987e-05
Vprtstp: contraction number = 6.458576e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 6.192260e-06
Vprtstp: contraction number = 5.701964e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 4.024730e-06
Vprtstp: contraction number = 6.499613e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.288249e-06
Vprtstp: contraction number = 5.685473e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 1.493835e-06
Vprtstp: contraction number = 6.528287e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 8.479567e-07
Vprtstp: contraction number = 5.676376e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 4.809235e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.772778e+01
Vpmg_setPart:  lower corner = (-57.5905, -81.1386, -67.9503)
Vpmg_setPart:  upper corner = (138.033, 122.704, 119.386)
Vpmg_setPart:  actual minima = (-57.5905, -81.1386, -67.9503)
Vpmg_setPart:  actual maxima = (138.033, 122.704, 119.386)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.067092469849E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.598300e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 73.4403
Vpbe_ctor2:  solute dimensions = 115.072 x 119.907 x 110.198
Vpbe_ctor2:  solute charge = -24
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (124.936, 129.887, 121.014)
Vclist_setupGrid:  Grid lower corner = (-22.247, -44.161, -34.789)
Vclist_assignAtoms:  Have 4171471 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = -27.3152, -49.1711, -39.381
VPMG::focusFillBound -- New mesh maxs = 107.757, 90.7361, 90.817
VPMG::focusFillBound -- Old mesh mins = -57.5905, -81.1386, -67.9503
VPMG::focusFillBound -- Old mesh maxs = 138.033, 122.704, 119.386
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (-27.3152, -49.1711, -39.381)
Vpmg_setPart:  upper corner = (107.757, 90.7361, 90.817)
Vpmg_setPart:  actual minima = (-57.5905, -81.1386, -67.9503)
Vpmg_setPart:  actual maxima = (138.033, 122.704, 119.386)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (-27.3152, -49.1711, -39.381)
VPMG::extEnergy    Disj part upper corner = (107.757, 90.7361, 90.817)
VPMG::extEnergy    Old lower corner = (-57.5905, -81.1386, -67.9503)
VPMG::extEnergy    Old upper corner = (138.033, 122.704, 119.386)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.0531182 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.0917509 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.037115
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 5.722777e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (257, 289, 257)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 3.991250e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (129, 145, 129)
Vbuildops: Galer: (065, 073, 065)
Vbuildops: Galer: (033, 037, 033)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 8.896846e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 7.739774e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.419763e-01
Vprtstp: contraction number = 1.419763e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.329137e-02
Vprtstp: contraction number = 1.640511e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 7.996713e-03
Vprtstp: contraction number = 3.433338e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 3.544283e-03
Vprtstp: contraction number = 4.432175e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 2.472329e-03
Vprtstp: contraction number = 6.975540e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.658374e-03
Vprtstp: contraction number = 6.707741e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.187051e-03
Vprtstp: contraction number = 7.157921e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.728896e-04
Vprtstp: contraction number = 7.353429e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.097396e-04
Vprtstp: contraction number = 6.985300e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 4.662368e-04
Vprtstp: contraction number = 7.646489e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 3.210607e-04
Vprtstp: contraction number = 6.886217e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.504182e-04
Vprtstp: contraction number = 7.799713e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.711250e-04
Vprtstp: contraction number = 6.833570e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.349377e-04
Vprtstp: contraction number = 7.885329e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 9.184079e-05
Vprtstp: contraction number = 6.806162e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 7.289030e-05
Vprtstp: contraction number = 7.936594e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 4.950687e-05
Vprtstp: contraction number = 6.791969e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 3.945390e-05
Vprtstp: contraction number = 7.969378e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 2.676943e-05
Vprtstp: contraction number = 6.784991e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 2.139286e-05
Vprtstp: contraction number = 7.991527e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 1.450846e-05
Vprtstp: contraction number = 6.781917e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 1.161715e-05
Vprtstp: contraction number = 8.007153e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 7.877745e-06
Vprtstp: contraction number = 6.781135e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 6.316899e-06
Vprtstp: contraction number = 8.018664e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 4.283908e-06
Vprtstp: contraction number = 6.781663e-01
Vprtstp: iteration = 26
Vprtstp: relative residual = 3.438801e-06
Vprtstp: contraction number = 8.027253e-01
Vprtstp: iteration = 27
Vprtstp: relative residual = 2.332568e-06
Vprtstp: contraction number = 6.783086e-01
Vprtstp: iteration = 28
Vprtstp: relative residual = 1.873919e-06
Vprtstp: contraction number = 8.033717e-01
Vprtstp: iteration = 29
Vprtstp: relative residual = 1.271483e-06
Vprtstp: contraction number = 6.785152e-01
Vprtstp: iteration = 30
Vprtstp: relative residual = 1.022098e-06
Vprtstp: contraction number = 8.038635e-01
Vprtstp: iteration = 31
Vprtstp: relative residual = 6.937620e-07
Vprtstp: contraction number = 6.787624e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 7.110316e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 8.068006e+01
Vpmg_setPart:  lower corner = (-27.3152, -49.1711, -39.381)
Vpmg_setPart:  upper corner = (107.757, 90.7361, 90.817)
Vpmg_setPart:  actual minima = (-27.3152, -49.1711, -39.381)
Vpmg_setPart:  actual maxima = (107.757, 90.7361, 90.817)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 6.489074998152E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 2.689200e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.541499e+02
