##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:54:38 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (161, 161, 161)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 7002 atoms
Valist_getStatistics:  Max atom coordinate:  (124.994, 86.429, 69.912)
Valist_getStatistics:  Min atom coordinate:  (61.002, 24.367, 19.934)
Valist_getStatistics:  Molecule center:  (92.998, 55.398, 44.923)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.714036, 0.687873, 0.563233
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.545021, 0.529631, 0.456314
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.763296, 0.769955, 0.810169 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 92.998 55.398 44.923
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 150.121 110.428 89.9817
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 35.8751 0.36815 -0.13565
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 136.6 97.7685 81.4281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 49.3963 13.0275 8.4179
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 136.6 97.7685 81.4281
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 49.3963 13.0275 8.4179
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.926239
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 1.716639e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 8.701600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.991980e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 2.281499e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 9.649194e-02
Vprtstp: contraction number = 9.649194e-02
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.495035e-02
Vprtstp: contraction number = 1.549389e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.342299e-03
Vprtstp: contraction number = 2.235599e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 9.142828e-04
Vprtstp: contraction number = 2.735491e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 3.168493e-04
Vprtstp: contraction number = 3.465550e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 1.277059e-04
Vprtstp: contraction number = 4.030493e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 5.385922e-05
Vprtstp: contraction number = 4.217443e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.472651e-05
Vprtstp: contraction number = 4.590953e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.093879e-05
Vprtstp: contraction number = 4.423911e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 5.176818e-06
Vprtstp: contraction number = 4.732533e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.325410e-06
Vprtstp: contraction number = 4.491968e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.107354e-06
Vprtstp: contraction number = 4.761971e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 5.027673e-07
Vprtstp: contraction number = 4.540261e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 6.425176e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 6.972124e+00
Vpmg_setPart:  lower corner = (35.8751, 0.36815, -0.13565)
Vpmg_setPart:  upper corner = (150.121, 110.428, 89.9817)
Vpmg_setPart:  actual minima = (35.8751, 0.36815, -0.13565)
Vpmg_setPart:  actual maxima = (150.121, 110.428, 89.9817)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 2.009869612272E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.311000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 41.1554
Vpbe_ctor2:  solute dimensions = 67.2034 x 64.741 x 53.0102
Vpbe_ctor2:  solute charge = -14
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (76.772, 74.842, 62.758)
Vclist_setupGrid:  Grid lower corner = (54.612, 17.977, 13.544)
Vclist_assignAtoms:  Have 8079827 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 49.3963, 13.0275, 8.4179
VPMG::focusFillBound -- New mesh maxs = 136.6, 97.7685, 81.4281
VPMG::focusFillBound -- Old mesh mins = 35.8751, 0.36815, -0.13565
VPMG::focusFillBound -- Old mesh maxs = 150.121, 110.428, 89.9817
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (49.3963, 13.0275, 8.4179)
Vpmg_setPart:  upper corner = (136.6, 97.7685, 81.4281)
Vpmg_setPart:  actual minima = (35.8751, 0.36815, -0.13565)
Vpmg_setPart:  actual maxima = (150.121, 110.428, 89.9817)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (49.3963, 13.0275, 8.4179)
VPMG::extEnergy    Disj part upper corner = (136.6, 97.7685, 81.4281)
VPMG::extEnergy    Old lower corner = (35.8751, 0.36815, -0.13565)
VPMG::extEnergy    Old upper corner = (150.121, 110.428, 89.9817)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.217901 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.194228 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 0.917891
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 2.156628e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (161, 161, 161)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 9.055600e-02
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (081, 081, 081)
Vbuildops: Galer: (041, 041, 041)
Vbuildops: Galer: (021, 021, 021)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 3.949010e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 1.142797e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.238680e-01
Vprtstp: contraction number = 1.238680e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.760499e-02
Vprtstp: contraction number = 1.421270e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 3.071967e-03
Vprtstp: contraction number = 1.744941e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 6.693281e-04
Vprtstp: contraction number = 2.178826e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.771795e-04
Vprtstp: contraction number = 2.647125e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 5.845484e-05
Vprtstp: contraction number = 3.299188e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 2.074245e-05
Vprtstp: contraction number = 3.548457e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.544294e-06
Vprtstp: contraction number = 4.119231e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 3.427340e-06
Vprtstp: contraction number = 4.011262e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 1.524739e-06
Vprtstp: contraction number = 4.448753e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 6.418970e-07
Vprtstp: contraction number = 4.209881e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 5.407996e+00
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 5.953924e+00
Vpmg_setPart:  lower corner = (49.3963, 13.0275, 8.4179)
Vpmg_setPart:  upper corner = (136.6, 97.7685, 81.4281)
Vpmg_setPart:  actual minima = (49.3963, 13.0275, 8.4179)
Vpmg_setPart:  actual maxima = (136.6, 97.7685, 81.4281)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 3.241995228643E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 5.250000e-03
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 0.000000e+00
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 1.780194e+01
