##############################################################################
# MC-shell I/O capture file.
# Creation Date and Time:  Tue Nov 24 17:52:42 2026

##############################################################################
Hello world from PE 0
Vnm_tstart: starting timer 26 (APBS WALL CLOCK)..
NOsh_parseInput:  Starting file parsing...
NOsh: Parsing READ section
NOsh: Storing molecule 0 path apbs.pqr
NOsh: Done parsing READ section
NOsh: Done parsing READ section (nmol=1, ndiel=0, nkappa=0, ncharge=0, npot=0)
NOsh: Parsing ELEC section
NOsh_parseMG: Parsing parameters for MG calculation
NOsh_parseMG:  Parsing dime...
PBEparm_parseToken:  trying dime...
MGparm_parseToken:  trying dime...
NOsh_parseMG:  Parsing cglen...
PBEparm_parseToken:  trying cglen...
MGparm_parseToken:  trying cglen...
NOsh_parseMG:  Parsing fglen...
PBEparm_parseToken:  trying fglen...
MGparm_parseToken:  trying fglen...
NOsh_parseMG:  Parsing cgcent...
PBEparm_parseToken:  trying cgcent...
MGparm_parseToken:  trying cgcent...
NOsh_parseMG:  Parsing fgcent...
PBEparm_parseToken:  trying fgcent...
MGparm_parseToken:  trying fgcent...
NOsh_parseMG:  Parsing mol...
PBEparm_parseToken:  trying mol...
NOsh_parseMG:  Parsing lpbe...
PBEparm_parseToken:  trying lpbe...
NOsh: parsed lpbe
NOsh_parseMG:  Parsing bcfl...
PBEparm_parseToken:  trying bcfl...
NOsh_parseMG:  Parsing pdie...
PBEparm_parseToken:  trying pdie...
NOsh_parseMG:  Parsing sdie...
PBEparm_parseToken:  trying sdie...
NOsh_parseMG:  Parsing srfm...
PBEparm_parseToken:  trying srfm...
NOsh_parseMG:  Parsing chgm...
PBEparm_parseToken:  trying chgm...
MGparm_parseToken:  trying chgm...
NOsh_parseMG:  Parsing sdens...
PBEparm_parseToken:  trying sdens...
NOsh_parseMG:  Parsing srad...
PBEparm_parseToken:  trying srad...
NOsh_parseMG:  Parsing swin...
PBEparm_parseToken:  trying swin...
NOsh_parseMG:  Parsing temp...
PBEparm_parseToken:  trying temp...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing ion...
PBEparm_parseToken:  trying ion...
NOsh_parseMG:  Parsing calcenergy...
PBEparm_parseToken:  trying calcenergy...
NOsh_parseMG:  Parsing calcforce...
PBEparm_parseToken:  trying calcforce...
NOsh_parseMG:  Parsing write...
PBEparm_parseToken:  trying write...
NOsh_parseMG:  Parsing end...
MGparm_check:  checking MGparm object of type 1.
NOsh:  nlev = 4, dime = (193, 225, 225)
NOsh: Done parsing ELEC section (nelec = 1)
NOsh: Parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing PRINT section
NOsh: Done parsing file (got QUIT)
Valist_readPQR: Counted 16077 atoms
Valist_getStatistics:  Max atom coordinate:  (173.688, 74.257, 44.56)
Valist_getStatistics:  Min atom coordinate:  (96.627, -11.936, -38.103)
Valist_getStatistics:  Molecule center:  (135.157, 31.1605, 3.2285)
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1868):  coarse grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO(./src/generic/nosh.c, 1873):  fine grid center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1885):  Coarse grid spacing = 0.7093, 0.669102, 0.653613
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1887):  Fine grid spacing = 0.521402, 0.482875, 0.473764
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1889):  Displacement between fine and coarse grids = 0, 0, 0
NOsh:  2 levels of focusing with 0.735094, 0.721676, 0.724839 reductions
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1983):  starting mesh repositioning.
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1985):  coarse mesh center = 135.157 31.1605 3.2285
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1990):  coarse mesh upper corner = 203.25 106.1 76.4332
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 1995):  coarse mesh lower corner = 67.0647 -43.7789 -69.9762
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2000):  initial fine mesh upper corner = 185.212 85.2425 56.2901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2005):  initial fine mesh lower corner = 85.1029 -22.9215 -49.8331
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2066):  final fine mesh upper corner = 185.212 85.2425 56.2901
NOsh_setupCalcMGAUTO (./src/generic/nosh.c, 2071):  final fine mesh lower corner = 85.1029 -22.9215 -49.8331
NOsh_setupMGAUTO:  Resetting boundary flags
NOsh_setupCalc:  Mapping ELEC statement 0 (1) to calculation 1 (2)
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -45
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9495019 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.419621
Vpmg_fillco:  done filling coefficient arrays
Vpmg_fillco:  filling boundary arrays
Vpmg_fillco:  done filling boundary arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 3.908854e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.042850e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 113)
Vbuildops: Galer: (049, 057, 057)
Vbuildops: Galer: (025, 029, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.736233e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 6.029692e+00
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.030156e-01
Vprtstp: contraction number = 1.030156e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 2.121119e-02
Vprtstp: contraction number = 2.059028e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 1.286273e-02
Vprtstp: contraction number = 6.064125e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 5.181587e-03
Vprtstp: contraction number = 4.028373e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 4.233857e-03
Vprtstp: contraction number = 8.170966e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 2.003154e-03
Vprtstp: contraction number = 4.731274e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 1.613965e-03
Vprtstp: contraction number = 8.057122e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 8.275815e-04
Vprtstp: contraction number = 5.127628e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 6.562008e-04
Vprtstp: contraction number = 7.929138e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 3.534604e-04
Vprtstp: contraction number = 5.386467e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 2.772167e-04
Vprtstp: contraction number = 7.842934e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 1.540960e-04
Vprtstp: contraction number = 5.558685e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.198696e-04
Vprtstp: contraction number = 7.778891e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 6.802874e-05
Vprtstp: contraction number = 5.675228e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 5.258024e-05
Vprtstp: contraction number = 7.729122e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.026338e-05
Vprtstp: contraction number = 5.755656e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.327203e-05
Vprtstp: contraction number = 7.689831e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.352616e-05
Vprtstp: contraction number = 5.812195e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 1.035941e-05
Vprtstp: contraction number = 7.658799e-01
Vprtstp: iteration = 20
Vprtstp: relative residual = 6.062998e-06
Vprtstp: contraction number = 5.852647e-01
Vprtstp: iteration = 21
Vprtstp: relative residual = 4.628711e-06
Vprtstp: contraction number = 7.634361e-01
Vprtstp: iteration = 22
Vprtstp: relative residual = 2.722641e-06
Vprtstp: contraction number = 5.882071e-01
Vprtstp: iteration = 23
Vprtstp: relative residual = 2.073336e-06
Vprtstp: contraction number = 7.615165e-01
Vprtstp: iteration = 24
Vprtstp: relative residual = 1.224051e-06
Vprtstp: contraction number = 5.903777e-01
Vprtstp: iteration = 25
Vprtstp: relative residual = 9.302887e-07
Vprtstp: contraction number = 7.600079e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.998650e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 3.206997e+01
Vpmg_setPart:  lower corner = (67.0647, -43.7789, -69.9762)
Vpmg_setPart:  upper corner = (203.25, 106.1, 76.4332)
Vpmg_setPart:  actual minima = (67.0647, -43.7789, -69.9762)
Vpmg_setPart:  actual maxima = (203.25, 106.1, 76.4332)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 4.260001421544E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.336300e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vnm_tstart: starting timer 27 (Setup timer)..
Setting up PBE object...
Vpbe_ctor2:  solute radius = 53.0294
Vpbe_ctor2:  solute dimensions = 80.1092 x 88.164 x 86.1232
Vpbe_ctor2:  solute charge = -45
Vpbe_ctor2:  bulk ionic strength = 0.1
Vpbe_ctor2:  xkappa = 0.103925
Vpbe_ctor2:  Debye length = 9.62233
Vpbe_ctor2:  zkappa2 = 0.848263
Vpbe_ctor2:  zmagic = 7042.98
Vpbe_ctor2:  Constructing Vclist with 75 x 75 x 75 table
Vclist_ctor2:  Using 75 x 75 x 75 hash table
Vclist_ctor2:  automatic domain setup.
Vclist_ctor2:  Using 2.5 max radius
Vclist_setupGrid:  Grid lengths = (89.841, 98.973, 95.443)
Vclist_setupGrid:  Grid lower corner = (90.237, -18.326, -44.493)
Vclist_assignAtoms:  Have 9495019 atom entries
Vacc_storeParms:  Surf. density = 10
Vacc_storeParms:  Max area = 254.469
Vacc_storeParms:  Using 2584-point reference sphere
Setting up PDE object...
Vpmp_ctor2:  Using meth = 2, mgsolv = 1
Setting PDE center to local center...
Vpmg_ctor2:  Filling boundary with old solution!
VPMG::focusFillBound -- New mesh mins = 85.1029, -22.9215, -49.8331
VPMG::focusFillBound -- New mesh maxs = 185.212, 85.2425, 56.2901
VPMG::focusFillBound -- Old mesh mins = 67.0647, -43.7789, -69.9762
VPMG::focusFillBound -- Old mesh maxs = 203.25, 106.1, 76.4332
VPMG::extEnergy:  energy flag = 1
Vpmg_setPart:  lower corner = (85.1029, -22.9215, -49.8331)
Vpmg_setPart:  upper corner = (185.212, 85.2425, 56.2901)
Vpmg_setPart:  actual minima = (67.0647, -43.7789, -69.9762)
Vpmg_setPart:  actual maxima = (203.25, 106.1, 76.4332)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
VPMG::extEnergy:   Finding extEnergy dimensions...
VPMG::extEnergy    Disj part lower corner = (85.1029, -22.9215, -49.8331)
VPMG::extEnergy    Disj part upper corner = (185.212, 85.2425, 56.2901)
VPMG::extEnergy    Old lower corner = (67.0647, -43.7789, -69.9762)
VPMG::extEnergy    Old upper corner = (203.25, 106.1, 76.4332)
Vpmg_qmEnergy:  Calculating linear energy
VPMG::extEnergy: extQmEnergy = 0.277246 kT
Vpmg_qfEnergyVolume:  Calculating energy
VPMG::extEnergy: extQfEnergy = 0 kT
VPMG::extEnergy: extDiEnergy = 0.23224 kT
Vpmg_fillco:  filling in source term.
fillcoCharge:  Calling fillcoChargeSpline2...
Vpmg_fillco:  filling in source term.
Vpmg_fillco:  marking ion and solvent accessibility.
fillcoCoef:  Calling fillcoCoefMol...
Vacc_SASA: Time elapsed: 2.411082
Vpmg_fillco:  done filling coefficient arrays
Vnm_tstop: stopping timer 27 (Setup timer).  CPU TIME = 4.954437e+00
Vnm_tstart: starting timer 28 (Solver timer)..
Vnm_tstart: starting timer 30 (Vmgdrv2: fine problem setup)..
Vbuildops: Fine: (193, 225, 225)
Vbuildops: Operator stencil (lev, numdia) = (1, 4)
Vnm_tstop: stopping timer 30 (Vmgdrv2: fine problem setup).  CPU TIME = 2.069480e-01
Vnm_tstart: starting timer 30 (Vmgdrv2: coarse problem setup)..
Vbuildops: Galer: (097, 113, 113)
Vbuildops: Galer: (049, 057, 057)
Vbuildops: Galer: (025, 029, 029)
Vnm_tstop: stopping timer 30 (Vmgdrv2: coarse problem setup).  CPU TIME = 1.764184e+00
Vnm_tstart: starting timer 30 (Vmgdrv2: solve)..
Vnm_tstop: stopping timer 40 (MG iteration).  CPU TIME = 4.316008e+01
Vprtstp: iteration = 0
Vprtstp: relative residual = 1.000000e+00
Vprtstp: contraction number = 1.000000e+00
Vprtstp: iteration = 1
Vprtstp: relative residual = 1.279743e-01
Vprtstp: contraction number = 1.279743e-01
Vprtstp: iteration = 2
Vprtstp: relative residual = 1.977317e-02
Vprtstp: contraction number = 1.545089e-01
Vprtstp: iteration = 3
Vprtstp: relative residual = 6.745862e-03
Vprtstp: contraction number = 3.411624e-01
Vprtstp: iteration = 4
Vprtstp: relative residual = 2.272451e-03
Vprtstp: contraction number = 3.368659e-01
Vprtstp: iteration = 5
Vprtstp: relative residual = 1.521252e-03
Vprtstp: contraction number = 6.694323e-01
Vprtstp: iteration = 6
Vprtstp: relative residual = 6.534431e-04
Vprtstp: contraction number = 4.295429e-01
Vprtstp: iteration = 7
Vprtstp: relative residual = 4.581898e-04
Vprtstp: contraction number = 7.011932e-01
Vprtstp: iteration = 8
Vprtstp: relative residual = 2.171268e-04
Vprtstp: contraction number = 4.738795e-01
Vprtstp: iteration = 9
Vprtstp: relative residual = 1.502432e-04
Vprtstp: contraction number = 6.919609e-01
Vprtstp: iteration = 10
Vprtstp: relative residual = 7.618304e-05
Vprtstp: contraction number = 5.070647e-01
Vprtstp: iteration = 11
Vprtstp: relative residual = 5.186488e-05
Vprtstp: contraction number = 6.807930e-01
Vprtstp: iteration = 12
Vprtstp: relative residual = 2.755773e-05
Vprtstp: contraction number = 5.313369e-01
Vprtstp: iteration = 13
Vprtstp: relative residual = 1.848474e-05
Vprtstp: contraction number = 6.707644e-01
Vprtstp: iteration = 14
Vprtstp: relative residual = 1.013682e-05
Vprtstp: contraction number = 5.483882e-01
Vprtstp: iteration = 15
Vprtstp: relative residual = 6.717305e-06
Vprtstp: contraction number = 6.626642e-01
Vprtstp: iteration = 16
Vprtstp: relative residual = 3.762653e-06
Vprtstp: contraction number = 5.601432e-01
Vprtstp: iteration = 17
Vprtstp: relative residual = 2.470240e-06
Vprtstp: contraction number = 6.565155e-01
Vprtstp: iteration = 18
Vprtstp: relative residual = 1.403617e-06
Vprtstp: contraction number = 5.682109e-01
Vprtstp: iteration = 19
Vprtstp: relative residual = 9.151836e-07
Vprtstp: contraction number = 6.520179e-01
Vnm_tstop: stopping timer 30 (Vmgdrv2: solve).  CPU TIME = 2.292648e+01
Vnm_tstop: stopping timer 28 (Solver timer).  CPU TIME = 2.505500e+01
Vpmg_setPart:  lower corner = (85.1029, -22.9215, -49.8331)
Vpmg_setPart:  upper corner = (185.212, 85.2425, 56.2901)
Vpmg_setPart:  actual minima = (85.1029, -22.9215, -49.8331)
Vpmg_setPart:  actual maxima = (185.212, 85.2425, 56.2901)
Vpmg_setPart:  bflag[FRONT] = 0
Vpmg_setPart:  bflag[BACK] = 0
Vpmg_setPart:  bflag[LEFT] = 0
Vpmg_setPart:  bflag[RIGHT] = 0
Vpmg_setPart:  bflag[UP] = 0
Vpmg_setPart:  bflag[DOWN] = 0
Vnm_tstart: starting timer 29 (Energy timer)..
Vpmg_energy:  calculating only q-phi energy
Vpmg_qfEnergyVolume:  Calculating energy
Vpmg_energy:  qfEnergy = 7.791734886550E+05 kT
Vnm_tstop: stopping timer 29 (Energy timer).  CPU TIME = 1.333300e-02
Vnm_tstart: starting timer 30 (Force timer)..
Vnm_tstop: stopping timer 30 (Force timer).  CPU TIME = 1.000000e-06
Vgrid_writeDX:  Opening virtual socket...
Vgrid_writeDX:  Writing to virtual socket...
Vgrid_writeDX:  Writing comments for ASC format.
printEnergy:  Performing global reduction (sum)
Vcom_reduce:  Not compiled with MPI, doing simple copy.
Vnm_tstop: stopping timer 26 (APBS WALL CLOCK).  CPU TIME = 6.905428e+01
